% LNSI Exercise 3_1: Manually hand tuning of the weights
% Exercise class at :http://webcast.tuhh.de/Mediasite/Play/e6e3e15dee944bf79e183bdf47c175931d
clear
clc
%% Load data
load('approx.mat')

%% Plot original curve
figure()
plot(phi,g_phi,'DisplayName','Original Data','LineWidth',2)
grid on
legend
hold on

%% Grid input-axis
x=-10:0.1:10;


%% Weight choice 1
% CONDITIONS ON WEIGHTS derived in class
%w_1_10=7*w_1_11;
%w_1_11<0
%w_1_20=-5*w_1_21;

w_2_10=-1;
w_2_11=2;
w_2_12=8;

w_1_11=-3; % governs slope at the first inflection point. 
w_1_21=0.5;% governs slope at the second inflection point

w_1_10=7*w_1_11;
w_1_20=-5*w_1_21;

% compute output and plot
y1=w_2_11./(1+ exp(-1*(w_1_10+w_1_11*x))) + w_2_12./(1+ exp(-(w_1_20+w_1_21*x)))+w_2_10;
figure()
plot(phi,g_phi,'DisplayName','Original Data','LineWidth',2)
grid on
legend
hold on
plot(x,y1,'--','DisplayName','Weight Choice 1','LineWidth',1)

%% Weight choice 2
% CONDITIONS ON WEIGHTS derived in class
%w_1_10=7*w_1_11;
%w_1_11<0
%w_1_20=-5*w_1_21;

w_2_10=1;
w_2_11=-2;
w_2_12=8;

w_1_11=3; % governs slope at the first inflection point. 
w_1_21=0.5; % governs slope at the second inflection point. 

w_1_10=7*w_1_11;
w_1_20=-5*w_1_21;

% compute output and plot
y2=w_2_11./(1+ exp(-1*(w_1_10+w_1_11*x))) + w_2_12./(1+ exp(-(w_1_20+w_1_21*x)))+w_2_10;
figure()
plot(phi,g_phi,'DisplayName','Original Data','LineWidth',2)
grid on
legend
hold on
plot(x,y2,'-.','DisplayName','Weight choice 2','LineWidth',1.5)
%% Trained network Weights taken from nntoolbox for visualization



% Input to Layer1
w_1_11=0.5;
w_1_21=-3;

% Bias to Layer1

w_1_10=-2.5;
w_1_20=-21;

% Hidden Layer to Output layer

w_2_11=2.1811;
w_2_12= 0.54528;

% Bias to Output layer

w_2_10=-1.0157;

% Compute and plot
y3=w_2_11./(1+ exp(-1*(w_1_10+w_1_11*x))) + w_2_12./(1+ exp(-(w_1_20+w_1_21*x)))+w_2_10;

figure()
plot(phi,g_phi,'DisplayName','Original Data','LineWidth',2)
grid on
legend
hold on
plot(x,y3,'DisplayName','Scaled by nn tool','LineWidth',1)

