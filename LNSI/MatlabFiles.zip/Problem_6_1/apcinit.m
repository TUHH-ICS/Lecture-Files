% -------------------------------> APCINIT.M <------------------------------

% ----------      Switches       -----------
regty      ='apc';                      % Controller type (apc, pid, none)
refty      ='rsim.signals.values';      % Reference signal (siggener/<var. name>)
simul      ='simulink';                 % Control object spec. (simulink/matlab/nnet)


% ----------   Initializations   -----------
Ts = tsam;                         % Sampling period (in seconds)

samples  = Tsim/Ts;                % Number of samples in simulation
u_0      = 0.16;                   % Initial control input
y_0      = stepint;                % Initial output
ulim_min = 0;                      % Minimum control input
ulim_max = 1;                      % Maximum control input
%del_ulim = 9.4e-004;              % Half of tritration range
del_ulim = 0.5;                    % Half of tritration range

% --  System to be Controlled (SIMULINK) --
integrator= 'ode15s';                         % Name of dif. eq. solver (f. ex. ode45 or ode15s)
sim_model = 'TankModel_openloop_control';     % Name of SIMULINK model


% ---  System to be Controlled (MATLAB)  --
% mat_model = 'springm';       % Name of MATLAB model
% model_out = 'smout';         % Output equation (function of the states)
% x0        = [0;0];           % Initial states


% ----- Neural Network Specification ------
% "nnfile" must contain the following variables which together define
% a NNARX model:
% NN, NetDef, W1, W2
% (i.e. regressor structure, architecture definition, and weight matrices)

% Name of file containing neural network model
nnfile  = 'TrainedNeuralNetworkData'

% ------------ Reference filter ---------------
Am = [1];                    % Denominator of filter
Bm = [1];                    % Numerator of filter (starts in q^{-1})
%  0.2212
% ----------
% z - 0.7788


% ---------- APC initializations -----------
N1 = delayx;                 % Minimum prediction horizon (typically=nk)
N2 = predx;                  % Maximum prediction horizon (>= nb)
Nu = conhx;                  % Control horizon
rho = rhox;                  % Weight factor on differenced control signal


% ------ Choose Data to be Plotted  -------
% plot_a and plot_b must be cell structures containing the vector names in strings
plot_a = {'ref_data','y_data','yhat_data'};
plot_b = {'u_data'};
