%% Investigate Time Constants
% Generate several open loop simulations to find out about the range of
% time constants in the nonlinear model. The definition of the sampling
% time is based on this

Tosam = 100;                % number of sample
tsam  = 0.20;               % sampling time

stepint   = 7;              % initial setpoint
dsteptime = 500;            % time of step disturbance

TankModel_Initialisation;   % Initialize pH plant

%% Simulate Open Loop Response

figure;

% umin = 0.0;
% umax = 1.0;
% umin_mdl = 0.0;
% umax_mdl = 1.0;
% scale_range = 1.0;
Tsim = 50;
t1 = 0:tsam:Tosam-tsam;

uMagnitude = cell(3,1);
% uMagnitude{1,1} = [-0.1:0.01:0.07]';  % Random magnitude of excitation signal
% uMagnitude{2,1} = [0.071:0.001:0.079]';
% uMagnitude{3,1} = [0.07999:1e-6:0.08001]';
% uMagnitude{4,1} = [0.081:0.001:0.089]';
% uMagnitude{5,1} = [0.09:0.010:1.000]';
% colors = {'b','g','r','g','b'};
% uMagnitude{1,1} = [0:0.05:0.45]';  % Random magnitude of excitation signal
% uMagnitude{2,1} = [0.480:0.002:0.499]';
% uMagnitude{3,1} = [0.5015:0.0001:0.5039]';
% uMagnitude{4,1} = [0.504:0.002:0.518]';
% uMagnitude{5,1} = [0.52:0.050:1.000]';
% colors = {'b','g','r','g','b'};
uMagnitude{1,1} = [0:0.01:0.46]';  % Random magnitude of excitation signal
uMagnitude{2,1} = [0.460:0.0025:0.530]';
uMagnitude{3,1} = [0.530:0.010:1.000]';
colors = {'b','r','b'};

%g          = uMagnitude*ones(1,Tosam/tsam); % Excitation signal

% Setup figure
figure(1);
ylabel('y [pH]')
xlabel('t [s]')
grid
hold on

uydata = [];

for ii = 1:size(uMagnitude,1)
    for jj = 1:size(uMagnitude{ii,1})
    
    gk = uMagnitude{ii,1}(jj)*ones(1,Tosam/tsam); % Excitation signal

    simin = [t1', gk'];

    %sim('TankModel_openloop_train',Tsim);
    sim('TankModel_openloop',Tsim);

    % Take simulation data and plot it
    N = length(ysim.time);
    t = ysim.time(1:N);
    u = usim.signals.values(1:N);
    y = ysim.signals.values(1:N,:);
    uydata = [uydata; [u(end), y(end)]];

    % Plot data
    figure(1);
    plot(t-t(1),y,colors{ii}); hold on
    end
end

figure(1);
xlabel('Time');
ylabel('pH Value');
   
figure(2);
plot(uydata(:,1),uydata(:,2));
xlabel('Reagent flow u');
ylabel('pH Value');
