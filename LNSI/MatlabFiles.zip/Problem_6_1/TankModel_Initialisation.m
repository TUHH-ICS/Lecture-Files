%% Initialise pH Tank Model

umin_mdl    =  0.0799;%0.0798750 +0.0000050;%0.0798750;
umax_mdl    =  0.0805+0.0000625%0.08005000+0.0001000;
scale_range =  0.3;
umin        =  0.0;
umax        =  1.0;

%supress unnecessary warning
%clear all
warning off MATLAB:fzero:UndeterminedSyntax

%values of chemical constants
 kw=1e-14;
    ka1m=1e-1;
    kb1m=1e-13;
 
    %system constants
    Vtankm=10;
    
 %reagent concentrations: approx 20% reagents
 caSr=5.0
 cbSr=5.0
    
 %initial flow and concentrations in effluent stream
 Fe0m= 1.0;  % Fe0m = 6.25 for neutralization at u = 0.5
    ca1e0m=0.0;
    cb1e0m=0.4;
    caSe0=0.0;
    cbSe0=0.0;
    
    %pH of effluent stream
        pHe=TankModel_findpHofWeakMixture(kw, ka1m, kb1m, ca1e0m, cb1e0m,caSe0,cbSe0);
    
    %draw titration curve if required
      % titcurve
    
  
        
%get initial state

pH0 = stepint;
'effluent pH and setpoint'
[pHe pH0]

if pHe>pH0
    'acidic reagent required to reach setpoint'
else
    'WARNING: basic reagent needed to reach setpoint.program set up for acid!'
    pause
end  
    
%assume effluent is basic so no alkaline flow
FbSr0=0;





%To get initial guess  of reagent flow, set concentrations in tank equal those in effluent stream
ca10=ca1e0m;
cb10=cb1e0m;
cbS0=cbSe0;

%calculate estimate of  corresponding acid flow from:

%caS0=explicit func(pH0,ca10,cb10,cbS0)...rearrangement of pHweakfun
%Fe0m.caSe0+FaSr0.caSr=(Fe0m+FaSr0)*caStanktotal;
%Fe0m.caSe0+FaSr0.caSr=(Fe0m+FaSr0)*(caS0);

cH0=10^(-pH0);
caS0=-(kw/cH0-cH0+ca10*ka1m/(1+ka1m)-cb10*cH0/(cH0+kb1m)-cbS0);


FaSr0g=Fe0m*(caS0-caSe0)/(caSr-caS0);



%check what resulting pH and concentrations would then  be

Ftotchk=FaSr0g+FbSr0+Fe0m;
caS0chk=(FaSr0g*caSr+Fe0m*caSe0)/Ftotchk;
cbS0chk=(FbSr0*cbSr+Fe0m*cbSe0)/Ftotchk;

ca10chk=(Fe0m*ca1e0m)/Ftotchk;
cb10chk=(Fe0m*cb1e0m)/Ftotchk;


%update estimate of reagent flow by change factor,calculate new
%corresponding concentrations

FaSr0g2=FaSr0g*cb10chk/cb10;

Ftotchk2=FaSr0g2+FbSr0+Fe0m;
caS0chk2=(FaSr0g2*caSr+Fe0m*caSe0)/Ftotchk2;
cbS0chk2=(FbSr0*cbSr+Fe0m*cbSe0)/Ftotchk2;

ca10chk2=(Fe0m*ca1e0m)/Ftotchk2;
cb10chk2=(Fe0m*cb1e0m)/Ftotchk2;

%'true pH in tank at initial time'
pHchk2=TankModel_findpHofWeakMixture(kw, ka1m, kb1m, ca10chk2,cb10chk2,caS0chk2,cbS0chk2)


x0tank=[ca10chk2,cb10chk2,caS0chk2,cbS0chk2];

Ts = tsam;
disp(Ts)
%disturbances

FeStep=0.25;


