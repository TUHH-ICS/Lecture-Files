%% Problem 1.5.1

% Train a neural network to capture the behaviour of the CSTR pH process given in Exercise
% 1.1.2, and design an approximate predictive controller based on instantaneous lineariza-
% tion. Use the MATLAB tools provided in the NNSYSID and NNCONTROL toolbox (a link to the
% download site is provided on the web page of this course). Tune the controller for the
% reference trajectory given in Exercise 1.1.2, and compare the achievable performance and
% the design effort with that of the PID controller.

% inputs:  effluent stream (flow rate F_e), base
%           reagent stream (flow rate F_a), acid
% outputs: pH value at the outlet
%
%                 | d = Delta F_e
%                 |
%                 v
%              +-----+
%  F_a = u --->|  G  |---> y = pH
%              +-----+
%
% Assumptions: F_e = const.  => Acid stream is the controlled input.
%              V   = const.  => Constant volume inside tank.
%              Ts  = ? sec.  => 5 to 10 samples during rise time. 
%                 (Do simulations to investigate!)

%% Set Toolbox Paths

clear all
close all
clc

% Set the toolbox paths
SetToolboxPaths

%% Investigate Time Constants

InvestigateTimeConstants;

% Identified maxmimum time constant: Change according to observations
% timcon = 100;
timcon = 30;    %25;

%% Generate Training and Validation Data
close all

% Length and sampling time of training signal
Tosam   = 20000;            % Time
tsam    = 0.20;             % Sampling time 

% Generate multi-level PRBS excitation signal or multi-sine excitation
% signal. Choose by commenting out the respective other.
PRBSExcitation;
% MultiSineExcitation; % Currently not optimized

% You can also define a completely new excitation signal here along the
% lines of the given scripts for the subsequent script 'GenerateData' to 
% process it correctly.

%% Simulate Model and Divide Data into Training and Validation Portion
close all

% Generate simulation data
GenerateData;

% Store data
t_total = [t_train; t_validate];
u_total = [u_train; u_validate];
y_total = [y_train; y_validate];

% Store training data in .mat file
save TrainingAndValidationSignals t_train u_train y_train t_validate u_validate y_validate t_total u_total y_total;

%% Train Neural Network using the Norgaard NNToolbox
close all

% Define 6 tanh units in hidden layer
NetDef = ['HHHHHH';'L-----'];

% Lag space information
% NN=[na nb nk].
%   na = # of past outputs used for determining the prediction
%   nb = # of past inputs used for determining prediction
%   nk = time delay (usually 1)
NN = [4 4 1];
%NN = [10 5 1];

% Run script which contains commands for training the neural network with
% the Norgaard toolbox
TrainNNARXModel

%% Retrain Neural Network using the Norgaard NNToolbox
close all

% Execute, if the training data is not satisfactory
RetrainNNARXModel

%% Simulate pH Tank Controlled by APC
close all

delayx = 1;                    % for N1  in apcinit: Minimum prediction horizon (typically=nk)
conhx  = 5; %3;                    % for Nu  in apcinit: Control horizon
predx  = 10;                   % for N2  in apcinit: Maximum prediction horizon (>= nb)
rhox   = 80; %100; %80;                   % for rho in apcinit: Weight factor on differenced control signal
%rhox = 60;

save TrainedNeuralNetworkData NN NetDef W1 W2
nnfile = 'TrainedNeuralNetworkData';
SimulateAPCSolution