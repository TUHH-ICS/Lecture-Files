% Initialization
stepint = 7;                % Initial setpoint
TankModel_Initialisation;   % Initialize pH plant

                       
% Allowed magnitudes of excitation signal
% Vector concatenation with allowed amplitudes. The more often a certain
% value is contained in the vector, the higher its relative probability
% to appear in the generated signal.
%     % Initial lower density interval
%     uMagnitude = [0:0.01:0.49]';  
%     % High density within interval [0.49..0.51] to improve equal data
%     % distribution. Might need some optimisation...
%     uMagnitude = vertcat(uMagnitude, [0.490:0.00025:0.510]');
%     % Final lower density interval
%     uMagnitude = vertcat(uMagnitude, [0.510:0.010:1.000]');
uMagnitude{1,1} = [0:0.05:0.45]';  % Random magnitude of excitation signal
uMagnitude{2,1} = [0.480:0.002:0.499]';
uMagnitude{3,1} = [0.5015:0.0001:0.5039]';
uMagnitude{4,1} = [0.504:0.002:0.518]';
uMagnitude{5,1} = [0.52:0.050:1.000]';
uMag = vertcat(uMagnitude{1,1}, uMagnitude{2,1}, uMagnitude{3,1}, uMagnitude{4,1}, uMagnitude{5,1});

% uMagnitude{1,1} = [0:0.01:0.46]';  % Random magnitude of excitation signal
% uMagnitude{2,1} = [0.460:0.0025:0.530]';
% uMagnitude{3,1} = [0.530:0.010:1.000]';
% uMag = vertcat(uMagnitude{1,1}, uMagnitude{2,1}, uMagnitude{3,1});

% First Signal Portion - Multi-Level Pseudo-Random-Binary-Sequence
g = MultilevelPRBS(Tosam, tsam, timcon, 0.5, uMag);
               
% Second Signal Portion - Low Amplitude, High Frequency
bandwidth    = [1/(timcon)*0; 1/(tsam*2)];                 % Randwidth range
N            = 15;                                         % Number of sinusoids
randomPhases = 10;                                         % Number of random phases
gamma        = 0.025;                                       % Amplitude gain
levels       = [-1, 1]*gamma;                              % Admissible amplitude levels
sinedata     = [N, randomPhases, 1];                       % Parameter vector
g2 = idinput(Tosam/tsam, 'Sine', bandwidth, levels, sinedata)';

% Produce final training signal, saturate and prepare for simulation.
gk = g+g2;
gk(gk < 0) = 0;
gk(gk > 1) = 1;
t1 = 0:tsam:Tosam-tsam;
simin = [t1', gk'];
figure;
plot(gk);                   % show input data for training 

