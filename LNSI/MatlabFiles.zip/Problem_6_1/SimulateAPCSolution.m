close all

% Time to simulate and sampling time
Tsim = 300;
tsam = 0.25;
Ts   = tsam;

% Construct reference signal and scale it
sim('ReferenceSignal', Tsim)  

% No disturbance input as dsteptime > Tsim
dsteptime = 5000; 

% Initial pH value
stepint   = 7;

% Initialize tank model
TankModel_Initialisation;

apcinit

figure
apccon2                     % start simulation
 