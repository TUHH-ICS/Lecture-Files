%% Multi-Sine Excitation Signal

%  In the 'SINE' case, the sinusoids are chosen from the frequency grid
%     freq = 2*pi*[1:Grid_Skip:fix(P/2)]/P intersected with pi*[BAND(1) BAND(2)].
%     (for Grid_Skip see below.) For multi-input signals, the different inputs
%     use different frequencies from this grid. An integer number of
%     full periods is always delivered. The selected frequencies are obtained
%     as [U,FREQS] = IDINPUT(....), where row ku of FREQS contains the
%     the frequencies of input number ku. The resulting signal is affected by a
%     5th input argument SINEDATA:
%     U = IDINPUT(N,TYPE,BAND,LEVELS,SINEDATA)
%     where
%     SINEDATA= [No_of_Sinusoids, No_of_Trials, Grid_Skip],
%     meaning that No_of_Sinusoids are equally spread over the indicated
%     BAND, trying No_of_Trials different, random, relative phases,
%     until the lowest amplitude signal is found.
%     Default SINEDATA = [10,10,1];

Tosam   = 10000;             % number of sample
tsam    = 0.25;             % sampling time 
stepint = 7;                % initial setpoint
TankModel_Initialisation;   % Initialize pH plant
                            
% Generate Multi-Sine Signal
gamma0       = 0.1;
gamma1       = 0.2;
gamma        = 0.2;


% First Signal Portion - High Amplitude, Low Frequency
bandwidth    = [1/(timcon)*0; 1/(timcon)*0.1];             % 0 to 0.3 times the system's open-loop time constant
N            = 15;                                         % Number of sinusoids
randomPhases = 10;                                         % Number of random phases
levels       = ([-1, 1])*gamma0 + [0.5, 0.5];
sinedata     = [N, randomPhases, 1];
g0 = idinput(Tosam/tsam, 'Sine', bandwidth, levels, sinedata)';

% First Signal Portion - High Amplitude, Low Frequency
bandwidth    = [1/(timcon)*0.1; 1/(timcon)*0.3];             % 0 to 0.3 times the system's open-loop time constant
N            = 15;                                         % Number of sinusoids
randomPhases = 10;                                         % Number of random phases
levels       = ([-1, 1])*gamma1;
sinedata     = [N, randomPhases, 1];
g1 = idinput(Tosam/tsam, 'Sine', bandwidth, levels, sinedata)';

% Second Signal Portion - Low Amplitude, High Frequency
bandwidth    = [1/(timcon)*0.3; 1/(2*tsam)];            % 0.5 to 3 times the system's open-loop time constant
N            = 10;                                       % Number of sinusoids
levels       = [-1, +1]*gamma;
sinedata     = [N, randomPhases, 1];
g2 = gamma*idinput(Tosam/tsam, 'Sine', bandwidth, levels, sinedata)';


gk = g0+g1+g2;
gk(gk < 0) = 0;
gk(gk > 1) = 1;
t1 = 0:tsam:Tosam-tsam;
simin = [t1', gk'];
plot(gk);                   % show input data for training 