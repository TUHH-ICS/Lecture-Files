function [sys,x0,str,ts] = TankModel_SFunction(t,x,u,flag,Vtank,kw,ka1, kb1,x0tank)

% Model of pH control tank, with initial state x0, and chemical constants kwv, ka1v, kb1v
% x: concentrations ca1 and cb1
% u: [Fe,FaS,FbS,ca1e,caSe,cb1e,cbSe,caSr,cbSr] 
%      effluent flow, 
%      reagent aS flow,
%      reagent bS flow, 
%      concentrations of effluent, 
%      concentrations of reagent 
%      incoming concentrations of a1 and b1

switch flag,

  %%%%%%%%%%%%%%%%%%
  % Initialization %
  %%%%%%%%%%%%%%%%%%
  case 0,
    [sys,x0,str,ts]=mdlInitializeSizes(Vtank,kw,ka1, kb1,x0tank);

  %%%%%%%%%%%%%%%
  % Derivatives %
  %%%%%%%%%%%%%%%
  case 1,
    sys=mdlDerivatives(t,x,u,Vtank,kw,ka1, kb1);
  %%%%%%%%%%
  % Update %
  %%%%%%%%%%
  case 2,
    sys=mdlUpdate(t,x,u,Vtank,kw,ka1,kb1);    

  %%%%%%%%%%%
  % Outputs %
  %%%%%%%%%%%
  case 3,
    sys=mdlOutputs(t,x,u,Vtank,kw,ka1, kb1);

  %%%%%%%%%%%%%%%%%%%%%%%
  % GetTimeOfNextVarHit %
  %%%%%%%%%%%%%%%%%%%%%%%
  case 4,
    sys=mdlGetTimeOfNextVarHit(t,x,u,Vtank,kw,ka1,kb1);

  %%%%%%%%%%%%%
  % Terminate %
  %%%%%%%%%%%%%
  case 9,
    sys=mdlTerminate(t,x,u,Vtank,kw,ka1,kb1);

  %%%%%%%%%%%%%%%%%%%%
  % Unexpected flags %
  %%%%%%%%%%%%%%%%%%%%
  otherwise
    error(['Unhandled flag = ',num2str(flag)]);

end
% end csfunc

%
%=============================================================================
% mdlInitializeSizes
% Return the sizes, initial conditions, and sample times for the S-function.
%=============================================================================
%
function [sys,x0,str,ts]=mdlInitializeSizes(Vtank,kw,ka1, kb1,x0tank)

sizes = simsizes;
sizes.NumContStates  = 4;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 4;
sizes.NumInputs      = 9;
sizes.DirFeedthrough = 0;
sizes.NumSampleTimes = 1;

sys = simsizes(sizes);
x0  = x0tank;
str = [];
ts  = [0 0];

% end mdlInitializeSizes
%
%=============================================================================
% mdlDerivatives
% Return the derivatives for the continuous states.
%=============================================================================
%
function sys=mdlDerivatives(t,x,u,Vtank,kw,ka1, kb1)

 Fe=u(1);
 FraS=u(2);
 FrbS=u(3);
 ca1e=u(4);
 caSe=u(5);
 cb1e=u(6);
 cbSe=u(7);
 caSr=u(8);
 cbSr=u(9);
 
 Fout=Fe+FraS+FrbS;

 ca1=x(1);
 cb1=x(2);
 caS=x(3);
 cbS=x(4);
 
%effluent ca1 concentration
sys(1)=1/Vtank*(Fe*ca1e-Fout*ca1);
sys(2)=1/Vtank*(Fe*cb1e-Fout*cb1);
sys(3)=1/Vtank*(FraS*caSr+Fe*caSe-Fout*caS);
sys(4)=1/Vtank*(FrbS*cbSr+Fe*cbSe-Fout*cbS);

% end mdlDerivatives
%
%
%=============================================================================
% mdlUpdate
% Handle discrete state updates, sample time hits, and major time step
% requirements.
%=============================================================================
%
function sys=mdlUpdate(t,x,u,Vtank,kw,ka1,kb1)

sys = [];

% end mdlUpdate
%=============================================================================
% mdlOutputs
% Return the block outputs.
%=============================================================================
%
function sys=mdlOutputs(t,x,u,Vtank,kw,ka1, kb1)


%first get concentrations
ca1=x(1);
 cb1=x(2);
 caS=x(3);
 cbS=x(4);
 %get pH
 %sys=pHweakfun(kw, ka1, kb1, ca1, cb1,caS,cbS);
 %sys=[ca1;cb1;caS;cbS];
sys = x;

% end mdlOutputs

%
%=============================================================================
% mdlGetTimeOfNextVarHit
% Return the time of the next hit for this block.  Note that the result is
% absolute time.  Note that this function is only used when you specify a
% variable discrete-time sample time [-2 0] in the sample time array in
% mdlInitializeSizes.
%=============================================================================
%
function sys=mdlGetTimeOfNextVarHit(t,x,u,Vtank,kw,ka1,kb1)

sampleTime = 1;    %  Example, set the next hit to be one second later.
sys = t + sampleTime;

% end mdlGetTimeOfNextVarHit

%
%=============================================================================
% mdlTerminate
% Perform any end of simulation tasks.
%=============================================================================
%
function sys=mdlTerminate(t,x,u,Vtank,kw,ka1,kb1)

sys = [];

% end mdlTerminate