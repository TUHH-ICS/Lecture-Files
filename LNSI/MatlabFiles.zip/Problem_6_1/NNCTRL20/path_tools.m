%%%%%%%%%%%%% New toolbox path %%%%%%%%%%%%%%%%%%

% NNCTRL Toolbox
NNCTRLtoolbox_path  = 'E:\Projects\Education\Neural Networks and Genetic Computing for Control Systems\CSTR pH Plant Example\New Solution\NNCTRL20\';
addpath([NNCTRLtoolbox_path, 'CTRLDEMO'])
addpath([NNCTRLtoolbox_path, 'CTRLTOOL'])
addpath([NNCTRLtoolbox_path, 'TEMPLATE'])

% NNSYSID Toolbox
NNSYSIDtoolbox_path = 'E:\Projects\Education\Neural Networks and Genetic Computing for Control Systems\CSTR pH Plant Example\New Solution\NNSYSID20\';
addpath([NNSYSIDtoolbox_path])
