function y=smout(x);
y = x(1);