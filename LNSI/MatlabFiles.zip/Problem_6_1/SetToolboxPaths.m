%%%%%%%%%%%%% New toolbox path %%%%%%%%%%%%%%%%%%

% NNCTRL Toolbox
NNCTRLtoolbox_path  = 'NNCTRL20\';
addpath(genpath(NNCTRLtoolbox_path))

% NNSYSID Toolbox
NNSYSIDtoolbox_path = 'NNSYSID20\';
addpath(genpath(NNSYSIDtoolbox_path))
