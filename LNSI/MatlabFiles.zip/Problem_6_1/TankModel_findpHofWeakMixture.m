% Function to find pH of a mixture of a weak acid and a weak base 

function pHweak = TankModel_findpHofWeakMixture(kw, ka1, kb1, ca1, cb1,Sa,Sb);



cHweak=fzero(@cHzfun,[1e-20 13.99],[],kw, ka1, kb1, ca1, cb1, Sa, Sb);

pHweak=-log10(cHweak);



function cHz= cHzfun(cH,kw, ka1, kb1, ca1, cb1, Sa, Sb)
%zero function associated with weak pH


cHz=kw/cH-cH+ca1*ka1/(1+ka1)-cb1*cH/(cH+kb1)+Sa-Sb;

