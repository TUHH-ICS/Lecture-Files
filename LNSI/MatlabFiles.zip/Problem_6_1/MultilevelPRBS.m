function x = MultilevelPRBS(simt,samt,timcon,alpha,levec)
% generate N-samples-constant signal
% simt : Time to simulate
% samt : Sampling time
% alpha : probability of u(t-1)
nu = round(simt/samt);
xinput = randn(1,nu);
% sim('randomsim',simt);
% xinput = rx'+meax;
nr = 0;
ticon = timcon/samt;
d = 1;
xoutput = [];
r = length(levec);
d = floor(r*rand(1)+1);
    
xoutput(1) = levec(d);
for i = 2:nu,
 k = rand(1);
 if (k > alpha)&(nr > ticon),
     d = floor(r*rand(1)+1);
     xoutput(i) = levec(d);
     nr = 0;
 else
     xoutput(i) = xoutput(i-1);
     nr = nr+1;
 end
end
x = xoutput;
