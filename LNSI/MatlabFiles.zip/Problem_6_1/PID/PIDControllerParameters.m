%% Define PID Controller Parameters
%setpoint = 10;
%Tsim = 70;

Tosam   = 10000;              % number of sample
tsam    = 0.25;               % Define sampling time
stepint = 7;                  % Define initial condition y(0) = y0
umax    = 0.080002;
umin    = 0.0799;
dsteptime = 500000;

Kp = -.002;
Ti = .5;
Td = 0.001;
gamma = .01;
Kaw = 10;

Ki = 1/Ti;
Kd = Td;