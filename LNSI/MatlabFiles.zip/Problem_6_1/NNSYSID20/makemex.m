mex marq.c matrix.c nnmisc.c

mex nnarmax2.c matrix.c nnmisc.c

mex nnoe.c matrix.c nnmisc.c

mex nnssif.c matrix.c nnmisc.c
