% ph_init

if exist('ysim') clear ysim;
end
if exist('usim') clear usim;
end


stepint   = 7;                % initial setpoint
TankModel_Initialisation;     % Initialize pH plant

Tsim = Tosam;

%% Simulate Open Loop Response to Excitation Signal
sim('TankModel_openloop',Tsim);

% Take half of the samples for training
N = floor(length(ysim.time)/2);
t_train = ysim.time(1:N);
u_train = usim.signals.values(1:N);
y_train = ysim.signals.values(1:N,:);

% Take the other half of the samples for validation
t_validate = ysim.time(N:2*N);
u_validate = usim.signals.values(N:2*N);
y_validate = ysim.signals.values(N:2*N,:);

% Plot data
figure;
subplot(211)
plot(t_validate-t_validate(1),y_validate)
ylabel('y [pH]')
xlabel('t [s]')
grid
subplot(212)
plot(t_validate-t_validate(1),u_validate)
ylabel('u [m^3/s]')
xlabel('t [s]')
grid
figure;
hist(y_train)
