%% Investigate Time Constants
% Generate several open loop simulations to find out about the range of
% time constants in the nonlinear model. The definition of the sampling
% time is based on this

Tosam = 100;                % number of sample
tsam  = 0.20;               % sampling time

stepint   = 7;              % initial setpoint
dsteptime = 500;            % time of step disturbance

TankModel_Initialisation;   % Initialize pH plant

%% Simulate Open Loop Response

figure;

% umin = 0.0;
% umax = 1.0;
% umin_mdl = 0.0;
% umax_mdl = 1.0;
% scale_range = 1.0;
Tsim = 50;
t1 = 0:tsam:Tosam-tsam;

uMag1 = 0;
uMag2 = 1;
uMag = [uMag1, uMag2];
%g          = uMagnitude*ones(1,Tosam/tsam); % Excitation signal

% Setup figure
figure(1);
ylabel('y [pH]')
xlabel('t [s]')
grid
hold on

simmodel = 'TankModel_openloop';    
% sim('TankModel_openloop_train',Tsim);

%% Plot step responses for initial values
g1 = uMag1*ones(1,Tosam/tsam); % Excitation signal
    simin = [t1', g1'];

    sim(simmodel,Tsim);

    % Take simulation data and plot it
    N = length(ysim.time);
    t = ysim.time(1:N);
    u = usim.signals.values(1:N);
    y = ysim.signals.values(1:N,:);
    yend = y(end);
    % Plot data
    figure(1);
    plot(t-t(1),y,'b'); hold on
    
    g2 = uMag2*ones(1,Tosam/tsam); % Excitation signal
    simin = [t1', g2'];
    sim(simmodel,Tsim);

    % Take simulation data and plot it
    N = length(ysim.time);
    t = ysim.time(1:N);
    u = usim.signals.values(1:N);
    y = ysim.signals.values(1:N,:);
    yend = [yend, y(end)];
    % Plot data
    figure(1);
    plot(t-t(1),y,'b'); hold on

%% Bisection
ii = 1;
while(abs(yend(ii,1) - yend(ii,2)) > 0.1)
    uMagMid = (uMag1 + uMag2)/2;
    gk = uMagMid*ones(1,Tosam/tsam); % Excitation signal
    simin = [t1', gk'];
    sim(simmodel,Tsim);

    % Take simulation data and plot it
    N = length(ysim.time);
    t = ysim.time(1:N);
    u = usim.signals.values(1:N);
    y = ysim.signals.values(1:N,:);
    % Plot data
    figure(1);
    plot(t-t(1),y,'b'); hold on
    
    if(y(end) > 7)
        uMag1 = uMagMid;
        %uMag2 = uMag2;
        yend(ii+1,:) = [y(end), yend(ii,2)];
    else
        %uMag1 = uMag1;
        uMag2 = uMagMid;
        yend(ii+1,:) = [yend(ii,1), y(end)];
    end
    uMag = [uMag; [uMag1, uMag2]];
    ii = ii+1;
end
