function H = mkhankel(g)
% MKHANHEL Construct Hankel matrix from given measurement data
%
% H = mkhankel(g)
%
%   g  has dimension  no x ni x ndata
%       no - number of outputs
%       ni - number of inputs 
%       ndata - number of measurements
%
% TUHH :: Institut for Control Systems :: Control Systems Theory and Design
% Last update: 13.06.2008

[l,m,k] = size(g);

nh = floor((k-1)/2);

bcol = g(:,:,2);
for j=3:k
    bcol = [bcol; g(:,:,j)];
end

H = bcol(1:nh*l,:);
for j=1:nh-1
    H = [H bcol(j*l+1:(nh+j)*l,:)];
end
