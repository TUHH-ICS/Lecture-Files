% Exercise 7.6 :: Subspace Identification - Generate data
%
% TUHH :: Institut for Control Systems :: Control Systems Theory and Design
% Last update: 13.06.2008

Gc = zpk( {[] 2; 1 .5},{[-.5 -3+i*3 -3-i*3] [-.5 -10]; [-.5 -6+i*3 -6-i*3] [-2 -4]}, [100 30;100 100]);
G = c2d(Gc,.5);
impulse(G)

[y,t] = impulse(G);
randn('state',0);
wnoise = .05*randn(size(y));
yn = y + wnoise;

% g  - impulse response without noise
% gn - add measurement noise
for j=2:length(t)
    g(1,1,j) = y(j,1,1);
    g(1,2,j) = y(j,1,2);
    g(2,1,j) = y(j,2,1);
    g(2,2,j) = y(j,2,2);
    gn(1,1,j) = yn(j,1,1);
    gn(1,2,j) = yn(j,1,2);
    gn(2,1,j) = yn(j,2,1);
    gn(2,2,j) = yn(j,2,2);
end

H  = mkhankel(g);
Hn = mkhankel(gn);

