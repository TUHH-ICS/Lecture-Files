% Exercise 7.6  :: Subspace Identification - Parameter exsimation
%
% TUHH :: Institut for Control Systems :: Control Systems Theory and Design
% Last update: 23.01.2009
clear all;
clc
cs7_mkdata;
%% System info
ni = 2      % number of inputs to the system
no = 2      % number of system outputs
Ts = 0.5;   % sampling time

%% Perform SVD
[U,S,V] = svd(H);

Sd = diag(S)
pause();
%% Consider n most significant singular values
n = input('order of the model=');

Us = U(:,1:n);
Vs = V(:,1:n);
Ss = S(1:n,1:n);

%% Factorisation to extended observability and controllability matrices
Obs = Us*sqrt(Ss);
Ctr = sqrt(Ss)*Vs';

%% Get C and B: first blocks of Obs and Ctr respectively
C = Obs(1:no,:);
B = Ctr(:,1:ni);


%% Get the system matrix  (here A=Phi)
obs0 = Obs(1:end-no, :);       % skip the last measurement
obs1 = Obs(no+1:end, :);       % skip the first measurement

A = obs0\obs1       % This is numerically better, than pseudoinverse
% A = pinv(obs0)*obs1

% ctr0 = Ctr(:, 1:end-no);       % skip the last measurement
% ctr1 = Ctr(:, no+1:end);       % skip the first measurement
% 
% A = ctr1*ctr0' * inv(ctr0*ctr0')

%% Get the model
model = ss(A,B,C,zeros(no,ni),Ts);

impulse(model,G)

