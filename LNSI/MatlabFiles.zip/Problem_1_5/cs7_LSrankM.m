% Exercise 7.5  :: Least Squares Identification - inverses
%
% TUHH :: Institut for Control Systems :: Control Systems Theory and Design
% Last update: 23.01.2009
clear all
clc
format short e
load cs7_LSsysdat

for i=1:10
M = mkm(y2,u2,i);
svd(M'*M)
end

for i=1:20
M = mkm(y3,u3,i);
svd(M'*M)
end
