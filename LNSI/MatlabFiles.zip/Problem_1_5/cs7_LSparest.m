% Exercise 7.5  :: Least Squares Identification
%
% TUHH :: Institut for Control Systems :: Control Systems Theory and Design
% Last update: 23.01.2009
clear all
clc
load cs7_LSsysdat

Ts = 1;                 % sampling time
n = 3;                  % model order

M  = mkm(y3,u3,n);
yn = y3(n+1:length(y3));                          % FIXME
p  = pinv(M'*M)*M'*yn;  % get parameters        % FIXME

den = [1 p(1:n)'];                              % FIXME
num = p(n+1:2*n)';                              % FIXME

G = tf(num,den,Ts);
[p z] =pzmap(G);


%% Plot simulation results of this model with the other signals
Tfin = length(u3)-1;
T = (0:Ts:Tfin)';

figure(1)   % step 
[y,T,x]=lsim(G,u1,T);
subplot(211),       plot(T,[y y1]), title('step input : true plant and model'), legend('model','plant')
subplot(212),       plot(T,y-y1),   title('step input : error between true plant and Model')

figure(2)   % sin
[y,T,x]=lsim(G,u2,T);
subplot(211),       plot(T,[y y2]), title('sinusoidal input : true plant and model'), legend('model','plant')
subplot(212),       plot(T,y-y2),   title('sinusoidal input : error between true plant and Model ')

figure(3)   % white noise
[y,T,x]=lsim(G,u3,T);
subplot(211),       plot(T,[y y3]), title('white noise input : true plant  und Model'), legend('model','plant')
subplot(212),       plot(T,y-y3),   title('white noise input : error between true plant and model')

