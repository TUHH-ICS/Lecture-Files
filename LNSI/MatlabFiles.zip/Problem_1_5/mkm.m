function M = mkm(y,u,n)
% M = mkm(y,u,n)
% Form the measurement matrix M
% y - measured outputs
% u - measured inputs
% n - order of the system

ny = length(y);
nu = length(u);
ndata = min(nu,ny)-1;

for i=n:ndata
    M(i-n+1,1:n) = -y(i:-1:i-n+1)';
    M(i-n+1,n+1:2*n) = u(i:-1:i-n+1)';
end
