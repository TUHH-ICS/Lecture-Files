% #########################################################################
% TUHH :: Institute for Control Systems :: Control Lab
% #########################################################################
% Experiment CSTD2: Magnetic Levitation Plant
%
% Copyright Herbert Werner and Hamburg University of Technology, 2014
% #########################################################################
% This file is to be completed by the student.
% The completed version is to be published using 
%   publish('cstd2_design.m','pdf') 
% and submitted as a pdf-file at least one week prior to the scheduled date
% for the experiment
%
% !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
% !!!  The gaps in the code are denoted by TODO !!!
% !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
%
% HINT 1:
% if you want to find out more about a certain command, just type 
% 'help command' into the matlab window
% HINT 2:
% use section evaluations (Ctrl+Enter) to run the code within a single 
% section

%----------------------------
% v.0.9 - 13-11-2014
% by Michael Heuer 
%----------------------------
% Last modified on 25-11-2014
% by Julian Theis
% ---------------------------

%%
clear all; clc; close all

%% I. Load and scale the plant
% In the first step we load the plant which was identified in the previous task.
% After that the system matrices are extracted and the number of states,
% inputs and outputs are stored, because we need them later.

load models.mat

% Choose the model for the controller design and for comparison
sys_design = % TODO 
sys_comp = % TODO 

% Extract the relevant matrices
[A,B,C,D] = ssdata(sys);

% Extract the system dimensions
n  = size(A,1);
ni = size(B,2);
no = size(C,1);

%% I.b Design of a Prefilter for Reference Tracking 
%

V = % TODO

%% I.c Simulation of the Feed Forward Design
%

sys = % TODO: Model used for controller synthesis
sim('cstd2_sim_ff');

figure(1);
t = data(:,1);
plot(t, data(:,2), t, data(:,3), t, data(:,4), t, data(:,5));
legend({'r_1','r_2','y_1','y_2'});
grid('on');

% Simulation with an other plant for comparison

sys = % TODO: Simulation model with sligtly different gains
sim('cstd2_sim_ff');

figure(2);
t = data(:,1);
plot(t, data(:,2), t, data(:,3), t, data(:,4), t, data(:,5));
legend({'r_1','r_2','y_1','y_2'});
grid('on');

%% II.a Design of the observer
% For the linear quadratic regulator, it is important to have access to the
% states, which are not measured in general. For that reason we have to
% estimate them using an Luenberg observer.

Q_obsv = % TODO
R_obsv = % TODO

L = % TODO

% Build observer system
A_obsv = % TODO
B_obsv = % TODO
C_obsv = % TODO
D_obsv = % TODO

%% II.b Analysis of the observer 

disp('Eigenvalues of the observer are: ');
damp(A_obsv);

%% III.a Design of the controller
% In the next step the optimal state feeback gains are calculated.
%

Q = % TODO
R = % TODO

F = % TODO

% Calculate Prefilter for Reference Tracking

V = % TODO

% Combine Observer, State Feedback Gain and Prefilter
% to a 2dof controller (inputs: r,y outputs: u)
A_lqg = % TODO
B_lqg = % TODO
C_lqg = % TODO
D_lqg = % TODO

%% III.b Analysis of the closed loop system and the controller  
%
disp('Eigenvalues of the closed loop are: '); % For comparison
damp(%TODO);

disp('Eigenvalues of the implemented controller are: ');
damp(A_lqg);

fastestpole = max(double(abs(eig(A_lqg))))

%% III.c Simulation
%

sys = % TODO: Model used for controller synthesis
sim('cstd2_sim_lqg');

figure(3);
t = data(:,1);
plot(t, data(:,2), t, data(:,3), t, data(:,4), t, data(:,5));
legend({'r_1','r_2','y_1','y_2'});
grid('on');

% Simulation with an other plant

sys = % TODO: Simulation model with slightly different gains
sim('cstd2_sim_lqg');

figure(4);
t = data(:,1);
plot(t, data(:,2), t, data(:,3), t, data(:,4), t, data(:,5));
legend({'r_1','r_2','y_1','y_2'});
grid('on');

%% IV.a Design of the Controller with integral action
% The problem of the previous design is the steady control offset.
% To improve that, one can add an integrator to the controller.
%

% Build augmented plant
A_aug = % TODO
B_aug = % TODO
C_aug = % TODO
D_aug = % TODO

% Tuning Parameter
Q_C = % TODO

Q_aug = % TODO
R_aug = % TODO

F_aug = % TODO

F = % TODO
Fi = % TODO

sys_cl_int = % TODO

% Combine Observer, Integrator and Gains to controller

A_alqg = % TODO
B_alqg = % TODO
C_alqg = % TODO
D_alqg = % TODO

%% IV.b Analysis of the new Design

disp('Eigenvalues of the observer are: ');
damp(A_obsv);

disp('Eigenvalues of the closed loop with augmented statefeedback are: ');
damp(A_aug+B_aug*F_aug);

disp('Eigenvalues of the implemented controller are: ');
damp(A_alqg);


%% TODO: Complete the Simulink Model

open('cstd2_sim_lqg_int');

%% IV.c Simulation of the new design

sys = % TODO: Model used for controller synthesis
sim('cstd2_sim_lqg_int');
data_s1 = data; 

figure(3);
t = data(:,1);
plot(t, data(:,2), t, data(:,3), t, data(:,4), t, data(:,5));
legend({'r_1','r_2','y_1','y_2'});
grid('on');

% Simulation with an other plant
sys = % TODO: Simulation model with sligtly different gains
sim('cstd2_sim_lqg_int');
data_s2 = data; 

figure(4);
t = data(:,1);
plot(t, data(:,2), t, data(:,3), t, data(:,4), t, data(:,5));
legend({'r_1','r_2','y_1','y_2'});
grid('on');
