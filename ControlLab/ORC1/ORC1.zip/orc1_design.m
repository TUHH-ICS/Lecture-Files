% #########################################################################
% TUHH :: Institute for Control Systems :: Control Lab
% #########################################################################
% Experiment ORC1: Robust Control of a Spring-Mass-Damper System
%
% Copyright Herbert Werner and Hamburg University of Technology, 2014
% #########################################################################
% This file is to be completed by the student.
% The completed version is to be published using
%   publish('orc1_design.m','pdf')
% and submitted as a pdf-file at least one week prior to the scheduled date
% for the experiment
%
% !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
% !!!  The gaps in the code are denoted by XXX !!!
% !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
%
% HINT 1:
% if you want to find out more about a certain command, just type
% 'help command' into the matlab window
% HINT 2:
% use section evaluations (Ctrl+Enter) to run the code within a single
% section

%----------------------------
% v.0.8 - 15-12-2014
% by Simon Wollnack
%----------------------------
% Last modified on 15-12-2014
% by Simon Wollnack
% ---------------------------

%%

clc
clear all
close all

%% 1. Nominal Controller Design

% First we want to design a controller for the nominal plant model 
% k1 = 390N/m and k2 = 390N/m. 

% The masses of mass one and two are defined here.
m1 = XXX; 
m2 = XXX;

% Furthermore, we assume the following damping coefficients.
c1 = 0.01;
c2 = 0.01;

% The spring stiffness constants are fixed and known. 
k1 = XXX; 
k2 = XXX; 

% The nominal system matrix A is constructed here
A  = XXX;
    
% The input matrix B.    
B = XXX;

% The output matrix C is determined by assuming that the position of the
% second cart is measured in centimeters   
C = XXX;   

% And finally the feedthrough matrix D is constructed.
D = XXX;

% Now we can construct the state space model.
Sys = XXX;

% For constructing the generalized plant, we define the weighting filters 
% at this point using the parametrization you know from the lecture.
wsp = XXX;      wsz = XXX;      	Ms = XXX;     
        
Ws = Ms * tf([1/XXX 1],[1/XXX 1]);
        
wk = XXX;           Mk = XXX;
        
Wk = 1/Mk * tf([1/XXX 1],[1/(1000*XXX) 1]);
        
Ws = ss(Ws);        Wk = ss(Wk);        


 %S/KS      
 % Construct the generalized plant
 systemnames = 'XXX XXX XXX';
 inputvar    = '[XXX; XXX]';
 input_to_Sys = '[XXX]';
 input_to_Wk = '[XXX]';
 input_to_Ws = '[XXX]';
 outputvar   = '[XXX; XXX; XXX]';
 GSYS = sysic;

 % Before we compute the optimal gamma we apply the ssbal(.)
 % command.
 GSYS = ssbal(XXX);
 
 % Compute the optimal Hinf norm of the closed loop
 [~,~, hinf_Opt] = hinfsyn( GSYS, 1, 1, 'Method', 'LMI', 'Display', 'off');
 
 
 % and solve the suboptimal controller design problem in the second
 % step
 hinf_sub = 1.1*hinf_Opt;
 [K,CL, hinf] = hinfsyn( GSYS, 1, 1, 'Method', 'LMI', 'Display', 'off',...
     'GMIN', hinf_sub);
 
 K = ssbal(K);
 
 disp('###################################')
 disp(['Hinf norm: ' num2str(hinf_sub)])
 disp('###################################')
 
 % and have a look at the pole-zero map of plant and controller.
 figure
 pzmap(Sys, XXX)
 
 % Additionally, the Bode plot of the controller gives valuable
 % insights
 figure
 bode(XXX)
 grid on
 
 % To plot the transfer functions S,KS, T and SG we need to construct them.
 % To do that the Matlab function loopsens(.) (see help) is used here.
 
 loops = loopsens(XXX, XXX);
 
 % Now, we can extract the different loop transfer functions.
 S = loops.XXX;
 KS = loops.XXX;
 T = loops.XXX;
 SG = loops.XXX;
 
 % Next, sigma plots of these transfer functions are generated
 % and plotted.
 figure(4)
 s1 = subplot(221);   sigma(XXX, inv(Ws),'r--', {1e-3, 1e4}); title('S')
 grid on
 s2 = subplot(223);   sigma(XXX, inv(Wk),'r--', {1e-3, 1e4}); title('KS')
 grid on
 s3 = subplot(222);   sigma(XXX, inv(Ws),'r--', {1e-3, 1e4}); title('SG')
 grid on
 s4 = subplot(224);   sigma(XXX, inv(Wk),'r--', {1e-3, 1e4}); title('T')
 grid on
 
 % To scale the y axis the set(.) command can be used.
 set(s1, 'ylim', [-60, 20]);
 
 
 % Furthermore, the gain and phase margins are computed
 disp('###################################')
 disp(['k1 = 390N/m, k2 = 390N/m']);
 disp(allmargin(Sys*K));
 disp('###################################')
 disp(char(10))
 
 % To test a posteriori for stability the loops field "Stable" can be read
 if loops.Stable
     disp('###################################')
     disp('Closed-loop system is stable!')
     disp('###################################')
     disp(char(10))
 else
     disp('###################################')
     disp('Closed-loop system is unstable!')
     disp('###################################')
     disp(char(10))
 end
 
 % In time domain we can analyze the step responses of T, S, SG and KS
 figure(5)
 Tsim = 10;
 subplot(2,2,1);
 % SG
 step(SG, Tsim);
 ylabel('Output y');   grid;
 set(gca, 'ylim', [XXX XXX]);
 
 % S
 subplot(2,2,2);
 step(XXX, Tsim);
 ylabel('Error e');  grid;
 set(gca, 'ylim', [XXX XXX]);
 
 % T
 subplot(2,2,3);
 step(XXX, Tsim);
 ylabel('Output y');  grid;
 set(gca, 'ylim', [XXX XXX]);
 
 % KS
 subplot(2,2,4);
 step(XXX, Tsim);
 ylabel('Control u');  grid;
 set(gca, 'ylim', [XXX XXX]);
        


%% 2. Robust Controller Design

%% Defining The Uncertainty

% Next, we want to design a robust controller for the uncertain system.
% First we need to define the range of the parameter uncertainty for the
% spring stiffness.
% We have three different spring stiffness 
% with kl = 200 N/m, km = 390 N/m, kh = 830 N/m.
% k1 is in {200 N/m, 390 N/m, 830 N/m}.
% k2 is in {200 N/m, 390 N/m}.
k1vec = [XXX XXX XXX];
k2vec = [XXX XXX];

% Based on the ranges of the parameter uncertainties we can choose the
% nominal plant parameters, e.g, as mean values.
k10 = XXX;
k20 = XXX;

% As an additional tuning knob we can shrink the uncertainty range for
% nominal performance
unc_p1 = 10;
unc_p2 = 10;
k1_range = XXX*[1-unc_p1/100 1+unc_p1/100];
k2_range = XXX*[1-unc_p2/100 1+unc_p2/100];




% To assign uncertain variables which can be used to construct the
% uncertain state-space model we use the function ureal(.) (see help).
k1 = ureal('k1', XXX, 'range', XXX); 
k2 = ureal('k2', XXX, 'range', XXX); 


% The masses of mass one and two are defined here.
m1 = XXX; 
m2 = XXX;

% Furthermore, we assume the following damping coefficients.
c1 = 0.01;
c2 = 0.01;

% To construct an uncertain state-space object the function uss(.) can be
% used. However, we need the system matrices A, B, C and D.    

% As done before we construct the uncertain system matrix A
A  = XXX;
    
% The input matrix B.    
B = XXX;

% The output matrix C is determined by assuming that the position of the
% second cart is measured in centimeters   
C = XXX;   

% And finally the feedthrough matrix D is constructed.
D = XXX;



% Now we are ready to construct the uncertain state space model
Sys_uss = XXX;   

% To obtain the nominal transfer function model from the uncertain state
% space model we can substitute the uncertain parameters k1 and k2 by its
% nominal values
G0 = tf(usubs(XXX));


figure
% And have a look at the pole zero map
pzmap(G0)   


%% Robust controller design by constructing the uncertain state-space model manually

% To extract the plant matrices A0, Bw and Cz the Matlab function
% lftdata(.) (see help) can be used.
[XXX, XXX] = lftdata(XXX);         % extract the uncerrtainity in LFT form

% To extract the correct plant matrices we need to know the size of the
% DELTA block
mdelta = size(DELTA, 1);
ndelta = size(DELTA, 2);

% Now we extract the matrix A0 of the nominal state space model
A0 = Sys0.XXX;

% The input and output matrices of the uncertainty channel Bw and Cz 
% are contained in the first mdelta columns of B and the first ndelta rows
% of C of the uncertain state-space model, but we have to extract them
Bw = Sys0.XXX; 
Cz = Sys0.XXX;
Dw = Sys0.D;

% Now we are ready to construct the generalized plant for the robust
% controller design problem (-C since the controller is designed for
% positive feedback)
GSYS = ssbal(ss(A0, [Bw B], [Cz; -C], Dw ));

% First, we do the optimal synthesis
[~,~, hinf,INFO] = hinfsyn(GSYS, 1, 1, 'Method', 'LMI' );

% to do the suboptimal synthesis in a second step.
[K,CL,hinf,INFO] = hinfsyn(GSYS, 1, 1, 'Method', 'LMI', 'GMIN', 1.1*hinf );

% Norm from w to z, if < 1 => Robust Stability
disp('###################################')
disp(['Hinf norm from w to z (Approach 1): ' num2str(hinf)]) 
disp('###################################')
disp(char(10))

%% Robust controller design by using Matlabs sysic

% An alternative method is to use Matlabs sysic function
systemnames = 'Sys_uss';
inputvar    = '[u{1}]';
input_to_Sys_uss = '[XXX]';
% Have in mind that the controller is designed for positive feedback!
outputvar   = '[XXX]';               
GSYSu = sysic;

% Since the uncertain state space model GSYSu is constructed we can extract
% the LFR matrices GSYS and the Delta block
[GSYS, Delta] = XXX;

% Again we apply the ssbal(.) function
GSYS = ssbal(XXX);

% and compute the optimal controller
[K,CL,hinf,INFO] = hinfsyn(GSYS, 1, 1, 'Method', 'LMI' );

% The Hinf norm multiplied by 1.1 should be the same as the suboptimal
% solution obtained by the first approach
disp('###################################')
disp(['Hinf norm from w to z (Approach 2): ' num2str(1.1*hinf)]) 
disp('###################################')
disp(char(10))


%% 3. Robust Performance Controller Design
% Since we are interested in designing a controller for tracking we need to
% add performance specifications. This is done by adding weighting filters
% for the Sensitivity and Control Sensitivity transfer functions
close all


% Therefore, we define these weighting filters at this point using the 
% parametrization you know from the lecture.
wsp = XXX;      wsz = XXX;      	Ms = XXX;     
        
Ws = Ms * tf([1/XXX 1],[1/XXX 1]);
        
wk = XXX;           Mk = XXX;
        
Wk = 1/Mk * tf([1/XXX 1],[1/(1000*XXX) 1]);
        
Ws = ss(Ws);        Wk = ss(Wk);      
        
        
% To simplify the notation we define the uncertain state space model as G.
G = Sys_uss;


% S/KS weighting scheme
% Next, the Matlab sysic function is used to construct the generalized
% plant
systemnames = XXX;
inputvar    = '[XXX]';
input_to_G = '[XXX]';
input_to_Wk = '[XXX]';
input_to_Ws = '[XXX]';
outputvar   = '[XXX]';
GSYSu = sysic;

   
% Again we extract the LFR matrices contained in GSYS and the Delta block 
[GSYS, Delta] = XXX;

% and apply the ssbal(.) function
GSYS = ssbal(GSYS);
        
% Compute the optimal Hinf norm of the closed loop
[~,~, hinf_Opt] = hinfsyn( GSYS, 1, 1, 'Method', 'LMI', 'Display', 'off');

% and solve the suboptimal controller design problem in the second
% step
hinf_sub = XXX;
[K,CL, hinf] = hinfsyn( GSYS, 1, 1, 'Method', 'LMI', 'Display', 'off',...
    'GMIN', hinf_sub);

K = ssbal(K);

% The inputs of the closed loop CL are w = [wu' wp']' and the
% outputs are z = [zu' zp']'.
% To check for robust stability using the small gain theorem, we need to
% compute the Hinf norm from wu to zu
hinf_rob_stab = XXX;

disp('###################################')
disp(['Hinf norm of the closed loop: ' num2str(hinf_sub)])
disp('###################################')
disp(char(10))
% Hinf norm from wu to zu => robust stability
disp('###################################')
disp(['Hinf norm from wu to zu: ' num2str(hinf_rob_stab)])  
disp('###################################')
disp(char(10))
        
% To plot the transfer functions S,KS, T and SG we need to construct them.
% To do that the matlab function sysic is used. 

% S,KS, T, SG, KSG
systemnames = 'G K';
inputvar    = '[XXX]';
input_to_G = '[XXX]';
input_to_K  = '[XXX]';
outputvar   = '[XXX]';

S = sysic;  
KS = XXX;
T = XXX;      
SG = XXX;  
KSG = XXX;

 pzplot(G,'k', K, 'r', SG, 'b')
 set(gca, 'xlim', [-100 1], 'ylim', [-50 50])
 


% To evaluate these transfer functions for all possible combinations of
% springs cells are defined.
S_cell = {};
SG_cell = {};
KSG_cell = {};
T_cell = {};
KS_cell = {};

for k = k1vec
    
    for kk = k2vec
        
        % To substitute values for uncertain parameters we can use the
        % function usubs(.)
        S_cell = [S_cell {usubs(XXX)}];
        SG_cell = [SG_cell {usubs(XXX)}];
        KSG_cell = [KSG_cell {usubs(XXX)}];
        T_cell = [T_cell {usubs(XXX)}];
        KS_cell = [KS_cell {usubs(XXX)}];
       
        
    end
    
end

% Next, the sigma plots of these transfer functions are generated
% and plotted.
figure(4)
s1 = subplot(221);   
sigma(S_cell{1}, S_cell{2}, S_cell{2}, S_cell{4},...
    S_cell{5}, S_cell{6}, inv(Ws),'r--', {1e-3, 1e4});    title('S')
grid on

s2 = subplot(223);   
sigma(KS_cell{1}, KS_cell{2}, KS_cell{2}, KS_cell{4},...
    KS_cell{5}, KS_cell{6}, inv(Wk),'r--', {1e-3, 1e4});   title('KS')
grid on

s3 = subplot(222);   
sigma(SG_cell{1}, SG_cell{2}, SG_cell{2}, SG_cell{4},...
    SG_cell{5}, SG_cell{6}, inv(Ws),'r--', {1e-3, 1e4});    title('SG')
grid on

s4 = subplot(224);   
sigma(T_cell{1}, T_cell{2}, T_cell{2}, T_cell{4},...
    T_cell{5}, T_cell{6}, inv(Wk),'r--', {1e-3, 1e4});    title('T')
grid on
        
        
% To scale the y axis the set(.) command can be used.
set(s1, 'ylim', [-60, 20]);
        


% To check a posteriori for stability (small gain theorem is conservative)
% we use the Matlab function isstable(.) for all possible T's.
stability_check = [isstable(T_cell{1}) isstable(T_cell{2})...
    isstable(T_cell{3}) isstable(T_cell{4})...
    isstable(T_cell{5}) isstable(T_cell{6})];

if isequal(stability_check, ones(1,6))
disp('###################################')
disp('All closed-loop systems are stable!')
disp('###################################')
disp(char(10))
% Furthermore, the gain and phase margins are computed
disp('Stability margins:')
for k = k1vec
    
    for kk = k2vec
        
        Gi = usubs(G,'k1', k, 'k2', kk);
        disp('###################################')
        disp(['k1 = ' num2str(k) 'N/m, k2 = ' num2str(kk) 'N/m']);
        disp(allmargin(Gi*K));
        disp('###################################')
        disp(char(10))
        
    end
    
end

else
    str = ['There exists a combination of springs'...
        ' such that the closed-loop system is unstable!'];

    disp(str)       
end


% In time domain we can analyze the step responses of T, S, SG and KS
figure(5)
Tsim = 10;
subplot(2,2,1);
% SG
step(SG_cell{1}, SG_cell{2}, SG_cell{3}, SG_cell{4},...
    SG_cell{5}, SG_cell{6}, Tsim);
ylabel('Output y');   grid;
set(gca, 'ylim', [XXX XXX]);

% S
subplot(2,2,2);
step(XXX, XXX, XXX, XXX,...
    XXX, XXX, Tsim);
ylabel('Error e');  grid;    
set(gca, 'ylim', [XXX XXX]);
         
% T
subplot(2,2,3);
step(XXX, XXX, XXX, XXX,...
    XXX, XXX, Tsim);
ylabel('Output y');  grid;   
set(gca, 'ylim', [XXX XXX]);

% KS
subplot(2,2,4);
step(XXX, XXX, XXX, XXX,...
    XXX, XXX, Tsim);
ylabel('Control u');  grid;    
set(gca, 'ylim', [XXX XXX]);

set(findobj('type', 'line'), 'linewidth', 1)


 