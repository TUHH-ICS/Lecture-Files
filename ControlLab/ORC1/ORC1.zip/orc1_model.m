% #########################################################################
% TUHH :: Institute for Control Systems :: Control Lab
% #########################################################################
% Experiment ORC1: Robust Control of a Spring-Mass-Damper System
%
% Copyright Herbert Werner and Hamburg University of Technology, 2014
% #########################################################################
% This file is to be completed by the student.
% The completed version is to be published using
%   publish('orc1_model.m','pdf')
% and submitted as a pdf-file at least one week prior to the scheduled date
% for the experiment
%
% !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
% !!!  The gaps in the code are denoted by XXX !!!
% !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
%
% HINT 1:
% if you want to find out more about a certain command, just type
% 'help command' into the matlab window
% HINT 2:
% use section evaluations (Ctrl+Enter) to run the code within a single
% section

%----------------------------
% v.0.8 - 15-12-2014
% by Simon Wollnack
%----------------------------
% Last modified on 15-12-2014
% by Simon Wollnack
% ---------------------------
%%%
% 1.  Defining model parameters
%%%
% 2.  Construction of uncertainty model based on SVD
%%%
% 3.  Construction of uncertainty model based on LFT modeling 


%% 1. Model parameters
% First the nominal plant parameters are defined. Particularly, we assume
% that the two masses are known and fixed to keep the parametric
% uncertainty affine, i.e.,
m1 = XXX;
m2 = XXX;

%%%
% In addition, viscous friction is desrcibed by the model parameters
c1 = 0.01;
c2 = 0.01;


%%%
% The spring stiffness is assumed to be uncertain but contained in
% a given intervall. The springs available during the experiment have the
% following spring stiffness kl = 200, km = 390, kh = 830.
% It is assumed that the first spring varies between k1 = 200 and k1 = 830
% while k2 varies between k2 = 200 and k2 = 390.

% Based on the ranges of the parameter uncertainties we can choose the
% nominal plant parameters, e.g, as mean values.
k10 = XXX;    
k20 = XXX;



%% 2. Construction of uncertainty model based on SVD 
 
%%%
 % We begin to construct the nominal plant matrix A0 of a state-space
 % model. To do that we assume a certain ordering of the states, i.e., we
 % want to construct A0 such that the state vector x is given by 
 % $x = [x_1 \ \dot{x}_1 \ x_2 \ \dot{x}_2]^T$.
 
A0 = XXX;   
            
%%%           
% Due to physical modeling and the ordering of the states, i.e., 
% x = [x_1 \dot{x}_1 x_2 \dot{x}_2 ]^T the input matrix B can be
% uniquely determined if we assume that the force used to control the
% system acts on the first cart.
            
B = XXX;

%%%
% The output matrix C is determined by assuming that the position of the
% second cart is measured in cm.
    
C = XXX;

%%%
% The feedthrough matrix D is assumed to be 0.
    
D = XXX;



%%%
% Next, we want to construct a cell containing all possible plant matrices
% Ai that are in the uncertain model set. This is done to compare these
% matrices to the uncertainty description later on.

A_cell = {};

k1_vec = linspace(200,830,5);
k2_vec = linspace(200,390,5);
for k1i = k1_vec
    
    for k2i = k2_vec
        
        
        % At this point we construct the system matrix Ai for spring
        % stiffness k1i and k2i
        Ai = XXX;
        
        % and store all matrices Ai in the cell A_cell.
        A_cell = [A_cell Ai];
        
        
    end
    
end

%%%
% To use the SVD for obtaining an uncertainty description we need to
% initialize two empty arrays Fb and Fc to store all deviations from the
% nominal plant matrix A0 contained in the uncertainty set. Have in mind
% that we need one array that contains all concatenated A_deltas to find
% Bw and one other array that contains all concatenated A_deltas' to find
% Cz.
A_delta_cell = {};
Fb = [];
Fc = [];

%%%
% Next, we need two row vectors denoted by k1_vec and k2_vec containing
% possible spring stiffness.
k1_vec = linspace(200,830,5);
% Spring k2 is fixed to compute columns of Bw and rows of Cz corresponding
% to k1.
k2_vec = k20;


%%%
% To keep things simple we use a nested loop structure to assign possible
% plant matrices.
for k1i = k1_vec

    for k2i = k2_vec
        

        % At this point we construct the system matrix Ai for spring
        % stiffness k1i and k2i
        Ai = XXX;
    
        % to compute the deviation from the nominal plant matrix A0
        A_delta = XXX; 
        
        A_delta_cell = [A_delta_cell A_delta];    
          
        %%%
        % and concatenate them in the arrays Fb and Fc.
        Fb = [Fb A_delta];
        Fc = [Fc A_delta'];

    
    end
    
end

%%%
% Based on the uncertainty set which is described here by the arrays Fb
% and Fc, we are now ready to determine the matrices Bw and Cz using the
% SVD.

[Ub,Sb,Vb] = XXX;
[Uc,Sc,Vc] = XXX;

tol = 1e-5;

%%%
% We have to decide which singular values are significant enough to keep
% them which we do here.
sb = diag(Sb);
sc = diag(Sc);
keep_up_to = find( max([sb sc],[],2) > tol ,1, 'last');

%%%
% Next we can select the corresponding entries of the matrices Ub and Uc to
% construct Bwus and Czus, where us indicates that these matrices are not
% scaled yet.
Bwus = Ub(:,XXX);
Czus = Uc(:,XXX)';

%%%
% Therefore, we use the singular values contained in Sb and Sc to construct
% scaling matrices.
Tb = Sb(1:XXX, 1:XXX);
Tc = Sc(1:XXX, 1:XXX);

%%%
% and apply the mapping.
Bw1 = Bwus*Tb;
Cz1 = Tc*Czus;

%%%
% Find the maximum norm.
Delta = [];
dN = [];
for k = 1:length(A_delta_cell)
    
    A_delta = A_delta_cell{k};    
    Delta = Bw1\A_delta/Cz1;
    dN = [dN norm(Delta)];

end

k = XXX;

%%%
% Rescale so |Delta| < 1.
Bwk1 = k*Bw1;
Czk1 = k*Cz1;


A_delta_cell = {};
Fb = [];
Fc = [];

%%%
% Next, we need two row vectors denoted by k1_vec and k2_vec containing
% possible spring stiffness constants, where spring k1 is fixed to compute
% columns of Bw and rows of Cz corresponding to k2.
k1_vec = k10;
k2_vec = linspace(200,390,5);

%%% 
% Here we do the same as before.
for k1i = k1_vec

    for k2i = k2_vec
        

        Ai = XXX;
    
        A_delta = XXX; 
        
        A_cell = [A_cell Ai];
        A_delta_cell = [A_delta_cell A_delta];    
          
        Fb = [Fb A_delta];
        Fc = [Fc A_delta'];

    
    end
    
end

%%%
% Based on the uncertainty set which is described here by the arrays Fb
% and Fc, we are now ready to determine the matrices Bw and Cz using the
% SVD.

[Ub,Sb,Vb] = XXX;
[Uc,Sc,Vc] = XXX;

tol = 1e-5;

%%%
% We have to decide which singular values are significant enough to keep
% them which we do here.
sb = diag(Sb);
sc = diag(Sc);
keep_up_to = find( max([sb sc],[],2) > tol ,1, 'last');

%%%
% Next we can select the corresponding entries of the matrices Ub and Uc to
% construct Bwus and Czus, where us indicates that these matrices are not
% scaled yet.
Bwus = Ub(:,XXX);
Czus = Uc(:,XXX)';

%%%
% Therefore, we use the singular values contained in Sb and Sc to construct
% scaling matrices.
Tb = Sb(1:XXX, 1:XXX);
Tc = Sc(1:XXX, 1:XXX);

%%%
% and apply the mapping.
Bw1 = Bwus*Tb;
Cz1 = Tc*Czus;

%%%
% Find the maximum norm.
Delta = [];
dN = [];
for k = 1:length(A_delta_cell)
    
    A_delta = A_delta_cell{k};    
    Delta = Bw1\A_delta/Cz1;
    dN = [dN norm(Delta)];

end

k = XXX;

%%%
% Rescale so |Delta| < 1.
Bwk2 = k*Bw1;
Czk2 = k*Cz1;

%%%
% Here, we construct matrices Bw and Cz of the uncertainty description.
Bw = [XXX XXX];
Cz = [XXX; XXX];

%% Analysis of uncertainty description (Approach 1)

% Since we have computed the matrices Bw and Cz we can now have a closer
% look at the uncertain model properties. Firstly, we want to generate
% some Deltas and plot the eigenvalues of the corresponding system
figure(1); clf(1);  hold on
for delta1 = -1:0.2:1
    

        for delta2 = -1:0.2:1
        
        %%%
        % Here, we need to construct the Delta matrix.
        Delta = XXX;
        
        %%%
        % to build a particular matrix Ai contained in the uncertainty set.
        Ai = A0 + XXX;
    
        %%%
        % Now, we can compute the eigenvalues
        eigs = eig(Ai);
    
        %%%
        % and plot them.
        plot(real(eigs), imag(eigs), 'g+');
        
        end
    

end

%%%
% For comparison we plot the eigenvalues of the original system.
for i = 1:length(A_cell)
    
    eigs = eig(A_cell{i});
    
    plot(real(eigs), imag(eigs), 'ro');
    
end
title('Poles of uncertain system (Approach 1: g+, Approach 2: bd) and original system (ro)')



%% 3. Construction of uncertainty model based on LFT modeling 
% Uncerain State-Space (USS) model of Matlab

%%%
% First we need to define the range of the parameter uncertainty for the
% spring stiffness.
k1_range = [200 830];
k2_range = [200 390];

%%%
% Based on the ranges of the parameter uncertainties we can choose the
% nominal plant parameters, e.g, as mean values.
k10 = XXX;
k20 = XXX;

%%%
% To assign uncertain variables which can be used to construct the
% uncertain state-space model we use the function ureal(.) (see help).
k1 = ureal('k1', XXX, 'range', XXX); 
k2 = ureal('k2', XXX, 'range', XXX); 

%%%
% Furthermore, we assume that the nonlinear damper is not connected to the
% second cart


%%%
% As done before we construct the uncertain sytem matrix A
A = XXX;
 
%%%
% To construct an uncertain state-space object the function uss(.) can be
% used. However, we need the system matrices A, B, C and D.     
Sys_uss = uss(A,B,C,D);    
 
%%%
% To extract the plant matrices A0, Bw and Cz the Matlab function
% lftdata(.) (see help) can be used.
[XXX, XXX] = lftdata(Sys_uss); 

%%%
% To extract the correct plant matrices we need to know the size of DELTA.
mdelta = size(DELTA, 1);
ndelta = size(DELTA, 2);

A0 = Sys0.XXX;

%%%
% The input and output matrices of the uncertainty channel Bw and Cz 
% are contained in the first mdelta columns of B and the first ndelta rows
% of C of the uncertain state-space model, but we have to extract them.
Bw = Sys0.XXX; 
Cz = Sys0.XXX;

%%%
% Same as before we plot the eigenvalues of the uncertain state-space
% model.
figure(1);  hold on

for delta1 = -1:0.2:1
    
    for delta2 = -1:0.2:1
        
        Delta = XXX;
        
        Ai = A0 + XXX;
        
        eigs = eig(Ai);
        
        plot(real(eigs), imag(eigs), 'bd');
        
    
    end

end

set(gca, 'xlim', [-0.005 0])

