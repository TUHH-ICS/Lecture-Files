function G = lin_CMG_stab( q1dot,q2)
    rmpath(genpath('Simulation'));
    addpath(genpath('Simulation/CMGpend'));
    load Simulation/CMGpend/CMGpendsys.mat
    
    global sys
    
    n1 = numel(q1dot);
    n2 = numel(q2);
    
    ns = 6;
    ni = 2;
    no = 3;
    
    G = ss(zeros(ns,ns,n1,n2),zeros(ns,ni,n1,n2),zeros(no,ns,n1,n2),zeros(no,ni,n1,n2));
    
    for i = 1:n1
        for j = 1:n2
            sys.parameters.data.Dq1_s = q1dot(i);
            sys.parameters.data.q2_s = q2(j);
            [A,B,~,D] = eqm_lin_ssinout(0);

            A = A(3:8,3:8);
            B = B(3:8,:);

            C = [1 0 0 0 0 0;
                 0 1 0 0 0 0;
                 0 0 1 0 0 0];

            if isempty(D)
                D = zeros(size(C,1),size(B,2));
            end

            G(:,:,i,j) = ss(A,B(:,1:2),C,D(:,1:2));

            G(:,:,i,j).InputName = {'T1','T2'};
            G(:,:,i,j).StateName = {'q4','qx','w1','w2','w4','wx'};
            G(:,:,i,j).OutputName = {'q4','qx','w1'};
        end
    end
end

