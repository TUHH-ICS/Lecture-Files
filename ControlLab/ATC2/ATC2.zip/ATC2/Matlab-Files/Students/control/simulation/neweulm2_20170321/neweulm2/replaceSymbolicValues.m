% replaceSymbolicValues - replace symbolic value by numerical value
%
%  Syntax:
%> replaceSymbolicValues('symbolic value', numerical value, ...);
%     
%  Desciption: 
% This function replaces the symbolic values in the sys
% structure by numeric values. All the writen functions in the file 
% sysFunction will be deleted, in order to make sure, that this symbolic 
% values don't appear anymore in any expressions. Hence, if an analysis 
% has to be performed, the sys function must be generated again by the 
% function call writeMbsNonLin or writeMbsLin. Then also there the 
% symbolic values are replace by the numeric values. 
%
%  Example function calls:
% replace in the symbolic value of the paramete 'mass1' by 2 
%> replaceSymbolicValues('mass1',2);
% replace the symbolic values of the two parameters
%   'mass1' and 'length1' to 2 and 3, respectively
%> modifyConstant('mass1',2,'length1',3);
%
% First appearance: 25.02.2013
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
