function defineGraphics
% DEFINEGRAPHICS - erzeuge graphische Darstellung von Koerpern
%

global sys;

sys.graphics.line = [];
sys.graphics.surfaces = [];

if(isempty(sys.graphics.axes) || ~ishandle(sys.graphics.axes))
    createAnimationWindow;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% contact point for the spring to ISYS %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if(~any(strcmp(sys.parameters.constant, 'rAnim')))
    newConstant('rAnim', 0.1); % Constant scaling factor for animation
end
if(isfield(sys.model.frame,'K1_cg'))
    h = drawCube([0 0 0], '1.5*rAnim', '1.5*rAnim', '1.5*rAnim',[0 0 0.7],'FaceAlpha',0.6);
    addGraphics('K1_cg',h); % Assign it to a coordinate system
    drawLine({'support','K1_cg'},'forceElement','Color',[1 0 0],'LineWidth',2);
end
if(isfield(sys.model.frame,'Body1_cg'))
    h = drawSphere(zeros(3,1), '2*rAnim', [], [0.7 0 0]);
    addGraphics('ISYS',h);

    h = drawCube([0 0 0], 2*sys.parameters.data.l1, '3*rAnim', '3*rAnim', [0 0 1],'FaceAlpha',0.6);
    addGraphics('Body1_cg',h); % Assign it to a coordinate system
end
if(isfield(sys.model.frame,'Body2_cg'))
    h = drawCube([0 0 0], '6*rAnim', '6*rAnim', '6*rAnim',[1 0 0],'FaceAlpha',0.6);
    addGraphics('Body2',h); % Assign it to a coordinate system

    drawLine({'connection','Body2'});
    plotTrajectories('Body2','Color','red');
end

