function res_ = f_D2FH(t,y_,varargin)

res_ = 0; % Default return value
