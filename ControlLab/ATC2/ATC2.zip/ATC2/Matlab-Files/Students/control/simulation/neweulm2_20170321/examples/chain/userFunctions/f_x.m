function x = f_x(t)
% f_x - definition of time-depending user-defined variable x

global sys;



% constant user-defined variables

xAmp = sys.parameters.data.xAmp;
xOmega = sys.parameters.data.xOmega;
x = zeros(1,1);

x(1) = xAmp*sin(t*xOmega);


% END OF FILE

