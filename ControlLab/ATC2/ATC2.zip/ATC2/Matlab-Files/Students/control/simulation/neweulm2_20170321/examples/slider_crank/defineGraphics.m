function defineGraphics
% DEFINEGRAPHICS - create graphic visualization of modeling elements
%

global sys;

% Inertial system
% h = drawRotBody([0 0.03 0.03 0],[-0.04 -0.04 0.04 0.04], ...
%     'Tag', 'Bolt_ISYS', 'FaceColor', [0 0 0.7], 'EdgeColor', 'none');
% addGraphics('ISYS',h);

%%%%%%%%%%%%%%
% Crank
% h(1) = drawSphere([0 0 0],0.08,20,[1 0 0], ...
%     'Tag','Sphere_P1','EdgeColor','none');
h = drawSTL('Kurbel.stl', [0; 0; -22], 1e-3, 1e-3, 1e-3, [0.5; .5; .5], ...
      [0.5; 0.5; 0.5]);
transformGraphics(h, 'RotationAngles', [0, 0, -0.5*pi]); % Rotate body
addGraphics('P1', h);

h = [];

%%%%%%%%%%%%
% Piston Rod
h = drawSTL('Pleuel.stl', [0; 0; 0], 1e-3, 1e-3, 1e-3, [0; 0.5; 1], ...
      [0; 0.5; 1], 'Frame', 'P2');
transformGraphics(h,'RotationAngles',[0, 0, 0]);
% addGraphics('P2_cg',h);
h = [];

%%%%%%%%%%%%
% Slider
h = drawRotBody([0.013 0.015 0.015 0.011 0.011 0.015 0.015 0.013 0]*2, ...
      [-0.01 -0.01 0.013 0.013 0.016 0.016 0.02 0.02 0.018]*2, ...
    'Tag', 'Cylinder', 'FaceColor', [0.35; 0.35; 0.35], 'EdgeColor', 'none');
transformGraphics(h, 'RotationAngles', [0,0.5*pi, 0]);
% h(2) = drawRotBody([0 0.03 0.03 0],[-0.15 -0.15 0.15 0.15], ...
%     'Tag', 'Bolt_Cylinder', 'FaceColor', [0 0 0.7], 'EdgeColor', 'none');
addGraphics('P3_cg', h);

% Force element
% if(sys.parameters.data.k1 > 0)
%     drawSpring(sys.felem.Force.ksys1, sys.felem.Force.ksys2, '', 'diameter',0.05, 'num_winding',-5);
% end

% If desired, please adjust the visible area here
global gui;
gui.timeInt.figureOpt='manual';

createAnimationWindow('clearWindow', true, 'DrawCS', false);
view(0,90);