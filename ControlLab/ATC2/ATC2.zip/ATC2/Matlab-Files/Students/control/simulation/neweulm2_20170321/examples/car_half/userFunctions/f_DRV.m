function res_ = f_DRV(t,y_,varargin)

res_ = 0; % Default return value
