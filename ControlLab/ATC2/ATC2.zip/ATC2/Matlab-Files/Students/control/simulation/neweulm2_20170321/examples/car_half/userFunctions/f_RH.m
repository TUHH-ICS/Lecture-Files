function res_ = f_RH(t,y_,varargin)
% res_ = f_RH(t,y_,varargin)
% f_RH - definition of state-depending user-defined variable RH
% Positions, velocities, ... of coordinate systems can be calculated by
% calling the functions in 'sysFunctions', e.g. body1_r

global sys;

Dy_ = zeros(sys.counters.genCoord,1); % Default value for derivatives
% Treat optional input arguments
if(length(varargin) == 1)
	% Call was f_RH(t,y_,Dy_)
	% Generalized velocities have been passed
	Dy_ = varargin{1};
elseif(nargin==1 && ischar(t) && strcmp(t,'linearization'))
	% Case IV: Call was f_...('linearization')
	% Return symbolic expression to calculate the linearization
	% Necessary for all parameters appearing in the equations of motion to linearize!
    symRoadR_S = getAbsoluteKinematics('S','RoadR','ISYS');
    symRoadR_r = getAbsoluteKinematics('r','ISYS','RoadR');
    symRoadR_v = getAbsoluteKinematics('v','ISYS','RoadR');
    symRoadR_o = getAbsoluteKinematics('omega','ISYS','RoadR');
    symRA_r    = getAbsoluteKinematics('r','ISYS','RA');
    symRA_v    = getAbsoluteKinematics('v','ISYS','RA');
    r_ = transpose(symRoadR_S)*(symRA_r-symRoadR_r);
    r_ = mapleSimplify(r_,'combine');
    v_ = transpose(symRoadR_S)*(symRA_v-symRoadR_v);
    Dphi_Dirdef_ = transpose(symRoadR_S)*symRoadR_o;
    v_ = v_ - cross(Dphi_Dirdef_,r_);
    v_ = mapleSimplify(v_(3), 'combine');
    x_ = r_(3)-sym('r0');
    c_ = sym('ctr');
    d_ = sym('dtr');
    res_ = mapleSimplify(c_*x_+d_*v_);
	return;
end

% Force law of the rear tire
% Parameters
r0 = sys.parameters.data.r0; % Nominal length
ctr = sys.parameters.data.ctr; % Stiffness
dtr = sys.parameters.data.dtr; % Damping

% Calculate the positions of the two coordinate systems involved
RAr = RA_r(t,y_);
RoadRr = RoadR_r(t,y_);

% distance in z-direction, without nominal length
r = RAr(3) - RoadRr(3) - r0;

% Calculate the velocities of the two coordinate systems involved
RAv = RA_v(t,y_,Dy_);
RoadRv = RoadR_v(t,y_,Dy_);
% Relative velocity in z-direction
v = RAv(3) - RoadRv(3);

% Calculate force
res_ = ctr * r + dtr * v;

% Respect lifting off of the tire, therefore: force < 0
if(sys.parameters.data.useLiftOff)
    res_ = min(res_, 0);
end
