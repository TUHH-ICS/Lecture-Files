% calcReacForce - Gather kinematic values needed for the computation of the
% reaction forces.
%
%  Syntax:
%> calcReacForce;
%
%  Optional parameters, given pairwise:
%
% CheckExecution ... Logical to check whether the reaction forces are
%                    required using the parameter
%                    sys.settings.equation.calcReactionForces. If false,
%                    the function is evaluated in any case {false}
% Representation ... Determine, if which frame the forces should be
%                    displayed. Choose 'ISYS' for the represenation in the
%                    global inertial system or 'reference' for the
%                    representation in the reference system of each body.
%                    {'reference'}
%
%  Example:
%> calcReacForce('Representation', 'ISYS');
%
%  See also: 
% calcEqMotNonLin, writeMbsNonLin
%
% First appearance: 19.09.2012
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
