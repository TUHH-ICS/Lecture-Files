% matlab2anim(ye_,varargin)
%
% Input arguments
% ye_ ... 		  f x nsteps matrix containing the generalized coordinates
%			  of all bodies in the system. Each column represents one step.
%
%
% Optional input arguments, should be specified in pairs, {default values}
% 'startanim' ............ true|false -> start anim
% 'amplitude' ............ numval -> multiply gencoord with
% 'plotForce' ............ Cell Array containing the Forcename and forcevalues or key value
%  arguments of AnimStrFile -> help AnimStrFile
%
% structure of the Force Cell Array
% 	a) 'internal Force': {'FORCENAME',KEYVAL}
%		KEYVAL: 
%			1-6 plot Component of the force vector
%			7 plot resulting force arrow
%			8 plot resulting moment arrow
% 	b) 'external Force': {'FORCENAME',Forcearray}
%		Forcearry: 
%			6xForcesteps Array containg the whole forcevector [force;moment] at every forcestep
% Example function calls:
% animate movement with anim
% matlab2anim(ye_,'startanim',true);
%
% plot force arrow and search automatically for the force application point including external forces
% FS1_ext is external force, FH5 is internal, force caused by the ligamentum
% matlab2anim(ye_,'startanim',true,'plotforce',{'FS1_ext',force;'FH5',7});
