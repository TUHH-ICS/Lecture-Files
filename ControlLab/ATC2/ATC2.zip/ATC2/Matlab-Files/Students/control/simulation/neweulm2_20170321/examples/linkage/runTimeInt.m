%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                   %
%                             runTimeInt                            %
%                                                                   %
% Does a time integration of the Equations of Motion                %
% This routine handles systems with and without loops. In the case  %
% of a system with loops, the initial values defined in setUserVar  %
% are only the basis. From them the consistent initial values are   %
% calculated, before the integration starts.                        %
%                                                                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global sys;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Default values for parameters: Don't change!!

% Reset everything
sys.settings.timeInt = [];

% Integration algorithm
if sys.counters.constraint == 0
    sys.settings.timeInt.integrator = @ode45;
else
    sys.settings.timeInt.integrator = @ode15s;
end;

% Integration options and tolerances
sys.settings.timeInt.intOpts = odeset;

% Initial values
sys.settings.timeInt.y0 = zeros(sys.counters.genCoord,1); % Initial displacements
sys.settings.timeInt.Dy0 = zeros(sys.counters.genCoord,1); % Initial velocities

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% These values are to be adjusted
% Initialize all values and parameters for the time integration
% Time Intervall [t0, t1], there are no default values for this
sys.settings.timeInt.t0 = 0; % Start time t0
sys.settings.timeInt.t1 = 10; % End time t1
% sys.settings.timeInt.time = 0:0.01:10; % Specify if fixed-step solver is used

% Initial values for the integration
% Add displacement: Attention!! Do not exceed system dimension
sys.settings.timeInt.y0(1) = pi/5;
sys.settings.timeInt.y0(2) = 0.01;
sys.settings.timeInt.y0(3) = 0.001;
sys.settings.timeInt.y0(4) = 0.4;
sys.settings.timeInt.y0(5) = 0.0;


% Choice of the integration algorithm
% Possibilities:
% sys.settings.timeInt.integrator = @ode45
% sys.settings.timeInt.integrator = @ode23
% sys.settings.timeInt.integrator = @ode113
sys.settings.timeInt.integrator = @ode15s;
% sys.settings.timeInt.integrator = @ode23s
% sys.settings.timeInt.integrator = @ode23t
% sys.settings.timeInt.integrator = @ode23tb
% sys.settings.timeInt.integrator = @radau5Mex;
% FIXED STEP:
% sys.settings.timeInt.integrator = @ode1;
% sys.settings.timeInt.integrator = @ode1s;
% sys.settings.timeInt.integrator = @ode2;
% sys.settings.timeInt.integrator = @ode3;
% sys.settings.timeInt.integrator = @ode4;
% sys.settings.timeInt.integrator = @ode5;
% sys.settings.timeInt.integrator = @newmarkBeta;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Integration options and tolerances
% sys.settings.timeInt.intOpts = odeset(sys.settings.timeInt.intOpts, 'RelTol', 1e-8); % Relative tolerances
% sys.settings.timeInt.intOpts = odeset(sys.settings.timeInt.intOpts, 'AbsTol', 1e-10); % Absolute tolerances, Increasing this value can worsen the results!

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Final conditions, must be a scalar function
% Initialization to standard value
% sys.settings.timeInt.finalCond = sym(['t-' mat2str(sys.settings.timeInt.t1)]); % Use the integration time set in runTimeInt
% Definition of userdefined functions
% sys.settings.timeInt.finalCond = ['(t-' mat2str(sys.settings.timeInt.t1) ')*(gamma-3.1)'];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Activate a measure to follow the progress of the integration
sys.settings.timeInt.display.type = 'waitbar';
% sys.settings.timeInt.display.type = 'odeplot';
% sys.settings.timeInt.display.type = 'animation';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ensure that system dimension is not exceeded
sys.settings.timeInt.y0 = sys.settings.timeInt.y0(1:sys.counters.genCoord);
sys.settings.timeInt.Dy0 = sys.settings.timeInt.Dy0(1:sys.counters.genCoord);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Calculation of the static equilibrium
if (sys.counters.constraint == 0) % No loops in the system
    % The initial values are designed to be deflections from the static
    % equlibrium. Therefore the static equilibrium is calculated and added
    % to the initial values
    % Attention! All time dependent functions are evaluated at t = t0 !
    fprintf(1,'Calculating Static Equilibrium ...\n');
    [ye,res] = staticEquilibrium(sys.settings.timeInt.t0, zeros(sys.counters.genCoord,1));
    sys.results.statEq = ye;
    updateGeo(0,ye);
    fprintf(1,'ok!\n');
    % If initial values are supposed to be absolute values, activate this line
%     ye = zeros(sys.counters.genCoord,1);
    % Adjust initial values
    y0 = ye + sys.settings.timeInt.y0;
else
    % Empty vector, as initial values have to be consistent and are
    % calculated in timeInt
    y0 = sys.settings.timeInt.y0;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Time integration

fprintf(1,'Integrating the System over the Time ...');
sys.results.timeInt = timeInt(y0, sys.settings.timeInt.Dy0);
fprintf(1,' ok!\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Adjustment of the visible area

% Adjustment of the visible area by hand
% xlim([-1.5 1.5]);
% ylim([-1.5 1.5]);
% zlim([-1.5 1.5]);

% Automatic scaling of the plot area
% This finds the extrema of the trajectories of all coordinate systems.
% This method may take some time.
% fitCanvas('square'); % decides the optimal graph size, with square axis scales
fitCanvas('equal'); % decides the optimal graph size, with equal axis scales
% fitCanvas('small'); % decides the optimal graph size, with smallest axis scales
% fitCanvas('CenterCS','P2_cg'); % decides the optimal graph size, centered to the passed coordinate system

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot trajectories for certain coordinate systems
% Has to be run only once
plotTrajectories('BA_cg','onthefly',true); % Plots a line for BA_cg

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Animation of the results

animTimeInt;
% animTimeInt(sys.results.timeInt,'TimeStep','Optimal','Stride',1);
% animTimeInt(sys.results.timeInt,'TimeStep',6e-2,'Stride',1);
% animTimeInt(sys.results.timeInt,'TimeStep',1e-2,'Stride',0.1,'CenterCS','P2_cg');
