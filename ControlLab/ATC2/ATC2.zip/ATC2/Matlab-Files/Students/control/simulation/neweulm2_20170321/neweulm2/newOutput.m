% newOutput(varargin) - Create new system output
% 
%  Syntax:
%> newOutput;
%> newOutput(varargin);
% 
%  Description:
% A system output may be specified which currently only has an effect on
% the calculation of an output matrix or frequency response for a
% linearized system. And it may be very handy to obtain results after a
% numerical simulation. All values to be explained now can be contained in
% a mathematical expression like '2*KSYS1.omega(2) + 1'.
% 
% Different values can be specified as system outputs:
%
% - _kinematic_: specific coordinates of kinematic values of any coordinate 
%   system r_rel, phi_rel, r, v, a, phi, omega, alpha
%   For nodes of an elastic body, the value 'd' is available as well,
%   denoting the elastic deformation in the local frame of reference.
%   Should be specified in the following way:
%   KSYS1.omega(2) will give the second coordinate of the angular velocity
%   of coordinate system KSYS1.
%
% - _genCoord_: generalized coordinates and their first time derivative. 
%
% - _appliedForce_: applied forces, either by component, described in the 
%   respective DirDef system, or absolute value of the vector. 
%   felem1 would give the norm of the force vector, while felem1(4) would 
%   give the torque around the y-axis.
%
% - _reactionForce_: reaction forces, the forces between bodies. There are 
%   two ways to specifie this. First part of the variable is the name of 
%   the body on which the forces act. Second part is the component of the 
%   force. Possible are numbers from 1 to 6 for the 6 components of the 
%   reaction forces and moments acting on one body. You seperate both parts
%   by using backets or underlines.
%   examples: K3(1) would be reaction force in x direction acting on body K3  
%             P1_5 would be the torque around the y-axis acting on body P1
%
% - _element_: Pressure or difference of pressure in a volume element. 
%   This should be given as elem1.p or elem1.dp, respectively.
%
% - _userDef_: Any symbolic expression, using the parameters and 
%   generalized coordinates.
%
% - _combination_: The option 'combination' allows the user to give a 
%   mathematical expression, containing the IDs of other system outputs. 
%   This can be used e.g. to directly provide the sum of two forces from
%   force elements. However, the user has to ensure to get reasonable 
%   results. This might look like 'outID1+outID2'
%
%  Optional parameters, given pairwise:
% Id .............. Output identifier {'SYSOUT_1'}
% Name ............ Name of the system output {'Output Number 1'}
% Var ............. Variable or expression, which is used an output {}
% Type ............ Type of parameter to be used as output:
%                   ('kinematic', 'genCoord', 'appliedForce',
%                   'reactionForce', 'element', 'userDef', 'combination')
%                   {is being determined}
% Group ........... Specify to which output group the output is assigned.
%                   New groups can be defined as well. {'control'}
% newGroup ........ This option can be used to define new groups in
%                   addition to 'control'. {}
%
%  Examples:
%> newOutput('Id', 'myOutput', 'Var', 'Frame1.r(3)');
%> newOutput('Var', 'x1+0.5*x2', 'Type', userDef');
%
%  See also: 
%   newBody, newForceElem, newGenCoord, newFrame, newConstraint, newSys,
%   newInput, newConstant, newTimeDependent, newStateDependent, newVolume,
%   calcEqMotNonLin
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
