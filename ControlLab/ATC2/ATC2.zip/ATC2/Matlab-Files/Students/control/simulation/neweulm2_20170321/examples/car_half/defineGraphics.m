function defineGraphics
% DEFINEGRAPHICS - Create graphical representations of bodies and force
% elements
%

global sys;

% Adjust view
axis([-2.3 2.3 -2 2 0 1.6]); view(0, 0);
set(sys.graphics.light,'Position',[-6 -15 1])

% sys.graphics.line = [];
% sys.graphics = rmfield(sys.graphics, 'line');
% updateGeo(0,zeros(sys.counters.genCoord,1));

% Chassis
carlength_ = sys.parameters.data.ar + sys.parameters.data.ag + sys.parameters.data.ae + sys.parameters.data.aef;
h = drawCube([0 0.64 0.1], carlength_, 1.205, 0.6, [0 0 0.7],'Tag','Chassis');
h(2) = drawCube([0.3 0.64 0], 0.7, 1.205, 0.05, [0 0 0.7],'Tag','Chassis');
transformGraphics(h(2), 'RotationAngles',[0 3.9 0])
transformGraphics(h(2), 'Translation',[0.8 0 0.4])
addGraphics('CAR',h);


% Front wheel
h = drawRotBody([0 sys.parameters.data.r0 sys.parameters.data.r0 0],[0 0 0.005 0.005], ...
                   'FaceColor',[0.3 0.3 0.3], 'EdgeColor','none', 'NumPoints', 40, ...
                   'Tag','Front_wheel','FaceAlpha',0.8);
transformGraphics(h,'RotationAngles',[-0.5*pi, 0, 0], ...
    'Translation',[0 0.035 0]); % Rotate body and move it, so frames are visible
h(2) = drawRotBody([0 sys.parameters.data.r0 sys.parameters.data.r0 0],[0 0 0.005 0.005], ...
                   'FaceColor',[0.3 0.3 0.3], 'EdgeColor','none', 'NumPoints', 40, ...
                   'Tag','Front_wheel','FaceAlpha',0.8);
transformGraphics(h(2),'RotationAngles',[-0.5*pi, 0, 0], ...
    'Translation',[0 1.235 0]); % Rotate body and move it, so frames are visible
addGraphics('FA',h);

% Back wheel
h = drawRotBody([0 sys.parameters.data.r0 sys.parameters.data.r0 0],[0 0 0.005 0.005], ...
                   'FaceColor',[0.3 0.3 0.3], 'EdgeColor','none', 'NumPoints', 40, ...
                   'Tag','Back_wheel', 'FaceAlpha', 0.8);
transformGraphics(h,'RotationAngles',[-0.5*pi, 0, 0], ...
    'Translation',[0 0.035 0]); % Rotate body and move it, so frames are visible
h(2) = drawRotBody([0 sys.parameters.data.r0 sys.parameters.data.r0 0],[0 0 0.005 0.005], ...
                   'FaceColor',[0.3 0.3 0.3], 'EdgeColor','none', 'NumPoints', 40, ...
                   'Tag','Back_wheel', 'FaceAlpha', 0.8);
transformGraphics(h(2),'RotationAngles',[-0.5*pi, 0, 0], ...
    'Translation',[0 1.235 0]); % Rotate body and move it, so frames are visible
addGraphics('RA',h);

% Schwinge
h = drawRotBody([0 0 0.05 0.05],[-0.1 sys.parameters.data.daprbx sys.parameters.data.daprbx -0.1], ...
                   'FaceColor','red', 'EdgeColor','none', 'NumPoints', 20, ...
                   'Tag','Schwinge', 'FaceAlpha', 0.8);
transformGraphics(h,'RotationAngles',[0, 0.5*pi, 0]); % Rotate body
addGraphics('RA',h);

% Ungespannte Federlaenge Federbein Hinterachse
h = drawRotBody([sys.parameters.data.l0r sys.parameters.data.l0r],[0 0.005], ...
                   'FaceColor',[0 0.7 0], 'EdgeColor',[0 0.7 0], 'NumPoints', 20, ...
                   'Tag','FELEM_FH_Nomlength', 'FaceAlpha', 0.8);
transformGraphics(h,'RotationAngles',[-0.5*pi, 0, 0]); % Rotate body
addGraphics('CARRF',h);

% Hinterachse, Federbein
drawSpring('RAF','CARRF','FELEM_FH','Color',[0.8 0 0], ...
    'LineWidth',2, 'Diameter',0.07,'NumWinding',4);
drawLine('RAD','CARRD','DAMPER_FH','Color',[0.8 0 0], 'LineWidth',2);

% If a motor is included, draw one
if(isfield(sys.model.body,'E'))
    h = drawCube([0 0.038 0], 1.3*(sys.parameters.data.aef+sys.parameters.data.aer), 0.005, 0.3, [0.7 0 0], ...
        'Tag','Engine');
    addGraphics('E_cg',h);
end

% Fahrer
drawLine('Driver','CARS','Sitzfederung','Color',[0.8 0 0], 'LineWidth',2);
h = drawRotBody([0 0 0.1 0.1],[-0.03 0.08 0.08 -0.03], ...
                   'FaceColor',[0 0.7 0], 'EdgeColor',[0 0.7 0], 'NumPoints', 20, ...
                   'Tag','Fahrer', 'FaceAlpha', 0.2);
addGraphics('Driver_cg',h);

% road
plotTrajectories('RoadR');
plotTrajectories('RoadF','Color',[1 0 0]);

% END OF defineGraphics
