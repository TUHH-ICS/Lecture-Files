% res = signum(varargin)
% SIGNUM - sign function. This function is introduced for the numeric
% evaluation of expressions with MAPLE syntax.
% It accepts several input arguments as MAPLE uses this to signify
% derivatives. 
%
% usage:
% signum(x)     sign(x). Meaning 1 for all positive and -1 for all negative
%               numbers and undefined for x = 0. But as in Matlab the
%               sign function is defined, so sign(0) = 0. If x is
%               non-numeric it tries to evaluate the given expression.
% signum(1,x)   derivative of signum(x), 0 for all nonzero elements,
%               undefined otherwise
% signum(n,x)   n-th order derivative of signum(x), equals signum(1,x)
% signum(0,x,y) as signum(0) is undefined this handles this exception.
%               signum(0,x,y) = sign(x) for all x ~= 0 and
%               signum(0,0,y) = y.
%
% See also: csgn, mapleSimplify, mapleSubs
%
% First appearance: 05.12.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
