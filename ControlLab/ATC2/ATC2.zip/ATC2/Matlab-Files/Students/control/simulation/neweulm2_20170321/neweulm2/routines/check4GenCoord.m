% check4GenCoord - Check if an expression contains variables, which are
% currently undefined. If so, regard them as generalized coordinates and do
% all necessary definitions
%
% This function shall not be used in the future, it will be replaced by
% newGenCoord, requiring explicit definitions of generalized coordinates.
% It will be supported for some time to keep compatibility with existing
% input files, but it showed that it is better to use explicit definitions.
% In order to get a model up to date, you can follow these steps:
% - Save your input files (usually sysDef.m and setUserVar.m under
%   different names or in a different folder for backup.
% - Perform a complete modelling and initialization, optionally also the
%   time integration.
% - Call 'writeSysDef' to recreate sysDef.m and setUserVar.m in the current
%   version.
% - Continue with your simulations and analysis as before, using the new
%   model.
%
% expr       Expression to be searched (string or sym)
% yidx       Indices of parameters in the vector of the generalized
%            coordinates
%
% See also: newBody, newGenCoord
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
