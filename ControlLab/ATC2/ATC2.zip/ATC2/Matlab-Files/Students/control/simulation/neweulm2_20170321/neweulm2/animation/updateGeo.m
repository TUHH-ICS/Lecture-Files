% updateGeo - Ensure the graphical representation of the
% system is up to date. 
%
%  Syntax:
% updateGeo(t, y, varargin);
%
%  Description:
% Ensure the graphical representation of the system is up to date. 
% This means especially the adjustment of the used time t and vector 
% of generalized coordinates y. If no input arguments are specified but 
% an animation window exists, the current configuration is reupdated. 
% This is mainly to adjust newly created graphic objects. In
% some rare cases an output is needed, e.g. to obtain the values used for
% color interpolation.
%
%  Input values:
% t ....... Simulation time
% y ....... Vector of generalized coordinates or complete state vector
% Dy ...... Optionally as a third vector, the generalized velocities can be
%           specified. This is only necessary for some advanced features
%           like coloring surfaces using system outputs. Otherwise these
%           values are not considered
%
%  Return values:
% varargout{1} ... Values used for color interpolation
%
%  Valid options for mesh colors:
% (have to be adjusted in sys.graphics.surfaces.MESH_NAME.cdataSelect)
%   - '' .................... uniform surface color as defined (default)
%   - 'usum' ................ nodal displacemts vector sum
%   - 'ux', 'uy', 'uz' ...... nodal displacemts
%   - 'vonMises' ............ von Mises stress
%   - 'sx', 'sy', 'sz' ...... stresses
%   - 'sxy', 'syz', 'sxz' ... shear stresses
%   - 's1', 's2', 's3' ...... principal stresses
%   - 'spsum' ............... principal stress sum
% 
%  See also: createAnimationWindow, initGraphics, drawSys
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
