% createHelpTocs(allData)
% Create the files helptoc.xml and the function_help.m used for the tree
% and the table of contents in the matlab help browser. The input arguments
% are to be acquired e.g. as
% createHelpTocs(setNeweulm2HelpTocData);
