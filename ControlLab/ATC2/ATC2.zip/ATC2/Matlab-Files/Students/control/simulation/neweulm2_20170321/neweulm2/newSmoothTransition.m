% newSmoothTransition(varargin) - create a time dependent variable defined
% by a n-times continuously differentiable polynominal
%
%  Syntax:
%> newSmoothTransition;
%> newSmoothTransition('Property', value, ...);
%
%  Description:
% This function alows the creation of a smooth transition between the start
% value and the end value. Before the time t reaches the start time, the
% start value is passed out. After the time t passes the end time, the end
% value is hold. All paramters can be defined as numerical or symbolical
% values. The created variable can be used like a variable defined with 
% newTimeDependent.
%
%  Mandatory parameters, given pairwise:
% Id .............. Identifier of the transition {'smoothTrans_1'}
%
%  Optional parameters, given pairwise:
% StartTime ....... Time, when the transition is started {0}
% EndTime ......... Time, when the transition is completed {1}
% StartValue ...... Value at the beginning of the transition {0}
% EndValue ........ Value at the end of the transition {1}
%
%  Example:
%> newSmoothTransition('Id','myElementID', 'StartTime', 0, ...
%>    'EndTime', 't_end', 'StartValue', 'p1', 'EndValue', 1);
%
%  See also: 
% newBody, newForceElem, newGenCoord, newFrame, newConstraint,
% newSys, newInput, newOutput, newConstant, newStateDependent, newVolume
%
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
