#ifndef seulexMexh
#define seulexMexh

/* Optionsettings */
#define OPT_WARNMISS "OptWarnMiss"
#define OPT_WARNTYPE "OptWarnType"
#define OPT_WARNSIZE "OptWarnSize"

/* H and Tols */
#define OPT_INITIALSS "InitialStep"
#define OPT_RTOL "RelTol"
#define OPT_ATOL "AbsTol"

/* StepSizeSelection */
#define OPT_RHO "rho"
#define OPT_MAXSTEPS "MaxNumberOfSteps"
#define OPT_STEPSIZESEQUENCE "StepSizeSequence"
#define OPT_MAXSS "MaxStep"
#define OPT_SSSELECTPAR1 "StepSizeSelectionParam1"
#define OPT_SSSELECTPAR2 "StepSizeSelectionParam2"
#define OPT_SSSELECTPAR3 "StepSizeSelectionParam3"

/* Extrapolation */
#define OPT_MAXEXCOLUMN "MaxExtrapolationColumn"
#define OPT_ORDERDECFRAC "OrderDecreaseFraction"
#define OPT_ORDERINCFRAC "OrderIncreaseFraction"

/* Mass */
#define OPT_MASSMATRIX "Mass"
#define OPT_MASSLBAND "MassLowerBandwidth"
#define OPT_MASSUBAND "MassUpperBandwidth"

/* Jacobi */
#define OPT_TRANSJTOH "TransfromJACtoHess"
#define OPT_JACRECOMPFACTOR "RecomputeJACFactor"
#define OPT_JACOBIMATRIX "Jacobian"
#define OPT_JACOBILBAND "JacobianLowerBandwidth"
#define OPT_JACOBIUBAND "JacobianUpperBandwidth"

/* Output */
#define OPT_OUTPUTFUNCTION "OutputFcn"
#define OPT_OUTPUTCALLMODE "OutputCallMode"
#define OPT_OUTPUTLAMBDADENSE "OutputDenseLambda"

/* Estimation of Work */
#define OPT_WORKFCN "WorkForRightSide"
#define OPT_WORKJAC "WorkForJacobimatrix"
#define OPT_WORKDEC "WorkForDecomposition"
#define OPT_WORKSOL "WorkForSolve"

/* Special structure */
#define OPT_M1 "M1"
#define OPT_M2 "M2"

/* Rest */
#define OPT_EPS "eps"
#define OPT_IGPIDO "IncludeGridPointsInDenseOutput"
#define OPT_ISAUTONOMOUS "SystemIsAutonomous"
#define OPT_FUNCCALLMETHOD "FuncCallMethod"

typedef void (*SeulexRightSide)(int *n, double *t,
  double *x, double *f, double *rpar, int *ipar);

typedef void (*SeulexSolout)(int *nr, double *told,
  double *t, double *x, double *rc, int *lrc,
  double *ic, int *lic, int *n, 
  double *rpar, int *ipar, int *irtrn);
  
typedef void (*SeulexMAS)(int *n, double *am,
  int *lmas, double *rpar, int *ipar);
  
typedef void (*SeulexJAC)(int *n, double *t,
  double *x, double *dfx, int *ldfx, double *rpar, int *ipar);

struct ListElement
{ /* Verkettete Liste mit (t,x)-Paaren, also Vektoren der L�nge d+1 */
  double* values;
  struct ListElement *next;
};
typedef struct ListElement SListElement;
typedef SListElement* PListElement;

struct ParameterOptions
{ /* Parameter f�r Options */    
  const mxArray *opt;  /* Optionen */
  int optCreated;      /* Flag, ob Optionen selbst generiert wurden */
};
typedef struct ParameterOptions SParameterOptions;

struct ParameterGlobal 
{ /* globale Variablen usw. */
  int d;              /* Dimension des Systems */
  int tLength;        /* L�nge des t-Vektors */  
  double* tPointer;   /* Pointer auf Zeitdaten in tArray */  
  double direction;   /* sign(tEnd-tStart) */
  int funcCallMethod; /* Methode, um Matlab-Funktionen aufzurufen */
};
typedef struct ParameterGlobal SParameterGlobal;

struct ParameterSeulex
{ /* Parameter f�r Seulex (soweit nicht ausgelagert) */
  double tStart;    /* Startzeitpunkt */
  double tEnd;      /* Endzeitpunkt */
  double h;         /* Startschrittweite */
  int IFCN;         /* Flag, ob System nicht autonom */
  int denseFlag;    /* Flag, ob dense-Output aktiv */
  int maxExColumn;  /* maximale Spalte im Extrapolationstableau */  
  double *xStart;   /* Startwert */
  double *RTOL;     /* releative Toleranz */
  double *ATOL;     /* absolute Toleranz */
  int ITOL;         /* Switch f�r RTOL und ATOL */  
  int IOUT;         /* Switch f�r SOLOUT */  
  double *WORK;     /* Double-Arbeits-Array */
  int LWORK;        /* L�nge von WORK */
  int *IWORK;       /* Integer-Arbeits-Array */
  int LIWORK;       /* L�nge von IWORK */
  double *RPAR;     /* Zusatz double-array */
  int *IPAR;        /* Zusatz int-array */
  int IDID;         /* Status */  
  int mm;           /* m1=mm*m2, falls m1,m2!=0 */
};
typedef struct ParameterSeulex SParameterSeulex;

struct ParameterRightSide 
{ /* Parameter f�r rechte Seite f */
  char *rightSideFcn;           /* Funktionsname f�r rechte Seite */
  const mxArray *rightSideFcnH; /* Funktionshandle oder inline-function f�r rightSide */
  mxArray *tArg;                /* Zum Aufruf von f: t */
  mxArray *xArg;                /* Zum Aufruf von f: x */
};
typedef struct ParameterRightSide SParameterRightSide;

struct ParameterMassmatrix
{ /* Parameter f�r Massenmatrix */
  int IMAS;                /* Switch zur Berechnungsmethode f�r Massenmatrix */
  int MLMAS;               /* untere Bandbreite von Massenmatrix */
  int MUMAS;               /* obere Bandbreite von Massenmatrix */  
  SeulexMAS seulexMASFunc; /* Funktion f�r Massenmatrix aus seulex */
};
typedef struct ParameterMassmatrix SParameterMassmatrix;

struct ParameterJacobimatrix
{ /* Parameter f�r Jacobimatrix */
  int IJAC;                /* Switch zur Berechnungsmethode f�r Jacobi */
  int MLJAC;               /* untere Bandbreite von Jacobi */
  int MUJAC;               /* obere Bandbreite von Jacobi */
  SeulexJAC seulexJACFunc; /* Funktion f�r Jacobimatrix aus Radau */
  char *jacFcn;            /* Funktion zur Berechnung der Jacobimatrix */
  const mxArray *jacFcnH;  /* Funktionshandle oder inline-function f�r Jacobi */
  mxArray *tArg;           /* Zum Aufruf von jac: t */
  mxArray *xArg;           /* Zum Aufruf von jac: x */
};
typedef struct ParameterJacobimatrix SParameterJacobimatrix;

struct ParameterOutput
{ /* Parameter zum Speichern der Seulex-Ausgabe */
  SListElement txList;        /* Start der txListe */
  PListElement lastTXElement; /* letzter Eintrag in txListe */
  int numberOfElements;       /* Anzahl der Eintr�ge in txListe */
  int tPos;                   /* Position im t-Vektor */
  int includeGrid;            /* Flag, dense Ausgabe mit Gridpoints */
  char* outputFcn;            /* Outputfunction */
  const mxArray *outputFcnH;  /* Outputfunction: handle oder inline-function */
  int outputCallMode;         /* Modus f�r outputFcn-Aufruf */
  mxArray *tArg;              /* Zum Aufruf von outputFcn: t */
  mxArray *xArg;              /* Zum Aufruf von outputFcn: x */
};
typedef struct ParameterOutput SParameterOutput;

#ifdef FORTRANNOUNDER
/* Fotran functions without underscore */
#ifdef FORTRANUPP
/* Fotran functions without underscore  & UPPERCASE letters */
#define SEULEX_ SEULEX
#define CONTEX_ CONTEX
#else
/* Fotran functions without underscore  & lowercase letters */
#define SEULEX_ seulex
#define CONTEX_ contex
#endif
#else
/* Fortran functions with underscore */
#ifdef FORTRANUPP
/* Fortran functions with underscore & UPPERCASE letters */
#else
/* Fortran functions with underscore & lowercase letters */
#define SEULEX_ seulex_
#define CONTEX_ contex_
#endif
#endif

extern double CONTEX_ (int *i,
  double *t, double *rc, int *lrc, double *ic, int *lic);

extern void SEULEX_ (int *n, SeulexRightSide fcn, int *ifcn,
  double *t, double *x, double *tend, double *h, 
  double *rtol, double *atol, int *itol,
  SeulexJAC jac, int *ijac, int *mljac, int *mujac,
  SeulexMAS mas, int *imas, int *mlmas, int *mumas,
  SeulexSolout solout, int *iout,
  double *work, int *lwork,
  int *iwork, int *liwork,
  double *rpar, int *ipar, int* idid);

#endif
