%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                    %
% Programm to build a multi-body-system-model                        %
% The definition is in the file sysDef.m                             %
% The following routine is initSys which starts setUserVar.m to get  %
% all values for the parameters of the model.                        %
%                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Author:       Dipl.-Ing. Thomas Kurz
%
% e-Mail:       kurz@itm.uni-stuttgart.de
%
% Institute:    Universitaet Stuttgart
%               Institut fuer Technische und Numerische Mechanik
%               Pfaffenwaldring 9
%               70569 Stuttgart
%

%%%%%%%%%%%%%%%%%%%%%%%%
% Extend path variable %
%%%%%%%%%%%%%%%%%%%%%%%%

run('../addpathNeweulm2');

%%%%%%%%%%%%%%%%%%%%%%%%
% Initialize workspace %
%%%%%%%%%%%%%%%%%%%%%%%%

close all;
clear all;
clear global;
global sys;

%%%%%%%%%%%%%%%%%%%%%
% define the System %
%%%%%%%%%%%%%%%%%%%%%

% Number of chain links
p = 25;
% Formulation ('recursive', 'recursiveMinimal', 'newtonEuler')
formulation = 'recursiveMinimal';
% Parameter set
% Set 1: Circular motion of support, r=0.15
% Set 2: Excite the second eigenfrequency in the xz-plane
%        Hard coded xOmega=9.4775, yOmega=0 for p=25
parSet = 1;
% Number of dimensions
% For nDimensions==3, a spatial pendulum is set up, nDimensions==2 creates
% a pendulum in the xz-plane
nDimensions = 3;

% Integrationtime
t_end = 10;

tic;
sysDef(p,formulation,parSet);
fprintf(1,' ok!\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% create nonlinear equations of motion %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

sys.settings.equation.frameOfReference = 'body';
calcEqMotNonLin;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% save the system and create functions for numerical evaluation %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Don't use code runtime optimization
sys.settings.equation.optimize = false;
writeMbsNonLin;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% linearize the equations of motion %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% calcEqMotLin;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% create functions for numerical evaluation %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% writeMbsLin;


%%%%%%%%%%%%%%%%%%%
% save the System %
%%%%%%%%%%%%%%%%%%%

fprintf(1,'\nSaving System ...');
save 'sys.mat' sys;
fprintf(1,' ok!\n');

fprintf(1,'\n---\n');
toc;

%%%%%%%%%%%%%%%%%%%%%%%%
% Integrate the System %
%%%%%%%%%%%%%%%%%%%%%%%%

tic;
timeInt(zeros(sys.counters.genCoord,1),zeros(sys.counters.genCoord,1),'time',[0,t_end]);
toc;

%%%%%%%%%%%%%%%%%%%
% Simulate Result %
%%%%%%%%%%%%%%%%%%%

% create animation window
sys.settings.graphics.frame.size = 0.001;
sys.settings.graphics.frame.fontSize = 3;
sys.settings.graphics.frame.colors = {'red'  'yellow'  'blue'};
sys.settings.graphics.frame.nrot = 10;
sys.settings.graphics.frame.dlratio = 0.05;
createAnimationWindow;

defineGraphics(p);
setVisibility('off','type','text');
axis([-0.7 0.7 -0.7 0.7 -1.4 0.07]);
view(45,10);
animTimeInt('Stride',0.2);

%%%%%%%%%%%%%%%%%%%
% Save the system %
%%%%%%%%%%%%%%%%%%%

fprintf(1,'\nSaving System ...');
save 'sys.mat' sys;
fprintf(1,' ok!\n');

% END OF startSysDef
