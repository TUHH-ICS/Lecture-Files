function defineGraphics
% DEFINEGRAPHICS - create graphic visualization of modeling elements
%

global sys;

%%%%%%%%%%%%%%
% Support    %
%%%%%%%%%%%%%%
h = drawCube([0 0 0.01], 0.15,0.15,0.02,'blue','FaceAlpha',0.3, ...
    'Tag','Support','EdgeColor','blue');
addGraphics('ISYS',h);


%%%%%%%%%%%%%%
% Pendulum 1 %
%%%%%%%%%%%%%%

h(1) = drawSphere([0 0 0],0.02,20,'red', ...
    'Tag','Ball_P1','EdgeColor','none');

h(2) = drawRotBody([0.005 0.005],[0 sys.parameters.data.l1], ...
    'Tag','Rod_P1','FaceColor','red','EdgeColor','red');
addGraphics('P1_cg',h);


%%%%%%%%%%%%%%
% Pendulum 2 %
%%%%%%%%%%%%%%

h(1) = drawSphere([0 0 0],0.02,20,[0 1 0], ...
    'Tag','Ball_P2','EdgeColor','none');

h(2) = drawRotBody([0.005 0.005],[0 sys.parameters.data.l2], ...
    'Tag','Rod_P2','FaceColor',[0 1 0],'EdgeColor',[0 1 0]);
addGraphics('P2_cg',h);

% If desired, please adjust the visible area here

% % Update the plot window to a reasonable configuration
% updateGeo(0,zeros(sys.counters.genCoord,1));
% 
% % define Visible area
% axis equal;
% xlim([-0.4 0.4]);
% ylim([-0.4 0.4]);
% zlim([-0.4 0.4]);
% view(30,18);
% 
% % set visibility properties
% setVisibility('on');

% END OF defineGraphics
