#ifndef dopriMexh
#define dopriMexh

/* Optionsettings */
#define OPT_WARNMISS "OptWarnMiss"
#define OPT_WARNTYPE "OptWarnType"
#define OPT_WARNSIZE "OptWarnSize"

/* H and Tols */
#define OPT_INITIALSS "InitialStep"
#define OPT_RTOL "RelTol"
#define OPT_ATOL "AbsTol"

/* Output */
#define OPT_OUTPUTFUNCTION "OutputFcn"
#define OPT_OUTPUTCALLMODE "OutputCallMode"

/* StepSizeSelection */
#define OPT_RHO "rho"
#define OPT_SSMINSEL "StepSizeMinSelection"
#define OPT_SSMAXSEL "StepSizeMaxSelection"
#define OPT_SSBETA "StepSizeBeta"
#define OPT_MAXSS "MaxStep"
#define OPT_MAXSTEPS "MaxNumberOfSteps"

/* Rest */
#define OPT_IGPIDO "IncludeGridPointsInDenseOutput"
#define OPT_EPS "eps"
#define OPT_STEST "StiffTestAfterStep"
#define OPT_FUNCCALLMETHOD "FuncCallMethod"

struct ListElement
{ /* Verkettete Liste mit (t,x)-Paaren, also Vektoren der L�nge d+1 */
  double* values;
  struct ListElement *next;
};
typedef struct ListElement SListElement;
typedef SListElement* PListElement;

struct ParameterGlobal 
{ /* globale Variablen usw. */
  int d;              /* Dimension des Systems */
  int tLength;        /* L�nge des t-Vektors */  
  double* tPointer;   /* Zeiger auf alle Zeitwerte */
  double direction;   /* sign(tEnd-tStart) */  
  int funcCallMethod; /* Methode, um Matlab-Funktionen aufzurufen */ 
};
typedef struct ParameterGlobal SParameterGlobal;

struct ParameterOptions
{ /* Parameter f�r Optionen */    
  const mxArray *opt;  /* Options */
  int optCreated;      /* Flag, ob Options selbst erzeugt wurde */
};
typedef struct ParameterOptions SParameterOptions;

struct ParameterDOPRI
{ /* Parameter f�r DOPRI */
  double tStart;    /* Startzeitpunkt */
  double tEnd;      /* Endzeitpunkt */
  double *xStart;   /* Startwert */
  double *RTOL;     /* releative Toleranz */
  double *ATOL;     /* absolute Toleranz */
  int ITOL;         /* Switch f�r RTOL und ATOL */
  int IOUT;         /* Switch f�r SOLOUT */
  int denseFlag;    /* Flag, ob dense output */
  double *WORK;     /* Double-Arbeits-Array */
  int LWORK;        /* L�nge von WORK */
  int *IWORK;       /* Integer-Arbeits-Array */
  int LIWORK;       /* L�nge von IWORK */
  double *RPAR;     /* Zusatz double-array */
  int *IPAR;        /* Zusatz int-array */
  int IDID;         /* Status */
};
typedef struct ParameterDOPRI SParameterDOPRI;

struct ParameterRightSide
{ /* Parameter f�r rechte Seite f */
  char *rightSideFcn;            /* Funktionsname f�r rechte Seite, 
                                    falls als String angegeben und funcCallMethod==0 */
  const mxArray *rightSideFcnH;  /* Funktionshandle oder inline-function f�r rightSide */
  mxArray *tArg;                 /* Zum Aufruf von rightSideFcn: t */
  mxArray *xArg;                 /* Zum Aufruf von rightSideFcn: x */
};
typedef struct ParameterRightSide SParameterRightSide;

struct ParameterOutput
{ /* Parameter zum Speichern der DOPRI-Ausgabe */
  SListElement txList;        /* Start der txListe */
  PListElement lastTXElement; /* letzter Eintrag in txListe */
  int numberOfElements;       /* Anzahl der Eintr�ge in txListe */
  int tPos;                   /* Position im t-Vektor */
  int includeGrid;            /* Flag, dense Ausgabe mit Gridpoints */
  char* outputFcn;            /* Outputfunction, falls als String angegeben */
  const mxArray *outputFcnH;  /* Outputfunction: handle oder inline-function */
  int outputCallMode;         /* Modus f�r outputFcn-Aufruf */
  mxArray *tArg;              /* Zum Aufruf von outputFcn: t */
  mxArray *xArg;              /* Zum Aufruf von outputFcn: x */  
  mxArray *emptyArg;          /* Zum Aufruf von outputFcn: empty array [] */
  mxArray *toldArg ;          /* Zum Aufruf von outputFcn: tOld */
};
typedef struct ParameterOutput SParameterOutput;

struct DopriDense
{ /* Argumente zum Aufruf von CONTD */
  double *con;
  int *icomp;
  int *nd;
};
typedef struct DopriDense SDopriDense;

typedef void (*DOPRIRightSide)(int *n, double *t,
  double *x, double *f, double *rpar, int *ipar);

typedef void (*DOPRISolout)(int *nr, double *told,
  double *t, double *x, int *n,
	double *con, int *icomp, int *nd,
	double *rpar, int *ipar, int *irtrn);

#ifdef FORTRANNOUNDER
/* Fotran functions without underscore */
#ifdef FORTRANUPP
/* Fotran functions without underscore  & UPPERCASE letters */
#define DOP853_ DOP853
#define CONTD8_ CONTD8

#define DOPRI5_ DOPRI5
#define CONTD5_ CONTD5
#else
/* Fotran functions without underscore  & lowercase letters */
#define DOP853_ dop853
#define CONTD8_ contd8

#define DOPRI5_ dopri5
#define CONTD5_ contd5
#endif
#else
/* Fortran functions with underscore */
#ifdef FORTRANUPP
/* Fortran functions with underscore & UPPERCASE letters */
#else
/* Fortran functions with underscore & lowercase letters */
#define DOP853_ dop853_
#define CONTD8_ contd8_

#define DOPRI5_ dopri5_
#define CONTD5_ contd5_
#endif
#endif

#endif
