function res = getNeweulWorkingPath
% Store the last working path of the neweulm2-GUI
% --------------------- Automatically generated file! ---------------------

res = 'D:\OneDrive\TU\Master - Systems and Control\5SC55 - Internship\Files TUHH\ATC - Control Lab\Neweul\MBS';