% newPeriodic(varargin) - create a periodic variable defined
% by a spline
%
%  Syntax:
%> newPeriodic;
%> newPeriodic('Property', value, ...);
%
%  Description:
% This function is used to define a periodic signal. Therefore, it is 
% necessary to define one period of the signal. This can be done with a
% discrete set of matching input and output values, which are used to 
% set up a spline. Next to the standard case, in which the argument is the 
% time t, it is possible to set the used argument to be a user-defined 
% value depending on the time, the generized coordinates or other defined 
% values. 
%
%  Mandatory parameters, given pairwise:
% Id .............. Identifier of the periodic {'periodic_1'}
%
%  Optional parameters, given pairwise:
% Breaks ......... Discrete values of the argument {[0 1 2 3 4]}
% Values ......... Discrete values of the output {[0 1 0 -1 0]}
% Argument ....... Argument {'t'}
%
%  Example:
%>   newPeriodic('Id','myElementID','Breaks',[0 1 2 3],'Values',[1; -2; 0; 1],'Argument','t');
%
%  See also: newBody, newForceElem, newGenCoord, newFrame, newConstraint,
%   newSys, newInput, newOutput, newConstant, newStateDependent, newVolume,
%   calcEqMotNonLin, newTimeDependent>createSymbolicFunctionMfiles,
%   newTimeDependent>createTemplateFunctionMfiles
%
% First appearance: 11.02.2013
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
