function res_ = f_D2FV(t,y_,varargin)

res_ = 0; % Default return value
