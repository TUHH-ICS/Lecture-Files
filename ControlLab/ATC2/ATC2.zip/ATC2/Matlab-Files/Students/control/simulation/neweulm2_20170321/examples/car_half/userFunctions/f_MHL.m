function res_ = f_MHL(t,y_,varargin)
% res_ = f_MHL(t,y_,varargin)
% f_MHL - Definition of user-defined variable MHL
% For a better template, please call the appropriate function
% newUserVarTvar for time dependent parameters
% newUserVarYvar for state dependent parameters

global sys;

if(nargin==1 && ischar(t) && strcmp(t,'linearization'))
	% Case IV: Call was f_...('linearization')
	% Return symbolic expression to calculate the linearization
	% Necessary for all parameters appearing in the equations of motion to linearize!
	res_ = sym('cerx*(1+(xe-aer*cos(be)-her*sin(be)+aer)^2/xd_erx^2)');
	return;
end

% constant user-defined variables

xdm = sys.parameters.data.xd_erx;
c = sys.parameters.data.cerx;

% relative vector
% ksys1 = str2func('KARHL_r');
ksys1 = str2func('CARER_r');
ksys2 = str2func('ER_r');
SDirdef = CARER_S(t,y_);

r_ = transpose(SDirdef)*(ksys2(t,y_) - ksys1(t,y_));

% state dependent user defined functions
x = r_(1);
res_ = springParam(x, c, 0, -xdm, 0, xdm);

