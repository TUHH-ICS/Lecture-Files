function defineGraphics
% DEFINEGRAPHICS - create graphic visualization of modeling elements
%

global sys;


%%%%%%%%%
% Bar 1 %
%%%%%%%%%

h(1) = drawRotBody([0.025 0.025],[0 sys.parameters.data.l1], ...
    'Tag','Bar_B1','FaceColor',[0 1 0],'EdgeColor',[0 1 0]);

transformGraphics(h(1),'RotationAngles',[pi/2, 0, 0],'Translation',[0; sys.parameters.data.l1/2; 0]); % Rotate body
addGraphics('B1_cg',h);
h = [];

%%%%%%%%%
% Bar 2 %
%%%%%%%%%

h(1) = drawRotBody([0.025 0.025],[0 sys.parameters.data.l2], ...
    'Tag','Bar_B2','FaceColor',[0 1 0],'EdgeColor',[0 1 0]);

transformGraphics(h(1),'RotationAngles',[pi/2, 0, 0],'Translation',[0; sys.parameters.data.l1/2; 0]); % Rotate body
addGraphics('B2_cg',h);
h = [];

%%%%%%%%%%%%%%%
% Cross  Bar  %
%%%%%%%%%%%%%%%

h(1) = drawCube([0 0 0],0.05,sys.parameters.data.l3,0.05,'blue', ...
    'Tag','Bar_B1');

transformGraphics(h(1),'RotationAngles',[0, 0, 0],'Translation',[0; 0; 0]); % Rotate body
addGraphics('CB_cg',h);
h = [];

%%%%%%%%
% Ball %
%%%%%%%%

h(1) = drawSphere([0 0 0],sys.parameters.data.l4/2,20,[1 0 0], ...
    'Tag','Sphere_BA','EdgeColor','none');
addGraphics('BA_cg',h);





