% writeAnimGeo(varargin)
% Export surface objects so they can be used for an animation with Anim. Of
% the following list of necessary files for Anim, this function creates the
% simulation independent files .geoall and .geo.
% 
% Optional input arguments
% handle ... If one input argument is given, it should be a graphics handle
%            to the object to be exported to anim.
% 
% Anim requests the following files to be able to create an animation:
% - SomeName.str ....... An .str file contains the positions and
%                        orientations of coordinate systems during an
%                        animation. Therefore one has to be created for
%                        each animation result. This can be created with
%                        the function writeStrFile. Default filename for
%                        this is [sys.model.id,'.str']
% - SomeName.geoall .... File containing the number of geometric objects
%                        and their filenames in the order of the coordinate
%                        systems exported in SomeName.str. Default filename
%                        is [sys.model.id,'.geoall']
% - Shape1.geo ......... For each surface object representing a rigid body
%                        with a specific geometry one .geo file is
%                        necessary for its definition. If two bodies are
%                        represented by the same shape, they can use the
%                        same .geo file. However, for simplicity, each
%                        surface objects gets its own .geo file. Their
%                        filename is the fieldname of the corresponding
%                        entry in sys.graphics.surfaces.
% 
% To be able to use Anim execute the following function:
%   writeStrFile
% If you don't change anything, the filenames of 
% the .geoall and of .str-file will be the same.
% This function prints the command for writeStrFile together with the
% necessary coordinate systems to which the shapes are attached. This is
% preferable as you don't have to worry if the geometric shapes will be
% attached to the correct coordinate system.
%
% use Anim:
% - Help in the command line:
%   anim -h
% 
% - Animation of the file DP.str with the shapes of DP.geoall:
%   anim -g DP.geoall -k DP.str
% 
% - In Anim:
%   Right  mouse button: Menu
%   Left   mouse button: Rotate
%   Middle mouse button: Zoom or Translation
% 
% - Define the time step size
%   [Menu][Realtime][Interval]
%   Then type the same time stepsize which has been used in Neweul-M^2
%   before to calculate the .str file. As a default, this is set to 0.05 s.
% 
% See also: writeGeo2NFF, writeStrFile
%
% First appearance: 04.11.2009
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
