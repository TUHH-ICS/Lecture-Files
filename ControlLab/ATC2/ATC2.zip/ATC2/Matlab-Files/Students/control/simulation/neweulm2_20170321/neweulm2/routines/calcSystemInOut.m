% calcSystemInOut(useMinimalInputVect_)
% Calculate all necessary data for system inputs and system outputs
%
% Input arguments
