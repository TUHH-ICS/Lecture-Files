%% Software Structure


%% Introduction
% The software consists of two main parts, one for the definition of the system
% and the derivation of the equations of motion, the other one provides functions
% for the numerical analysis, simulation and optimization of multibody systems.
% All files building the software are stored in a directory called neweulm2,
% the model-specific data is stored to a separate model directory. It contains
% all files being necessary for the system's definition and performing 
% simulations. The user is welcome to edit these files to his needs. 
%     
%
%% Graphical user interface
% A graphic user interface (GUI) can be found in neweulm2/gui/ and has been
% created with the Matlab GUI layout editor guide. It is created not independently
% but as a front-end to the existing version, which is controlled by input files.
% Therefore, it calls the same functions for the actual modeling and simulation.
% There are different ways to start it. If you've just started Matlab the best 
% is to move to the folder examples/sandbox/ and run the file link_neweulm2.m.
% This will then set up the Matlab path so the file neweulm2.m and startneweulm2.m 
% in the folder neweulm2/gui/ are found. There is a small difference between these
% two files.
% % When you call startneweulm2.m, the workspace is cleared, figures are closed
% and the gui is started. This means you are ready to go, but your workspace is
% empty. When running link_neweulm2.m also this startneweulm2 is called. If still
% this is not convenient for you, you can call the function writeneweulm2link.m
% after starting the GUI. This will create a file also called link_neweulm2.m,
% but this time with the absolute path stored inside, therefore making it possible
% to start the GUI from any given folder. Many of the input files can be created 
% from the GUI under the menu entry Export System to ensure compatibility in both
% ways.
% % When you call neweulm2 directly the workspace as well as all figures are kept
% and only the GUI is started. Therefore, this presents the easiest way to switch
% from input files to the GUI. You simply run the input files, type neweulm2
% and then you can work on the current model. Also, you can type Neweul-M² commands
% or close the GUI at any time and continue working solely with commands. With 
% the only exception that, if you select Exit from the File menu, then the workspace
% will be cleared. In order to keep the model you should select Close Menu
% or click on the little cross in the upper right corner. Another way to 
% start is to move to the provided examples folder and call the gettingStarted-GUI
% or go directly to one model and type: 
 fullModelRun ;
%%
% to set up the system and run all available simulations. After these commands
% the resulting data structure will be saved to a file called sys.mat which can
% easily be loaded in the graphical user interface.
% % Another way of switching the way to control Neweul-M² is to save your model
% as a .mat file and load it in the other mode. Sometimes it happens that strange
% errors occur when some elements like bodies are deleted in the GUI. If that is
% the case, simply open Export System from the File menu and create the Input fi
% les. This will create one file containing all definitions which can be used to
% easily rebuild your model from scratch.
