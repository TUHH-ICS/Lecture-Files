% [numberOfOutputs, myIndices] = getNumOfCell(myStruct)
% This function returns the overall number of entries and an index array
% for each substructure.
%
% First appearance: 02.07.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
