% newRandomSignal(varargin) - create a time dependent variable containuing
% a random signal based on a normal distribution
%
%  Syntax:
%> newRandomSignal;
%> newRandomSignal('Property', value, ...);
%
%  Description:
% This function is used to define a random signal based on a Gaussian
% distribution. All parameters have to be numerical values. The created
% variable can be used like a variable defined with newTimeDependent.
%
%  Mandatory parameters, given pairwise:
% Id .............. Identifier of the normalDist 
%
%  Optional parameters, given pairwise:
% StartTime ....... Time in seconds, when the normalDist is started (double) {0}
% EndTime ......... Time in seconds, when the normalDist is completed (double) {1}
% Mean ............ Mean value of the normal distribution (double) {0}
% Deviation ....... Standard deviation of the normal distribution (double) {1e-6}
% Cutoff .......... Cutoff frequency in Hz {200}
%
%  Example:
%> newRandomSignal('Id', 'myElementID', 'StartTime', 0, ...
%>   'EndTime', 1, 'Mean', 0, 'Deviation',1e-3);
%
%  See also: 
% newBody, newForceElem, newGenCoord, newFrame, newConstraint,
% newSys, newInput, newOutput, newConstant, newStateDependent, newVolume,
% calcEqMotNonLin
%
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
