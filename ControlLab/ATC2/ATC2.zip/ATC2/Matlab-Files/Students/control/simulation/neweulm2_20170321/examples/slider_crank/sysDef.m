% sysDef
% System definition slider_crank
% 
% Please consider the file setUserVar.m, which can be used to set numerical
% values to parameters.
%


% Create basic data structure

global sys;

sys = newSys('Id','SK', 'Name','slider_crank');

% If necessary, adjust the direction of gravity
% sys.model.gravity = '[0; 0; -g]';

%%%%%%%%%%%%%%
% Pendulum 1 %
%%%%%%%%%%%%%%

newConstant('m1',1,'l1',0.05);
newGenCoord('gamma1');

newBody('Id','CA', ...
        'Name','Pendulum 1', ...
        'RefSys','ISYS', ...
        'RelPos','[0; 0; 0]', ...
        'RelRot','[0; 0; gamma1]', ...
        'CgPos','[l1; 0; 0]', ...
        'CgRot','[0; 0; 0]', ...
        'Mass','m1', ...
        'Inertia',eye(3));

%%%%%%%%%%%%%%
% Pendulum 2 %
%%%%%%%%%%%%%%

newConstant('m2', 1, 'l2', 0.2);
newConstant('veps', 0.030)
newGenCoord('delta1');

newBody('Id','FA', ...
        'Name','Pendulum 2', ...
        'RefSys','CA', ...
        'RelPos','[veps; 0; 0]', ...
        'RelRot','[0; 0; delta1]', ...
        'CgPos','[l2; 0; 0]', ...
        'CgRot','[0; 0; 0]', ...
        'Mass','m2', ...
        'Inertia',eye(3));

%%%%%%%%%%%%%%%%%%
% Body 3, Slider %
%%%%%%%%%%%%%%%%%%

newConstant('m3',2);
newGenCoord('phi1');

newBody('Id','SB', ...
    'Name','Pendel 3', ...
    'RefSys','FA_cg', ...
    'RelPos','[0; 0; 0]', ...
    'RelRot','[0; 0; phi1]', ...
    'CgPos','[0; 0; 0]', ...
    'CgRot','[0; 0; 0]', ...
    'Mass','m3', ...
    'Inertia', eye(3));

%%%%%%%%%%%%%%%%%
% Force element %
%%%%%%%%%%%%%%%%%
newConstant('k1',0.5);
newForceElem('ID','Force','Name','Applied force at slider', ...
    'frame1','ISYS','frame2','FA_cg','Type','SpringDampCmp', ...
    'Stiffness','[k1;0;0;0;0;0]','Nomlength','[l1+l2+0.2;0;0;0;0;0]');

%%%%%%%%%%%%%%%%%%%
% Define the loop %
%%%%%%%%%%%%%%%%%%%

% The coordinate systems ISYS and P3_cg shall have the same y-coordinate
% and orientation around z-axis
newConstraint('Id','S1', 'Name','kin Loop 1', ...
   'frame1','ISYS', 'frame2','SB_cg', ...
   'Constraints', [0 1 0 0 0 1]);
% Because in the constraints vector above two entries are ones, two
% generalized coordinates are to be declared dependent. This means that
% these two coordinates can be calculated from the other independent ones
% through the constraint equations
declareDependent('delta1','phi1')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Body 3 is not necessary.                                        %
% If it is removed, the loop could be defined like this.          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% newConstraint('Id','S1', 'Name','kin Loop 1', ...
%    'frame1','ISYS', 'frame2','P2_cg', ...
%    'Constraints', [0 1 0 0 0 0]);
% 
% declareDependent('delta1')

% END OF FILE
