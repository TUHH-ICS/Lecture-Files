function y = f_y(t)
% f_y - definition of time-depending user-defined variable y

global sys;



% constant user-defined variables

yAmp = sys.parameters.data.yAmp;
yOmega = sys.parameters.data.yOmega;
y = zeros(1,1);

y(1) = yAmp*cos(t*yOmega);


% END OF FILE

