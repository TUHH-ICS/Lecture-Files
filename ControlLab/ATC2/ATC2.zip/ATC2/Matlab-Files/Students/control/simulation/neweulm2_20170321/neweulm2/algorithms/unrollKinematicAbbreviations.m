% unrollKinematics(vars_) - This function is needed for abbrevaitions >=3
% and unrolls the kinematic abbreviations, which depend recursively on each
% other. All kinematic abbreviations as well as the constant, time and
% state dependent parameters are passed to the calling funtion.
% 
