% SELECTDEGREEOFFREEDOM M-file for SelectDegreeofFreedom.fig
%      SELECTDEGREEOFFREEDOM, by itself, creates a new
%      SELECTDEGREEOFFREEDOM or raises the existing singleton*.
%
%      H = SELECTDEGREEOFFREEDOM returns the handle to a new
%      SELECTDEGREEOFFREEDOM or the handle to the existing singleton*.
%
%      SELECTDEGREEOFFREEDOM('CALLBACK',hObject,eventData,handles,...)
%      calls the local function named CALLBACK in SELECTDEGREEOFFREEDOM.M
%      with the given input arguments.
%
%      SELECTDEGREEOFFREEDOM('Property','Value',...) creates a new
%      SELECTDEGREEOFFREEDOM or raises the existing singleton*.  Starting
%      from the left, property value pairs are applied to the GUI before
%      SelectDegreeofFreedom_OpeningFunction gets called.  An unrecognized
%      property name or invalid value makes property application stop.  All
%      inputs are passed to SelectDegreeofFreedom_OpeningFcn via varargin.
%
% Graphical user interface to select which generalized coordinates are to
% be considered dependent or independent in systems with kinematic loops.
% This is especially necessary to calculate consistent initial conditions.
% 
% For more information, please open the corresponding window and click on
% the help button, labeled with a question mark "?".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
%
% First appearance: 01.04.2008
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
