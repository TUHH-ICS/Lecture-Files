% GRAPHICOBJECTS M-file for GraphicObjects.fig
%      GRAPHICOBJECTS, by itself, creates a new GRAPHICOBJECTS or raises the existing
%      singleton*.
%
%      H = GRAPHICOBJECTS returns the handle to a new GRAPHICOBJECTS or the handle to
%      the existing singleton*.
%
%      GRAPHICOBJECTS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GRAPHICOBJECTS.M with the given input arguments.
%
%      GRAPHICOBJECTS('Property','Value',...) creates a new GRAPHICOBJECTS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before GraphicObjects_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to GraphicObjects_OpeningFcn via varargin.
%
% Graphical user interface to define graphic objects in the animation
% window, which are then automatically attached to a given coordinate
% system.
% 
% For more information, please open the corresponding window and click on
% the help button, labeled with a question mark "?".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
%
% First appearance: 01.07.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
