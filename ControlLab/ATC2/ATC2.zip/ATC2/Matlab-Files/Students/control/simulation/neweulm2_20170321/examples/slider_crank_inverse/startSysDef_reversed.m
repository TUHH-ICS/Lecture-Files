function [worked_,myTimes,res] = startSysDef_reversed(modelType_,fileName_)
% startSysDef_reversed(modelType_,fileName_)
% File to model and simulate the reversed slider_crank
% 
% In comparison to the regular slider crank, which is modeled from the
% rotation support to the slider, this one is modeled starting from the
% slider. In the regular model, the angle of the first body, the rotating
% rod is a good choice for the simulation. However in this model, the
% x-position of the slider, the relative rotation angle between slider and 
% are bad choices, resulting in singular configurations. Only the rotation
% angle between crank an rod is a reasonable choice of an independent
% coordinate. Therefore this model is a lot more suitable to investigate
% the handling of singular configurations. And depending on the
% implementation and choices made by the user, a time integration will
% finish or abort early. But even if a time integration seems to run
% without problems, considerable errors are possible.
% 
% This system is modeled in sysDef_reversed and the simulation is performed
% in the current function. The additional function compareAll.m runs all
% models and draws plots to compare the results. This is quite convenient
% for the comparison but makes this model UNSUITABLE FOR BEGINNERS, which
% want to learn how to use Neweul-M2!!
%

%% Preparation
global sys;
sys = [];

if(exist('fileName_','var') == 0)
    fileName_ = ['ergebnisVergleich_',datestr(date,'yymmdd'),'.mat'];
end
myTimes = [];

tic;
% Modeling
worked_ = sysDef_reversed(modelType_);
if(~worked_)
    return;
end
calcEqMotNonLin;
% Set the system name
if(sys.counters.genCoord == 1 || isempty(sys.settings.equation.index))
    sys.model.name = ['S',num2str(modelType_,'%02d'),'_analytical_reference', ...
        '_yind_',sys.parameters.vectors.ind{1}];
else
    sys.model.name = ['S',num2str(modelType_,'%02d'),'_', sys.settings.equation.equationType, ...
        '_yind_',sys.parameters.vectors.ind{1}];
end
writeMbsNonLin;
myTimes.tModel = toc;

%% Animation window and time integration
% All other settings
sys.settings.timeInt.time = [0 40];
sys.settings.timeInt.integrator = @ode15s;%@radau5Mex;
sys.settings.timeInt.intOpts = odeset;
% sys.par.timeInt.intOpts = odeset(sys.par.timeInt.intOpts, 'RelTol',1e-5,'AbsTol',1e-8);

% Regular case
tic;
% Start time integration
fprintf('\nTime integration ... ');
timeInt(sys.settings.timeInt.y0, sys.settings.timeInt.Dy0);
fprintf('ok!\n');
myTimes.timeInt = toc;
myTimes.reachedEnd = sys.results.timeInt.x(end);



% Animation window
% Determine final time for the animation in case something went wrong
% tEnd = min(4, sys.results.timeInt.x(end));
% createAnimationWindow; view(0,90); axis([-0.6 1.6 -0.6 0.6]); 
% updateGeo(0,sys.par.timeInt.y0);
% plotTrajectories('P2_crank_cg','Color','blue');
% plotTrajectories('P1_rod_cg','Color','red');
% animTimeInt(sys.results.timeInt,'time',[0 tEnd]);
% defineGraphics;
% saveas(sys.graphics.fig,[sys.name,'_trajectory.fig']); % Save the figure
% close(sys.graphics.fig);

% sys.results.comp.x = linspace(sys.par.timeInt.t0,sys.par.timeInt.t1,1000);
sys.results.comp.x = [sys.results.timeInt.x(1) : 0.03 : sys.results.timeInt.x(end)];
% sys.results.comp.y = deval_wrap(sys.results.timeInt, sys.results.comp.x);
sys.results.comp.y = deval_wrap(sys.results.timeInt, sys.results.comp.x);
% fig_ = plotStandardResults('result',sys.results.comp,'name',sys.name);
% saveas(fig_,['states_',sys.name,'.fig']);
% Plot constraint violations
if(~isempty(sys.dynamics.constraints) && isfield(sys.dynamics.constraints,'c_1') && ~isempty(sys.dynamics.constraints.c_1))
%     plotStandardResults('type','constraints','result',sys.results.comp,'name',sys.name);
    [fig_, sys.results.comp] = plotStandardResults('type','positionconstraints','result',sys.results.comp,'name',sys.model.name);
    set(findobj(gcf,'Type','axes','Tag','legend'),'String',{'x-violation','y-violation'});
end
sys.results.comp.out = zeros(3,length(sys.results.comp.x));
for g_ = 1:length(sys.results.comp.x)
    sys.results.comp.out(:,g_) = eqm_sysout_control(sys.results.comp.x(g_), sys.results.comp.y(:,g_));
end

myStack = dbstack; % If not called by compareAll, return
if(length(myStack) < 2 || ~strcmp(myStack(2).name,'compareAll'))
    return;
end

fprintf('\nFinished simulating system\n%s\n',sys.name);

%% Clean up
name_ = ['sys_',sys.name];
eval([name_,'=sys;']);
if(exist(fileName_,'file') == 2)
    load(fileName_);
    allNames{end+1} = name_;
else
    allNames = {name_};
end
save(fileName_,'allNames',allNames{:});
res = sys; % Return data structure
% END OF FILE

