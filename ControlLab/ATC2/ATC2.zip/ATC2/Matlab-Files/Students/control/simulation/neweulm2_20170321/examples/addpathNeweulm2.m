function addpathNeweulm2(varargin)
% addpathNeweulm2 - Add neweulm2 to path
%
%  Syntax:
%> addpathNeweulm2;
%
%  Description:
% Add the necessary folders to the path variable, making
% all functions of neweulm2 available. If a local version of neweulm2 is
% available, this will be used. For this the current directory and some
% higher directories are checked. If nothing is found and a version at the
% specified server path is available, this is used instead.
%
% In analogy to the function addpath, a function call with one input
% argument is accepted, if this is a valid directory.
% 
%  Optional input arguments, given pairwise:
%
% allowServer ... As a default, the server version is allowed and usable.
%                 This option can be used to suppress the usage of the
%                 server version. Of course this option is only valid if
%                 the serverpath is correct, meaning you are at the ITM.
%                 {true}
% CTest ......... Logical whether to add the CTest directory {false}
% Folder ........ Specify the location of neweulm2, or more explicitly, the
%                 location of the folder containing the file
%                 calcEqMotNonLin.m. This can be done using an absolute
%                 path or giving a relative path as seen from a model
%                 folder, e.g. from the folder examples/double_pendulum/ it
%                 would be '../../neweulm2/'. A relative path is preferable
%                 to avoid writing the folders sysFunctions/ and
%                 userFunctions/ automatically at unreasonable locations.
%                 {'../../neweulm2/'}
% MatMorembs .... Path specification of the location of MatMorembs, which
%                 is also developed at the ITM.
%                 {'/home/itm/itmsw/morembs/matmorembs/'}
% neweulm2_3 .... Use Neweul-M² 3.0 true/false {false}
%                 /home/itm/itmsw/neweulm2/neweulm2_3/neweulm2/'
% publishHelp ... Logical whether publishHelp shall be called if the help
%                 files are not available. {true}
% useServer ..... When you are working at the ITM, this flag can be used to
%                 give the server version priority over the local version.
%                 The difference to 'allowServer' is merely the order in
%                 which the different versions are tried. {false}
% useReference .. When you are working at the ITM, this flag can be used to
%                 give the unencrypted server version priority over the
%                 local version. You have to make sure that you have the
%                 permissions to access this version {false}
% Update ........ In the case that something in the directories has
%                 changed, ensure all current directories are available
%                 {false}
%
%  Examples:
%> addpathNeweulm2;
%> addpathNeweulm2('folder','location/of/my/neweulm2/version');
%
%  See also: 
% startneweulm2
%
% First appearance: 29.10.2010
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de


% Path to ITM server version
serverPath_ = '/home/itm/itmsw/neweulm2/currentVersion/neweulm2/';
referencePath_ = '/home/itm/itmsw/neweulm2/currentVersionReference/neweulm2/';
morembsServerPath_ = '/home/itm/itmsw/morembs/matmorembs/';
morembsReferencePath_ = '/home/itm/itmsw/morembs/matmorembsReference/';
% Default values
searchNeweulm2_ =  true;
manualPath_     =    ''; % Specify the path manually
useServer_      = false; % If true, give the server version priority over local version
useNeweulm2_3   = false; % Use the new version of Neweulm2
allowServer_    =  true; % If true, the server version is allowed for usage
useUpdate_      = false; % Keep the same neweulm2 version, but reload all subdirectories
includeCTest_   = false; % add the folder to CTest
usePublishHelp_ =  true; % Call publishHelp if help is not available
if(nargin == 1)
    if(exist(varargin{1}, 'dir') == 7) % Allow the call addpathNeweulm2('/home/user/newDir')
        varargin = [{'folder'}, varargin];
    else
        error(['The function %s requires argument value pairs and not just one ', ...
            'input argument!\nDid you confuse it with ''addpath''?'], mfilename);
    end
end

% Optional input arguments
for h_ = 2 : 2 : length(varargin)
    switch lower(varargin{h_-1})
        case 'allowserver'; allowServer_ = varargin{h_};
        case 'ctest';                           includeCTest_ = varargin{h_};
        case {'folder','path'};                 manualPath_ = varargin{h_};
        case {'morembs','matmorembs'};          morembsReferencePath_ = varargin{h_};
        case {'neweulm2_3'};                    useNeweulm2_3 =    varargin{h_};
        case {'publishhelp','usepublishhelp'};  usePublishHelp_ = varargin{h_};
        case {'useserver','server'};            useServer_ = varargin{h_};
        case {'usereference','reference'};      useServer_ = ~varargin{h_};
                                                manualPath_ = referencePath_;
        case {'update','reload'};               useUpdate_ = varargin{h_};
    end
end

% Use the new version of Neweul-M²
if useNeweulm2_3
    serverPath_     = '/home/itm/itmsw/neweulm2/neweulm2_3/neweulm2/';
    referencePath_  = '/home/itm/itmsw/neweulm2/neweulm2_3_reference/neweulm2/';
end

% If the server version was given priority over the local version
if(allowServer_ && useServer_); manualPath_ = serverPath_; end

%% Adjust the path

% Add folders for model specific files
if(exist([pwd,filesep,'sysFunctions'],'dir')==7)
    addpath('sysFunctions');
end
if(exist([pwd,filesep,'userFunctions'],'dir')==7)
    addpath('userFunctions');
end
if(exist([pwd,filesep,'abbreviations'],'dir')==7)
    addpath('abbreviations');
end
% Add the folder of this file to the path
addpath(fileparts(mfilename('fullpath')));

if(useUpdate_ && exist('calcEqMotNonLin.m','file') == 2)
    % Reload and update all folders of neweulm2
    newPath_ = fileparts(which('calcEqMotNonLin'));
    % make sure all subfolders are available, 
    addpath(n2genpath(newPath_));
    if(includeCTest_)
        % Search whether a CTest folder exists at the available neweulm2
        % version
        idx_ = strfind(newPath_, [filesep,'neweulm2']);
        newPath_ = newPath_(1:idx_(end));
        if(exist([newPath_,'CTest'],'dir') == 7) % Folder exists, add it
            addpath([newPath_,'CTest']);
        end
    end
    touchPfiles; % Avoid warnings due to the encryption
    return;
end

if(~isempty(manualPath_) && exist(manualPath_,'dir')~=7)
    error('Invalid path! The specified path ''%s'' does not exist!',manualPath_);
end

% Search for MatMorembs on the itm-server or at the specified location
% if it is not already available and the path exists. The reason this is
% done first, is that then files with the same names will then be used from
% neweulm2 and not matmorembs.
if(exist('newRedData.m','file') ~= 2 && exist(morembsReferencePath_,'dir') == 7 && exist([morembsReferencePath_,'InstallMatMorembs.m'],'file') > 0)
    addpath(n2genpath(morembsReferencePath_));
end
if(exist('newRedData.m','file') ~= 2 && exist(morembsServerPath_,'dir') == 7)
    addpath(n2genpath(morembsServerPath_));
end

% 1.) Try to use the manually specified path
if(~isempty(manualPath_) && exist(manualPath_,'dir')==7)
    newPath_ = fileparts(which('calcEqMotNonLin')); % Currently used version
    if(~isempty(newPath_) && ~strcmp(newPath_, manualPath_))
        % Remove old neweulm2 location, to ensure that the correct one is
        % used
        rmpath(n2genpath(newPath_));
    end
    addpath(n2genpath(manualPath_));
    searchNeweulm2_ = false;
    touchPfiles; % Avoid warnings due to the encryption
end

% 2.) Try if this file was called from the default location inside the
% examples directory, then use the relative path
if(searchNeweulm2_ && ...
        exist('calcEqMotNonLin.m','file')==0 && ...
        exist('../../neweulm2','dir')==7 && ...
        exist('../../neweulm2/calcEqMotNonLin.m','file')~=0)
    addpath(n2genpath('../../neweulm2/'));
    % Remove relative path to superior folder, absolute path was addded
    currentPath_ = path;
    if(~isempty(strfind(currentPath_,':..:')) || strncmp(currentPath_,'..:',3) || (~isempty(strfind(currentPath_,':..')) && max(strfind(currentPath_,':..'))==length(currentPath_)-2))
        rmpath('..');
    end
    searchNeweulm2_ = false;
    touchPfiles; % Avoid warnings due to the encryption
end

% 3.) If a local version exists, use it. As this is not quite the default
% location, use the absolute path. Here try all parent directories starting
% from the current directory and the location of this file
startFolder_ = {pwd; fileparts(mfilename('fullpath'))};
for g_ = 1:length(startFolder_)
    if(exist([startFolder_{g_},filesep,'calcEqMotNonLin.m'],'file'))
        % Found neweulm2 version directly in this location
        currentPath_ = pwd;
        cd(startFolder_{g_});
        newPath_ = n2genpath(pwd); % Use absolute path
        cd(currentPath_);
        addpath(newPath_);
        searchNeweulm2_ = false;
        break; % Quit this search block
    end
    while(searchNeweulm2_ && ...
            exist('calcEqMotNonLin.m','file')==0 && ...
            ~isempty(startFolder_{g_}) && ...
            ~(exist([startFolder_{g_},filesep,'neweulm2'],'dir')==7 && ...
              exist([startFolder_{g_},filesep,'neweulm2',filesep,'calcEqMotNonLin.m'],'file')==2))
        % Search in all parent directories for a directory called neweulm2
        % containing a file called calcEqMotNonLin.m
        idx_ = findstr(startFolder_{g_}, filesep);
        startFolder_{g_} = startFolder_{g_}(1:idx_(end)-1);    
    end
    if(exist([startFolder_{g_},filesep,'neweulm2'],'dir')==7 && ...
            exist([startFolder_{g_},filesep,'neweulm2',filesep,'calcEqMotNonLin.m'],'file')==2)
        % Found neweulm2 version
        currentPath_ = pwd;
        cd([startFolder_{g_},filesep,'neweulm2']);
        newPath_ = n2genpath(pwd); % Use absolute path
        cd(currentPath_);
        addpath(newPath_);
        searchNeweulm2_ = false;
        touchPfiles; % Avoid warnings due to the encryption
        break; % Quit this search block
    end
end

% 4.) If you are at the ITM, readable server version is allowed and exists,
% use it
if(searchNeweulm2_ && exist('calcEqMotNonLin.m','file')==0 && ...
        allowServer_ && exist(referencePath_,'dir')==7)
    addpath(n2genpath(referencePath_)); % Recursively include server path
    searchNeweulm2_ = false;
end

% 5.) If you are at the ITM, encrypted server version is allowed and
% exists, use it
if(searchNeweulm2_ && exist('calcEqMotNonLin.m','file')==0 && ...
        allowServer_ && exist(serverPath_,'dir')==7)
    addpath(n2genpath(serverPath_)); % Recursively include server path
    searchNeweulm2_ = false;
end

if(includeCTest_ && exist('calcEqMotNonLin.m','file') == 2)
    % Search whether a CTest folder exists at the available neweulm2 version
    newPath_ = fileparts(which('calcEqMotNonLin'));
    idx_ = strfind(newPath_, [filesep,'neweulm2']);
    newPath_ = newPath_(1:idx_(end));
    if(exist([newPath_,'CTest'],'dir') == 7) % Folder exists, add it
        addpath([newPath_,'CTest']);
    end
end

%% Check if neweulm2 is available, otherwise throw error
if(exist('calcEqMotNonLin.m','file')==0)
    if(searchNeweulm2_)
        error(['Unable to find the folder containing neweulm2! ', ...
            'Please search manually for the file ''calcEqMotNonLin.m'' ', ...
            'and specify the path to this function in the call to addpathNeweulm2: ', ...
            'addpathNeweulm2(''Folder'',''C:\MyFiles'');']);
    else
        error(['Specified location of neweulm2 is incorrect! ', ...
            'Please search manually for the file ''calcEqMotNonLin.m'' ', ...
            'and specify the path to this function in the call to addpathNeweulm2: ', ...
            'addpathNeweulm2(''Folder'',''C:\MyFiles'');']);
    end
end


%% Check for the existance of help-files, otherwise, create them
% This works only under the following conditions
% - a local version is used
% - java virtual machine is running
% - publishHelp.m is available
if(usePublishHelp_)
    newPath_ = fileparts(which('calcEqMotNonLin'));
    if(exist([newPath_, filesep, 'help', filesep, 'html', filesep, 'calcEqMotNonLin.html'],'file') ==0 && ...
            ~strncmp(newPath_, '/home/itm/itmsw/neweulm2/',25) && ...
            usejava('jvm') && exist([newPath_, filesep, 'help', filesep,'createNeweulM2Help.m'],'file') ~= 0)
        fprintf('\nFiles for the Neweul-M2 help not found, creating them ...\n');
        cd([newPath_, filesep, 'help'])
        createNeweulM2Help;
        cd(startFolder_{1})
        fprintf('\n\nFinished creating files for the Neweul-M2 help. ok!\n');
    end
end

%% Just in case this was a demonstration run and the user tried to stop it
global sys;
if(isfield(sys,'par') && isfield(sys.par,'codegen') && ...
        isfield(sys.par.codegen,'waitTime') && ...
        ~isempty(sys.par.codegen.waitTime) && ...
        ~isnumeric(sys.par.codegen.waitTime))
    error('Demonstration run aborted!');
elseif(isempty(sys)) % This name has not been used before
    clear global sys;
end
end % END OF addpathNeweulm2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% SUBFUNCTIONS
function returnPath_ = n2genpath(newPath_)
% newPath_ = n2genpath(newPath_)
% Generate path based on given root directory, omitting additionally all
% hidden directories. This function is based on genpath

    % Generate path based on given root directory
    files = dir(newPath_);
    if isempty(files)
        returnPath_ = '';
        return;
    end

    % Add newPath_ to the path even if it is empty
    returnPath_ = [newPath_ pathsep];

    % set logical vector for subdirectory entries in newPath_
    isdir = logical(cat(1,files.isdir));
    %
    % Recursively descend through directories which are neither
    % private nor "class" directories.
    %
    dirs = files(isdir); % select only directory entries from the current listing

    for i=1:length(dirs)
        dirname = dirs(i).name;
        if(     ~strncmp( dirname,'.',1) && ...
                ~strncmp( dirname,'@',1) && ...
                ~strcmp(  dirname,'help') && ...
                ~strcmp(  dirname,'private'))
            returnPath_ = [returnPath_ n2genpath(fullfile(newPath_,dirname))]; %#ok<AGROW> % recursive calling of this function.
        elseif strcmp(dirname,'help')
            matlabVersion = version('-release');
            if str2double(matlabVersion(1:4))<2008
                returnPath_ = [returnPath_ fullfile(newPath_,dirname),'/oldMatlab',pathsep]; %#ok<AGROW>
            else
                returnPath_ = [returnPath_ fullfile(newPath_,dirname),'/newMatlab',pathsep]; %#ok<AGROW>
            end
        end
    end
end % END OF n2genpath

function touchPfiles
% touchPfiles
% Function to ensure that .p files are newer than .m files of Neweul-M2.
% Otherwise a warning might be thrown, which is undesirable
% See also: addpathNeweulm2>handleFolderTouch,
% addpathNeweulm2>handleFolderFprintf
    % Determine folder of neweulm2
    myFolder = fileparts(which('calcEqMotNonLin.p'));
    if(~isempty(myFolder))
        % Only if the p-coded version is used
        if(isunix)
            % If possible, use the touch command
            handleFolderTouch(myFolder);
        else
            % Otherwise try to open files shortly
            handleFolderFprintf(myFolder);
        end
    end
end % END OF MAIN FUNCTION

function handleFolderTouch(currentFolder_)
% handleFolderFprintf(currentFolder_)
% Function to update .p files, so the .p files are newer than the
% corresponding .m files. This prevents warnings due to this cause.
% In this implementation, the touch command of linux is used to update the
% time stamp.
% See also: addpathNeweulm2>touchPfiles
    allFiles_ = dir(currentFolder_);
    for g_ = 1:numel(allFiles_)
        [tmpPath_,tmpFile_,tmpExt_] = fileparts(allFiles_(g_).name);
        if(strncmp(allFiles_(g_).name, '.', 1))
            % Skip all files and folders starting with a dot
        elseif(allFiles_(g_).isdir)
            % Call function recursively for subfolders
            handleFolderTouch([currentFolder_, allFiles_(g_).name]);
        elseif(strcmp(tmpExt_, '.p'))
            mIdx_ = strcmp({allFiles_(:).name}, [tmpFile_,'.m']);
            if(~isempty(mIdx_) && ...
                    allFiles_(mIdx_).datenum >= allFiles_(g_).datenum)
                status = system(['touch ',currentFolder_,'/',allFiles_(g_).name]);
                if(status ~= 0)
                    % This is usually the case for files where the user doesn't
                    % have permissions. Quit immediately, either the user has
                    % permissions for all files or none.
                    return;
                end
            end
        end
    end
end % END OF handleFolderTouch

function handleFolderFprintf(currentFolder_)
% handleFolderFprintf(currentFolder_)
% Function to update .p files, so the .p files are newer than the
% corresponding .m files. This prevents warnings due to this cause.
% In this implementation, each file is opened for writing to update the
% time stamp. This might not work properly.
% See also: addpathNeweulm2>touchPfiles
    allFiles_ = dir(currentFolder_);
    for g_ = 1:numel(allFiles_)
        [tmpPath_,tmpFile_,tmpExt_] = fileparts(allFiles_(g_).name);
        if(strncmp(allFiles_(g_).name, '.', 1))
            % Skip all files and folders starting with a dot
        elseif(allFiles_(g_).isdir)
            % Call function recursively for subfolders
            handleFolderFprintf([currentFolder_, allFiles_(g_).name]);
        elseif(strcmp(tmpExt_, '.p'))
            mIdx_ = strcmp({allFiles_(:).name}, [tmpFile_,'.m']);
            if(~isempty(mIdx_) && ...
                    allFiles_(mIdx_).datenum >= allFiles_(g_).datenum)
                fid = fopen([currentFolder_,'/',allFiles_(g_).name],'a');
                fprintf(fid,' \b');
                if(fid < 0)
                    % This is usually the case for files where the user doesn't
                    % have permissions. Quit immediately, either the user has
                    % permissions for all files or none.
                    return;
                end
                fclose(fid);
            end
        end
    end
end % END OF handleFolderFprintf

% END OF FILE
