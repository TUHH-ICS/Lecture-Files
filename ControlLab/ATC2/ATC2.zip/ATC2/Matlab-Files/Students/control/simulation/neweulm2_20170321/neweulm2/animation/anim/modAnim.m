% result = modAnim(t,n,varargin)
%
% Input arguments
% t		time
% n		n-th eigenfrequency which will be animated
%
%
% Optional input arguments, should be specified in pairs, {default values}
% 'createanim' ............ {true}|false -> create animFiles
% 'plotmatlab' ............ true|{false} -> show animation in Matlab
% arguments of animModeShape -> help fresResPlot
% arguments of AnimStrFile -> help AnimStrFile
%
% Example function calls:
% show eigenmode #4 in matlab
% result = modAnim(0,4,'plotmatlab',true,'repetitions',3)
%
% show eigenmode #4 in anim
% result = modAnim(0,4,'createanim',true,'startanim',true)
% result = modAnim(0,4,'createanim',true,'startanim',true,'inits',false)
% numerical linearization
% result = modAnim(0,4,'createanim',true,'startanim',true,'numlin',true)
