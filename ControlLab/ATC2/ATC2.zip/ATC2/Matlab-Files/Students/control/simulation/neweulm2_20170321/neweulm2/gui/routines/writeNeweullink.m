function writeNeweullink
% Creates a file in the current folder which will change the folder to the
% folder containing the startneweulm2.m file and call startneweulm2.m.
% startneweulm2.m should be always in the same folder, therefore this link
% creation avoids any adjustments of the path variable beforehand.
%
% First appearance: 01.12.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de

% Ensure that sandbox folder can be found
if(isdir('../sandbox'))
    % Get the absolute path of the current sandbox folder
    current_ = pwd; cd('../sandbox'); Sandboxpath_ = pwd; cd(current_);
else
    Sandboxpath_ = pwd;
    warning('Could not find ''sandbox'' folder, created link in current folder!');
end
file2open_ = 'startneweulm2.m';

% Create file
fid = fopen([Sandboxpath_,filesep,'link_neweulm2.m'],'w'); % open the file
fprintf(fid,'%% This routine is a link which calls %s from any given folder.',file2open_);
str_buffer = which(file2open_);
str_buffer = str_buffer(1:end-length(file2open_));
fprintf(fid,'\n\n%% Change the folder');
fprintf(fid,'\ncd(''%s'');', str_buffer);
fprintf(fid,'\n%% Call %s and pass the pass to the sandbox folder', file2open_);
fprintf(fid,'\n%s(''%s'');',file2open_(1:end-2),Sandboxpath_);
fclose(fid); % close the file
