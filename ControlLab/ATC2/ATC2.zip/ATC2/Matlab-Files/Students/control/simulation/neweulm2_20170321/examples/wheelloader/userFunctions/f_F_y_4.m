function res_ = f_F_y_4(t,y_,varargin)
% f_F_y_4 - definition of state-depending user-defined variable F_y_4
%
% If you want to use this parameter as a state-dependent parameter in the
% definition of a coordinate system, please also define the derivatives
% with respect to the local coordinate directions x1 (Cases II and III), in
% which the parameter is used. This is necessary to calculate the jacobian
% matrices: Jt = dr/dy = dr/dx1 * dx1/dy
%
% This is not necessary if this parameter is to be a parameter of a force
% element. In both cases if you want to linearize the equations of motion,
% Case IV is necessary, where you can return a symbolic expression for this
% parameter.
%
% Positions, velocities, ... of coordinate systems can be calculated by
% calling the functions in 'sysFunctions', e.g. body1_r

global sys;

res_ = 0; % Default return value
Dy_ = zeros(sys.counters.genCoord,1); % Default value for derivatives
calcDerivatives_ = false;

if(length(varargin) == 1) % Treat optional input arguments
	% Case I: Call was f_F_y_4(t,y_,Dy_)
	% Generalized velocities have been passed
	% Only necessary if you require velocities for the evaluation
	Dy_ = varargin{1};
elseif(length(varargin)>1 && ischar(varargin{1}) && strcmp(varargin{1},'derivative'))
	% Case II: Call was f_...(t,y_,'derivatives', ...)
	% Only necessary if this parameter is used to define a coordinate system
	calcDerivatives_ = true;
	component_ = varargin{2}; % Define axis direction
elseif(length(varargin)>2 && ischar(varargin{2}) && strcmp(varargin{2},'derivative'))
	% Case III: Call was f_...(t,y_,Dy_,'derivatives', ...)
	% Only necessary if this parameter is used to define a coordinate system
	Dy_ = varargin{1};
	calcDerivatives_ = true;
	component_ = varargin{3}; % Define axis direction
elseif(nargin==1 && ischar(t) && strcmp(t,'linearization'))
	% Case IV: Call was f_...('linearization')
	% Return symbolic expression to calculate the linearization
	% Necessary for all parameters appearing in the equations of motion to linearize!
	res_ = sym('0');
	return;
end

% If you have any parameters to define, do that here
% Definitions start #######################################################

% constant user-defined variables

mued = sys.parameters.data.mued;
mues = sys.parameters.data.mues;
K_alpha = sys.parameters.data.K_alpha;

% state dependent user-defined variables

F_z_4 = f_F_z_4(t,y_,Dy_);
alpha4 = f_alpha4(t,y_,Dy_);


% generalized coordinates



% Definitions stop ########################################################
% Function definitions
if(~calcDerivatives_)
	% Regular call, calculate position
	% Please enter your function here
	% Function start ######################################################
	res_ = zeros(1,1);

    mue = mues - (mues - mued)*tan(alpha4);
    
    alpha_crit = atan(3*mue*F_z_4/K_alpha);
	
    if abs(F_z_4)>eps
    
        H = 1 - (K_alpha*abs(tan(alpha4)))/(3*mue*abs(F_z_4));

        if abs(alpha4) <= alpha_crit
            res_(1) = mue*abs(F_z_4)*(1-H*H*H)*sign(alpha4);
        else
            res_(1) = mue*abs(F_z_4)*sign(alpha4);
        end
        
    end
%     res_(1) = 0;
	% Function stop  ######################################################
else
	% Please define here the derivatives with respect to the
	% cartesian coordinates of the local coordinate system as numerical
	% values
	% Derivatives start ###################################################
	if(component_ == 1) % x-direction

	elseif(component_ == 2) % y-direction

	elseif(component_ == 3) % z-direction

	end
	% Derivatives stop  ###################################################
end


% END OF FILE

