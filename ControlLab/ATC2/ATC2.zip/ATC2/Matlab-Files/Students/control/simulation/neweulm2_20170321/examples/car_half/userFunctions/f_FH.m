function res_ = f_FH(t,y_,varargin)
% res_ = f_FH(t,y_,varargin)
% f_FV - definition of state-depending user-defined variable FV
% Positions, velocities, ... of coordinate systems can be calculated by
% calling the functions in 'sysFunctions', e.g. body1_r

% res_ = 75000;%2.0498e+07;
% return;

global sys;

if(nargin==1 && ischar(t) && strcmp(t,'linearization'))
	% Case IV: Call was f_...('linearization')
	% Return symbolic expression to calculate the linearization
	% Necessary for all parameters appearing in the equations of motion to linearize!
	res_ = sym(0);
	return;
end

% constant user-defined variables

xa_mnsr = sys.parameters.data.xa_mnsr;
xd_mnsr = sys.parameters.data.xd_mnsr;
xa_plsr = sys.parameters.data.xa_plsr;
xd_plsr = sys.parameters.data.xd_plsr;
cr = sys.parameters.data.cr;

% relative vector
ksys1 = str2func('RAF_r');
ksys2 = str2func('CARRF_r');
l0 = sys.parameters.data.l0r;

% symbolically
% KAR_S = getAbsoluteKinematics('S','KAR','ISYS');
% KARHF_r = getAbsoluteKinematics('r','ISYS','KARHF');
% HAF_r = getAbsoluteKinematics('r','ISYS','HAF');
% mapleSimplify( transpose(KAR_S) *(KARHF_r - HAF_r) )
% la = ((-faphox+cos(bh)*faphux-faphuz*sin(bh))^2+(faphoz-sin(bh)*faphux-faphuz*cos(bh))^2)^(1/2);
% la = norm(ksys2(t,y_)-ksys1(t,y_));

% state dependent user defined functions
% x = l0 - norm(ksys2(t,y_)-ksys1(t,y_));
x = norm(ksys2(t,y_)-ksys1(t,y_)) - l0;
res_ = springParam(x, cr, xa_mnsr, xd_mnsr, xa_plsr, xd_plsr);

