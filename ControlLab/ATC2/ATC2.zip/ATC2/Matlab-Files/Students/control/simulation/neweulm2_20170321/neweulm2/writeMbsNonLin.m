% writeMbsNonLin - Create Matlab functions for the numerical evaluation 
% 
%  Syntax:
%> writeMbsNonLin
%> writeMbsNonLin('Property', value, ...);
%
%  Description:
% This function creates all files needed for the numerical evaluation of
% the equations of motion. If needed, the equations of motion can be
% transformed from _NewtonEuler_ to _Minimal_. For large systems, it is 
% advisable to stick with the _NewtonEuler_ description.
%
%  Preliminaries:
%> calcEqMotNonLin;
%
%  Optional Parameters, given pairwise:
% CleanSysFunctions ... Logical whether the contents of the folder
%                       sysFunctions are to be deleted {true}
% FrameList ........... Write only files for a given list of coordinate
%                       systems {fieldnames(sys.model.frame)}
% MassSymmetric ....... Logical: true/false {true}
% Minimal ............. Parameter whether the equations of motion are to be
%                       formulated in minimal form {false}
% OnlyPositions ....... Logical: true/false or flag
%                       Specifies if only the position vectors and
%                       rotation matrices are exported. This is usefull
%                       after calculating only the kinematics of all
%                       frames. Then an animation is possible {false}
% OutType ............. Type to use for the status updates, see
%                       'n2StatusOutput' for more information {'CMD'}
% OutHandle ........... Handle to use for the status updates, see
%                       'n2StatusOutput' for more information {1}
% PermuteMassMatrix ... Decide, whether the mass matrix is supposed to be
%                       permuted to minimize the fill-in during
%                       decomposition {false}
% Subfunction ......... Option to call a subfunction of this file from
%                       outside
% CheckVarargin ....... An advanced feature to avoid errors if invalid
%                       parameters are passed. This is only if you know
%                       exactly what you are doing. {true}
%
%  Example:
%>   writeMbsNonLin('Abbreviations', 2, 'Simplify', 3);
%>   writeMbsNonLin('CleanSysFunctions', false);
%
%  See also:
% writeMbsLin, calcEqMotNonLin, sym2mcode, writeHelpvarDef,
% writeGenCoordDef, scriptWriteMbsNonLin
%
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
