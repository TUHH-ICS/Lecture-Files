function DMVL = f_DMVL(t,varargin)

DMVL = 0;
