%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                    %
% Definition of numerical values of userdefined parameters           %
% for the model 'elastic pendulum'                                   %
%                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global sys;

fprintf(1,'Setting Numerical Values ...');

% Gravitation
sys.parameters.data.g = 9.81;

sys.parameters.data.m2 = 2;

% Excitation
sys.parameters.data.phi0 = 0;
sys.parameters.data.omega = 50*2*pi;

% Force element
sys.parameters.data.k = 5;
sys.parameters.data.d = 0.5;

fprintf(1,' ok!\n');
