// Class definition of the basic graphical objects used in Neweul-M²

#ifndef BOXES_H
#define BOXES_H

#include <osg/Shape>
#include <osg/ShapeDrawable>
#include <osg/Geode>
#include <osg/BlendFunc>

class boxes
{
public:
	boxes(const osg::Vec3 &center=osg::Vec3(0,0,0), float lengthX=1.0, float lengthY=1.0, float lengthZ=1.0, const osg::Vec4 &color=osg::Vec4(0,1,0,1));
	~boxes();
	osg::Box*           basicBox;
	osg::ShapeDrawable* basicBoxDrawable;
	osg::Geode*         patchGeode;

};

#endif // BOXES_H

#ifndef SPHERES_H
#define SPHERES_H

#include <osg/Shape>
#include <osg/ShapeDrawable>
#include <osg/Geode>

class spheres
{
public:
	spheres(const osg::Vec3 &center=osg::Vec3(0,0,0), float radius=1.0, const osg::Vec4 &color=osg::Vec4(0,1,0,1));
	~spheres();
	osg::Sphere*        basicSphere;// = new osg::Sphere( osg::Vec3(0,0,0), 1.0);
	osg::ShapeDrawable* basicSphereDrawable; // = new osg::ShapeDrawable(unitSphere);
	osg::Geode*         patchGeode;

};

#endif // SPHERES_H

#ifndef CONES_H
#define CONES_H

#include <osg/Shape>
#include <osg/ShapeDrawable>
#include <osg/Geode>

class cones
{
public:
	cones(const osg::Vec3 &center=osg::Vec3(0,0,0), float radius=1.0, float height=1.0, const osg::Vec4 &color=osg::Vec4(0,1,0,1));
	~cones();
	osg::Cone*          basicCone;// = new osg::Sphere( osg::Vec3(0,0,0), 1.0);
	osg::ShapeDrawable* basicConeDrawable; // = new osg::ShapeDrawable(unitSphere);
	osg::Geode*         patchGeode;

};

#endif // CONES_H

#ifndef CYLINDERS_H
#define CYLINDERS_H

#include <osg/Shape>
#include <osg/ShapeDrawable>
#include <osg/Geode>

class cylinders
{
public:
	cylinders(const osg::Vec3 &center=osg::Vec3(0,0,0), float radius=1.0, float height=1.0, const osg::Vec4 &color=osg::Vec4(0,1,0,1), const osg::Vec4f &quadVec=osg::Vec4f(0.0,0.0,0.0,1.0));
	~cylinders();
	osg::Cylinder*      basicCylinder;
	osg::ShapeDrawable* basicCylinderDrawable;
	osg::Geode*         patchGeode;

};

#endif // CYLINDERS_H

#ifndef PATCHPROTO_H
#define PATCHPROTO_H

#include <osg/Geode>
#include <osg/Geometry>
#include <osg/Texture2D>
#include <hdf5.h>
#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <osg/Material>
#include <osgUtil/SmoothingVisitor>

class patchProto
{
public:
    patchProto(const char *fileName);
    ~patchProto();
    osg::Geode*             patchGeode;
    osg::Geometry*          patchGeometry;
    osg::Vec3Array*         patchVertices;
    osg::Vec3Array*         patchNormals;
    osg::DrawElementsUInt*  patchTriangles;
    osg::DrawElementsUInt*  patchQuads;
    osg::DrawElementsUInt*  patchLines;
    osg::Vec4Array*         patchColors;
    float*                  vertCoords;
    float*                  vertNormals;
    float*                  shapeFuns;
    int32_t*                faces;
    int32_t*                lines;
    float*                  faceColor;
    int32_t numVertices;
    int32_t numTriangles;
    int32_t numQuads;
    int32_t frameNumber;
    int32_t numCoordinates;
    int32_t firstCoord;
    void updateStructure(double* genCoords);

};

#endif // PATCHPROTO_H
