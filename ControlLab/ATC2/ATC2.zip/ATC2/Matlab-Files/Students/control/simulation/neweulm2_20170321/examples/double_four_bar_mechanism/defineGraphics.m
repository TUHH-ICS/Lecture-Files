function defineGraphics
% DEFINEGRAPHICS - create graphic visualization of modeling elements
%

global sys;

%%%%%%%%%%%%%%%%%%%%%%%%
% Initialize animation %
%%%%%%%%%%%%%%%%%%%%%%%%

createAnimationWindow('drawcs',false);

view(0,90);

axis([-1 3 -1.5 1.5 -1 1]);

%%%%%%%%%%%%%%%%%%%%%%%%
% add graphic elements %
%%%%%%%%%%%%%%%%%%%%%%%%

h = drawCube([0,0,0],0.05,sys.parameters.data.l,0.05,'color',[1 0 0]);
addGraphics('L1_cg',h);

h = drawCube([0,0,0],0.05,sys.parameters.data.l,0.05,'color',[0 1 0]);
addGraphics('L2_cg',h);

h = drawCube([0,0,0],0.05,sys.parameters.data.l,0.05,'color',[0 0 1]);
addGraphics('L3_cg',h);

h = drawCube([0,0,0],0.05,sys.parameters.data.l,0.05,'color',[1 1 0]);
addGraphics('L4_cg',h);

h = drawCube([0,0,0],0.05,sys.parameters.data.l,0.05,'color',[1 0 1]);
addGraphics('L5_cg',h);

h = drawSphere([0,0,0], 0.05, 20, [0,0,0]);
addGraphics('L1_end',h);

h = drawSphere([0,0,0], 0.05, 20, [0,0,0]);
addGraphics('L2_end',h);

h = drawSphere([0,0,0], 0.05, 20, [0,0,0]);
addGraphics('L3_end',h);
