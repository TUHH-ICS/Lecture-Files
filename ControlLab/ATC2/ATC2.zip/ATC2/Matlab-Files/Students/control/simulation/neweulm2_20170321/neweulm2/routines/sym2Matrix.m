% s = sym2Matrix(varname,expr,varargin)
% SYM2MATRIX - Create m-file code for the evaluation of symbolic
% expressions. Initialize entries in an array by using system data
% structure fields as indices.
%
% Input:
% varname ..... Parametername to be used in the function m-file
% expr ........ Symbolic expression
%
% optional Parameters:
% Type ........ Specification whether it is a 'row' or 'column vector
% SecondDim ... Specification of the field in the global data structure to
%               be used for the initialization
% Shift ....... Very similar to startIdx. Just instead of giving the
%               indices of the first element, these values are added.
%               {zeros(1, ndims(expr))}
%
% See also: sym2mcode
%
% First appearance: 25.01.2012
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
