% createSubplots - use subplots in the animation window
%
%  Description:
% Function to use subplots in the main animation window of Neweul-M2 and to
% add a new one. This function provides many options, which are grouped 
% here for better readability.
% 
%  Plot and general properties:
% XVar ................ Variable for the x-coordinate. This is very
%                       similar to the output definition, see XType for
%                       more information {'t'}
% YVar ................ Variable for the y-coordinate. This is very
%                       similar to the output definition, see XType for
%                       more information {'t'}
% XType/YType ......... Type of variable {''}. Currently available are:
%      - 'constraint': 'c_1(2)', 'c_3(1)'
%      - 'genCoord'/'state': 'alpha1', 'D2x2'
%      - 'input': 'inVar1','DinVar2' For inputs, the entries of
%           sys.model.input(:).list are required
%      - 'output': 'myOut1' Similar to inputs, entries of
%           sys.model.output(:).list are required
%      - 'kinematic': 'myFrame.r(2)'
% OnTheFly ............ Logical whether the curve shall be plotted up to
%                       the current time if true or all at once {false}
% CurrentMarker ....... Marker specification for the current point {'o'}
% AxesIdx ............. Index of the subplot. For each new axes, one entry
%                       is stored under sys.graphics.subplots.axes. This
%                       option references to the indices of this array and
%                       will be added to the respective plot. The animation
%                       itself is not contained in this list. {1}
% Subplots ............ For new axes, specify the subplots to be used.
%                       Please make sure that you do not use the same space
%                       twice {1}
% PlotIdx ............. All settings of curves are stored under
%                       sys.graphics.subplots.plots. This selects which of
%                       these entries shall be used. As a standard, a new
%                       one is made {[]}
% PlotAll ............. Logical whether to only plot all curves {false}
% ResetSubplot ........ Reset the current subplot {false}
% ResetAll ............ Reset the complete animation window
% Result .............. Specify the result to be used, otherwise, the
%                       currently used result or one of sys.results is
%                       used. Can be specified as fieldname under
%                       sys.results or as a structure {''}
% useLegend ........... Specifies whether to create a legend entry for this
%                       curve or not {true}
% 
%  Line Properties:
% Color ............... Color of the line {[0 0 1]}
% Marker .............. Marker shape {'none'}
% MarkerSize .......... Marker size {6}
% MarkerEdgeColor ..... Edge color of the marker {'auto'}
% MarkerFaceColor ..... Face color of the marker {'none'}
% 
%  Axes Properties:
% Box ................. Frame the axes with a box {'on'}
% FontName ............ Fontname {}
% FontSize ............ Fontsize {}
% Title ............... Title {''}
% XGrid/YGrid ......... Use grid lines in x/y-direction {'on'}
% XLim/YLim ........... Axis limits, if not available, automatic {[]}
% XLimMode/YLimMode ... Mode for axis limits, manual/auto {'auto'}
% XScale/YScale ....... Axis scaling, linear or logarithmic {'lin'}
% 
%  Examples: (can be called subsequently)
%     createAnimationWindow('subplot',{3,3,[1,2,4,5]});
%     createSubplots('yType','genCoord','yVar',sys.parameters.genCoord{1},'subplots',3);
%     names_ = fieldnames(sys.model.frame);
%     createSubplots('yType','kinematic','yVar',[names_{end},'.r(1)'],'subplots',6,'Color',[1 0 0]);
%     createSubplots('yType','kinematic','yVar',[names_{end},'.r(2)'],'subplots',6,'onTheFly',true);
%     createSubplots('yType','kinematic','yVar',[names_{end},'.r(3)'],'subplots',6,'onTheFly',true);
%     if(~isempty(sys.model.input))
%         createSubplots('yType','input','yVar',sys.model.input(end).list{1},'subplots',7:8,'Color',[0 1 1]);
%     end
%     if(~isempty(sys.model.output))
%         createSubplots('yType','output','yVar',sys.model.output(end).list{1},'subplots',7:8);
%     end
%     createSubplots('xType','genCoord','xVar', sys.parameters.genCoord{1}, ...
%         'yType','kinematic','yVar',[names_{end},'.r(1)'],'subplots',9, 'onTheFly',true);
% 
%  See also: createAnimationWindow, plotStandardResults, updateGeo,
% animTimeInt
%
% First appearance: 17.10.2012
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
