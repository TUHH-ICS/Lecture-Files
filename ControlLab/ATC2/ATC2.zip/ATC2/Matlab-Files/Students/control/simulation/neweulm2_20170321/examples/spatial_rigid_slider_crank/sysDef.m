function sysDef(formulation)
% Definition of a Spatial Rigid Slider-crank Mechanism

newSys('Id','SRSC','Name','Spatial rigid slider-crank','simplify',10, ...
    'formulation',formulation,'gravity','[0, 0, -g]');

% constant parameters
newConstant('m_CR', 0.12, 'm_CO', 0.5, 'm_S', 2.0, ...
    'Az', 0.12, 'Ay', 0.1, ... 
    'l_AB',0.08, 'l_BC',0.3, ...
    'Ixx_CR',0.0001, 'Iyy_CR',0.00001, 'Izz_CR',0.0001, ...
    'Ixx_CO',0.004, 'Iyy_CO',0.004, 'Izz_CO',0.0004, ...
    'Ixx_S',0.0001, 'Iyy_S',0.0001, 'Izz_S',0.0001);
        
% For a correct modelling the inertia tensors of crank and connection rod 
% should be defined as
%     'Ixx_CR',0.0001, 'Iyy_CR',0.0001, 'Izz_CR',0.00001
%     'Ixx_CO',0.0004, 'Iyy_CO',0.004, 'Izz_CO',0.004


% Generalized coordinates
newGenCoord('theta1','eta1','beta1','s');

% Position A
newFrame('Id','A','Name','A','RefSys','ISYS',...
        'RelPos','[0; Ay; Az]','RelRot','[0; 0; 0]');

% Crank
newBody('Id','CR', 'Name','Crank','RefSys','A', ...
        'RelPos','[0; 0; 0]','RelRot','[theta1; 0; 0]','CgPos', '[0; 0; l_AB/2]', ...
        'Mass','m_CR','Inertia', '[Ixx_CR,0,0; 0,Iyy_CR,0; 0,0,Izz_CR]');

% Sliding block
newBody('Id','S', 'Name','Sliding block','RefSys','ISYS', ...
        'RelPos','[s; 0; 0]','RelRot','[0; 0; 0]','CgPos', '[0; 0; 0]', ...
        'Mass','m_S','Inertia', '[Ixx_S, 0, 0; 0, Iyy_S, 0; 0, 0, Izz_S]');

% Connection rod
newBody('Id','CO', 'Name','Connection rod','RefSys','S', ...
        'RelPos','[0; 0; 0]','RelRot','[eta1; beta1; 0]','CgPos','[-l_BC/2; 0; 0]', ...
        'Mass','m_CO','Inertia', '[Ixx_CO, 0, 0; 0, Iyy_CO, 0; 0, 0, Izz_CO]');

% End point of crank
newFrame('Id','B1','Name','B1','RefSys','CR',...
        'RelPos','[0; 0; l_AB]');

% End point of connection rod
newFrame('Id','B2','Name','B2','RefSys','CO',...
        'RelPos','[-l_BC; 0; 0]');

newConstraint('Id','D', 'Name','Constraint Crank-Connection Rod', ...
   'frame1','B1', 'frame2','B2', ...
   'Constraints', [1 1 1 0 0 0]);

declareDependent('s','eta1','beta1')

% Output for slider position and velocity
newOutput('id','r_S','type','kinematic','var','S_cg.r(1)');
newOutput('id','v_S','type','kinematic','var','S_cg.v(1)');

% END OF sysDef