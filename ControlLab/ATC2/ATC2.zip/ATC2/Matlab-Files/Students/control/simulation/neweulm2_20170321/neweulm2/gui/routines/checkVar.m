% allVarStruct = checkVar(handles)
% This file first determines whether the given input describes a force
% element, a body or a coordinate system. Then it searches in the specified
% fields for all used variables. These are then grouped in two lists, those
% known in the system and the unknowns. These two cell arrays are passed
% back to the caller.
%
% Input arguments
% handles ... Data structure as in sys.model.body.(myID) or corresponding
%             element. To make the changes easier handles.data.body.(myID)
%             is accepted as well
%
% Return argument
% allVarStruct.unknownVars ... List of all used variables, which have not
%                              been previously defined
% allVarStruct.knownVars ..... List of all used and known variables
%
% First appearance: 01.07.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
