#ifndef odexMexh
#define odexMexh

/* Optionsettings */
#define OPT_WARNMISS "OptWarnMiss"
#define OPT_WARNTYPE "OptWarnType"
#define OPT_WARNSIZE "OptWarnSize"

/* H and Tols */
#define OPT_INITIALSS "InitialStep"
#define OPT_RTOL "RelTol"
#define OPT_ATOL "AbsTol"

/* Extrapolation */
#define OPT_MAXEXCOLUMN "MaxExtrapolationColumn"
#define OPT_MAXNUMBEROFSTABCHECKS "MaxNumberOfStabilityChecks"
#define OPT_MAXSTABCHECKLINE "MaxLineForStabilityCheck"
#define OPT_INTERPOLDEGREE "DegreeOfInterpolation"
#define OPT_ORDERDECFRAC "OrderDecreaseFraction"
#define OPT_ORDERINCFRAC "OrderIncreaseFraction"

/* StepSizeSelection */
#define OPT_RHO "rho"
#define OPT_MAXSTEPS "MaxNumberOfSteps"
#define OPT_STEPSIZESEQUENCE "StepSizeSequence"
#define OPT_MAXSS "MaxStep"
#define OPT_SSREDUCTION "StepSizeReduction"
#define OPT_SSSELECTPAR1 "StepSizeSelectionParam1"
#define OPT_SSSELECTPAR2 "StepSizeSelectionParam2"
#define OPT_SSSELECTPAR3 "StepSizeSelectionParam3"

/* Output */
#define OPT_DENSEOUTPUTWOEE "DeactivateErrorEstInDenseOutput"
#define OPT_OUTPUTFUNCTION "OutputFcn"
#define OPT_OUTPUTCALLMODE "OutputCallMode"

/* Rest */
#define OPT_EPS "eps"
#define OPT_IGPIDO "IncludeGridPointsInDenseOutput"
#define OPT_FUNCCALLMETHOD "FuncCallMethod"

typedef void (*OdexRightSide)(int *n, double *t,
  double *x, double *f,double *rpar, int *ipar);
  
typedef void (*OdexSolout)(int *nr, double *told,
  double *t, double *x, int *d, 
  double *con, int *ncon, int *icomp, int *nd,  
	double *rpar, int *ipar, int *irtrn);  

struct ListElement
{ /* Verkettete Liste mit (t,x)-Paaren, also Vektoren der L�nge d+1 */
  double* values;
  struct ListElement *next;
};
typedef struct ListElement SListElement;
typedef SListElement* PListElement;

struct ParameterGlobal 
{ /* globale Variablen usw. */
  int d;              /* Dimension des Systems */
  int tLength;        /* L�nge des t-Vektors */  
  double* tPointer;   /* Pointer auf Zeitdaten in tArray */  
  double direction;   /* sign(tEnd-tStart) */
  int funcCallMethod; /* Methode, um Matlab-Funktionen aufzurufen */
};
typedef struct ParameterGlobal SParameterGlobal;

struct ParameterIO 
{ /* Parameter f�r Input/Output zwischen Matlab und C */    
  const mxArray *opt;  /* Optionen */
  int optCreated;      /* Flag, ob Optionen selbst generiert wurden */
};
typedef struct ParameterIO SParameterIO;

struct ParameterRightSide 
{ /* Parameter f�r rechte Seite f */
  char *rightSideFcn;           /* Funktionsname f�r rechte Seite */
  const mxArray *rightSideFcnH; /* Funktionshandle oder inline-function f�r rightSide */
  mxArray *tArg;                /* Zum Aufruf von f: t */
  mxArray *xArg;                /* Zum Aufruf von f: x */
};
typedef struct ParameterRightSide SParameterRightSide;

struct ParameterOdex
{ /* Parameter f�r odex */
  double tStart;    /* Startzeitpunkt */
  double tEnd;      /* Endzeitpunkt */
  double h;         /* Startschrittweite */  
  int denseFlag;    /* Flag, ob dense-Output aktiv */
  int maxExColumn;  /* maximale Spalte im Extrapolationstableau */
  double *xStart;   /* Startwert */  
  double *RTOL;     /* releative Toleranz */
  double *ATOL;     /* absolute Toleranz */
  int ITOL;         /* Switch f�r RTOL und ATOL */      
  int IOUT;         /* Switch f�r SOLOUT */    
  double *WORK;     /* Double-Arbeits-Array */
  int LWORK;        /* L�nge von WORK */
  int *IWORK;       /* Integer-Arbeits-Array */
  int LIWORK;       /* L�nge von IWORK */  
  double *RPAR;     /* Zusatz double-array */
  int *IPAR;        /* Zusatz int-array */  
  int IDID;         /* Status */    
};
typedef struct ParameterOdex SParameterOdex;

struct ParameterOutput
{ /* Parameter zum Speichern der Odex-Ausgabe */
  SListElement txList;        /* Start der txListe */
  PListElement lastTXElement; /* letzter Eintrag in txListe */
  int numberOfElements;       /* Anzahl der Eintr�ge in txListe */
  int tPos;                   /* Position im t-Vektor */
  int includeGrid;            /* Flag, dense Ausgabe mit Gridpoints */
  char* outputFcn;            /* Outputfunction */
  const mxArray *outputFcnH;  /* Outputfunction: handle oder inline-function */
  int outputCallMode;         /* Modus f�r outputFcn-Aufruf */
  mxArray *tArg;              /* Zum Aufruf von outputFcn: t */
  mxArray *xArg;              /* Zum Aufruf von outputFcn: x */
  mxArray *emptyArg;          /* Zum Aufruf von outputFcn: empty array [] */
  mxArray *toldArg;           /* Zum Aufruf von outputFcn: tOld */
};
typedef struct ParameterOutput SParameterOutput;

struct OdexDense 
{ /* Argumente zum Aufruf von CONTEX */
  double *con;
  int *ncon;
  int *icomp; 
  int *nd;
};
typedef struct OdexDense SOdexDense;

#ifdef FORTRANNOUNDER
/* Fotran functions without underscore */
#ifdef FORTRANUPP
/* Fotran functions without underscore  & UPPERCASE letters */
#define ODEX_ ODEX
#define CONTEX_ CONTEX
#else
/* Fotran functions without underscore  & lowercase letters */
#define ODEX_ odex
#define CONTEX_ contex
#endif
#else
/* Fortran functions with underscore */
#ifdef FORTRANUPP
/* Fortran functions with underscore & UPPERCASE letters */
#else
/* Fortran functions with underscore & lowercase letters */
#define ODEX_ odex_
#define CONTEX_ contex_
#endif
#endif

extern void ODEX_ (int *n, OdexRightSide fcn,
  double *t, double *x, double *tend, double *h,
  double *rtol, double *atol, int *itol,
  OdexSolout solout, int *iout,
  double *work, int *lwork, int *iwork, int *liwork,
  double *rpar, int *ipar, int *idid);

extern double CONTEX_ (int *i, double *s, double *con, int *ncon,
  int *icomp, int *nd);

#endif
