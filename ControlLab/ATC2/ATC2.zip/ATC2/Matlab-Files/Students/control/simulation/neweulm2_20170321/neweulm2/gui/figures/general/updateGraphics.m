% varargout = updateGraphics(varargin)
% updateGraphics M-file for updateGraphics.fig
%      updateGraphics, by itself, creates a new updateGraphics or raises the existing
%      singleton*.
%
%      H = updateGraphics returns the handle to a new updateGraphics or the handle to
%      the existing singleton*.
%
%      updateGraphics('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in updateGraphics.M with the given input arguments.
%
%      updateGraphics('Property','Value',...) creates a new updateGraphics or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before updateGraphics_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to updateGraphics_OpeningFcn via varargin.
%
% Graphical user interface to update the animation window to a given
% configuration. A static equilibrium can also be calculated numerically.
% Should this pose some problems, you can try using a damped time
% integration, which is numerically usually more robust.
% 
% For more information, please open the corresponding window and click on
% the help button, labeled with a question mark "?".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
%
% First appearance: 01.07.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
