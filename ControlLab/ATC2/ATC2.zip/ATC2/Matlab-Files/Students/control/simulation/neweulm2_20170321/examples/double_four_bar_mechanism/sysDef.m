function sysDef(formulation)
% System definition of the double four-bar mechanism 


if nargin==0
    formulation = minimal;
end

newSys('Id','DFBM','Name','Double four bar mechanism','simplify',3, ...
    'formulation',formulation,'gravity','[0, -g, 0]','Angles','xyz');

% constant parameters
newConstant('m',1, ...
            'l',1, ...
            'Ixx',0, ...
            'Iyy',0, ...
            'Izz',0);
        
% Generalized coordinates
newGenCoord('alpha1');

% system definition
newFrame('Id','A','Name','A','RefSys','ISYS',...
        'RelPos','[0; 0; 0]','RelRot','[0; 0; 0]');

newFrame('Id','B','Name','B','RefSys','ISYS',...
        'RelPos','[l; 0; 0]','RelRot','[0; 0; 0]');

newFrame('Id','C','Name','C','RefSys','ISYS',...
        'RelPos','[2*l; 0; 0]','RelRot','[0; 0; 0]');

% body 1
newBody('Id','L1', 'Name','Link 1','RefSys','A', ...
        'RelPos','[0; 0; 0]','RelRot','[0; 0; alpha1]','CgPos', '[0; l/2; 0]', ...
        'Mass','m','Inertia', '[Ixx,0,0; 0,Iyy,0; 0,0,Izz]');
newFrame('Id','L1_end','Name','end of link 1','RefSys','L1',...
        'RelPos','[0; l; 0]','RelRot','[0; 0; 0]');
% body 2
newBody('Id','L2', 'Name','Link 2','RefSys','B', ...
        'RelPos','[0; 0; 0]','RelRot','[0; 0; alpha1]','CgPos', '[0; l/2; 0]', ...
        'Mass','m','Inertia', '[Ixx,0,0; 0,Iyy,0; 0,0,Izz]');
newFrame('Id','L2_end','Name','end of link 2','RefSys','L2',...
        'RelPos','[0; l; 0]','RelRot','[0; 0; 0]');
% body 3
newBody('Id','L3', 'Name','Link 3','RefSys','C', ...
        'RelPos','[0; 0; 0]','RelRot','[0; 0; alpha1]','CgPos', '[0; l/2; 0]', ...
        'Mass','m','Inertia', '[Ixx,0,0; 0,Iyy,0; 0,0,Izz]');
newFrame('Id','L3_end','Name','end of link 3','RefSys','L3',...
        'RelPos','[0; l; 0]','RelRot','[0; 0; 0]');
% body 4
newBody('Id','L4', 'Name','Link 4','RefSys','L1_end', ...
        'RelPos','[0; 0; 0]','RelRot','[0; 0; -alpha1-pi/2]','CgPos', '[0; l/2; 0]', ...
        'Mass','m','Inertia', '[Ixx,0,0; 0,Iyy,0; 0,0,Izz]');
newFrame('Id','L4_end','Name','end of link 4','RefSys','L4',...
        'RelPos','[0; l; 0]','RelRot','[0; 0; 0]');
% body 5
newBody('Id','L5', 'Name','Link 5','RefSys','L2_end', ...
        'RelPos','[0; 0; 0]','RelRot','[0; 0; -alpha1-pi/2]','CgPos', '[0; l/2; 0]', ...
        'Mass','m','Inertia', '[Ixx,0,0; 0,Iyy,0; 0,0,Izz]');
newFrame('Id','L5_end','Name','end of link 5','RefSys','L5',...
        'RelPos','[0; l; 0]','RelRot','[0; 0; 0]');


newOutput('id','x_1','type','kinematic','var','L1_end.r(1)');
newOutput('id','Dx_1','type','kinematic','var','L1_end.v(1)');

newOutput('id','r1_2','type','kinematic','var','L1_cg.r(2)','newGroup','position');
newOutput('id','r2_2','type','kinematic','var','L2_cg.r(2)','group','position');
newOutput('id','r3_2','type','kinematic','var','L3_cg.r(2)','group','position');
newOutput('id','r4_2','type','kinematic','var','L4_cg.r(2)','group','position');
newOutput('id','r5_2','type','kinematic','var','L5_cg.r(2)','group','position');

newOutput('id','v1_1','type','kinematic','var','L1_cg.v(1)','newgroup','velocity');
newOutput('id','v1_2','type','kinematic','var','L1_cg.v(2)','group','velocity');
newOutput('id','v1_3','type','kinematic','var','L1_cg.v(3)','group','velocity');
newOutput('id','omega1_1','type','kinematic','var','L1_cg.omega(1)','group','velocity');
newOutput('id','omega1_2','type','kinematic','var','L1_cg.omega(2)','group','velocity');
newOutput('id','omega1_3','type','kinematic','var','L1_cg.omega(3)','group','velocity');
newOutput('id','v2_1','type','kinematic','var','L2_cg.v(1)','group','velocity');
newOutput('id','v2_2','type','kinematic','var','L2_cg.v(2)','group','velocity');
newOutput('id','v2_3','type','kinematic','var','L2_cg.v(3)','group','velocity');
newOutput('id','omega2_1','type','kinematic','var','L2_cg.omega(1)','group','velocity');
newOutput('id','omega2_2','type','kinematic','var','L2_cg.omega(2)','group','velocity');
newOutput('id','omega2_3','type','kinematic','var','L2_cg.omega(3)','group','velocity');
newOutput('id','v3_1','type','kinematic','var','L3_cg.v(1)','group','velocity');
newOutput('id','v3_2','type','kinematic','var','L3_cg.v(2)','group','velocity');
newOutput('id','v3_3','type','kinematic','var','L3_cg.v(3)','group','velocity');
newOutput('id','omega3_1','type','kinematic','var','L3_cg.omega(1)','group','velocity');
newOutput('id','omega3_2','type','kinematic','var','L3_cg.omega(2)','group','velocity');
newOutput('id','omega3_3','type','kinematic','var','L3_cg.omega(3)','group','velocity');
newOutput('id','v4_1','type','kinematic','var','L4_cg.v(1)','group','velocity');
newOutput('id','v4_2','type','kinematic','var','L4_cg.v(2)','group','velocity');
newOutput('id','v4_3','type','kinematic','var','L4_cg.v(3)','group','velocity');
newOutput('id','omega4_1','type','kinematic','var','L4_cg.omega(1)','group','velocity');
newOutput('id','omega4_2','type','kinematic','var','L4_cg.omega(2)','group','velocity');
newOutput('id','omega4_3','type','kinematic','var','L4_cg.omega(3)','group','velocity');
newOutput('id','v5_1','type','kinematic','var','L5_cg.v(1)','group','velocity');
newOutput('id','v5_2','type','kinematic','var','L5_cg.v(2)','group','velocity');
newOutput('id','v5_3','type','kinematic','var','L5_cg.v(3)','group','velocity');
newOutput('id','omega5_1','type','kinematic','var','L5_cg.omega(1)','group','velocity');
newOutput('id','omega5_2','type','kinematic','var','L5_cg.omega(2)','group','velocity');
newOutput('id','omega5_3','type','kinematic','var','L5_cg.omega(3)','group','velocity');

% END OF sysDef