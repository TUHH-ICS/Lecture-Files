% S = kardan2rotmat(phi, formulation_)
% KARDAN2ROTMAT - Calculate rotation matrix from Kardan-angles
% Kardan-angles are defined as sequential rotations around
% the x-axis, then the y-axis, then the z-axis. The rotation matrix is
% defined in a way that its multiplication transforms a coordinate system
% rotated with the given Kardan-angles back to the inertial frame.
%
% Input arguments
% phi ............ Vector of Kardan-angles in rad [alpha beta gamma]
% formulation_ ... Parameter to specify the angular description.
%                  Implemented choices:
%       - 'kardan' ... Kardan angles, requires a three element vector
%           causing the order x-y-z
%       - 'euler' ... Euler angles, requires a three element vector
%           causing the order z-y-z
%       - 'xyz' ..... When a combination of x, y, z is given, this order is
%           used. Here an arbitrary number of rotations can be specfied, it
%           only has to match the length of the phi vector. This is slower
%           than the other modes but the most versatile. Even a numerical
%           vector with elements between 1 and 3 is accepted.
%
% Return argument
% S ....... Rotation matrix
%
% See also: rotmat2kardan
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
