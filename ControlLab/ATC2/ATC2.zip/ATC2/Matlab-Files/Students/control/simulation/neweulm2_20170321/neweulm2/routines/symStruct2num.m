% exprStruct_ = symStruct2num(exprStruct_, whiteList_,useSimplify)
% 
% If possible, replace all parameters by their numerical value, except
% those, which are passed in whiteList_. Tries for all parameters listed in
% sys.parameters.data. If for some parameters symbolic expressions are
% stored, they are replaced first, before inserting numerical values. If
% function handles are stored for a parameter nothing is done.
% 
% Input arguments
% exprStruct_ ... Structure with the expressions in which the parameters
%                 shall be replaced. Could be
%                 sys.dynamics.nonlinear.generic with the fields {M, q, k}.
% whiteList_ .... Cell array of parameters which shall remain in the
%                 symbolic expressions. Can be used to achieve a partly
%                 symbolic formulation, where only the parameters of
%                 interest are still symbolic and all other parameters are
%                 replace by their numerical values.
% useSimplify ... Optional logical parameter to control usage of the
%                 simplify() command {true}
% 
% Return arguments
% exprStruct_ ... The structure from the input argument is returned after
%                 replacing the expressions.
% See also: exportEqMot
%
% First appearance: 19.12.2008
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
