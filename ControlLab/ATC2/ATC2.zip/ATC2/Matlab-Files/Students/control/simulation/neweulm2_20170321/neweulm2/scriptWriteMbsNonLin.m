% scriptWriteMbsNonLin - Script to allow the user to extend the call of
% writeMbsNonLin by own functions.
% 
%  Syntax:
% scriptWriteMbsNonLin
%
%  Description:
% Script which contains user specified commands being called in
% writeMbsNonLin.
% The reason this script exists is that then every user can easily extend
% Neweul-M2 and insert custom functions in here. Any user-written functions
% should be located in a folder in neweulm2/modules/ and should use telling
% names so they can be identified easily. This script is called after the
% files for coordinate systems are written and before the files for the
% equations of motion are created. As this is a script the visible variable
% space is the one of writeMbsNonLin. This means e.g. that the data
% structure sys is available.
%
%  See also: writeMbsNonLin, scriptcalcEqMotNonLin
%
% First appearance: 15.03.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de



% END OF FILE
