%
% System definition for double pendulum
%

% Create basic data structure

global sys;
sys = newSys('Id','doublePendulum', 'Name','double pendulum', ...
	'Gravity', '[0;0;-g]');


%%%%%%%%%%%%%%
% Create constant parameters and set numeric values
newConstant('L1', 2);
newConstant('m1', 1);
newConstant('L2', 1);
newConstant('m2', 2);

%%%%%%%%%%%%%%
% Create time dependent parameters

%%%%%%%%%%%%%%
% Create state dependent parameters

%%%%%%%%%%%%%%
% Create generalized coordinates
newGenCoord('alpha1');
newGenCoord('alpha2');

%%%%%%%%%%%%%%
% System definition

%%%%%%%%%%%%%%
% Body Number 1
%%%%%%%%%%%%%%
newBody('Id','BODY_1', ...
        'Name','Body Number 1', ...
        'RefSys','ISYS', ...
        'RelPos','[0;0;0]', ...
        'RelRot','[alpha1;0;0]', ...
        'CgPos','[0;0;-L1]', ...
        'CgRot','[0;0;0]', ...
        'Mass','m1', ...
        'Inertia','[0,0,0;0,0,0;0,0,0]');

%%%%%%%%%%%%%%
% Body Number 2
%%%%%%%%%%%%%%
newBody('Id','BODY_2', ...
        'Name','Body Number 2', ...
        'RefSys','BODY_1_cg', ...
        'RelPos','[0;0;0]', ...
        'RelRot','[alpha2;0;0]', ...
        'CgPos','[0;0;-L2]', ...
        'CgRot','[0;0;0]', ...
        'Mass','m2', ...
        'Inertia','[0,0,0;0,0,0;0,0,0]');

%%%%%%%%%%%%%%
% Parameters for the time integration
sys.settings.timeInt = [];
sys.settings.timeInt.y0 = [0.2;0.3];
sys.settings.timeInt.Dy0 = zeros(2,1);
sys.settings.timeInt.integrator = @ode45;

sys.settings.timeInt.intOpts = odeset;
sys.settings.timeInt.intOpts.AbsTol = 1e-06;
sys.settings.timeInt.intOpts.NormControl = 'off';
sys.settings.timeInt.intOpts.OutputFcn = @finalCond;
sys.settings.timeInt.intOpts.RelTol = 0.001;


sys.settings.timeInt.display.type = 'waitbar';

sys.settings.timeInt.time = [0 5];

%%%%%%%%%%%%%%
% Create new animation window, usually done in initSys.m
createAnimationWindow;

% Define graphic objects, usually done in defineGraphics.m

%-------- sphere --------
h = drawSphere(zeros(1,3),0.1,20,[1 0 0]);
set(h,'Tag','Sphere_1','FaceAlpha',1,'EdgeAlpha',1,'EdgeColor',[0.7 0 0]);
addGraphics('BODY_1_cg',h);

%-------- sphere --------
h = drawSphere(zeros(1,3),0.2,20,[0 0 1]);
set(h,'Tag','Sphere_2','FaceAlpha',1,'EdgeAlpha',1,'EdgeColor',[0 0 0.7]);
addGraphics('BODY_2_cg',h);

%-------- rotationalsymmetric body --------
h = drawRotBody('rVec',0.04,'zVec',[0;0;1;1], ...
	'fromVector',zeros(1,3),'toVector','[0,0,L1]','numPoints',20);
set(h,'Tag','RotBody_2','FaceAlpha',1,'EdgeAlpha',1,'FaceColor',[1 0 0],'EdgeColor',[0.7 0 0]);
addGraphics('BODY_1_cg',h);

%-------- rotationalsymmetric body --------
h = drawRotBody('rVec',0.06,'zVec',[0;0;1;1], ...
	'fromVector',zeros(1,3),'toVector','[0,0,L2]','numPoints',20);
set(h,'Tag','RotBody_1','FaceAlpha',1,'EdgeAlpha',1,'FaceColor',[0 0 1],'EdgeColor',[0 0 0.7]);
addGraphics('BODY_2_cg',h);

% Animation window, view settings
axis([-0.288       0.288     -1.1698      1.1837     -3.3604     0.27754]);
view(63.5, 26);

% End of sysDef.m

