% calcNomLength - Calculates the nominal lengths of all force 
% elements from the given initial conditions.
% 
%  Syntax: 
%> calcNomLength ('Property', value , ... );
% 
%  Description:
% Calculates the nominal lengths of all force elements from the given 
% initial conditions.To be able to do this, the parameters need numerical 
% values.
% 
%  Input arguments, given pairwise: 
% GenCoords......... Sets the initial position vector to value
%                   {sys.settings.timeInt.y0}
% Time ............. Sets the initial time to value {sys.settings.timeInt.time(1)}
% CheckVarargin ... An advanced feature to avoid errors if invalid
%                   parameters are passed. This is only if you know
%                   exactly what you are doing. {true}
%
% First appearance: 30.05.2008
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
