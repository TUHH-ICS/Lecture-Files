% varargout = writeGenCoordDef(fid,mode,varargin)
% writeGenCoordDef - create m-files with definitions of generalized
% coordinates and their derivatives if they are contained in the passed
% symbolic expressions. These initializations are written in the file
% specified by fid. With the parameter mode, some presets can be chosen.
% After these two mandatory arguments a list of symbolic expressions can be
% passed, which is used to search for appearances of generalized
% coordinates defined in neweulm2. If the expressions are very large and
% this function is called in sequence with writeHelpvarDef one can save
% computation time. Then the most time consuming operation is to find the
% symbolic parameters in the expression. Therefore one can search for those
% names and simply pass the cell array, which findSyms.m returns, thus
% omitting one of two searches.
%
% Input values
% fid ........ File identifier for the destination file
% mode ....... Representation of the generalized coordinates:
%             'gcvector'    Vector of generalized coordinates, 
%                           i.e. y(1..f) und Dy(1..f)
%             'gcvectorrigid' same as gcvecor, except only rigid-body
%                           degrees of freedom are used
%             'ssvector'    state vector, i.e. x(1..2*f)
%             'dependent'   The generalized coordinates are split in
%                           dependent (y_dep) and independent ones (y_ind).
%             'gcvector_c'  Vector of generalized coordinates, 
%                           i.e. y(1..f) und Dy(1..f), in C-code
%             'ssvector_c'  state vector, i.e. x(1..2*f), in C-code
%             'dependent_c' The generalized coordinates are split in
%                           dependent (y_dep) and independent ones (y_ind),
%                           in C-code
%             'extended'    The time and the generalized coordinates y form
%                           the extended coordinates q
%             'extended_q'  
%                            
% varargin ... One or more symbolic expressions to be searched for
%              appearances of generalized coordinates.
% 
% Return value
% varargout ..... List of all symbolic parameters found in input, only if
%                 an output is specified
%
% See also: writeHelpvarDef, writeSetValDef
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
