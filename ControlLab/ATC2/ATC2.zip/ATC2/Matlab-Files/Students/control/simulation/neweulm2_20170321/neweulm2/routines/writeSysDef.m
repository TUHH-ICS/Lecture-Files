% writeSysDef(sysDefPath_,varargin)
% 
% This function creates a file containing the definition of the current
% model. This enables the user to switch back from the graphical user
% interface to the input-file mode. This file is called 'sysDef.m' as a
% standard, but a different name can be specified. This file contains:
% - definition of constants, setting of their numerical values
% - definition of all other variables
% - definition of all modeling elements, like coordinate systems, bodies,
%   force elements, kinematic loops, system in-/outputs, ...
% - setting of the options for the time integration, if existent
% - definition of graphical objects, e.g. cubes, spheres, ... as well as
%   all line elements.
% - If an animation window is existent the visible area and orientation is
%   exported as well. This recreates the animation window in the current
%   fashion.
% 
% Input arguments
% sysDefPath_ ....... Path and filename for the file containing the system
%                     definition {'sysDef.m'}
% LegacyPath_ ....... The former version of this function created two
%                     files, therefore two filenames could be specified.
%                     Now the second input argument is kept only for
%                     compatibility and to issue a warning. The old format
%                     was writeSysDef(sysDefPath_,LegacyPath_)
% Optional input arguments, given in a pairwise manner
% overWrite ........ Usually, when the specified file exists already, the
%                    user is asked if he wants to really overwrite. If true
%                    is passed, then files are overwritten without further
%                    asking.
% CheckVarargin .... An advanced feature to avoid errors if invalid
%                    parameters are passed. This is only if you know
%                    exactly what you are doing. {true}
% SilentMode ....... Suppress prompts to command line. {false}
% 
% 
% The file startSysDef.m for the system definition or files for
% the simulation like runTimeInt.m have to be copied from another model and
% adjusted by the user. Only the very definition and options are exported
% to the file.
%
% See also: exportEqMot, writeSfunction, newBody, createAnimationWindow
%
% First appearance: 01.08.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
