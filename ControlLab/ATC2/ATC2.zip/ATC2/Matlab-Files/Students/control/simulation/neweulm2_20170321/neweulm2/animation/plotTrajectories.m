% plotTrajectories - add trajectories to animation window
%
%  Syntax:
%
% plotTrajectories(csys_specifier, varargin);
%
%  Description:
%
% Calculate and plot the trajectory of given coordinate systems from a time
% integration. The information which coordinate system is to be plotted is
% stored in sys.graphics.marker. Initialization can happen directly in sys,
% or by passing the arguments to plotTrajectories. To replot a trajectory
% a function call without arguments is enough.
% This function returns a cell array with the curves and a cell array with
% the corresponding names of coordinate systems.
%
% Output arguments:
% curves ....... The coordinates of the calculated trajectories
% csys_names ... The corresponding ids of the coordinate systems
%
% Input arguments:
% csys_specifier ... ID of a coordinate system, for which a trajectory
%                    shall be plotted
% On-the-fly ....... Determine, if the trajectories step-by-step or at once
%                    {false}
% Tag .............. A tag for this line can be given
%                    {['automark_',FrameID]}
% Result ........... The result to be used to plot the line can be
%                    specified {sys.results.timeInt}
% Refine ........... If a higher resolution than in the result shall be
%                    used, here a factor of refinement can be given. A
%                    factor of 2 would mean to use twice as many points as
%                    in the given result {1}
%
%  Example:
%
% plotTrajectories('CSYS_1');
% [curves, names] = plotTrajectories('CSYS_1','rd-', 'LineWidth', 2);
% plotTrajectories;
% plotTrajectories('','Result',sys.results.kian);
%
% If nothing is specified, this function uses the result of a time
% integration stored in sys.results.timeInt. To use a different result,
% e.g. of a kinematic analysis call it with
%   [curves, names] = plotTrajectories('CSYS_1','rd-', 'LineWidth', 2, 'Result','kian');
%
% To reset everything call plotTrajectories('reset');
% To plot all trajectories call plotTrajectories('all');
%
% To ensure smooth lines, a factor for refinement can be given. It adjusts
% the number of sample points in relation to the given result, e.g. from a
% time integration. 1 represents the original {default value}, while a
% value of 2 inserts one point between two given values, for this use the
% following options:
%   plotTrajectories('','Refine',2)
%
%  See also:
%
% animTimeInt, drawLine, fitCanvas, plotTrajectories>csys_call
%
% First appearance: 17.12.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
