% declareIndependentInitCond(varargin) - Declare generalized coordinates
% used in newImplicitInitCond independent.
% 
%  Syntax:
%> declareIndependentInitCond('genCoord1', 'genCoord2', ...);
%     
%  Description:
% For each implicit initial condition, two generalized coordinates depend on each other.
% This function is used to declare which of the generalized coordinates are
% to be considered independent. The dependent coordinates are collected in
% sys.parameters.implicitInitCond.dep, while the independent coordinates are listed
% in sys.parameters.implicitInitCond.ind
%
%  Input:
%   list of independent generalized coordinates
% 
%  Example:
%>   declareIndependentInitCond('alp1');
%
%  See also:
%   declareDependentInitCond, newConstraint, calcEqMotNonLin, calcCon
%
%  First appearance: 
%   15.11.2012
%
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
