% initial conditions
y0 = zeros(sys.counters.genCoord,1);
Dy0 = zeros(sys.counters.genCoord,1);
Dy0(1) = 600/60*2*pi;

% Time interval
% time_ = [0 0.1];
time_ = linspace(0,0.1,10000);

timeInt(y0,Dy0,'time',time_,'waitbar',true);

% Animate the motion
animTimeInt('stride',0.003,'scaleElastic',1e1);

plotStandardResults('type','output');
plotStandardResults;