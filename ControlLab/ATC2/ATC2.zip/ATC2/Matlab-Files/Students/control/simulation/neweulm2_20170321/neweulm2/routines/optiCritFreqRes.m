% [res_,grad_,maxFreq_] = optiCritFreqRes(p_)
% Optimization criterion for an optimization using the frequency response.
% This function uses scaled parameter values for the optimization in the
% range [-1 <= p_ <= 1]. This may look strange but improves the results.
%
% In order to support multiple in- and outputs this function does the
% following. The transfer function from all in- to all outputs is evaluated
% at the given frequencies. Then for each frequency, the maximal amplitude
% is extracted and from these maximal values, again the largest values are
% summed up. The parameter sys.settings.opt.spec.numPts specifies how many of
% these maximal values are to be summed up. This algorithm has several
% advantages. One is the possibility to consider multiple inputs and
% outputs, without the worry, which are important. Important would mean
% those with high amplitudes. Second, this function has no strong
% dependency on the resolution of the frequency range. Please adjust the
% parameter numPts according to the number of frequency points.
% 
% Input arguments
% p_ .......... Values of the design parameters. These values are scaled
%               using the properties stored under sys.settings.opt. Therefore
%               p_ will only take values in the interval [-1,1]. The used
%               settings are:
%               - sys.settings.opt.constr.lb representing the lower bound
%               - sys.settings.opt.constr.ub representing the upper bound
% 
% Return arguments
% res_ ........ Criterion value
% grad_ ....... This function does NOT calculate a gradient. To avoid any
%               misunderstandings, the second argument always returns [].
% maxFreq_ .... Frequencies used for the evaluation. This is not necessary
%               for the evaluation in an optimization, but a very
%               interesting property for further analysis.
%
% See also: newOpt, optiEvalFreqRes, optiCritTimeIntAdj,
%   optiCritTimeIntDir, optiCritTimeIntFinite
%
% First appearance: 10.08.2010
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
