% psi = optiCritTimeIntFinite(p_in)
% Calculates the criterion value using a numerical time integration. This
% is basically the same part as in optiCritTimeIntAdj and
% optiCritTimeIntDir without the calculation of a gradient. The reason to
% create a separate function is that this function does not require the
% minimal form of the equations of motion.
%
% The criterion is of the form
% psi = G1(t1,y1,Dy1) + int _{t0} ^{t1} {F(t,y,Dy) dt}
% where the time t is in [t0,t1] and y1=y(t1), Dy1=Dy(t1). The functions G1
% and F may contain symbolic expressions or references to kinematic
% expressions of the multibody system.
% 
% Incoming variables
% p_in ...... Vector of current design variables p. This function uses
%             scaled parameter values for the optimization in the range
%             [-1 <= p_ <= 1]. This may look strange but improves the
%             results, especially if the design variables are in a
%             different order of magnitude. The actual interval is given by
%             [sys.settings.opt.constr.lb, sys.settings.opt.constr.ub]
% Outgoing variables
% psi ....... Value of criterion function
%
% See also: newOpt, optiCritTimeIntDir, optiCritTimeIntAdj,
%   OptiCalcInitCon, writeFinalCond, writePsiTimeInt
%
% First appearance: 23.12.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
