% evalForces - Evaluates reaction forces and applied forces.
%
%  Syntax:
%> evalForces;
%> evalForces('Property', value, ...);
%   
%  Description:
% Reaction forces can be calculated as generalized reaction forces or in cartesian
% coordinates.
% 
%  Input arguments, given pairwise:
% AppliedForces .... Logical if the applied forces are evaluated {false}.
% ReactionForces ... Evaluation of reaction forces {true}.
% Struct ........... A structure is needed to get the states and time 
%                    vector and to store the result. The Structure must 
%                    contain a time vector x and a state vector y. If no 
%                    Structure is passed, 'sys.results.timeInt' will be 
%                    used to get the values and to store the result
%                    {sys.result.timeInt}
%
%  Output argument:
% result_ ............ Result structure
%
%  Example:
%> structOut_ = evalForces('struct',structIn_, ...
%>   'reactionForces',false,'appliedForces',true);
%> evalForces('appliedForces',true);
%
%  First appearance: 15.05.2012
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
