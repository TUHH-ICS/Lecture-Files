% plotTimeSteps - plot different configurations of a simulation
%
%  Description:
% Plot different configurations of a simulation of neweulm2 into one
% figure. The axes properties are kept as similar to the animation axes as
% possible.
%
%  Input arguments, given pairwise:
% FaceAlpha ....... Specify the parameter FaceAlpha, which defines the
%                   transparency of patch and surface objects. Only one
%                   parameter value is available for all elements {0.2}
% Resolution ...... If a numerical value is passed with this option, the
%                   time vector of the result is displayed with the given
%                   number of set points.
% Result .......... Result structure as returned by a time integration
%                   algorithm {sys.results.timeInt}
% Time ............ A time vector can be given, otherwise the given time is
%                   used.
%  Output arguments:
% varargout{1} .... Figure handle of the new figure 
% 
%  Example:
%   plotTimeSteps(sys.results.timeInt, 'time',[0:0.5:10]);
%
%  See also:
% animModeShape, animTimeInt, updateGeo
%
% First appearance: 29.06.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
