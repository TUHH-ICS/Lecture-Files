% [FRAMES, BODY, FELEM, IN, OUT] = subVar(oldName, newName)
% Substitute variable name
%
% When changing the name of a parameter, this has to be done in all
% modeling elements, as coordinate systems, force elements, ...
% For this all entries of the following elements are checked:
% - coordinate systems
% - bodies
% - force elements
% - system inputs
% - system outputs
% 
% Input arguments:
% oldName ... Current parameter name, to be replaced
% newName ... New parameter name
% 
% Output arguments:
% FRAMES .... Coordinate systems, depending on this parameter
% BODY ...... Bodies, depending on this parameter
% FELEM ..... Force elements, depending on this parameter
% IN ........ System inputs, depending on this parameter
% OUT ....... System outputs, depending on this parameter
%
% First appearance: 01.07.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
