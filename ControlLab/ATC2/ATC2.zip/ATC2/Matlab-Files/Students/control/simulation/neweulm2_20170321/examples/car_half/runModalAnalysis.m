%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                   %
%                         runModalAnalysis                          %
%                                                                   %
%    modal analysis and presentation of the natural/eigen modes     %
%                                                                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% modal analysis

fprintf(1,'running a modal analysis ...');
sys.results.modal = modalAnalysis(0);
fprintf(1,' ok!\n');


% presentation of the natural modes / Eigen modes

fprintf(1,'presenting eigen modes ...');

amp = 0.5*ones(sys.counters.genCoord,1);

for h_ = 1:sys.counters.genCoord % loop over all degrees of freedom
    showModeShape(sys.results.modal,h_, ...
              'Amplitude',amp(h_), ...
              'ShowRefPos','on', ...
              'RefPosTransparency',0.3);
end

fprintf(1,' ok!\n');
