% varargout = calcForcesFelem(varargin)
% calcForcesFelem - Calculate the forces of force elements for the
% nonlinear equations of motion. If nothing is specified, the program uses
% a call as from calcEqMotNonLin.m. However, this function has other
% applications and therefore offers options to adjust to these additional
% purposes.
% 
% Input
% varargin ....... Optional input arguments, to be passed in pairs of
%                  option name and value (usually boolean) 
%                  {standard values}
%   'felemStruct' ........... Structure of force elements to be considered.
%                             If nothing is specified sys.model.forceElement is used.
%   'startPoint' ............ The structure with fields for every body
%                             containing a vector for the first and last
%                             index of the position in the qa vector where
%                             the part of this body is located. This means
%                             that the applied forces acting on 'BODY1' are
%                             located at 
%                             qa(startPoint.BODY1(1) : startPoint.BODY1(2))
%   'StoreLocalForces' ...... Store the forces described in each dirdef
%                             system in Data_.LocalForces.(felem). {true}
%   'useIntermediateSave' ... The workspace is saved after the calculation
%                             of each force element, especially for
%                             debugging {false}.
%
% Optional output parameters
% varargout{1} ... qa: Vector of forces, is to be multiplied with the
%                  transposed global jacobian in order to get to the
%                  equations of motion.
% varargout{2} ... felemStruct_: Structure of force elements, could have changed, e.g.
%                  dimensions of some parameters adjusted
% varargout{3} ... Data_: Additional information. Depending on the options, the
%                  user can select more or less data to be stored in this
%                  structure. The fields are described above where the
%                  options in varargin are explained.
%
% Example
% from calcEqMotNonLin.m: 
%   [qa_felem, felemStruct_, Data_] = calcForcesFelem;
% See also: calcEqMotNonLin
%
% First appearance: 26.05.2010
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
