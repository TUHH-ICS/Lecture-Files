% varargout = Export_System(varargin)
% Export_System M-file for Export_System.fig
%      Export_System, by itself, creates a new Export_System or raises the existing
%      singleton*.
%
%      H = Export_System returns the handle to a new Export_System or the handle to
%      the existing singleton*.
%
%      Export_System('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in Export_System.M with the given input arguments.
%
%      Export_System('Property','Value',...) creates a new Export_System or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Export_System_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Export_System_OpeningFcn via varargin.
%
% Graphical user interface to export the currently loaded system. This can
% result e.g. in input files or C-functions.
%
% For more information, please open the corresponding window and click on
% the help button, labeled with a question mark "?".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
%
% First appearance: 01.03.2008
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
