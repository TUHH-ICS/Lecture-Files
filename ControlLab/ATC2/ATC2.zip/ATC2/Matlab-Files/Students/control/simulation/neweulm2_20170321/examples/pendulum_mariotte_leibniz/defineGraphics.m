function defineGraphics
% DEFINEGRAPHICS - create graphic visualization of modeling elements
%

global sys;

%%%%%%%%%%%%%%
% Support    %
%%%%%%%%%%%%%%
h = drawRotBody('rVec','[dP/2, dP/2]', 'zVec','[-b, (a-b)]', ...
    'ToVector',[0 1 0],'Color',[0.1 0.1 0.9]);
addGraphics('PB',h);
h = drawRotBody('rVec','[dP/2, dP/2]', 'zVec','[0, l]', ...
    'ToVector',[0 1 0],'Color',[0.9 0.1 0.1]);
addGraphics('PP',h);
h = drawSphere('[0, -b, 0]','(MB/MP)*dM/2',40,[0.1 0.1 0.1]);
addGraphics('PB',h);
h = drawSphere('[0, l, 0]','dM/2',40,[0.1 0.1 0.1]);
addGraphics('PP',h);

