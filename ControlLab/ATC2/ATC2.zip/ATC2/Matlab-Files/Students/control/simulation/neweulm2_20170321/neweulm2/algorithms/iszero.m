% res_ = iszero(expr_,dim_)
% iszero - Function to determine whether an expression is equal to zero no
% matter of which type. This is mainly to avoid long if cases due to
% symbolic expressions. 
% Maple distinguishes between sym('0') and sym('0.') whereas MuPad throws
% errors upon creating sym('0.'). Also Maple distinguishes between symbolic
% and numeric zeros. Especially Maple doesn't respect that the expression
% 'a-a' is equal to zero. Therefore a simplify() command can be useful.
% However as this simplification takes a lot of time and has been
% previously done at the designated applications of this function, no
% simplification is performed.
% If a dimension dim_ is given, the function returns whether all entries
% along this dimension are zero, comparable to the sum() command
% 
% Input
% expr_ ... Expression to be checked for zeros
% dim_ .... Dimension along which all entries are connected in an all()
%           statement. When a matrix is given for expr_, dim_=1 returns a
%           row vector, dim_=2 a column vector and dim_=0 a matrix of
%           size(expr_). {0}
%
% See also: any2str, mapleSimplify, sym2mcode
% 
% First appearance: 09.09.2010
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
