% EDITMATRIX M-file for EditMatrix.fig
%      EDITMATRIX, by itself, creates a new EDITMATRIX or raises the existing
%      singleton*.
%
%      H = EDITMATRIX returns the handle to a new EDITMATRIX or the handle to
%      the existing singleton*.
%
%      EDITMATRIX('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in EDITMATRIX.M with the given input arguments.
%
%      EDITMATRIX('Property','Value',...) creates a new EDITMATRIX or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before EditMatrix_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to EditMatrix_OpeningFcn via varargin.
%
% Graphical user interface to start an animation, make plots or perform
% other post processing.
%
% This function belongs to a GUI used to edit stiffness and damping
% matrices. This GUI can be adjusted to the name of the parameter easily.
% So if other matrices are to be edited, it would be an easy task.
% 
% For more information, please open the corresponding window and click on
% the help button, labeled with a question mark "?".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
%
% First appearance: 27.03.2009
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
