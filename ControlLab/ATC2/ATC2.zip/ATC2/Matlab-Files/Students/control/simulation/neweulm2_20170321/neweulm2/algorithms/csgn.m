function res = csgn(varargin)
% CSGN - complex sign function
% this function is introduced for the numeric evaluation of expressions
% with MAPLE syntax.
%
% Possible function calls:
% csgn(x) ......... Determines in which half-plane ("left" or "right") the
%     complex-valued expression of number x lies. it is defined as
%     
%                /  1    if Re(x) > 0, or Re(x) = 0 AND Im(x) > 0
%     csgn(x) = <
%                \ -1    if Re(x) < 0, or Re(x) = 0 AND Im(x) < 0
%    
% csgn(1, x) ...... Is the derivative of csgn(x). It is 0 for all
%     non-purely-imaginary numbers, undefined otherwise.
%    
% csgn(0, x, y) ... Is the same as csgn(x), only in case of x = 0 it
%     returnes y: csgn(0, 0, y) = y
%
% See also: signum, mapleSimplify, mapleSubs
%
% First appearance: 05.12.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de

if length(varargin) == 1
    
    if real(varargin{1}) ~= 0

        res = sign(real(varargin{1}));
        
    else

        res = sign(imag(varargin{1}));

    end;
    
elseif length(varargin) == 2
    
    if varargin{1} == 1

        if real(varargin{2}) ~= 0

            res = 0;

        else
            
            error(sprintf('function csgn(1,x) not defined if real(x) == 0. Called with x = %s!\n', num2str(varargin{2})));

        end;
        
    else

        error(sprintf('function csgn(%s, ...) not defined!\n', num2str(varargin{1})));
        
    end

elseif length(varargin) == 3
    
    if varargin{1} == 0
        
        if real(varargin{2}) ~= 0

            res = sign(real(varargin{2}));

        else

            if imag(varargin{2}) ~= 0

                res = sign(imag(varargin{2}));
                
            else

                res = varargin{3};
                
            end

        end;
        
    else

        error('function csgn(%s, ... , ...) not defined!\n', num2str(varargin{1}));

    end

else
    
    error('function csgn(''%s'',...) not defined!', num2str(varargin{1}));    

end;
