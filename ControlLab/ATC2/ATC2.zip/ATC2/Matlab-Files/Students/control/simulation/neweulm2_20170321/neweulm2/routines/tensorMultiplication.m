% result_ = tensorMultiplication(tensor,matrix,varargin)
% This function provides the multiplication of a third order tensor (tensor) and a
% first or second order tensor (matrix). The multiplication is implemented as a 
% matrix matrix multiplication for each element of the in 'varargin{1}' defined dimension.
% 
% Input arguments:
% tensor ......... Three-dimensional array
% matrix ......... One- or two-dimensional array
% varargin{1} .... dimension of matrix stack
% varargin{2} .... Boolean which decides whether the result gets squeezed
%                  or not
%
% Output arguments:
% result_ ........ Product of tensor and matrix/vector
%
% First appearance: 01.12.2008
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
