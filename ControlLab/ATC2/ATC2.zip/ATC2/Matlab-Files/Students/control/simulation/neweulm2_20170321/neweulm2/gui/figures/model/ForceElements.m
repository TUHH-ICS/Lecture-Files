% FORCEELEMENTS M-file for ForceElements.fig
%      FORCEELEMENTS, by itself, creates a new FORCEELEMENTS or raises the existing
%      singleton*.
%
%      H = FORCEELEMENTS returns the handle to a new FORCEELEMENTS or the handle to
%      the existing singleton*.
%
%      FORCEELEMENTS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FORCEELEMENTS.M with the given input arguments.
%
%      FORCEELEMENTS('Property','Value',...) creates a new FORCEELEMENTS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ForceElements_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ForceElements_OpeningFcn via varargin.
%
% Graphical user interface to display force elements and select further
% tasks.
% 
% For more information, please open the corresponding window and click on
% the help button, labeled with a question mark "?".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
%
% First appearance: 01.07.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
