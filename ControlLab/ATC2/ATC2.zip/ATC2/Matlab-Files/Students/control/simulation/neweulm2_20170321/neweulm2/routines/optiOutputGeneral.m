% stop = optiOutputGeneral(p_, optimValues, state, varargin)
% General output function for the optimization of mechanical systems.
% This function writes the current accepted configuration to the file
% 'optimizationResult.m'. Then during an optimization, one can
% visualize the current status, which allows the user to judge the progress
% 
% If you want to use this apart from the automatic use, call it like
% optiOutputGeneral(p_,struct('fval',0),'iter','manualResult.m');
% 
% Input arguments
% p_ ............ Values of the design parameters. These values are scaled
%                 using the properties stored under sys.settings.opt.
%                 Therefore p_ will only take values in the interval
%                 [-1,1]. The used settings are:
%               - sys.settings.opt.constr.lb representing the lower bound
%               - sys.settings.opt.constr.ub representing the upper bound
% optimValues ... Data structure with information like the function value
% state ......... Specifies the state of the optimization algorithm. Has
%                 the values
%               - 'interrupt': Somewhere in the middle of the calculation
%               - 'iter': Finished an optimization step
%               - 'init': At the beginning of the optimization
%               - 'done': At the very end of the optimization
% varargin{1} ... As a standard, the file is written in the current folder,
%                 called 'optimizationResult.m'. As a fourth argument, a
%                 different name and folder can be specified. This is not
%                 available when being used as an output function, but
%                 then, it can be called manually.
% 
% Return arguments
% stop .......... Value to quit an optimization. As this function is only
%                 for visualization, this is always false, meaning to
%                 continue the optimization.
%
% See also: newOpt, optiCritFreqRes, optiOutputFreqRes
%
% First appearance: 05.09.2012
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
