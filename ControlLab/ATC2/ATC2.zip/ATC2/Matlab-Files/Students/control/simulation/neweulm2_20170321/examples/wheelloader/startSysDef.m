%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% startSysDef                                                          %
%                                                                      %
%                                                                      %
% This is an Neweul-M² model of a wheel loader that drives on an       %
% incline. The gravitional vector is transformed, bacause the initial  %
% frame is located in the incline.                                     %
% Constraint equations on velocity level are used to ensure a constant %
% moving speed and to get the rotations of the wheels.                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%
% Extend path variable %
%%%%%%%%%%%%%%%%%%%%%%%%

run('../addpathNeweulm2');

% Set up model
sysDef;

% Compute the equations of motion
calcEqMotNonLin; 

% Create files for the numerical evaluation
writeMbsNonLin;

% Create animation window
createAnimationWindow;

% Define simple geometrical shapes to animate the wheel loader
defineGraphics;

% Perform a time integration
runTimeInt;

