% writeStructure(structure, varargin) - Export structure to m-file
%
%  Syntax:
% writeStructure(structure, 'Property', value, ...);
%
%  Describtion:
% Function to write a structure in an m-file to get a better overview. If
% nothing is specified the given structure is printed in STDOUT, meaning
% the Matlab command prompt
% 
%  Mandatory parameters
% structure ... Structure to be printed
%
%  Optional parameters {default value}:
%   Comment ...... Commentary text, which is printed at the top of the file
%                  {''}
%   Filename ..... Name of the file to be written {''}
%   FID .......... File identifier from fopen, or 1 for STDOUT {1}
%   Name ......... Name of the structure to be used in the file {'res'}
%   setUserVar ... Special option for neweulm2 {false}, then the following
%                  settings are used:
%                  Filename='setUserVar.m', can be changed by user
%                  Name='sys.parameters.data'
%                  structure=sys.parameters.data
%
%  See also: 
%   writeSysDef, any2str
%
%  First appearance: 
%   14.01.2011
%
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
