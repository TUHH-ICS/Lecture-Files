% [w, x, y, z] = rotmat2quat(S)
% ROTMAT2QUAT - calculate quaternions from the rotation matrix S. Can be
% used for symbolic or numeric input arguments.
% 
% Input arguments
% S .............. Rotation matrix
% 
% Return arguments
% w,x,y,z ........... Unit quaternion q = w+ix+jy+kz, 1 = w^2+x^2+y^2+z^2
%                     in case four arguments are used
% q ................. Unit quaternion q = [w; x; y; z] in case only one
%                     argument is used
%
% See also: kardan2rotmat, rotmat2kardan
%
% First appearance: 28.12.2013
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
