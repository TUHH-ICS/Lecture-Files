#ifndef optionsh
#define optionsh

/* PREFIX: opt */

struct OptionSettings 
{ /* m�gliche Einstellungen (Warnstufe, usw.) bei Optionen */
  int warnMiss;  /* Warnung, wenn Optionseintrag fehlt */
  int warnType;  /* Warnung, wenn Optionseintrag falschen Typ */
  int warnSize;  /* Warnung, wenn Optionseintrag falsche Gr��e */
};
typedef struct OptionSettings SOptionSettings;
typedef SOptionSettings* POptionSettings;

int opt_getSizeOfOptField (const mxArray *opt, const char *name, int *m, int *n);

double opt_getDoubleFromOpt (const mxArray *opt, POptionSettings optSet,
  const char *name, double defaultValue);
  
int opt_getDoubleVectorFromOpt (const mxArray *opt, POptionSettings optSet,
  const char *name, int m, int n, double *dpointer);
  
int opt_getIntFromOpt (const mxArray *opt, POptionSettings optSet,
  const char *name, int defaultValue);

char* opt_getStringFromOpt (const mxArray *opt, POptionSettings optSet,
  const char *name, char* defaultValue);


#endif
