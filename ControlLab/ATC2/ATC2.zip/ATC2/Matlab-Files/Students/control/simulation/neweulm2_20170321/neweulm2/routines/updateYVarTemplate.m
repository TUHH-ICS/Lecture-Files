% updateYVarTemplate(file)
%
% updateYVarTemplate - Makes a modified copy of template files for state
% dependant parameters with a corrected matching of the name of a
% generalized coordinate or velocity and its position in the vector of
% generalized coordinates. This function is needed due to the fact that if
% the vector of the generalized coordinates is re-sorted in
% calcEqmMotNonLin, the assignments of the symbolical variables to the
% vector of generalized coordinates is maybe wrong. A backup of the
% original file will be generated if any modifications accur.
%
% Input value
% file ... The template file that is supposed to be changed
% 
% See also newUserVarYvar
%
% First appearance: 
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
