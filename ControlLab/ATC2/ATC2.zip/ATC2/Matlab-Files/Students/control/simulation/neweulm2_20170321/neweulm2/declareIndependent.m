% declareIndependent(varargin) - Declare generalized coordinates used in
% newConstraint independent.
% 
%  Syntax:
%> declareIndependent('genCoord1', 'genCoord2', ...);
%     
%  Description:
% For each constraint equation, two generalized coordinates depend on each other.
% This function is used to revert the declaration of dependent coordiantes.
% The dependent coordinates are collected in sys.parameters.vectors.dep,
% while the independent coordinates are listed in sys.parameters.vectors.ind
%
%  Input:
% list of independent generalized coordinates
% 
%  Example:
%>   declareIndependent('alp1');
%
%  See also: 
%   declareDependent, newConstraint, calcEqMotNonLin, calcCon
%
%  First appearance: 
%   01.07.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
