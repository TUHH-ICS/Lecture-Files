% defineGraphics.m
sys.graphics.surfaces = [];
createAnimationWindow('drawCS',false);

% Define graphic objects, usually done in defineGraphics.m

rigidColor = [0.3 0.3 0.3];

%-------- representation of elastic body via mesh --------
drawMesh('L1', ...
			'Idx',1, ...
			'Tag','Mesh_1', ...
			'FaceColor',[0 0 1], 'EdgeColor','none', ...
			'FaceAlpha',1, 'EdgeAlpha',1);

%-------- representation of elastic body via mesh --------
drawMesh('L2', ...
			'Idx',1, ...
			'Tag','Mesh_2', ...
			'FaceColor',[0 0 1], 'EdgeColor','none', ...
			'FaceAlpha',1, 'EdgeAlpha',1);
        
%-------- Pfeiler 1 --------
h = drawRotBody('rVec',[0 sys.parameters.data.lL1/5 sys.parameters.data.lL1/5 0],'zVec',[-104.1e-3 -104.1e-3 50e-3 50e-3]);
set(h,'Tag','RotBody_I1','FaceAlpha',1,'EdgeAlpha',1,'FaceColor',rigidColor,'EdgeColor',rigidColor);
transformGraphics(h,'Translation',[-0.1; 0.07; 0]);
addGraphics('ISYS',h);

%-------- Pfeiler 2 --------
h = drawRotBody('rVec',[0 sys.parameters.data.lL1/5 sys.parameters.data.lL1/5 0],'zVec',[-104.1e-3 -104.1e-3 50e-3 50e-3]);
set(h,'Tag','RotBody_I2','FaceAlpha',1,'EdgeAlpha',1,'FaceColor',rigidColor,'EdgeColor',rigidColor);
transformGraphics(h,'Translation',[-0.1; -0.07; 0]);
addGraphics('ISYS',h);

%-------- Pfeiler 3 --------
h = drawRotBody('rVec',[0 sys.parameters.data.lL1/5 sys.parameters.data.lL1/5 0],'zVec',[-104.1e-3 -104.1e-3 50e-3 50e-3]);
set(h,'Tag','RotBody_I3','FaceAlpha',1,'EdgeAlpha',1,'FaceColor',rigidColor,'EdgeColor',rigidColor);
transformGraphics(h,'Translation',[-0.2; 0.07; 0]);
addGraphics('ISYS',h);

%-------- Pfeiler 4 --------
h = drawRotBody('rVec',[0 sys.parameters.data.lL1/5 sys.parameters.data.lL1/5 0],'zVec',[-104.1e-3 -104.1e-3 50e-3 50e-3]);
set(h,'Tag','RotBody_I4','FaceAlpha',1,'EdgeAlpha',1,'FaceColor',rigidColor,'EdgeColor',rigidColor);
transformGraphics(h,'Translation',[-0.2; -0.07; 0]);
addGraphics('ISYS',h);

%-------- cube --------
h = drawCube([-0.15 0 51e-3],0.15,0.25,0.005,rigidColor);
set(h,'Tag','Cube_I1','FaceAlpha',1,'EdgeAlpha',1,'EdgeColor',rigidColor);
addGraphics('ISYS',h);

%-------- cube --------
h = drawCube([0.2 0 -105e-3],1,0.5,0.005,rigidColor);
set(h,'Tag','Cube_I2','FaceAlpha',0.1,'EdgeAlpha',1,'EdgeColor',rigidColor);
addGraphics('ISYS',h);

h = drawRotBody('rVec',[0 0.8*sys.parameters.data.lL1 0.8*sys.parameters.data.lL1 0],'zVec',[-15e-3 -15e-3 15e-3 15e-3]);
set(h,'Tag','RotBody_I5','FaceAlpha',1,'EdgeAlpha',1,'FaceColor',rigidColor,'EdgeColor',rigidColor);
addGraphics('ISYS',h);

%-------- cube --------
h = drawCube([-sys.parameters.data.lL1 0 0],2*sys.parameters.data.lL1 ,1.6*sys.parameters.data.lL1 , 30e-3,rigidColor);
set(h,'Tag','Cube_I3','FaceAlpha',1,'EdgeAlpha',1,'EdgeColor',rigidColor);
addGraphics('ISYS',h);

h = drawCube([-0.1 0 0],0.054,0.23,30e-3,rigidColor);
set(h,'Tag','Cube_I4','FaceAlpha',1,'EdgeAlpha',1,'EdgeColor',rigidColor);
addGraphics('ISYS',h);

%-------- cube --------
h = drawCube([-0.01 0 0],0.02,0.05,0.0882,rigidColor);
set(h,'Tag','Cube_1','FaceAlpha',1,'EdgeAlpha',1,'EdgeColor',rigidColor);
addGraphics('L1_1',h);

%-------- cube --------
h = drawCube([0.01 0 0],0.02,0.05,0.0882,rigidColor);
set(h,'Tag','Cube_2','FaceAlpha',1,'EdgeAlpha',1,'EdgeColor',rigidColor);
addGraphics('L1_15',h);

%-------- cube --------
h = drawCube([-0.0075 0 0],0.015,0.05,0.0882,rigidColor);
set(h,'Tag','Cube_3','FaceAlpha',1,'EdgeAlpha',1,'EdgeColor',rigidColor);
addGraphics('L2_1',h);

%-------- rotationalsymmetric body --------
h = drawRotBody('rVec',[0 sys.parameters.data.lL1 sys.parameters.data.lL1 0],'zVec',[32.1e-3 32.1e-3 44.1e-3 44.1e-3]);
set(h,'Tag','RotBody_1','FaceAlpha',1,'EdgeAlpha',1,'FaceColor',rigidColor,'EdgeColor',rigidColor);
addGraphics('MM1',h);

%-------- rotationalsymmetric body --------
h = drawRotBody('rVec',[0 sys.parameters.data.lL1 sys.parameters.data.lL1 0],'zVec',[-32.1e-3 -32.1e-3 -44.1e-3 -44.1e-3]);
set(h,'Tag','RotBody_2','FaceAlpha',1,'EdgeAlpha',1,'FaceColor',rigidColor,'EdgeColor',rigidColor);
addGraphics('MM1',h);

%-------- rotationalsymmetric body --------
h = drawRotBody('rVec',[0 sys.parameters.data.lL1/3 sys.parameters.data.lL1/3 0],'zVec',[-44.1e-3 -44.1e-3 44.1e-3 44.1e-3]);
set(h,'Tag','RotBody_3','FaceAlpha',1,'EdgeAlpha',1,'FaceColor',rigidColor,'EdgeColor',rigidColor);
addGraphics('MM1',h);

%-------- cube --------
h = drawCube([0 0 0],0.03,0.05,0.07,rigidColor);
set(h,'Tag','Cube_4','FaceAlpha',1,'EdgeAlpha',1,'EdgeColor',rigidColor);
addGraphics('EE_cg',h);

%-------- rotationalsymmetric body --------
h = drawRotBody('rVec',[0 sys.parameters.data.lL2 sys.parameters.data.lL2 0],'zVec',[32.1e-3 32.1e-3 44.1e-3 44.1e-3]);
set(h,'Tag','RotBody_4','FaceAlpha',1,'EdgeAlpha',1,'FaceColor',rigidColor,'EdgeColor',rigidColor);
addGraphics('MM3',h);

%-------- rotationalsymmetric body --------
h = drawRotBody('rVec',[0 sys.parameters.data.lL2 sys.parameters.data.lL2 0],'zVec',[-32.1e-3 -32.1e-3 -44.1e-3 -44.1e-3]);
set(h,'Tag','RotBody_5','FaceAlpha',1,'EdgeAlpha',1,'FaceColor',rigidColor,'EdgeColor',rigidColor);
addGraphics('MM3',h);

%-------- rotationalsymmetric body --------
h = drawRotBody('rVec',[0 sys.parameters.data.lL2/3 sys.parameters.data.lL2/3 0],'zVec',[-44.1e-3 -44.1e-3 44.1e-3 44.1e-3]);
set(h,'Tag','RotBody_6','FaceAlpha',1,'EdgeAlpha',1,'FaceColor',rigidColor,'EdgeColor',rigidColor);
addGraphics('MM3',h);

% Animation window, view settings
axis([-0.3000    0.7000   -0.5000    0.5000   -0.5270    0.4730]);
view(37.5, 30);
% END OF FILE
