/*
 * SEULEXMEX-Interface von C. Ludwig
 * Version: $Id: seulexMex.c 287 2006-01-12 09:59:51Z luchr $ */
#define SEULEXMexVersion "12. Jan. 2006"
/*
 * 
 * Fragen, W�nsche, Probleme, Anregungen, 
 * Anmerkungen, Bemerkungen und Bugs an
 *  Ludwig_C@gmx.de
 */
#include <math.h>
#include "mex.h"
#include "string.h"
#include "options.h"
#include "seulexMex.h"

static SOptionSettings optSet;
static SParameterOptions paramOpt;
static SParameterGlobal paramGlobal;
static SParameterSeulex paramSeulex;
static SParameterRightSide paramRightSide;
static SParameterMassmatrix paramMassmatrix;
static SParameterJacobimatrix paramJacobimatrix;
static SParameterOutput paramOutput;

void SeulexMASFullFunc (int*, double*, int*, double*, int*);
void SeulexMASFullLRFunc (int*, double*, int*, double*, int*);
void SeulexMASBandedMatrixFunc (int*, double*, int*, double*, int*);
void SeulexMASBandedCellFunc (int*, double*, int*, double*, int*);
void SeulexMASBandedLRMatrixFunc (int*, double*, int*, double*, int*);
void SeulexMASBandedLRCellFunc (int*, double*, int*, double*, int*); 

void SeulexJACFullFunc (int*, double*,double*, double*, int*, double*, int*);
void SeulexJACFullLFunc (int*, double*,double*, double*, int*, double*, int*);
void SeulexJACBandedFunc (int*, double*,double*, double*, int*, double*, int*);
void SeulexJACBandedLFunc (int*, double*,double*, double*, int*, double*, int*); 

static char ismxArrayString (const mxArray *arr) {
  if (arr==NULL) return (char)0;
  if (mxIsChar(arr)) return (char)1;
  return (char)0;
}

static char ismxArrayFunction (const mxArray *arr) {
  if (arr==NULL) return (char)0;
  return (mxGetClassID(arr)==mxFUNCTION_CLASS)?(char)1:(char)0;
}

static char ismxArrayInline (const mxArray *arr) {
  if (arr==NULL) return (char)0;
  return (strcmp(mxGetClassName(arr),"inline")==0)?(char)1:(char)0;
}

static void clearList (PListElement current) {
  PListElement next;
  
  while (current!=NULL) {
    next=current->next;
    if (current->values!=NULL)
      {mxFree(current->values);current->values=NULL;}
    mxFree(current);
    current=next;
  }
}

static void initVars (void) {
  /* Option settings */
  optSet.warnMiss=0;optSet.warnType=1;optSet.warnSize=1;  
  
  /* Parameters for Options */
  paramOpt.opt=NULL;paramOpt.optCreated=0;
  
  /* global parameters */
  paramGlobal.tPointer=NULL;
  
  /* parameters for Seulex */
  paramSeulex.xStart=NULL;
  paramSeulex.RTOL=NULL;paramSeulex.ATOL=NULL;
  paramSeulex.WORK=NULL;paramSeulex.IWORK=NULL;
  paramSeulex.RPAR=NULL;paramSeulex.IPAR=NULL;
  
  /* parameters for RightSide */
  paramRightSide.rightSideFcn=NULL;
  paramRightSide.rightSideFcnH=NULL;
  paramRightSide.tArg=NULL;paramRightSide.xArg=NULL;
  
  /* parameters for massmatrix */
  paramMassmatrix.seulexMASFunc=NULL;
  
  /* parameters for jacobimatrix */
  paramJacobimatrix.seulexJACFunc=NULL;
  paramJacobimatrix.jacFcn=NULL;
  paramJacobimatrix.jacFcnH=NULL;
  paramJacobimatrix.tArg=NULL;paramJacobimatrix.xArg=NULL;
  
  /* parameters for output */
  paramOutput.txList.values=NULL;paramOutput.txList.next=NULL;
  paramOutput.lastTXElement=&paramOutput.txList;
  paramOutput.numberOfElements=0;
  paramOutput.outputFcn=NULL;
  paramOutput.outputFcnH=NULL;
  paramOutput.tArg=NULL;paramOutput.xArg=NULL;
}

static void doneVars (void) {
  /* global parameters */
  /* paramGlobal.tPointer darf nicht entsorgt werden,
     denn er geh�rt dem Aufrufer. */

  /* Parameters for Options */
  if ((paramOpt.optCreated) && (paramOpt.opt!=NULL))
    {mxDestroyArray((mxArray*)paramOpt.opt);paramOpt.opt=NULL;}
     
  /* parameters for Seulex */
  if (paramSeulex.xStart!=NULL)
    {mxFree(paramSeulex.xStart);paramSeulex.xStart=NULL;}
  if (paramSeulex.RTOL!=NULL)
    {mxFree(paramSeulex.RTOL);paramSeulex.RTOL=NULL;}
  if (paramSeulex.ATOL!=NULL)
    {mxFree(paramSeulex.ATOL);paramSeulex.ATOL=NULL;}
  if (paramSeulex.WORK!=NULL)
    {mxFree(paramSeulex.WORK);paramSeulex.WORK=NULL;}
  if (paramSeulex.IWORK!=NULL)
    {mxFree(paramSeulex.IWORK);paramSeulex.IWORK=NULL;}
  if (paramSeulex.RPAR!=NULL)
    {mxFree(paramSeulex.RPAR);paramSeulex.RPAR=NULL;}
  if (paramSeulex.IPAR!=NULL)
    {mxFree(paramSeulex.IPAR);paramSeulex.IPAR=NULL;}
     
  /* parameters for RightSide */
  if (paramRightSide.rightSideFcn!=NULL)
    {mxFree(paramRightSide.rightSideFcn);paramRightSide.rightSideFcn=NULL;}
  paramRightSide.rightSideFcnH=NULL; /* geh�rt Aufrufer => nicht freigeben */
  if (paramRightSide.tArg!=NULL)
    {mxDestroyArray(paramRightSide.tArg);paramRightSide.tArg=NULL;}
  if (paramRightSide.xArg!=NULL)
    {mxDestroyArray(paramRightSide.xArg);paramRightSide.xArg=NULL;}
    
  /* parameters for massmatrix */
  
  /* parameters for jacobimatrix */
  if (paramJacobimatrix.jacFcn!=NULL)
    {mxFree(paramJacobimatrix.jacFcn);paramJacobimatrix.jacFcn=NULL;}
  paramJacobimatrix.jacFcnH=NULL; /* geh�rt Aufrufer => nicht freigeben */
  if (paramJacobimatrix.tArg!=NULL)
    {mxDestroyArray(paramJacobimatrix.tArg);paramJacobimatrix.tArg=NULL;}
  if (paramJacobimatrix.xArg!=NULL)
    {mxDestroyArray(paramJacobimatrix.xArg);paramJacobimatrix.xArg=NULL;}
    
  /* parameters for output */
  clearList(paramOutput.txList.next);paramOutput.txList.next=NULL;
  paramOutput.lastTXElement=&paramOutput.txList;
  if (paramOutput.outputFcn!=NULL)
    {mxFree(paramOutput.outputFcn);paramOutput.outputFcn=NULL;}
  paramOutput.outputFcnH=NULL; /* geh�rt Aufrufer => nicht freigeben */
  if (paramOutput.tArg!=NULL)
    {mxDestroyArray(paramOutput.tArg);paramOutput.tArg=NULL;}
  if (paramOutput.xArg!=NULL)
    {mxDestroyArray(paramOutput.xArg);paramOutput.xArg=NULL;}
}

static void stopMexFunction (int errNo,
  int i1, int i2, int i3, int i4, int i5, double d1) {
  char *msg;
  
  mexPrintf("Error (%i) [Version: %s]:\n",errNo,SEULEXMexVersion);
  mexPrintf("Fehler (%i) [Version: %s]:\n",errNo,SEULEXMexVersion);
  switch (errNo) {
    #include "errors.c"      
    default: msg="unknown error number (Unbekannte Fehlernummer)";break;
  }
  
  doneVars();
  mexErrMsgTxt(msg);
}

static void addTXtoList (double t, double *x) {
  double* dpointer;
  PListElement target;
  
  target=mxMalloc(sizeof(SListElement));
  target->next=NULL;paramOutput.lastTXElement->next=target;
  paramOutput.lastTXElement=target;paramOutput.numberOfElements++;
  target->values=mxMalloc((paramGlobal.d+1)*sizeof(double));
  dpointer=target->values;
  *dpointer=t;dpointer++;
  memcpy(dpointer,x,paramGlobal.d*sizeof(double));
}

static void checkNumberOfArgs (int nlhs, int nrhs) {
  if ((nlhs<2) || (nlhs>4)) stopMexFunction(1,nlhs,0,0,0,0,0);    
    
  if ((nrhs!=3) && (nrhs!=4)) stopMexFunction(2,nrhs,0,0,0,0,0);
}

static void processArgs (int nrhs, const mxArray* prhs[]) {
  int buflen;
  double *dpointer;
  
  /* 1st arg: right side */
  if (ismxArrayString(prhs[0])) {
    if ((mxGetNumberOfDimensions(prhs[0])!=2) || (mxGetM(prhs[0])!=1))
      stopMexFunction(4,mxGetNumberOfDimensions(prhs[0]),mxGetM(prhs[0]),0,0,0,0);
    buflen=mxGetN(prhs[0])*sizeof(mxChar)+1;
    paramRightSide.rightSideFcn=mxMalloc(buflen);
    mxGetString(prhs[0],paramRightSide.rightSideFcn,buflen);
    paramRightSide.rightSideFcnH=prhs[0];
  } else
  if ( (ismxArrayFunction(prhs[0])) || (ismxArrayInline(prhs[0])) ) {
    if ((mxGetNumberOfDimensions(prhs[0])!=2) || (mxGetM(prhs[0])!=1) ||
        (mxGetN(prhs[0])!=1))
      stopMexFunction(19,mxGetNumberOfDimensions(prhs[0]),
                      mxGetM(prhs[0]),mxGetN(prhs[0]),0,0,0);
    paramRightSide.rightSideFcn=NULL; /* kein String */
    paramRightSide.rightSideFcnH=prhs[0];
  } else {
    stopMexFunction(3,0,0,0,0,0,0);
  }
  
  /* 2nd arg: row-vector containing time-values */
  if (!mxIsDouble(prhs[1])) stopMexFunction(5,0,0,0,0,0,0);
  if ((mxGetNumberOfDimensions(prhs[1])!=2) || (mxGetM(prhs[1])!=1))
    stopMexFunction(6,mxGetNumberOfDimensions(prhs[1]),mxGetM(prhs[1]),0,0,0,0);
  paramGlobal.tLength=mxGetN(prhs[1]);
  if (paramGlobal.tLength<2) stopMexFunction(7,0,0,0,0,0,0);
  if (paramGlobal.tLength>2) {
    paramSeulex.denseFlag=1;paramSeulex.IOUT=2;
  } else {
    paramSeulex.denseFlag=0;paramSeulex.IOUT=1;
  }
  dpointer=mxGetPr(prhs[1]);paramGlobal.tPointer=dpointer;
  paramSeulex.tStart=dpointer[0];
  paramSeulex.tEnd=dpointer[paramGlobal.tLength-1];
  if (paramSeulex.tStart==paramSeulex.tEnd) stopMexFunction(20,0,0,0,0,0,0);
  paramGlobal.direction=(paramSeulex.tEnd-paramSeulex.tStart)>0?1.0:-1.0;
  for (buflen=1; buflen<paramGlobal.tLength; buflen++,dpointer++)
    if (paramGlobal.direction*(dpointer[0]-dpointer[1])>0)
      stopMexFunction(14,paramGlobal.direction,0,0,0,0,0);        
  
  /* 3rd arg: start vector */
  if (!mxIsDouble(prhs[2])) stopMexFunction(8,0,0,0,0,0,0);
  if ((mxGetNumberOfDimensions(prhs[2])!=2) || (mxGetN(prhs[2])!=1))
    stopMexFunction(9,mxGetNumberOfDimensions(prhs[2]),mxGetN(prhs[2]),0,0,0,0);
  paramGlobal.d=mxGetM(prhs[2]);
  if (paramGlobal.d<1) stopMexFunction(10,0,0,0,0,0,0);
  dpointer=mxGetPr(prhs[2]);
  paramSeulex.xStart=mxMalloc(paramGlobal.d*sizeof(double));
  memcpy(paramSeulex.xStart,dpointer,paramGlobal.d*sizeof(double));
  /* little remark: A COPY of the startvector is made, because
     it will be passed to Fortran code. To be sure, that
     it will not be changed there, a copy will be passed.
     x0 belongs to the caller and it is not allowed 
     (due to Matlab-Contract) to change it. */
  /* kleine Anmerkung: der Startvektor wird KOPIERT, da er an den 
     Fortran code weitergegeben wird. Um ganz sicher zu gehen,
     dass er nicht ver�ndert wird, wird eine Kopie �bergeben.
     x0 geh�rt ja dem Aufrufer und darf nach Matlab-Konvention
     nicht ver�ndert werden. */

  /* 4th arg: struct with options */
  if (nrhs==4) {
    if (!mxIsStruct(prhs[3])) stopMexFunction(11,0,0,0,0,0,0);
    paramOpt.opt=prhs[3];paramOpt.optCreated=0;
  } else {
    paramOpt.opt=mxCreateStructMatrix(1,1,0,NULL);
    paramOpt.optCreated=1;
  }  
}

static void extractOptionSettings (void) {
  optSet.warnMiss=opt_getIntFromOpt(paramOpt.opt,&optSet,OPT_WARNMISS,0);
  optSet.warnType=opt_getIntFromOpt(paramOpt.opt,&optSet,OPT_WARNTYPE,1);
  optSet.warnSize=opt_getIntFromOpt(paramOpt.opt,&optSet,OPT_WARNSIZE,1);
}

static void extractHandTOLs (void) {
  int m1,n1,m2,n2,res1,res2;
  int takeScalar;
  
  paramSeulex.h=opt_getDoubleFromOpt(paramOpt.opt,&optSet,OPT_INITIALSS,1e-6);
  
  res1=opt_getSizeOfOptField(paramOpt.opt,OPT_RTOL,&m1,&n1);
  res2=opt_getSizeOfOptField(paramOpt.opt,OPT_ATOL,&m2,&n2);
  
  takeScalar=0;
  if (((res1!=0) || (res2!=0)) ||
      ((res1==0) && (m1==1)) ||
      ((res2==0) && (m2==1))) {
    takeScalar=1; 
  }  else {
    if ((n1!=1) || (n2!=1)) takeScalar=1;
    if (m1!=m2) takeScalar=1;
    if (m1!=paramGlobal.d) takeScalar=1;
  }

  if (takeScalar) {
    paramSeulex.RTOL=mxMalloc(1*sizeof(double));
    paramSeulex.ATOL=mxMalloc(1*sizeof(double));
    *paramSeulex.RTOL=opt_getDoubleFromOpt(paramOpt.opt,&optSet,OPT_RTOL,1e-3);
    *paramSeulex.ATOL=opt_getDoubleFromOpt(paramOpt.opt,&optSet,OPT_ATOL,1e-6);
    paramSeulex.ITOL=0;
  } else {
    paramSeulex.RTOL=mxMalloc(paramGlobal.d*sizeof(double));
    paramSeulex.ATOL=mxMalloc(paramGlobal.d*sizeof(double));
    opt_getDoubleVectorFromOpt(paramOpt.opt,&optSet,OPT_RTOL,
      paramGlobal.d,1,paramSeulex.RTOL);
    opt_getDoubleVectorFromOpt(paramOpt.opt,&optSet,OPT_ATOL,
      paramGlobal.d,1,paramSeulex.ATOL);
    paramSeulex.ITOL=1;
  }
}

static void extractOutput (void) {
  mxArray *arr;
  
  if (paramSeulex.denseFlag) {
    paramOutput.includeGrid=opt_getIntFromOpt(paramOpt.opt,&optSet,
      OPT_IGPIDO,0);
  }

  paramOutput.outputFcnH=NULL;paramOutput.outputFcn=NULL;
  arr=mxGetField(paramOpt.opt,0,OPT_OUTPUTFUNCTION);
  if ((arr!=NULL) && (!mxIsEmpty(arr))) {
    if ( (ismxArrayFunction(arr)) || (ismxArrayInline(arr)) ) {
      if ((mxGetNumberOfDimensions(arr)!=2) || (mxGetM(arr)!=1) ||
          (mxGetN(arr)!=1)) 
        stopMexFunction(401,mxGetNumberOfDimensions(arr),
                        mxGetM(arr),mxGetN(arr),0,0,0);
      paramOutput.outputFcnH=arr;
    } else {
      paramOutput.outputFcn=opt_getStringFromOpt(paramOpt.opt,&optSet,
        OPT_OUTPUTFUNCTION,NULL);
      if (paramOutput.outputFcn!=NULL) {
        if (strlen(paramOutput.outputFcn)==0) {
          mxFree(paramOutput.outputFcn);paramOutput.outputFcn=NULL;
        } else {
          paramOutput.outputFcnH=arr;
        }
      }
    }
  }

  paramOutput.outputCallMode=1;
  if ((paramOutput.outputFcnH!=NULL) && (paramSeulex.denseFlag)) {
    paramOutput.outputCallMode=opt_getIntFromOpt(paramOpt.opt,&optSet,
      OPT_OUTPUTCALLMODE,1);
    if ((paramOutput.outputCallMode<1) || (paramOutput.outputCallMode>3))
      paramOutput.outputCallMode=1;
  }
}

static void extractExtrapolParamKM (void) {
  paramSeulex.maxExColumn=opt_getIntFromOpt(paramOpt.opt,&optSet,
    OPT_MAXEXCOLUMN,12);
  if (paramSeulex.maxExColumn<3) stopMexFunction(501,0,0,0,0,0,0);
}

static void extractGlobalOptions (void) {
  paramGlobal.funcCallMethod=opt_getIntFromOpt(paramOpt.opt,&optSet,
    OPT_FUNCCALLMETHOD,1);
  switch (paramGlobal.funcCallMethod) {
    case 0: /* use maxCallMATLAB direct */
      /* rightSide, outputFcn, jacobiFcn testen */
      if (paramRightSide.rightSideFcn==NULL) stopMexFunction(22,0,0,0,0,0,0);
      if ((paramOutput.outputFcnH!=NULL) && (paramOutput.outputFcn==NULL))
        stopMexFunction(23,0,0,0,0,0,0);
      if ((paramJacobimatrix.jacFcnH!=NULL) && 
          (paramJacobimatrix.jacFcn==NULL)) 
        stopMexFunction(24,0,0,0,0,0,0);
      break;
    case 1: /* use maxCallMATLAB to call feval */
      break;
    default:
      stopMexFunction(21,0,0,0,0,0,0);
      break;
  }
}

static void extractRightSideParam (void) {
  int i;
  
  i=opt_getIntFromOpt(paramOpt.opt,&optSet,OPT_ISAUTONOMOUS,0);
  if ((i!=0) && (i!=1)) stopMexFunction(12,i,0,0,0,0,0);
  if (i==0) paramSeulex.IFCN=1; else paramSeulex.IFCN=0;
}

static void extractOptionsPart1 (void) {
  extractOptionSettings();
  extractHandTOLs();
  extractExtrapolParamKM();
  extractRightSideParam();
  extractOutput();  
  /* extractGlobalOptions sp�ter; erst wenn Jacobi-Param eingelesen */
}

static void prepareIWORKArray (void) {
  int i,km,nrdense;

  km=paramSeulex.maxExColumn;  
  
  if (paramSeulex.denseFlag) nrdense=paramGlobal.d;else nrdense=0;
  
  /* IWORK */
  paramSeulex.LIWORK=2*paramGlobal.d+km+20+nrdense;
  paramSeulex.IWORK=mxMalloc(paramSeulex.LIWORK*sizeof(int));
  
  /* Std-Values */
  for (i=1-1; i<=20-1; i++) paramSeulex.IWORK[i]=0;
  
  /* save values we already know */
  paramSeulex.IWORK[3-1]=km;
  paramSeulex.IWORK[6-1]=nrdense;
  if (nrdense>0) {
    for (i=1; i<=nrdense; i++) paramSeulex.IWORK[20+i-1]=i;
  }
}

static void extractIWORKOpt (void) {
  int i,m1,m2;
  
  i=opt_getIntFromOpt(paramOpt.opt,&optSet,OPT_TRANSJTOH,0);
  if ((i!=0) && (i!=1)) stopMexFunction(502,i,0,0,0,0,0);
  paramSeulex.IWORK[1-1]=i;
  
  i=opt_getIntFromOpt(paramOpt.opt,&optSet,OPT_MAXSTEPS,100000);
  if (i<=0) stopMexFunction(503,i,0,0,0,0,0);
  paramSeulex.IWORK[2-1]=i;
  
  /* paramSeulex.IWORK[3-1] wurde schon in prepareIWORKArray gesetzt */
  
  i=opt_getIntFromOpt(paramOpt.opt,&optSet,OPT_STEPSIZESEQUENCE,2);
  if ((i<=0) || (i>=5)) stopMexFunction(504,i,0,0,0,0,0);
  paramSeulex.IWORK[4-1]=i;
  
  i=opt_getIntFromOpt(paramOpt.opt,&optSet,OPT_OUTPUTLAMBDADENSE,0);
  if ((i!=0) && (i!=1)) stopMexFunction(505,i,0,0,0,0,0);
  paramSeulex.IWORK[5-1]=i;
  
  /* paramSeulex.IWORK[6-1] wurde schon in prepareIWORKArray gesetzt */
  
  /* paramSeulex.IWORK[7-1], paramSeulex.IWORK[8-1] momentan ohne Bedeutung */
  
  m1=opt_getIntFromOpt(paramOpt.opt,&optSet,OPT_M1,0);
  m2=opt_getIntFromOpt(paramOpt.opt,&optSet,OPT_M2,0);  
  if ((m1<0) || (m2<0)) stopMexFunction(506,m1,m2,0,0,0,0);
  if (m1+m2>paramGlobal.d) stopMexFunction(507,m1,m2,0,0,0,0);
  if (((m1==0) && (m2!=0)) || ((m1!=0) && (m2==0)))
    stopMexFunction(508,m1,m2,0,0,0,0);
  if (m2!=0) {
    if (m1%m2!=0) stopMexFunction(509,m1,m2,0,0,0,0);
    paramSeulex.mm=m1/m2;
  }  
  paramSeulex.IWORK[9-1]=m1;
  paramSeulex.IWORK[10-1]=m2;
  
  /* paramSeulex.IWORK[21],... wurde schon in prepareIWORKArray gesetzt */
}

static void extractMassMatrix (void) {
  mxArray *mField;
  int m,n,m1,len;
  
  mField=mxGetField(paramOpt.opt,0,OPT_MASSMATRIX);
  m1=paramSeulex.IWORK[9-1];
  
  if ((mField==NULL) || (mxIsEmpty(mField))) {
    /* Massenmatrix=Id */
    paramMassmatrix.IMAS=0;paramMassmatrix.MLMAS=0;
    paramMassmatrix.seulexMASFunc=NULL;
    return;
  }
  
  if (paramSeulex.IWORK[1-1]!=0) stopMexFunction(15,0,0,0,0,0,0);
  paramMassmatrix.IMAS=1; 
  paramMassmatrix.MLMAS=opt_getIntFromOpt(paramOpt.opt,&optSet,
    OPT_MASSLBAND,paramGlobal.d-m1);
  paramMassmatrix.MUMAS=opt_getIntFromOpt(paramOpt.opt,&optSet,
    OPT_MASSUBAND,paramGlobal.d-m1);   
  if ((paramMassmatrix.MLMAS<0) || (paramMassmatrix.MUMAS<0) || 
      (paramMassmatrix.MLMAS>paramGlobal.d-m1) ||
      (paramMassmatrix.MUMAS>paramGlobal.d-m1))
    stopMexFunction(110,paramGlobal.d,m1,0,0,0,0);
    
  if (paramMassmatrix.MLMAS==paramGlobal.d-m1) { 
    /* Massmatrix is full or fullbutlowerright */
    if (!mxIsDouble(mField)) stopMexFunction(101,paramGlobal.d,m1,0,0,0,0);      
    if (mxGetNumberOfDimensions(mField)!=2) stopMexFunction(102,0,0,0,0,0,0);
    m=mxGetM(mField);n=mxGetN(mField);
    if (m!=n) stopMexFunction(103,m,n,0,0,0,0);
    if (m!=paramGlobal.d-m1) stopMexFunction(104,m,m1,0,0,0,0);
    if (m1>0)
      paramMassmatrix.seulexMASFunc=SeulexMASFullLRFunc; else
      paramMassmatrix.seulexMASFunc=SeulexMASFullFunc;
  } else { 
    /* Massmatrix is banded or bandedbutlowerright */
    if ((!mxIsDouble(mField)) && (!mxIsCell(mField)))      
      stopMexFunction(105,paramMassmatrix.MLMAS,m1,0,0,0,0);
    if (m1==0) { 
      /* Massmatrix is banded */
      if (mxIsDouble(mField)) {
        len=1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS;
        if ((mxGetNumberOfDimensions(mField)!=2) ||
            (mxGetM(mField)!=len) || (mxGetN(mField)!=paramGlobal.d))
          stopMexFunction(106,mxGetM(mField),mxGetN(mField),0,0,0,0);            
        paramMassmatrix.seulexMASFunc=SeulexMASBandedMatrixFunc;
      }
      if (mxIsCell(mField)) {
        len=1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS;
        if ((mxGetNumberOfDimensions(mField)!=2) ||
            (mxGetM(mField)!=1) || (mxGetN(mField)!=len))
          stopMexFunction(107,mxGetM(mField),mxGetN(mField),0,0,0,0);
        paramMassmatrix.seulexMASFunc=SeulexMASBandedCellFunc;
      }      
    } else { 
      /* Massmatrix is bandedbutlowerright */
      if (mxIsDouble(mField)) {
        len=1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS;
        if ((mxGetNumberOfDimensions(mField)!=2) ||
            (mxGetM(mField)!=len) || (mxGetN(mField)!=paramGlobal.d-m1))
          stopMexFunction(108,mxGetM(mField),mxGetN(mField),0,0,0,0);
        paramMassmatrix.seulexMASFunc=SeulexMASBandedLRMatrixFunc;
      }
      if (mxIsCell(mField)) {
        len=1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS;
        if ((mxGetNumberOfDimensions(mField)!=2) ||
            (mxGetM(mField)!=1) || (mxGetN(mField)!=len))          
          stopMexFunction(109,mxGetM(mField),mxGetN(mField),0,0,0,0);
        paramMassmatrix.seulexMASFunc=SeulexMASBandedLRCellFunc;
      }
    }
  }
}

static void extractJacobiMatrix (void) {
  int m1,m2;
  int buflen;
  mxArray *arr;

  paramJacobimatrix.jacFcnH=NULL;
  paramJacobimatrix.jacFcn=NULL;

  arr=mxGetField(paramOpt.opt,0,OPT_JACOBIMATRIX);
  if ((arr!=NULL) && (!mxIsEmpty(arr))) {
    if (ismxArrayString(arr)) {
      if ((mxGetNumberOfDimensions(arr)!=2) || (mxGetM(arr)!=1))
        stopMexFunction(225,mxGetNumberOfDimensions(arr),mxGetM(arr),0,0,0,0);
      buflen=mxGetN(arr)*sizeof(mxChar)+1;
      paramJacobimatrix.jacFcn=mxMalloc(buflen);
      mxGetString(arr,paramJacobimatrix.jacFcn,buflen);
      paramJacobimatrix.jacFcnH=arr;
    } else 
    if ( (ismxArrayFunction(arr)) || (ismxArrayInline(arr)) ) {
      if ((mxGetNumberOfDimensions(arr)!=2) || (mxGetM(arr)!=1) ||
          (mxGetN(arr)!=1)) 
        stopMexFunction(226,mxGetNumberOfDimensions(arr),mxGetM(arr),mxGetN(arr),0,0,0);
      paramJacobimatrix.jacFcn=NULL; /* kein String */
      paramJacobimatrix.jacFcnH=arr;
    } else {
      stopMexFunction(227,0,0,0,0,0,0);
    }
  }
  
  m1=paramSeulex.IWORK[9-1];m2=paramSeulex.IWORK[10-1];
  
  paramJacobimatrix.IJAC=(paramJacobimatrix.jacFcnH==NULL)?0:1;
  paramJacobimatrix.MLJAC=opt_getIntFromOpt(paramOpt.opt,&optSet,
    OPT_JACOBILBAND,paramGlobal.d-m1);
  paramJacobimatrix.MUJAC=opt_getIntFromOpt(paramOpt.opt,&optSet,
    OPT_JACOBIUBAND,0);
  
  if ((paramJacobimatrix.MLJAC<0) ||
      (paramJacobimatrix.MUJAC<0) || 
      (paramJacobimatrix.MLJAC>paramGlobal.d-m1) ||
      (paramJacobimatrix.MUJAC>paramGlobal.d-m1))
    stopMexFunction(201,paramGlobal.d,m1,0,0,0,0);  
  
  if (m1>0) {
    if (paramSeulex.IWORK[1-1]!=0) stopMexFunction(16,0,0,0,0,0,0);
    if (paramJacobimatrix.MLJAC==paramGlobal.d-m1) {
      paramJacobimatrix.seulexJACFunc=SeulexJACFullLFunc; 
    } else {      
      if (m1+m2!=paramGlobal.d) stopMexFunction(202,0,0,0,0,0,0);
      if ((paramJacobimatrix.MLJAC>m2) || (paramJacobimatrix.MUJAC>m2))      
        stopMexFunction(203,0,0,0,0,0,0);
      paramJacobimatrix.seulexJACFunc=SeulexJACBandedLFunc;
    }
  } else {
    if (paramJacobimatrix.MLJAC==paramGlobal.d-m1) {
      paramJacobimatrix.seulexJACFunc=SeulexJACFullFunc; 
    } else {
      if (paramSeulex.IWORK[1-1]!=0) stopMexFunction(17,0,0,0,0,0,0);
      paramJacobimatrix.seulexJACFunc=SeulexJACBandedFunc;
    }
  }      
}

static void extractOptionsPart2 (void) {
  extractIWORKOpt();
  extractMassMatrix();
  extractJacobiMatrix();
  if (paramMassmatrix.MLMAS>paramJacobimatrix.MLJAC)
    stopMexFunction(18,paramMassmatrix.MLMAS,paramJacobimatrix.MLJAC,0,0,0,0);
  extractGlobalOptions();
}

static void prepareWORKArray (void) {
  int i,d,km,km2,nrdense,m1;
  int ljac,lmas,le1;
  
  d=paramGlobal.d;
  km=paramSeulex.IWORK[3-1];if (km==0) km=12;
  nrdense=paramSeulex.IWORK[6-1];
  km2=2+km*(int)(ceil(0.5*(km+3)));
  m1=paramSeulex.IWORK[9-1];
  
  if (m1>0) { 
    /* Spezialstruktur */
    /* ljac */
    if (paramJacobimatrix.MLJAC==d-m1) {
      ljac=d-m1; 
    } else {
      ljac=1+paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC;
    }
      
    /* lmas */
    if (paramMassmatrix.IMAS==0) {
      lmas=0; 
    } else {
      if (paramMassmatrix.MLMAS==d-m1) {
        lmas=d-m1; 
      } else {
        lmas=1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS;
      }
    }
    
    /* le1 */
    if (paramJacobimatrix.MLJAC==d-m1) {
      le1=d-m1; 
    } else {
      le1=1+2*paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC;
    }
      
    paramSeulex.LWORK=d*(ljac+km+8)+(d-m1)*(lmas+le1)+4*km+20+km2*nrdense;
    paramSeulex.WORK=mxMalloc(paramSeulex.LWORK*sizeof(double));
  } else { 
    /* keine Spezialstruktor */  
    /* ljac */
    if (paramJacobimatrix.MLJAC==d)  {
      ljac=d; 
    } else {
      ljac=1+paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC;
    }
      
    /* lmas */
    if (paramMassmatrix.IMAS==0) {
      lmas=0; 
    } else {
      if (paramMassmatrix.MLMAS==d) {
        lmas=d; 
      } else  {
        lmas=1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS;
      }
    }
    
    /* le1 */
    if (paramJacobimatrix.MLJAC==d) {
      le1=d; 
    } else {
      le1=1+2*paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC;
    }
      
    paramSeulex.LWORK=d*(ljac+lmas+le1+km+8)+4*km+20+km2*nrdense;
    paramSeulex.WORK=mxMalloc(paramSeulex.LWORK*sizeof(double));
  }    
  
  /* std-Values */
  for (i=1-1; i<=20-1; i++) paramSeulex.WORK[i]=0.0;  
}

static void extractWORKOpt (void) {
  double d;
  
  d=opt_getDoubleFromOpt(paramOpt.opt,&optSet,OPT_EPS,1e-16);
  if (!((d>0.0) && (d<1.0))) stopMexFunction(510,0,0,0,0,0,d);
  paramSeulex.WORK[1-1]=d;
  
  d=opt_getDoubleFromOpt(paramOpt.opt,&optSet,OPT_MAXSS,
    paramSeulex.tEnd-paramSeulex.tStart);
  if (!(d!=0.0)) stopMexFunction(511,0,0,0,0,0,d);
  paramSeulex.WORK[2-1]=d;
  
  d=paramSeulex.RTOL[1-1];
  if (1e-4<d) d=1e-4;
  d=opt_getDoubleFromOpt(paramOpt.opt,&optSet,OPT_JACRECOMPFACTOR,d);
  paramSeulex.WORK[3-1]=d;
  
  d=opt_getDoubleFromOpt(paramOpt.opt,&optSet,OPT_SSSELECTPAR1,0.1);
  if (!(d>0.0)) stopMexFunction(512,0,0,0,0,0,d);
  paramSeulex.WORK[4-1]=d;
  
  d=opt_getDoubleFromOpt(paramOpt.opt,&optSet,OPT_SSSELECTPAR2,4.0);
  if (!(d>0.0)) stopMexFunction(513,0,0,0,0,0,d);
  paramSeulex.WORK[5-1]=d;
  
  d=opt_getDoubleFromOpt(paramOpt.opt,&optSet,OPT_ORDERDECFRAC,0.7);
  if (!(d>0.0)) stopMexFunction(514,0,0,0,0,0,d);
  paramSeulex.WORK[6-1]=d;
  
  d=opt_getDoubleFromOpt(paramOpt.opt,&optSet,OPT_ORDERINCFRAC,0.9);
  if (!(d>0.0)) stopMexFunction(515,0,0,0,0,0,d);
  paramSeulex.WORK[7-1]=d;
  
  d=opt_getDoubleFromOpt(paramOpt.opt,&optSet,OPT_SSSELECTPAR3,0.8);
  if (!(d>0.0)) stopMexFunction(516,0,0,0,0,0,d);
  paramSeulex.WORK[8-1]=d;
  
  d=opt_getDoubleFromOpt(paramOpt.opt,&optSet,OPT_RHO,0.93);
  if (!(d>0.0)) stopMexFunction(517,0,0,0,0,0,d);
  paramSeulex.WORK[9-1]=d;
  
  d=opt_getDoubleFromOpt(paramOpt.opt,&optSet,OPT_WORKFCN,1.0);
  if (!(d>0.0)) stopMexFunction(518,0,0,0,0,0,d);
  paramSeulex.WORK[10-1]=d;
  
  d=opt_getDoubleFromOpt(paramOpt.opt,&optSet,OPT_WORKJAC,5.0);
  if (!(d>0.0)) stopMexFunction(519,0,0,0,0,0,d);
  paramSeulex.WORK[11-1]=d;

  d=opt_getDoubleFromOpt(paramOpt.opt,&optSet,OPT_WORKDEC,1.0);
  if (!(d>0.0)) stopMexFunction(520,0,0,0,0,0,d);
  paramSeulex.WORK[12-1]=d;

  d=opt_getDoubleFromOpt(paramOpt.opt,&optSet,OPT_WORKSOL,1.0);
  if (!(d>0.0)) stopMexFunction(521,0,0,0,0,0,d);
  paramSeulex.WORK[13-1]=d;  
}

static void extractOptionsPart3 (void) {
  extractWORKOpt();
}

static void prepareHelpMxArrays (void) {
  int d;

  d=paramGlobal.d;
  
  paramRightSide.tArg=mxCreateDoubleMatrix(1,1,mxREAL);
  paramRightSide.xArg=mxCreateDoubleMatrix(d,1,mxREAL);

  if ((paramOutput.outputFcnH!=NULL) || (paramSeulex.denseFlag)) {
    paramOutput.tArg=mxCreateDoubleMatrix(1,1,mxREAL);
    paramOutput.xArg=mxCreateDoubleMatrix(paramGlobal.d,1,mxREAL);    
  }

  if (paramJacobimatrix.IJAC!=0) {
    paramJacobimatrix.tArg=mxCreateDoubleMatrix(1,1,mxREAL);
    paramJacobimatrix.xArg=mxCreateDoubleMatrix(d,1,mxREAL);  
  }  
}

static int callOutputFcn (int reason, double t, double *x, int doCopy) {
  int doPoint,erg,offset;
  double *dpointer;
  mxArray* rhs[4];
  mxArray* lhs[1];
    
  if (paramOutput.outputFcnH==NULL) return 0;
  doPoint=0;lhs[0]=NULL;erg=0;
  switch (reason) {
    case 1: /* Init-Fall */
      offset=0;
      switch (paramGlobal.funcCallMethod) {
        case 0: break;
        case 1:
          rhs[offset++]=(mxArray*)paramOutput.outputFcnH;
          break;
        default: stopMexFunction(1002,0,0,0,0,0,0);break;
      }
      rhs[offset]=mxCreateDoubleMatrix(1,2,mxREAL);
      dpointer=mxGetPr(rhs[offset]);
      *dpointer=paramSeulex.tStart;dpointer++;
      *dpointer=paramSeulex.tEnd;
      offset++;
      
      rhs[offset]=mxCreateDoubleMatrix(paramGlobal.d,1,mxREAL);
      memcpy(mxGetPr(rhs[offset]),paramSeulex.xStart,paramGlobal.d*sizeof(double));
      offset++;

      rhs[offset++]=mxCreateString("init");

      switch (paramGlobal.funcCallMethod) {
        case 0:
          mexCallMATLAB(0,lhs,offset,rhs,paramOutput.outputFcn);
          while (--offset>=0) {mxDestroyArray(rhs[offset]);}
          break;
        case 1:
          mexCallMATLAB(0,lhs,offset,rhs,"feval");
          while (--offset>=1) {mxDestroyArray(rhs[offset]);}
          break;
        default: stopMexFunction(1002,0,0,0,0,0,0);break;
      }
      break;
    case 2: /* Done-Fall */
      offset=0;
      switch (paramGlobal.funcCallMethod) {
        case 0: break;
        case 1: 
          rhs[offset++]=(mxArray*)paramOutput.outputFcnH;
          break;
        default: stopMexFunction(1002,0,0,0,0,0,0);break;
      }
      rhs[offset++]=mxCreateDoubleMatrix(0,0,mxREAL);
      rhs[offset++]=mxCreateDoubleMatrix(0,0,mxREAL);
      rhs[offset++]=mxCreateString("done");
      
      switch (paramGlobal.funcCallMethod) {
        case 0:
          mexCallMATLAB(0,lhs,offset,rhs,paramOutput.outputFcn);
          while (--offset>=0) {mxDestroyArray(rhs[offset]);}
          break;
        case 1:
          mexCallMATLAB(0,lhs,offset,rhs,"feval");
          while (--offset>=1) {mxDestroyArray(rhs[offset]);}
          break;
        default: stopMexFunction(1002,0,0,0,0,0,0);break;
      }
      break;
    case 3: /* Neuer Grid-Punkt */
      if ((paramSeulex.denseFlag) && (paramOutput.outputCallMode==1)) break;
      doPoint=1;
      break;
    case 4: /* Neuer dense-Punkt */
      if ((paramSeulex.denseFlag) && (paramOutput.outputCallMode==2)) break;
      doPoint=1;
      break;
    case 5: /* Neuer dense und Grid-Punkt */
      doPoint=1;
      break;
    default: stopMexFunction(1001,0,0,0,0,0,0);
  }
  
  if (doPoint) {
    *mxGetPr(paramOutput.tArg)=t;
    if (doCopy)
      memcpy(mxGetPr(paramOutput.xArg),x,paramGlobal.d*sizeof(double));

    offset=0;
    switch (paramGlobal.funcCallMethod) {
      case 0: break;
      case 1:
        rhs[offset++]=(mxArray*)paramOutput.outputFcnH;
        break;
      default: stopMexFunction(1002,0,0,0,0,0,0);break;
    }
    rhs[offset++]=paramOutput.tArg;rhs[offset++]=paramOutput.xArg;
    
    switch (paramGlobal.funcCallMethod) {
      case 0:
        mexCallMATLAB(1,lhs,offset,rhs,paramOutput.outputFcn);
        break;
      case 1:
        mexCallMATLAB(1,lhs,offset,rhs,"feval");
        break;
      default: stopMexFunction(1002,0,0,0,0,0,0);break;
    }

    if (lhs[0]==NULL) {
      erg=0; 
    } else {
      erg=mxGetScalar(lhs[0]);
      mxDestroyArray(lhs[0]);
    }
  }

  return erg;
}

void SeulexSoloutFunc (int *nr, double *told,
  double *t, double *x, double *rc, int *lrc,
  double *ic, int *lic, int *n, 
  double *rpar, int *ipar, int *irtrn) {
  int i,erg;
  double *dpointer;
  double tdense;
  int alreadySaved;
  
  if (*nr==1) paramOutput.tPos=0;
  
  erg=0;
  if (paramSeulex.denseFlag) {
    alreadySaved=0;
    while (1) {
      if (paramOutput.tPos>=paramGlobal.tLength) break;
      tdense=paramGlobal.tPointer[paramOutput.tPos];
      if (tdense==*t) {
        addTXtoList(*t,x);paramOutput.tPos++;
        alreadySaved=1;
        erg=callOutputFcn(5,*t,x,1);if ((erg!=0) && (erg!=1)) erg=0;
        if (erg==1) {erg=-1;break;} /* Stop, NOW */
        continue;
      }
      if (paramGlobal.direction*(tdense-(*t))>0) break;
      
      dpointer=mxGetPr(paramOutput.xArg);
      
      for (i=1; i<=paramGlobal.d; i++,dpointer++)
        *dpointer=CONTEX_ (&i,&tdense,rc,lrc,ic,lic);
        
      dpointer=mxGetPr(paramOutput.xArg);
      addTXtoList(tdense,dpointer);
      erg=callOutputFcn(4,tdense,dpointer,0);if ((erg!=0) && (erg!=1)) erg=0;
      if (erg==1) {erg=-1;break;} /* Stop, NOW */
      
      paramOutput.tPos++;
    }
    if (!alreadySaved) {
      if (paramOutput.includeGrid) addTXtoList(*t,x);
      erg=callOutputFcn(3,*t,x,1);if ((erg!=0) && (erg!=1)) erg=0;
      if (erg==1) {erg=-1;} /* Stop, NOW */
    }
  } else {
    addTXtoList(*t,x);
    erg=callOutputFcn(3,*t,x,1);if ((erg!=0) && (erg!=1)) erg=0;
    if (erg==1) {erg=-1;} /* Stop, NOW */
  }
  
  *irtrn=erg;  
}

void SeulexRightSideFunc (int *n, double *t,
  double *x, double *f, double *rpar, int *ipar) {
  int i,d,m1,m2,offset;
  mxArray *rhs[3];
  mxArray *lhs[1];
  
  d=*n;lhs[0]=NULL;

  /* Call by value */
  /* Use always the SAME Matlab tArg and xArg */
  /* IMPORTANT NOTICE (if the right side is also a MEX-File)
     the right side must not "garble" the passed mxArrays:
     the size must not be changed and the memory must not
     be freed. 
     Hence: the right side has to take care, that the
     passed mxArrays have the same size and enough memory
     when returning. The values in the memory(-block)
     may be overwritten.
     If the right side is an m-file MATLAB obeys this
     restriction automatically. */
  /* WICHTIGE Anmerkung (falls rechte Seite auch MEX-File ist)
     die rechte Seite darf die �bergebenen mxArrays nicht
     "verst�mmeln": die Gr��e darf nicht ver�ndert werden
     und auch der Speicherplatz darf nicht freigegeben werden.
     Also: die rechte Seite muss sicherstellen, dass die
     �bergebenen mxArrays am Ende wieder diesselbe Gr��e
     und ausreichend Speicher haben. Der Speicher selbst
     darf nat�rlich zu rechenzwecken �berschrieben werden.
     Bei m-Files achtet MATLAB automatisch darauf.
  */
  offset=0;
  switch (paramGlobal.funcCallMethod) {
    case 0: break;
    case 1:
      rhs[offset++]=(mxArray*)paramRightSide.rightSideFcnH;
      break;
    default: stopMexFunction(1002,0,0,0,0,0,0);
  }
  if (paramSeulex.IFCN==1) { 
    /* nicht autonom */
    rhs[offset]=paramRightSide.tArg;
    *mxGetPr(rhs[offset])= *t;
    offset++;
  }
  rhs[offset]=paramRightSide.xArg;
  memcpy(mxGetPr(rhs[offset]),x,d*sizeof(double));
  offset++;

  switch (paramGlobal.funcCallMethod) {
    case 0:
      mexCallMATLAB(1,lhs,offset,rhs,paramRightSide.rightSideFcn);
      break;
    case 1:
      mexCallMATLAB(1,lhs,offset,rhs,"feval");
      break;
    default: stopMexFunction(1002,0,0,0,0,0,0);break;
  }
  
  /* check return values */
  if (lhs[0]==NULL) stopMexFunction(301,0,0,0,0,0,0);
  if ((!mxIsDouble(lhs[0])) || (mxGetNumberOfDimensions(lhs[0])!=2))
    stopMexFunction(302,0,0,0,0,0,0);
  m1=paramSeulex.IWORK[9-1];m2=paramSeulex.IWORK[10-1];
  if (m1==0) { 
    /* keine Spezialstruktur */
    if (!(((mxGetM(lhs[0])==d) && (mxGetN(lhs[0])==1)) ||
          ((mxGetM(lhs[0])==1) && (mxGetN(lhs[0])==d))))
      stopMexFunction(303,mxGetM(lhs[0]),mxGetN(lhs[0]),0,0,0,0);
    
    /* copy back */
    memcpy(f,mxGetPr(lhs[0]),d*sizeof(double));
  } else { 
    /* mit Spezialstruktur */
    if (!(((mxGetM(lhs[0])==d-m1) && (mxGetN(lhs[0])==1)) ||
          ((mxGetM(lhs[0])==1) && (mxGetN(lhs[0])==d-m1))))
      stopMexFunction(304,mxGetM(lhs[0]),mxGetN(lhs[0]),0,0,0,0);  
      
    /* Spezialstruktur eintragen: */
    for (i=0; i<m1; i++,f++) *f=x[i+m2];
    
    /* der Rest */
    memcpy(f,mxGetPr(lhs[0]),(d-m1)*sizeof(double));
  }
  
  /* free memory */
  mxDestroyArray(lhs[0]);    
}

void SeulexMASFullFunc (int *n, double *am,
  int *lmas, double *rpar, int *ipar) {
  int d;
  
  d=paramGlobal.d;

  mxAssert(paramSeulex.IWORK[9-1]==0,"internal error: SeulexMASFullFunc: m1!=0");
  mxAssert(*lmas==d,"internal error: SeulexMASFullFunc: unexpected lmas");

  /* durch extractMassMatrix wurde schon Typ/Dimension/Gr��e �berpr�ft */
  memcpy(am,mxGetPr(mxGetField(paramOpt.opt,0,OPT_MASSMATRIX)),
    d*d*sizeof(double));  
}

void SeulexMASFullLRFunc (int *n, double *am,
  int *lmas, double *rpar, int *ipar) {
  int d,m1,len;
  
  d=paramGlobal.d;m1=paramSeulex.IWORK[9-1];len=d-m1;
  mxAssert(m1!=0,"internal error: SeulexMASFullLRFunc: m1==0");
  mxAssert(*lmas==len,"internal error: SeulexMASFullLRFunc: unexpected lmas");
  
  /* durch extractMassMatrix wurde schon Typ/Dimension/Gr��e �berpr�ft */
  memcpy(am,mxGetPr(mxGetField(paramOpt.opt,0,OPT_MASSMATRIX)),
    len*len*sizeof(double));  
}

void SeulexMASBandedMatrixFunc (int *n, double *am,
  int *lmas, double *rpar, int *ipar) {
  int d,len;
  mxArray *mField;
  
  d=paramGlobal.d;len=1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS;
  mxAssert(paramSeulex.IWORK[9-1]==0,"internal error: SeulexMASBandedMatrixFunc: m1!=0");
  mxAssert(len==*lmas,"internal error: SeulexMASBandedMatrixFunc: enexpected lmas");
    
  mField=mxGetField(paramOpt.opt,0,OPT_MASSMATRIX);
  /* durch extractMassMatrix wurde schon Typ/Dimension/Gr��e �berpr�ft */  
  memcpy(am,mxGetPr(mField),len*d*sizeof(double));  
}

void SeulexMASBandedCellFunc (int *n, double *am,
  int *lmas, double *rpar, int *ipar) {
  int i,j,len;
  double *dpointer;
  mxArray *mField,*cellField;
  
  len=1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS;
  
  mxAssert(paramSeulex.IWORK[9-1]==0,"internal error: SeulexMASBandedCellFunc: m1!=0");
  mxAssert(len==*lmas,"internal error: SeulexMASBandedCellFunc: unexpected lmas");
  
  mField=mxGetField(paramOpt.opt,0,OPT_MASSMATRIX);
  /* durch extractMassMatrix wurde schon Typ/Dimension/Gr��e des cells 
     �berpr�ft, NICHT aber der Typ/Dimension/Gr��e der cell-Eintr�ge */
     
  for (i=paramMassmatrix.MUMAS; i>=-paramMassmatrix.MLMAS; i--) {
    /* ACHTUNG: cells beginnen bei 0 mit der Indizierung */
    cellField=mxGetCell(mField,paramMassmatrix.MUMAS-i); 
    len=paramGlobal.d-abs(i);
    if ((cellField==NULL) || (!mxIsDouble(cellField)) || 
        (mxGetNumberOfDimensions(cellField)!=2))
      stopMexFunction(111,paramMassmatrix.MUMAS-i+1,0,0,0,0,0);
    if ((mxGetM(cellField)!=1) || (mxGetN(cellField)!=len))
      stopMexFunction(112,paramMassmatrix.MUMAS-i+1,
        mxGetM(cellField),mxGetN(cellField),len,0,0);
    dpointer=mxGetPr(cellField);
    for (j=0; j<len; j++,dpointer++)
      am[paramMassmatrix.MUMAS+(j+(i>0?i:0))*(*lmas)-i]= *dpointer;
  }    
}

void SeulexMASBandedLRMatrixFunc (int *n, double *am,
  int *lmas, double *rpar, int *ipar) {
  int d,m1,len;
  mxArray *mField;
  
  d=paramGlobal.d;len=1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS;
  m1=paramSeulex.IWORK[9-1];
  mxAssert(m1!=0,"internal error: SeulexMASBandedMatrixFunc: m1==0");
  mxAssert(len==*lmas,"internal error: SeulexMASBandedMatrixFunc: enexpected lmas");
    
  mField=mxGetField(paramOpt.opt,0,OPT_MASSMATRIX);
  /* durch extractMassMatrix wurde schon Typ/Dimension/Gr��e �berpr�ft */  
  memcpy(am,mxGetPr(mField),len*(d-m1)*sizeof(double));    
}

void SeulexMASBandedLRCellFunc (int *n, double *am,
  int *lmas, double *rpar, int *ipar) {
  int i,j,m1,len;
  double *dpointer;
  mxArray *mField,*cellField;
  
  len=1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS;
  m1=paramSeulex.IWORK[9-1];
  
  mxAssert(m1!=0,"internal error: SeulexMASBandedLRCellFunc: m1==0");
  mxAssert(len==*lmas,"internal error: SeulexMASBandedCellFunc: unexpected lmas");
  
  mField=mxGetField(paramOpt.opt,0,OPT_MASSMATRIX);
  /* durch extractMassMatrix wurde schon Typ/Dimension/Gr��e des cells 
     �berpr�ft, NCIHT aber der Typ/Dimension/Gr��e der cell-Eintr�ge */
     
  for (i=paramMassmatrix.MUMAS; i>=-paramMassmatrix.MLMAS; i--) {
    /* ACHTUNG: cells beginnen bei 0 mit der Indizierung */
    cellField=mxGetCell(mField,paramMassmatrix.MUMAS-i); 
    len=paramGlobal.d-m1-abs(i);
    if ((cellField==NULL) || (!mxIsDouble(cellField)) || 
        (mxGetNumberOfDimensions(cellField)!=2))
      stopMexFunction(113,paramMassmatrix.MUMAS-i+1,0,0,0,0,0);
    if ((mxGetM(cellField)!=1) || (mxGetN(cellField)!=len))
      stopMexFunction(114,paramMassmatrix.MUMAS-i+1,
        mxGetM(cellField),mxGetN(cellField),len,0,0);
    dpointer=mxGetPr(cellField);
    for (j=0; j<len; j++,dpointer++)
      am[paramMassmatrix.MUMAS+(j+(i>0?i:0))*(*lmas)-i]= *dpointer;
  }    
}

void SeulexJACFullFunc (int *n, double *t,
  double *x, double *dfy, int *ldfy, double *rpar, int *ipar) {
  int d,offset;
  mxArray *rhs[3],*lhs[1];

  d=paramGlobal.d;lhs[0]=NULL;  
  
  mxAssert(paramSeulex.IWORK[9-1]==0,"internal error: SeulexJACFullFunc: m1!=0");
  mxAssert(*ldfy==d,"internal error: SeulexJACFullFunc: unexpected ldfy");      
  
  /* Call by value */
  offset=0;
  switch (paramGlobal.funcCallMethod) {
    case 0: break;
    case 1:
      rhs[offset++]=(mxArray*)paramJacobimatrix.jacFcnH;
      break;
    default: stopMexFunction(1002,0,0,0,0,0,0);
  }
  rhs[offset]=paramJacobimatrix.tArg;*mxGetPr(rhs[offset])=*t;
  offset++;

  rhs[offset]=paramJacobimatrix.xArg;
  memcpy(mxGetPr(rhs[offset]),x,d*sizeof(double));
  offset++;
  
  /* Call User's jac function */
  switch (paramGlobal.funcCallMethod) {
    case 0:
      mexCallMATLAB(1,lhs,offset,rhs,paramJacobimatrix.jacFcn);  
      break;
    case 1:
      mexCallMATLAB(1,lhs,offset,rhs,"feval");
      break;
    default: stopMexFunction(1002,0,0,0,0,0,0);
  }
  
  /* check return value */
  if (lhs[0]==NULL) stopMexFunction(204,0,0,0,0,0,0);
  if ((!mxIsDouble(lhs[0])) || (mxGetNumberOfDimensions(lhs[0])!=2))
    stopMexFunction(205,0,0,0,0,0,0);
  if ((mxGetM(lhs[0])!=d) || (mxGetN(lhs[0])!=d))
    stopMexFunction(206,mxGetM(lhs[0]),mxGetN(lhs[0]),0,0,0,0);
  
  /* copy back */
  memcpy(dfy,mxGetPr(lhs[0]),d*d*sizeof(double));
  
  /* free memory */
  mxDestroyArray(lhs[0]);  
}

void SeulexJACFullLFunc (int *n, double *t,
  double *x, double *dfy, int *ldfy, double *rpar, int *ipar) {
  int d,m1,len,offset;
  mxArray *rhs[3],*lhs[1];

  d=paramGlobal.d;m1=paramSeulex.IWORK[9-1];lhs[0]=NULL;  
  len=d-m1;
  mxAssert(m1!=0,"internal error: SeulexJACFullLFunc: m1==0");
  mxAssert(*ldfy==len,"internal error: SeulexJACFullLFunc: unexpected ldfy");
    
  /* Call by value */
  offset=0;
  switch (paramGlobal.funcCallMethod) {
    case 0: break;
    case 1:
      rhs[offset++]=(mxArray*)paramJacobimatrix.jacFcnH;
      break;
    default: stopMexFunction(1002,0,0,0,0,0,0);
  }
  rhs[offset]=paramJacobimatrix.tArg;*mxGetPr(rhs[offset])=*t;
  offset++;

  rhs[offset]=paramJacobimatrix.xArg;
  memcpy(mxGetPr(rhs[offset]),x,d*sizeof(double));
  offset++;
  
  /* Call User's jac function */
  switch (paramGlobal.funcCallMethod) {
    case 0:
      mexCallMATLAB(1,lhs,offset,rhs,paramJacobimatrix.jacFcn);  
      break;
    case 1:
      mexCallMATLAB(1,lhs,offset,rhs,"feval");
      break;
    default: stopMexFunction(1002,0,0,0,0,0,0);
  }
  
  /* check return value */
  if (lhs[0]==NULL) stopMexFunction(204,0,0,0,0,0,0);
  if ((!mxIsDouble(lhs[0])) || (mxGetNumberOfDimensions(lhs[0])!=2))
    stopMexFunction(207,0,0,0,0,0,0);
  if ((mxGetM(lhs[0])!=len) || (mxGetN(lhs[0])!=paramGlobal.d))
    stopMexFunction(208,mxGetM(lhs[0]),mxGetN(lhs[0]),0,0,0,0);

  /* copy back */
  memcpy(dfy,mxGetPr(lhs[0]),len*paramGlobal.d*sizeof(double));
  
  /* free memory */
  mxDestroyArray(lhs[0]);  
}
 
void SeulexJACBandedFunc (int *n, double *t,
  double *x, double *dfy, int *ldfy, double *rpar, int *ipar) {
  int i,j,d,len,offset;
  double *dpointer;
  mxArray *rhs[3],*lhs[1];
  mxArray *cellField;

  d=paramGlobal.d;lhs[0]=NULL;  
  len=paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC+1;
  mxAssert(paramSeulex.IWORK[9-1]==0,"internal error: SeulexJACBandedFunc: m1!=0");
  mxAssert(*ldfy==len,"internal error: SeulexJACBandedFunc: unexpected ldfy");  
  
  /* Call by value */
  offset=0;
  switch (paramGlobal.funcCallMethod) {
    case 0: break;
    case 1:
      rhs[offset++]=(mxArray*)paramJacobimatrix.jacFcnH;
      break;
    default: stopMexFunction(1002,0,0,0,0,0,0);
  }
  rhs[offset]=paramJacobimatrix.tArg;*mxGetPr(rhs[offset])=*t;
  offset++;

  rhs[offset]=paramJacobimatrix.xArg;
  memcpy(mxGetPr(rhs[offset]),x,d*sizeof(double));
  offset++;
  
  /* Call User's jac function */
  switch (paramGlobal.funcCallMethod) {
    case 0:
      mexCallMATLAB(1,lhs,offset,rhs,paramJacobimatrix.jacFcn);  
      break;
    case 1:
      mexCallMATLAB(1,lhs,offset,rhs,"feval");
      break;
    default: stopMexFunction(1002,0,0,0,0,0,0);
  }
  
  /* check return value */
  if (lhs[0]==NULL) stopMexFunction(204,0,0,0,0,0,0);
  if ((!mxIsCell(lhs[0])) && (!mxIsDouble(lhs[0])))
    stopMexFunction(209,0,0,0,0,0,0);
  if (mxIsCell(lhs[0])) {
    if (mxGetNumberOfDimensions(lhs[0])!=2) stopMexFunction(224,0,0,0,0,0,0);
    if ((mxGetM(lhs[0])!=1) || (mxGetN(lhs[0])!=len))
      stopMexFunction(210,mxGetM(lhs[0]),mxGetN(lhs[0]),0,0,0,0);        
    for (i=paramJacobimatrix.MUJAC; i>=-paramJacobimatrix.MLJAC; i--) {
      /* ACHTUNG: cells beginnen bei 0 mit der Indizierung */
      cellField=mxGetCell(lhs[0],paramJacobimatrix.MUJAC-i); 
      len=paramGlobal.d-abs(i);
      if ((cellField==NULL) || (!mxIsDouble(cellField)) || 
          (mxGetNumberOfDimensions(cellField)!=2))
        stopMexFunction(211,paramJacobimatrix.MUJAC-i+1,0,0,0,0,0);
      if ((mxGetM(cellField)!=1) || (mxGetN(cellField)!=len))
        stopMexFunction(212,paramJacobimatrix.MUJAC-i+1,len,
        mxGetM(cellField),mxGetN(cellField),0,0);
      dpointer=mxGetPr(cellField);
      for (j=0; j<len; j++,dpointer++)
        dfy[paramJacobimatrix.MUJAC+(j+(i>0?i:0))*(*ldfy)-i]= *dpointer;
    }
  }
  if (mxIsDouble(lhs[0])) {
    if (mxGetNumberOfDimensions(lhs[0])!=2) stopMexFunction(213,0,0,0,0,0,0);
    if ((mxGetM(lhs[0])!=len) || (mxGetN(lhs[0])!=d))
      stopMexFunction(214,mxGetM(lhs[0]),mxGetN(lhs[0]),0,0,0,0);
    memcpy(dfy,mxGetPr(lhs[0]),len*d*sizeof(double));
  }
    
  /* free memory */
  mxDestroyArray(lhs[0]);  
}

void SeulexJACBandedLFunc (int *n, double *t,
  double *x, double *dfy, int *ldfy, double *rpar, int *ipar) {
  int i,j,k,d,m2,len,offset;
  double *dpointer;
  mxArray *rhs[3],*lhs[1];
  mxArray *cellField,*innerField;
  
  d=paramGlobal.d;lhs[0]=NULL;
  m2=paramSeulex.IWORK[10-1];
  len=paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC+1;
  mxAssert(paramSeulex.IWORK[9-1]!=0,"internal error: SeulexJACBandedLFunc: m1==0");
  mxAssert(*ldfy==len,"internal error: SeulexJACBandedLFunc: unexpected ldfy");
  
  /* Call by value */
  offset=0;
  switch (paramGlobal.funcCallMethod) {
    case 0: break;
    case 1:
      rhs[offset++]=(mxArray*)paramJacobimatrix.jacFcnH;
      break;
    default: stopMexFunction(1002,0,0,0,0,0,0);
  }
  rhs[offset]=paramJacobimatrix.tArg;*mxGetPr(rhs[offset])=*t;
  offset++;

  rhs[offset]=paramJacobimatrix.xArg;
  memcpy(mxGetPr(rhs[offset]),x,d*sizeof(double));
  offset++;
  
  /* Call User's jac function */
  switch (paramGlobal.funcCallMethod) {
    case 0:
      mexCallMATLAB(1,lhs,offset,rhs,paramJacobimatrix.jacFcn);  
      break;
    case 1:
      mexCallMATLAB(1,lhs,offset,rhs,"feval");
      break;
    default: stopMexFunction(1002,0,0,0,0,0,0);
  }
  
  /* check return value */
  if (lhs[0]==NULL) stopMexFunction(204,0,0,0,0,0,0);
  if ((!mxIsCell(lhs[0])) || (mxGetNumberOfDimensions(lhs[0])!=2))
    stopMexFunction(215,0,0,0,0,0,0);
  if ((mxGetM(lhs[0])!=1) || (mxGetN(lhs[0])!=paramSeulex.mm+1))
    stopMexFunction(216,mxGetM(lhs[0]),mxGetN(lhs[0]),0,0,0,0);
  for (k=0; k<paramSeulex.mm+1; k++)
  { /* Schleife �ber alle Teilmatrizen */
    cellField=mxGetCell(lhs[0],k);
    if (cellField==NULL) stopMexFunction(217,k+1,0,0,0,0,0);
    if ((!mxIsDouble(cellField)) && (!mxIsCell(cellField)))
      stopMexFunction(218,k+1,0,0,0,0,0);
    if (mxGetNumberOfDimensions(cellField)!=2) 
      stopMexFunction(219,k+1,0,0,0,0,0);
    if (mxIsDouble(cellField)) { 
      /* diese banded Teilmatrix wird als Matrix �bergeben */
      if ((mxGetM(cellField)!=len) || (mxGetN(cellField)!=m2))
        stopMexFunction(220,k+1,mxGetM(cellField),mxGetN(cellField),0,0,0);
      memcpy(dfy+(k*(*ldfy)*m2),mxGetPr(cellField),len*m2*sizeof(double));
    }
    if (mxIsCell(cellField)) { 
      /* diese banded Teilmatrix wird als cell �bergeben */
      if ((mxGetM(cellField)!=1) || (mxGetN(cellField)!=len))
        stopMexFunction(221,k+1,mxGetM(cellField),mxGetN(cellField),0,0,0);
      for (i=paramJacobimatrix.MUJAC; i>=-paramJacobimatrix.MLJAC; i--) { 
        /* Schleife �ber alle diag-Vektoren */
        innerField=mxGetCell(cellField,paramJacobimatrix.MUJAC-i);
        if ((innerField==NULL) || (!mxIsDouble(innerField)) ||
            (mxGetNumberOfDimensions(innerField)!=2))
          stopMexFunction(222,k+1,paramJacobimatrix.MUJAC-i+1,0,0,0,0);
        len=m2-abs(i);
        if ((mxGetM(innerField)!=1) || (mxGetN(innerField)!=len))
          stopMexFunction(223,k+1,paramJacobimatrix.MUJAC-i+1,len,
          mxGetM(innerField),mxGetN(innerField),0);
        dpointer=mxGetPr(innerField);
        for (j=0; j<len; j++,dpointer++)
          dfy[k*(*ldfy)*m2+paramJacobimatrix.MUJAC+(j+(i>0?i:0))*(*ldfy)-i]= *dpointer;
      }
    }
  }
  
  /* free memory */
  mxDestroyArray(lhs[0]);  
}

static void createTXArrays (mxArray* plhs[]) {
  int i,d,count,n;
  PListElement current;
  double *tPointer, *xPointer, *vPointer;
  
  d=paramGlobal.d;n=paramOutput.numberOfElements;
  plhs[0]=mxCreateDoubleMatrix(n,1,mxREAL);
  plhs[1]=mxCreateDoubleMatrix(n,d,mxREAL);
  
  tPointer=mxGetPr(plhs[0]);
  xPointer=mxGetPr(plhs[1]);
  
  current=paramOutput.txList.next;
  count=0;
  while (current!=NULL) {
    vPointer=current->values;
    *tPointer= *vPointer; tPointer++; vPointer++;
    for (i=0; i<d; i++,vPointer++) xPointer[count+i*n]= *vPointer;
    
    current=current->next;count++;
  }
}

static void createStatVector (mxArray* plhs[]) {
  int i;
  double *dpointer;
  
  plhs[2]=mxCreateDoubleMatrix(1,8,mxREAL);
  dpointer=mxGetPr(plhs[2]);
  
  *dpointer=paramSeulex.IDID;dpointer++;
  for (i=14-1; i<=20-1; i++) {
    *dpointer=paramSeulex.IWORK[i];dpointer++;
  }
}

static void createHPred (mxArray* plhs[]) {
  plhs[3]=mxCreateDoubleMatrix(1,1,mxREAL);
  
  *mxGetPr(plhs[3])=paramSeulex.h;
}

static void createOutput (int nlhs, mxArray* plhs[]) {
  createTXArrays(plhs);
  
  if (nlhs>=3) createStatVector(plhs);
  if (nlhs>=4) createHPred(plhs);
}

void mexFunction (int nlhs, mxArray* plhs[],
                  int nrhs, const mxArray* prhs[]) {
  initVars();
  
  checkNumberOfArgs(nlhs,nrhs);
  processArgs(nrhs,prhs);  
  
  extractOptionsPart1();
  prepareIWORKArray();
  extractOptionsPart2();
  prepareWORKArray();
  extractOptionsPart3();
  prepareHelpMxArrays();

  callOutputFcn(1,0.0,NULL,0);
  SEULEX_ (&paramGlobal.d,&SeulexRightSideFunc,&paramSeulex.IFCN,
  &paramSeulex.tStart,paramSeulex.xStart,&paramSeulex.tEnd, 
  &paramSeulex.h,paramSeulex.RTOL,paramSeulex.ATOL,&paramSeulex.ITOL,
  paramJacobimatrix.seulexJACFunc,
  &paramJacobimatrix.IJAC,&paramJacobimatrix.MLJAC,&paramJacobimatrix.MUJAC,
  paramMassmatrix.seulexMASFunc,
  &paramMassmatrix.IMAS,&paramMassmatrix.MLMAS,&paramMassmatrix.MUMAS,
  &SeulexSoloutFunc,&paramSeulex.IOUT,paramSeulex.WORK,&paramSeulex.LWORK,
  paramSeulex.IWORK,&paramSeulex.LIWORK,paramSeulex.RPAR,paramSeulex.IPAR,
  &paramSeulex.IDID);
  callOutputFcn(2,0.0,NULL,0);
  
  createOutput(nlhs,plhs);

  doneVars();
}
