function defineGraphics
% DEFINEGRAPHICS - create graphic visualization of modeling elements
%

global sys;

sys.graphics.surfaces = [];
if(isempty(sys.graphics.axes) || ~ishandle(sys.graphics.axes))
    createAnimationWindow;
end

%%%%%%%%%%%%%%
% Support    %
%%%%%%%%%%%%%%
h = drawCube([0 0 0.01], 0.15,2.5,0.02,'blue','FaceAlpha',0.3, ...
    'Tag','Support','EdgeColor','blue');
addGraphics('ISYS',h);

%% Unified body representations
% When you are trying to understand how graphic objects are created and
% which commands you can use, please have a look at
% ../double_pendulum/defineGraphics.m
% This section here is a way of ensuring that almost no matter what kind of
% bodies you defined, they will all get reasonable representations. But as
% everything is done automatically, this is a lot more difficult to
% understand than the file mentioned above.
if(isempty(sys.model.body)); return; end
bodynames = fieldnames(sys.model.body);
colors_ = {[1 0 0],[0 0.7 0],[0 0 1],[0.7 0.7 0],[0 0.7 0.7],[0.7 0 0.7], ...
    [0.7 0 0],[0 1 0],[0 0 0.7],[1 1 0],[0 1 1],[1 0 1]};
for h_ = 1:numel(bodynames)
    handles = [];
    if(strcmp(sys.model.body.(bodynames{h_}).type,'rigid'))
        if(strcmp(bodynames{h_},'P3')) % Special part
            handles = [];
            frames = {'P3_1','P3_5'};
            drawLine(frames,bodynames{h_},'Color',colors_{h_},'Linewidth',2);
        else
            % Relative vector between the primary frame and center of gravity
            if(~strncmpi(sys.settings.equation.formulation,'recursive',9))
                mydiff_ = sys.kinematics(sys.model.frame.(bodynames{h_}).idx).handles.r(0,zeros(sys.counters.genCoord,1)) ...
                    - sys.kinematics(sys.model.frame.([bodynames{h_},'_cg']).idx).handles.r(0,zeros(sys.counters.genCoord,1));
            else
                data_ = absolutePositions(0, zeros(sys.counters.genCoord,1));
                mydiff_ = data_.kinematics.(bodynames{h_}).r_abs - data_.kinematics.([bodynames{h_},'_cg']).r_abs;
            end
            if(all(abs(mydiff_)<eps))
                % Create small cuboid
                mylength = 1.6*sys.settings.graphics.frame.size;
                handles = drawCube([0;0;0], mylength,mylength,mylength, ...
                    colors_{h_},'Tag',['Cube_',bodynames{h_}],'EdgeColor',colors_{h_}, ...
                    'FaceAlpha',0.6);
            elseif(mydiff_(1) == 0 && mydiff_(2) == 0)
                % Create cylinder in z-direction and sphere at the end
                mylength = norm(mydiff_);
                if(mylength > eps)
                    handles = zeros(1,2);
                    handles(1) = drawSphere([0 0 0],mylength/15,20,colors_{h_});
                    set(handles(1),'Tag',['Ball_',bodynames{h_}]); hold on;
                    handles(2) = drawRotBody([1 1]*mylength/60,[0 mylength],'Color',colors_{h_});
                    set(handles(2),'Tag',['Rod_',bodynames{h_}]);
                end
            else
                % Create cuboid
                mylength = abs(mydiff_);
                mylength(1) = max(mylength(1), max(mylength)/15);
                mylength(2) = max(mylength(2), max(mylength)/15);
                mylength(3) = max(mylength(3), max(mylength)/15);
                handles = drawCube(0.5*mydiff_, mylength(1),mylength(2),mylength(3), ...
                    colors_{h_},'Tag',['Cube_',bodynames{h_}],'EdgeColor',colors_{h_});
            end
        end
        if(any(~isempty(handles)) && any(ishandle(handles)))
            addGraphics([bodynames{h_},'_cg'],handles);
        end
    elseif(strcmp(sys.model.body.(bodynames{h_}).type,'flex'))
        frames = cell(1,sys.model.sid(sys.model.body.(bodynames{h_}).data.sidIdx).nnodes);
        for g_ = 1 : numel(frames)
            frames{g_} = [bodynames{h_},'_',num2str(g_)];
        end
        drawLine(frames,bodynames{h_},'Color',colors_{h_},'Linewidth',2);
%         drawElasticBeam(bodynames{h_},'Color',colors_{h_},'FaceAlpha',0.4, ...
%             'Sidelengths',sys.graphics.par.frame.size*ones(1,2));
    end
end

% If desired, please adjust the visible area here

% % Update the plot window to a reasonable configuration
% updateGeo(0,zeros(sys.counters.genCoord,1));
% 
% % define Visible area
% axis equal;
% xlim([-0.4 0.4]);
% ylim([-0.4 0.4]);
% zlim([-0.4 0.4]);
% view(30,18);
% 
% % set visibility properties
% setVisibility('on');
plotTrajectories('P1_1','Color',[0 0 1]); plotTrajectories('P1_5','Color',[1 0 0]);
plotTrajectories('P2_1','Color',[0 0 1]); plotTrajectories('P2_5','Color',[1 0 0]);
plotTrajectories('P3_1','Color',[0 0 1]); plotTrajectories('P3_5','Color',[1 0 0]);

%% Subplots
createAnimationWindow('subplot',{2,3,[1,2,4,5]});
% Plot the x-coordinates
createSubplots('yType','genCoord','yVar',sys.parameters.genCoord{6},'subplots',3,'onTheFly',false,'Color',[0 0.7 0],'currentMarker','+');
createSubplots('yType','genCoord','yVar',sys.parameters.genCoord{4},'subplots',3,'onTheFly',true,'Color',[1 0 0],'currentMarker','d');
createSubplots('yType','genCoord','yVar',sys.parameters.genCoord{5},'subplots',3,'onTheFly',true,'Color',[0 0 1],'currentMarker','s');
% Plot the x-positions
createSubplots('yType','kinematic','yVar','Weight3.r(1)','subplots',6,'onTheFly',false,'Color',[0 0.7 0],'currentMarker','+');
createSubplots('yType','kinematic','yVar','Weight1.r(1)','subplots',6,'onTheFly',true,'Color',[1 0 0],'currentMarker','d');
createSubplots('yType','kinematic','yVar','Weight2.r(1)','subplots',6,'onTheFly',true,'Color',[0 0 1],'currentMarker','s');

% END OF defineGraphics
