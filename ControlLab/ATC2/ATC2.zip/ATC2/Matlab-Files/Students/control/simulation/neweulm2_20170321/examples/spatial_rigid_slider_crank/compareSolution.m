% compareSolution

load sys
refSol = load('solution_ramin_masoudi.txt');

fig = figure;
plot(sys.results.timeInt.x,sys.results.timeInt.y(1,:),'k', ...
    refSol(:,1), refSol(:,3),'b')
set(fig,'Name',sprintf('compare solution - Crank angle'));
grid on
legend('neweulm2','solution Ramin Masoudi','location','southeast')
xlabel('Time [s]')
ylabel('Angle [rad]')

fig = figure;
plot(sys.results.timeInt.x,sys.results.timeInt.outControl(1,:),'k', ...
    refSol(:,1),refSol(:,2),'b')
set(fig,'Name',sprintf('compare solution - Slider position'));
grid on;
axis([0 5 0.18 0.315]);
legend('neweulm2','solution Ramin Masoudi');
xlabel('Time [s]')
ylabel('Angle [rad]')

% calculate difference between solutions
resNew(:,1) = sys.results.timeInt.x.';
resNew(:,2) = sys.results.timeInt.outControl(1,:).';
resNew(:,3) = sys.results.timeInt.y(1,:).'; 

new_int = zeros(size(refSol,1),2);

new_int(:,1) = interp1(resNew(:,1),resNew(:,2),refSol(:,1).');
new_int(:,2) = interp1(resNew(:,1),resNew(:,3),refSol(:,1).');

diff = refSol(:,2:3) - new_int;

for a = 1:2
    maxDiff(a) = max(abs(diff(:,a)));
end

printLine(1,'%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%');
printLine(1,'%% Difference between solution by');
printLine(1,'%% neweulm2 and by ramin masoudi');
printLine(1,'%% Slider Position: %e', maxDiff(1));
printLine(1,'%% Crank Angle:     %e', maxDiff(2));
printLine(1,'%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%');