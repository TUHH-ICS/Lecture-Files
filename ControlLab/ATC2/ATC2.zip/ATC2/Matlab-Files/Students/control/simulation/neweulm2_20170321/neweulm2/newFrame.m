% newFrame(varargin) - Create new coordinate system
% 
%  Syntax:
%> newFrame;
%> newFrame('Property', value, ...);
% 
%  Desciption:
% Define a new frame relative to an arbitrary parent frame. Please keep in
% mind, that in RelPos and RelRot are defined relative to the parent frame
% and not the current frame, e.g. the translations take place before the
% rotations.
%
%  Optional parameters, given pairwise:
% Id .............. Identifier of coordinate system {'FRAME1'}
% Name ............ Name of coordinate system 
%                   {'Coordinate system Number 1'}
% Type ............ Type of coordinate system ('' or 'node') {''}
% RefSys .......... Reference system of the coord.-sys. {'ISYS'}
% RelPos .......... Relative positition vector with respect to 
%                   reference system {'[0;0;0]'}
% RelRot .......... Relative rotation angle  {'[0;0;0]'}
%
%  Example:
%> newFrame('Id', 'fancyFrame', 'Name', 'The fanciest frame of all', ...
%>   'RelPos', '[0; 2; z1]', 'RelRot', '[0; pi/4; alpha1]');
%
%  See also:
% newBody, newForceElem, newGenCoord, newConstraint, newSys,
% newInput, newOutput, newConstant, newTimeDependent, newStateDependent,
% newVolume, calcEqMotNonLin
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
