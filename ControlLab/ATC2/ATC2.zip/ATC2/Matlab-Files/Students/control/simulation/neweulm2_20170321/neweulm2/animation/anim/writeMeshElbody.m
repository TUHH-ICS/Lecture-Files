% writeMeshElbody
% ================================================================
% script-name:  writeMeshElbody.m
% purpose:      writes MeshData
% created by:	ihrle
% date: 	21.02.2012
% description:	
% ================================================================
