% contra(t,sol) - Polynominal interpolation
%   Interpolate the polynominal provided by BVPRadau to
%   obtain a smooth solution. 
%
%   Input arguments:
%
%   t ......... Time vector
%   sol ....... Solution structure created with BVPRadau
%
%   Author:    Markus Burkhardt
%
%   e-Mail:    markus.burkhardt@itm.uni-stuttgart.de
%
%   Institute: University of Stuttgart
%              Institute of Engineering and Computational Mechanics
%              Pfaffenwaldring 9
%              70599 Stuttgart
%              Germany
%
%   Date:      2011/10/20 (First appearance)
%
%   See also: BVPRadau
%
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
