% err_ = writeStrFile(tisol, deltat, varargin)
% writeStrFile - write .str file for an animation with anim/...
% If nothing is specified the movement of all bodies is displayed. For this
% the motions of the primary coordinate systems are exported. Then all
% geometric shapes should be attached to them. 
%
% Input arguments
% tisol .... Solution structure of a time integration
% deltat ... Time step size for the animation
%
% Optional input arguments, should be specified in pairs, {default values}
% Filename ............ A filename can be specified {[sys.model.id,'.str']}
% CoordinateSystems ... The coordinate systems whose motion is to be
%                       exported can be specified. 
%                       If 'cg' is passed as value for this option, the
%                       frames in the centers of gravity are exported, if
%                       they exist.
%                       If 'all' is passed as value for this option, all
%                       existing coordinate systems are exported.
%                       An arbitrary list may be specified.
% CheckVarargin ....... An advanced feature to avoid errors if invalid
%                       parameters are passed. This is only if you know
%                       exactly what you are doing. {true}
%
% Return values
% err_ .... If an output parameter is specified, any occuring errors are not
%           thrown immediately, but their message passed back.
%
% Example
%   writeStrFile(sys.results.timeInt, 0.05, 'CoordinateSystems','cg')
% See also: writeAnimGeo, writeGeo2NFF
% 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% File format:
% Creating a .str file for an animation with anim. This contains
% Timestepsize NumberOfTimesteps Format(=12)
% Rotational matrix [c11 c12 c13 c21 ... c33] rx ry xz of body 1, at timestep 1
% Rotational matrix [c11 c12 c13 c21 ... c33] rx ry xz of body 2, at timestep 1
% ...
% Rotational matrix [c11 c12 c13 c21 ... c33] rx ry xz of body n, at timestep 1
% Rotational matrix [c11 c12 c13 c21 ... c33] rx ry xz of body 1, at timestep 2
% ...
% Rotational matrix [c11 c12 c13 c21 ... c33] rx ry xz of body n, at timestep m
%
% First appearance: 30.04.2008
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
