function initOpt
% Initializes the problemdependent parameters and options for the
% optimization

global sys

%% General settings
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Choice of design variables p by the user
sys.settings.opt.p = cell(0); % Creation of an empty cell array
% Initialization of the parameters

sys.settings.opt.p{end+1} = 'm2';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Choice of the method for the optimization or used to calculate the gradient
% 1.) use the result of the time integration, specify criterion 
%     by psiG1 and psiF
% sys.settings.opt.method = 'dir_tog';     % Gradient calculated with the direct method, ODEs inegrated together
sys.settings.opt.method = 'adj_sep';     % Gradient calculated with the adjoint variable method, integrated seperately
% sys.settings.opt.method = 'comparison';  % Comparison of dir_tog and adj_sep
% sys.settings.opt.method = 'finite_diff'; % Gradient calculated with finite differences
% 2.) use the frequency response function in a certain frequency range, 
%     gradient calculated numerically
% sys.settings.opt.method = 'freqRes';     % Frequency response

%% Method specific settings
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.) Options for the method using time integration

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Definition of the function criterion by the user. It has to be a symbolic
% expression or a string.
% psi = G1(t1,y1,z1,p) + \int_{t0} ^{t1} F(t,y,z,Dz,p) dt
% Definition of the part G1, evaluated only at t = t1
sys.settings.opt.psiG1 = '0';

% Definition of the function F, integrated over [t0,t1], F is only the function underneath the integral!
sys.settings.opt.psiF = '0';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initial values for the integration are set in runTimeInt
% Especially for systems with kinematic loops they may depend on the design
% parameters, as they are to be consistent with the constraints. Therefore
% they are stored in sys.settings.opt.initCon, 
% formulated implicit as Phi(x_,p_) = 0; e.g.:
% sys.settings.opt.initCon.pos = [x-2, y-x*sin(alpha)];
% The easiest way to understand them is to have a look at
% the automatically created default values.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Final conditions, must be a scalar function
% Initialization to standard value
% sys.settings.timeInt.finalCond = sym(['t-' mat2str(sys.settings.timeInt.time(end))]); % Use the integration time set in runTimeInt
% Definition of userdefined functions
% sys.settings.timeInt.finalCond = ['(t-' mat2str(sys.settings.timeInt.time(end)) ')*(beta2)'];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initial values for the integration are set in runTimeInt
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 2.) Options for the method using the frequency response matrix

% If you want several different optimizations to be performed in a loop,
% store the corresponding options as a struct array:
% sys.settings.opt(1).frequency = [0.1:0.1:1];
% sys.settings.opt(2).frequency = [1.0:0.1:2];
% If the constraints are a struct array the need the same dimension,
% otherwise always the same are applied
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Vector of frequencies to be considered
sys.settings.opt.frequency = [0.1:0.1:30];
% For the frequency response curves all combinations of inputs and outputs
% are used, both given as cell arrays of their IDs
% sys.settings.opt.in  = {'FPEX'};
% sys.settings.opt.out = {'VP1','VP2','Angle_alpha2'};

% Number of support points of the frequency response curve to be used in
% the optimization
sys.settings.opt.numPts = 20;

% This method requires a given range for each parameter for scaling. If
% nothing is specified, +/- 25 percent of the current values are used
% sys.settings.opt.constr.lb(k) < sys.settings.opt.p{k} < sys.settings.opt.constr.ub(k)
% These ranges are respected as inequality constraints

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Options for all methods

% Definition of constraints for the optimization

% If lb, ub are undefined: Medium-scale Algorithm
% If A, b are undefined: Large-scale Algorithm

% Inequality constraints
% A*p <= b
% Standard choices
% I. All design variables p >= 0
sys.settings.opt.constr.A = -eye(length(sys.settings.opt.p));
sys.settings.opt.constr.b = zeros(length(sys.settings.opt.p),1);

% II. No restrictions
% sys.settings.opt.constr.A = zeros(length(sys.settings.opt.p));
% sys.settings.opt.constr.b = ones(length(sys.settings.opt.p),1);

% III. Undefined / empty
% sys.settings.opt.constr.A = [];
% sys.settings.opt.constr.b = [];

% Free definitions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Equality constraints
% Aeq*p = beq
% I. Undefined / empty
sys.settings.opt.constr.Aeq = [];
sys.settings.opt.constr.beq = [];
% Free definitions

% Lower and upper boundaries for design variables p
% lb <= p <= ub
% I. Undefined / empty: medium-scale
sys.settings.opt.constr.lb = []; % Lower boundary
sys.settings.opt.constr.ub = []; % Upper boundary
% II. Undefined: Large-scale
% sys.settings.opt.constr.lb = -Inf; % Lower boundary
% sys.settings.opt.constr.ub = Inf; % Upper boundary
% III. Free definition
%sys.settings.opt.constr.lb = 0.01; % Lower boundary
%sys.settings.opt.constr.ub = 1000; % Upper boundary

% Nonlinear constraints
sys.settings.opt.constr.nonlcon = [];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Definition of options for the optimization
sys.settings.opt.optimOpts = optimset; % Initialization to empty standard values
sys.settings.opt.optimOpts = optimset(sys.settings.opt.optimOpts, 'GradObj','on'); % Gradient has to be calculated by the user Function
sys.settings.opt.optimOpts = optimset(sys.settings.opt.optimOpts, 'DerivativeCheck','on'); % Checks the derivatives
% sys.settings.opt.optimOpts = optimset(sys.settings.opt.optimOpts, 'GradObj','off'); % Gradient has to be calculated by Matlab
%sys.settings.opt.optimOpts = optimset(sys.settings.opt.optimOpts, 'TolFun','0.001'); % Definition of the tolerance for the function value
sys.settings.opt.optimOpts = optimset(sys.settings.opt.optimOpts, 'MaxIter',300); % Maximum number of iterations
%sys.settings.opt.optimOpts = optimset(sys.settings.opt.optimOpts, 'DerivativeCheck','on'); % Compare calculated gradient with Finite differences

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Definition of tolerances for the integrations in the optimization
% Standard values:
% 'RelTol' = 1e-3
% 'AbsTol' = 1e-6
%Example: sys.settings.opt.integrationTols = odeset('RelTol', 1e-3, 'AbsTol', 1e-6);

% The following line extracts tolerances from the existing options
% structure and neglects everything else
% Adjust Tolerances
% sys.settings.timeInt.intOpts = odeset(sys.settings.timeInt.intOpts, 'RelTol', 1e-6); % Relative tolerances
% sys.settings.timeInt.intOpts = odeset(sys.settings.timeInt.intOpts, 'AbsTol', 1e-8); % Absolute tolerances
% sys.settings.opt.quad_tol = 1e-6; % Tolerance for the integrations with quad, quadv, quadl, default 1e-6;

% All integration options are used in the optimization, so remove here any
% unwanted options!
