% framePlot - Create basic representation for coordinate systems
% 
%  Input parameters:
% id .... Id of the coordinate system
% par ... Parameter structure with lengths, fontsizes, ...
% 
%  Output parameters:
% gh .... Graphics group handle
%
%  See also:
% drawSys, initGraphics, createAnimationWindow
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
