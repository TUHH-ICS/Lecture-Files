#include "neweulSimulation.h"

neweulSimulation::neweulSimulation(const char *fileName)
{
    genCoords = NULL;
    timeVec = NULL;
    double temp;

    hid_t h5FileHandle;
    hid_t h5DataSet;
    hsize_t numDatasets;
    hsize_t i = 0;
    ssize_t strLength;
    int allocSize;

    if (!std::ifstream(fileName))
    {
         char *statusMessage = (char *) calloc(256, sizeof(char));
         sprintf(statusMessage, "Unable to find %s!", fileName);
         free(statusMessage);
         return;
    }
    
    char *grpName = (char *) calloc(256, sizeof(char));

    h5FileHandle = H5Fopen( fileName, H5F_ACC_RDONLY, H5P_DEFAULT );

    if (h5FileHandle<0){
        char *statusMessage = (char *) calloc(256, sizeof(char));
        sprintf(statusMessage, "Unable to open HDF5 file: %s!", fileName);
        free(statusMessage);
        free(grpName);
        return;
    } else {

        /* Get number of objects */
        H5Gget_num_objs(h5FileHandle, &(numDatasets));

        for (i=0; i< numDatasets; i++){

            // Get dataset name
            strLength =  H5Gget_objname_by_idx(h5FileHandle, i, grpName, 256);

            // Cut string
            char *grpName_tmp = (char *) realloc(grpName,strLength+1);
            if (grpName_tmp == NULL) {
                free(grpName);
                return;
            } else {
                grpName = grpName_tmp;
            }

            // Dataset open
            h5DataSet = H5Dopen(h5FileHandle, grpName, H5P_DEFAULT);

            allocSize = (int) H5Dget_storage_size(h5DataSet)/ (int) sizeof(double);

            // read data from HDF5 Datasets
            if (strcmp("genCoords", grpName)==0) {
                if (genCoords==NULL)
                    genCoords = (double *) calloc(allocSize, sizeof(double));
                else
                    genCoords = (double *) realloc(genCoords, allocSize*sizeof(double));

                H5Dread(h5DataSet, H5T_IEEE_F64LE, H5S_ALL, H5S_ALL, H5P_DEFAULT, genCoords);
            } else if (strcmp("timeVec", grpName)==0) {
                if (timeVec==NULL)
                    timeVec = (double *) calloc(allocSize, sizeof(double));
                else
                    timeVec = (double *) realloc(timeVec, allocSize*sizeof(double));
                H5Dread(h5DataSet, H5T_IEEE_F64LE, H5S_ALL, H5S_ALL, H5P_DEFAULT, timeVec);
            } else if (strcmp("stepSize", grpName)==0) {
                if (allocSize==1){
                    H5Dread(h5DataSet, H5T_IEEE_F64LE, H5S_ALL, H5S_ALL, H5P_DEFAULT, &temp);
                    stepSize = temp;
                }
            } else if (strcmp("numOfSamples", grpName)==0) {
                if (allocSize==1){
                    H5Dread(h5DataSet, H5T_IEEE_F64LE, H5S_ALL, H5S_ALL, H5P_DEFAULT, &temp);
                    numOfSamples = (int) temp;
                }
            } else if (strcmp("numGenCoords", grpName)==0) {
                if (allocSize==1){
                    H5Dread(h5DataSet, H5T_IEEE_F64LE, H5S_ALL, H5S_ALL, H5P_DEFAULT, &temp);
                    numGenCoords = (int) temp;
                }
            }

            //Close dataset
            H5Dclose(h5DataSet);

            // Realloc original size
            grpName_tmp = (char *) realloc(grpName,256);
            if (grpName_tmp == NULL) {
                free(grpName);
                return;
            } else {
                grpName = grpName_tmp;
            }

        }
    }

    // Close file
    H5Fclose(h5FileHandle);

    // Free string
    free(grpName);

}

neweulSimulation::~neweulSimulation()
{
    free(genCoords);
    free(timeVec);
}