function D2MHL = f_D2MHL(t,varargin)

D2MHL = 0;
