% [res_, psi_value, opts] = finiteDifferences(myfunc, p0, stepsize, varargin)
% finiteDifferences - Numerically calculates the gradient of myfunc with
% the design parameters p0. For this the finite differences method is
% applied.
% 
% Input arguments:
% 
% myfunc ..... Function handle to the function evaluating the criterion
%              Its function call has to be: psi = myfunc(p0,varargin);
%              psi then is the value of the function criterion
%              p0 the current value of the design parameters and if 
%              any additional input arguments are given, they are passed
%              through to the function criterion myfunc
%
% p0 ......... Numerical values of the design parameters as a vector
%
% stepsize ... Stepsize to be used in the calculation, can be a vector
%              As the result depends strongly on this stepsize, it is
%              advisable to try several stepsizes, because the optimal
%              stepsize depends on the model and the used function
%              criterion. Try several stepsizes to find the range where
%              reasonable results are produced.
%              Even with the simple example function
%               function res = mytest(x)
%               res = 3*x(1)^2 + 2*x(2)^2;
%              and the function call
%               finiteDifferences(@mytest, [1;2])
%              you can see errors occur for different stepsizes.
%              There are basically two possibilities for the definition of
%              this stepsize. It can be defined to be added to the initial
%              value, or to be a change defined as a relative change, like
%              a percentage. As both ways have advantages, in the two
%              'calcMode's both are used, see there for more information.
%              As this value is quite important, there are additional
%              possibilities. When a row vector is given, the same gradient
%              is calculated using the different elements. When a column
%              vector with the same length as p0 is given, it is considered
%              to be different stepsizes for each variable. These two
%              options can be combined to a matrix.
%              Standard values: {[1e-4, 1e-8, 1e-10, 1e-14]}
% 
% Optional input arguments, to be given in argument value pairs. 
% The default values are given in curly brackets {}.
% calcMode ........ Mode of calculation for the finite differences.
%                   Currently there are two possibilities:
% 	'forward': Uses forward differences, if length(p0) = n, this 
%                   calculation mode requires n+1 function evaluations.
%                   Df(x0) = (f(x0 + h) - f(x0)) / h
%   'central': Uses central differences, if length(p0) = n, this
%                	calculation mode requires 2*n function evaluations,
%                   therefore the solution is of a better precision, with
%                   the usual restrictions mentioned above.
%                   Df(x0) = (f(x0+h) - f(x0-h)) / (2*h)  with
%                   default: {'forward'}
% f0 .............. If the function value at the current configuration is
%                   already known, it can be passed with this option,
%                   omitting a recalculation. The algorithm changes
%                   automatically to 'calcMode','forward'. {[]}
% idxArg .......... Calculate the gradient only for these indices of the
%                   input vector p0. All other input values are kept
%                   constant. Can contain indices or be a logical vector
%                   {[1:length(p0)]}
% idxFun .......... Calculate the gradient only for these indices of the
%                   criterion function myfunc. All other values are not
%                   considered. Can contain indices or be a logical vector
%                   {[1:length(myfunc(p0))]}
% critSize ........ Short form of criterionsize. Dimensions of the
%                   criterion function. If not specified and
%                   'calcMode','central' is selected, one evaluation can be
%                   saved. Therefore this option is only necessary, when
%                   evaluations take a long time. {is determined}
% Options ......... Options data structure as returned by a previous run of
%                   finiteDifferences {}
% postArgs ........ Everything passed as argument to this parameter will be
%                   passed through to the criterion function myfunc after
%                   the argument x being used for the gradient {}.
% preArgs ......... Everything passed as argument to this parameter will be
%                   passed through to the criterion function myfunc before
%                   the argument x being used for the gradient {}.
% relPerturb ...... Logical parameter, short form of RelativePerturbation.
%   false: The stepsize is considered to be an absolute perturbation. Then
%                   the function is evaluated at
%                   h = p0 + stepsize
%                   The advantage of this method is, that it always works.
%   true: The stepsize which has been specified is considered to be a
%                   relative change. Then the function is evaluated at
%                   h = p0 * (1+stepsize)
%                   In this case, the user has to ensure, that the initial
%                   values are nonzero, otherwise a division by zero would
%                   occur. But on the other hand, if the elements of p0 have
%                   large differences in their magnitude, this method is
%                   preferable.
%                   The default value is {false}, meaning an absolute
%                   definition.
% Vectorized ...... Flag, that tells if the passed handle is vectorized {false}
%
% Return arguments:
% res_ ............ The gradient of the function is returned, for the
%                   properties
% dimension of function:        n = length(myfunc(p0)) or length(idxFun)
% number of design parameters:  m = length(p0)         or length(idxArg)
% number of stepsize:           p = length(stepsize)
% The result is of the size:    size(res_) = [n, m, p]
% 
% psi_value ....... Function value evaluated at the current configuration.
%                   This is only available for 'calcMode','forward' as
%                   otherwise this value is not calculated
% opts ............ Options data structure
% 
% Author:       Dipl.-Ing. Thomas Kurz
%
% First appearance: 05.12.2008
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
