% createSimulinkLibrary - Create Simulink library of exported system
%
%  Description:
% Create Simulink library with blocks for the  nonlinear and linearized 
% equations of motion. This creates the model 
% sysFunctions/src/MODELID_mdl.mdl, where MODELID represents the Id of the
% current system. The user can then copy the blocks from this model to any
% other simulink model.
%
%  See also: 
% exportSystem2C, compileMatlabCode
%
% First appearance: 25.11.2011
%
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
