function res_ = dampParam(v,d, pc,pr)
% dampParam(v,d, pc,pr)
% Calculate the nonlinear damping ratio as in the function of IB-40,
% page 7, besides Fig. 4
%
% Input arguments:
% v ..... Relative velocity
% d ..... Damping parameter
% pc .... Parameter for the nonlinearity in upper (x>0) part, tension
% pr .... Parameter for the nonlinearity in lower (v<0) part, compression

if(v >= 0)
    % compression
    res_ = d / (1 + pc*v);
else % rebound (v<0)
    res_ = d / (1 - pr*v);
end
