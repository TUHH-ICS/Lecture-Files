% tensor_out = leftSideDivide(matrix,tensor_in)
% leftSideDivide - This function provides the product of an inverted matrix and a 
% third order tensor. 
% 
% Input arguments:
% matrix ....... Square matrix that is supposed to be inverted
% tensor_in .... Three-dimensional array ( stack of matrices tensor_in(i) )
% 
% Output arguments:
% tensor_out ... Three-dimensional array containing a stack of matrices 
%                tensor_out(i) = matrix^(-1)*tensor_in(i);
% 
% See also: tensorTranspose, tensorMultiplication, twoSideDivide
%
% First appearance: 03.10.2010
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
