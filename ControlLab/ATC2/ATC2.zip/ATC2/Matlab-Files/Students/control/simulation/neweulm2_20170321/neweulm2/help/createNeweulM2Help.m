function publishHelp(varargin)
%publishHelp  generate hmtl-help from function help comments and marked-up
%             help files. For the file informations for Neweul-M2 see
%             setNeweulm2HelpTocData
% 
% Input:
%   -'HtmlDir': String {'./html/'}; Directory where the created html-files
%           will be saved to.
%   -'HelpFileDir': String {'./source/'}; Directory where the created
%           html-files will be saved to.
%   -'FunFiles': Cell array of strings {'..'}; Files and/or Directories
%           from which help comments are to be extracted. In the case of
%           directories, all files therein will be used. To recurse into
%           subdirectories the generatepath function can be used.
%           function names can also be given witout file extensions and
%           including packages, i.e. 'package.fun'.
%   -'MaxHeight': Integer {600}; Maximum height of included images in
%           pixels.
%   -'MaxWidth': Integer {800}; Maximum width of included images in pixels.
%  
%   Additionally, all input arguments for funHelp2MarkUp are allowed to
%   modify the help extraction, as they will be passed on to the function.
% 

% Check availability of Java, which is required for the publish function
if(~usejava('jvm'))
    fprintf('\nJava machine is not running. Cannot publish the help.\n');
    return;
end

% % Check in this is a good OS
% if(~isunix)
%     fprintf('\nUnable to publish help because of a non-*nix OS.\n');
%     return;
% end

%% Preparations
initialDir_ = pwd;
cd(fileparts(mfilename('fullpath')));
if(exist('source','dir') == 0)
    mkdir('source');
else
    delete('source/*');
end
% Bugfix 2015-06-05 matlab found html folder on path but not in this directory
if exist('html/*.html','file')
    delete('html/*.html');
else
    mkdir('html');
end

% if(exist('html','dir') == 0)
%     mkdir('html');
% else
%     delete('html/*.html');
% end
copyfile('sourceManual/*','source');

%% Extract help comments

cur_dir = pwd;

footer = sprintf('%s\n', ...
    '%%', ...
    '% <html>', ...
    '%   <hr>', ...
    '%   <p class="copy">&copy; 2013 ITM University of Stuttgart', ...
    '%        <tt class="minicdot">&#149;</tt>', ...
    '%        <a href="http://www.itm.uni-stuttgart.de/research/neweul/">Website</a>', ...
    '%        <tt class="minicdot">&#149;</tt>', ...
    '%        <a href="file:../../../info/README">Read me</a>', ...
    '%   </p>', ...
    '% </html>');

op = inputParser();

op.addParamValue('HtmlDir', './html/');
op.addParamValue('HelpFileDir', './source/');
op.addParamValue('FunFiles', {'../','../animation/','../../examples/'}, @iscellstr);
op.addParamValue('Footer', footer);
op.addParamValue('MaxHeight', 600);
op.addParamValue('MaxWidth', 800);

op.KeepUnmatched = true;

% % Find all m-files of neweulm2
% % Specify all directories > Error
% [status, tmpFiles] = system('find .. -type d | grep -v "/help" | grep -v "modules"');
% if(status ~= 0); error(tmpFiles); end;
% idx_ = [0 strfind(tmpFiles, sprintf('\n'))];
% FunFiles = cell(numel(idx_)-1,1);
% for g_ = 1 : numel(idx_)-1
%     FunFiles{g_} = tmpFiles(idx_(g_)+1 : idx_(g_+1)-1);
% end
% if(exist('../../examples/gettingStarted.m','file') ~= 0)
%     FunFiles{end+1} = '../../examples/';
% elseif(exist('gettingStarted','file') ~= 0)
%     FunFiles{end+1} = fileparts(which('gettingStarted'));
% end
% op.addParamValue('FunFiles', FunFiles);

op.parse( varargin{:} );

cd( op.Results.HtmlDir );
html_dir = pwd;
cd( cur_dir );

cd( op.Results.HelpFileDir );
helpfile_dir = pwd;
cd( cur_dir )

opts = op.Unmatched;
% opts.Source = op.Results.HelpFileDir;
opts.OutputDir = helpfile_dir;
opts.Footer = op.Results.Footer;


% -------------------------------------------------------------------------
% regexp pattern
% regExpPat = struct('head', '^%\s\s(?<head>[^\s].*):\s*', ...
%     'table', ['^%(?<nblank>\s+)(?<prop>[^\s].*)\s\.{3,}\s', ... property
%     '\s*(?<text>[^)][^\s]?.*)$'],  ... cell content
%     'info', ['^%(?<nblank>\s+)' ...
%     '//\s*(?<info_title>[^\s][^:]*):?' ... title line
%     '\s*(?<info_text>[^\s:][^:]*)$'], ... content of title line
%     'source', ['^%(?<nblank>\s*)' ...
%     '>(?<source>.*)$'], ... source code
%     'text', ['^%(?<nblank>\s+)' ...
%     '(?<text>[^\s].*)$']);
% % -------------------------------------------------------------------------
% opts.RegExp = regExpPat;
% opts.SkipPattern = '% First appearance:';
% opts.OutSuffix = '';

% ensure that Files field exists and has the right format
if ~isfield(opts, 'Files') || ~iscell(opts.Files)
    opts.Files = {};
else
    opts.Files = opts.Files(:);
end

for iF_ = 1:length(op.Results.FunFiles)
    fun_ = op.Results.FunFiles{iF_};
    switch exist( fun_ ) %#ok
        case 2
            s_ = which( fun_ );
            opts.Files = [opts.Files; s_];
        case 7
            s_ = what( fun_ );
            for g_ = numel(s_) : -1 : 1
                if(isempty(s_(g_).m))
                    s_(g_) = [];
                else
                    f_ = arrayfun(@(x) [s_(g_).path filesep x{1}], s_(g_).m, ...
                        'UniformOutput', false);
                    opts.Files = [opts.Files; f_];
                end
            end
        otherwise
            fprintf(2, 'Could not find file/directory of:\n\t''%s''\n', fun_);
            fprintf(2, 'Will be skipped!\n');
    end
end

% extract and markup the help comments of the specified m-files
% funHelp2MarkUpNew( opts );
funHelp2MarkUpNeweulm2( opts );
    

%% Generate the html-files from the marked-up help m-files

% go to source directory and get m-files
cd( helpfile_dir )
s = what;


fprintf('Generating the html-helpfiles.\n');
fprintf('\tSource directory:\n\t\t%s\n', pwd);
fprintf('\tOutput directory:\n\t\t%s\n', html_dir);
fprintf('Start publishing.\n\n');


options.format = 'html';
options.outputDir = html_dir;
options.maxHeight = op.Results.MaxHeight;
options.maxWidth = op.Results.MaxWidth;


% call the publish function to produce html-code
for f_ = 1:length(s.m)
    
    if ~isempty(strfind(s.m{f_}, 'example'))
        option.evalCode = true;
    else
        options.evalCode = false;
    end
    fprintf('Starting to publish %s\n', s.m{f_});
    pf_ = publish(s.m{f_}, options);
    
    [tmp_, filename, ext] = fileparts(pf_);
    fprintf('Published ''%s'' to:\n\t%s\n', ...
        s.m{f_}, [filename ext]);
end

fprintf('\nFinished publishing.\n\n')

cd( cur_dir )

%% Create the file helptoc.xml and function_help.m
% Here insert the values for Neweul-M2
createHelpTocs(setNeweulm2HelpTocData);

% Remove temporary m-files
delete('source/*');


%% Build the docsearch database files
% necessary to enable searching in the help browser for the created help
% files
fprintf('Building the search database ...')
builddocsearchdb( html_dir );
fprintf(' done.\n')

% Changing back to initial folder
cd(initialDir_);

