function res_ = f_FV(t,y_,varargin)
% res_ = f_FV(t,y_,varargin)
% f_FV - definition of state-depending user-defined variable FV
% Positions, velocities, ... of coordinate systems can be calculated by
% calling the functions in 'sysFunctions', e.g. body1_r

% res_ = 25000;
% return;

global sys

if(nargin==1 && ischar(t) && strcmp(t,'linearization'))
	% Case IV: Call was f_...('linearization')
	% Return symbolic expression to calculate the linearization
	% Necessary for all parameters appearing in the equations of motion to linearize!
	res_ = sym(0);
	return;
end

% constant user-defined variables

xa_mnsf = sys.parameters.data.xa_mnsf;
xd_mnsf = sys.parameters.data.xd_mnsf;
xa_plsf = sys.parameters.data.xa_plsf;
xd_plsf = sys.parameters.data.xd_plsf;
cf = sys.parameters.data.cf;
% hr = sys.parameters.data.hr;

% relative vector
% ksys1 = str2func('VA_r');
% ksys2 = str2func('KARV_r');
% l0 = sys.parameters.data.l0v;
% r_ = ksys2(t,y_)-ksys1(t,y_);
% r_ = transpose(VA_S(t,y_)) * r_;
% 
% % state dependent user defined functions
% % x = l0 - norm(ksys2(t,y_)-ksys1(t,y_));
% % x = sign(r_(3))*(norm(r_) - l0);
% x = r_(3) - l0;
x = y_(3); % das entspricht zf
res_ = springParam(x, cf, xa_mnsf, xd_mnsf, xa_plsf, xd_plsf);

