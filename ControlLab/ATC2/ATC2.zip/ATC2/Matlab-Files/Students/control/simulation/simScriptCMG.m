clear; close all;

load CMGpend/CMGpendsys.mat
addpath(genpath('CMGpend'),genpath('neweulm2_20170321/neweulm2'));

%% Parameters
q0      = [0;0;0;pi];   % Initial angles
w0      = [45;0;0;.05];   % Initial angular velocities

log     = true;         % Enable (1) or disable (0) logging

Tend    = 100;          % Simulation time


load LPVstab
load LPVswing

%% Running simulation
fprintf('Simulating Dynamics...');

open simCMG_full
sim simCMG_full

fprintf('Done\n');