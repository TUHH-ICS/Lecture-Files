% updateN2DataStructure(isOnlyKinematics)
% Function to check whether all necessary settings
% of neweulm2 are available in the data structure sys. This is mainly due
% to evolutions of the software and not to ensure data integrity for its
% own sake. Therefore not all properties are checked, only those settings
% which have been different in older versions. However, this function still
% fulfills the purpose of ensuring some data integrity.
%
% Input arguments
% isOnlyKinematics ... Logical value which specifies whether only the
%                      kinematics or the complete equations of motion are
%                      to be calculated.
% 
% See also: calcEqMotNonLin
% 
% First appearance: 20.01.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
