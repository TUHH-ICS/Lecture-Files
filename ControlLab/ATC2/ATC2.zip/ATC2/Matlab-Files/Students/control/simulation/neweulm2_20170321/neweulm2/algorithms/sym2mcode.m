% s = sym2mcode(varname,expr,varargin)
% SYM2MCODE - Create m-file code for the evaluation of symbolic
% expressions. Does an initialization of the size first, then assigns the
% necessary expressions. Necessary parameters have to be initialized
% beforehand by other functions, see writeGenCoord.m and writeHelpvarDef.m.
% Zero entries are skipped, symmetric matrices are initialized using this
% property and the Maple codegen optimization can be used.
%
% Input:
% varname ..... Parametername to be used in the function m-file
% expr ........ Symbolic expression
%
% optional Parameters:
% Allocation .. Logical parameter, whether the array shall be allocated
%               {true}
% Append ...... Logical: If true, add to existing vector 'varname' f.e.
%               qa(1) = qa(1) + 2*theta*m_1;
% Language .... String, deciding whether m-code ('m') or C-code ('C')
%               syntax shall be used {'m'}
% PrintAll .... Boolean, that decides whether zeros shall be printed or not
%               {false}
% Optimize .... Create runtime optimized code {true} or false
%               This is done using the Maple 'codegen[optimize]' function
% Size ........ Size of the array {size(expr)}
% startIdx .... Position in the array to start initializing the values
%               {ones(1, ndims(expr))}
% Shift ....... Very similar to startIdx. Just instead of giving the
%               indices of the first element, these values are added.
%               {zeros(1, ndims(expr))}
% Symmetric ... Consider this symbolic matrix to be symmetric. Initialize
%               only half the matrix and copy them to the other half.
%               {false}
% Vector ...... Logical, whether the second Value is a vector {false}
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
