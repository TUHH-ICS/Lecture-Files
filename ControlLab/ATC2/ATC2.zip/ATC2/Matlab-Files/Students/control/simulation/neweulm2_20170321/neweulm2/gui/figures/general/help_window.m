% varargout = help_window(varargin)
% help_window M-file for help_window.fig
%      help_window, by itself, creates a new help_window or raises the existing
%      singleton*.
%
%      H = help_window returns the handle to a new help_window or the handle to
%      the existing singleton*.
%
%      help_window('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in help_window.M with the given input arguments.
%
%      help_window('Property','Value',...) creates a new help_window or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before help_window_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to help_window_OpeningFcn via varargin.
%
% Graphical user interface to display help messages.
% 
% For more information, please open the corresponding window and click on
% the help button, labeled with a question mark "?".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
%
% First appearance: 01.03.2008
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
