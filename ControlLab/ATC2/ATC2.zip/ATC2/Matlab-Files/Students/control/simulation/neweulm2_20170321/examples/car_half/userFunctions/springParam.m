function res_ = springParam(x,c, xam,xdm,xap,xdp)
% springParam(x,c, xam,xdm,xap,xdp)
% Calculate the nonlinear spring stiffness as in the function of IB-40,
% page 7, besides Fig. 3
%
% Input arguments:
% x ..... Effective length of spring, nominal length already subtracted
% c ..... Stiffness parameter, if xam < x < xap, F = c*x
% xam ... Lower (x<0) bound for linear part
% xdm ... Parameter for the nonlinearity in lower (x<0) part, compression
% xap ... Upper (x>0) bound for linear part
% xdp ... Parameter for the nonlinearity in upper (x>0) part, tension

if(isa(x,'sym') || x < xam)
    % Rebound stop x<xam
    res_ = c * ( 1 + ((x-xam)/(xdm-xam))^2 );
elseif(xap < x)
    % Bump stop
    res_ = c * ( 1 + ((x-xap)/(xdp-xap))^2 );
else
    % Linear spring
    res_ = c;
end
