% outputvect = mcode2c(inputvect)
% Converts m-Code to C-Code, which contains several tasks
% - All occurences of the power sign '(a)^i' are replaced by by pow(a,i)
% - All numerical values in the expression are converted to decimal
%   numbers, which represent the data type double in C. This is necessary
%   to avoid numbers to be interpreted as integers, which would result in
%   4.3/2 = 2
% 
% This function accepts different input data types as numerical and
% symbolical expressions and strings. The return value depends on the input
% dimensions. If an array of some type has been passed, a symbolic array
% will be returned. If only one argument has been passed a string is
% returned.
% 
% The first part with the change of the power sign ^ to pow(,) is done in
% two steps. At first the part in front of the power sign is separated into
% the base and the rest which remains unchanged. Then the part after the
% power sign is separated into the exponent and the rest, before
% recomposing the complete expression.
% 
% The second part is done by calling vpa() for each subexpression between
% mathematical operators. Otherwise e.g. a^(1/2) would remain unchanged.
%
% First appearance: 11.03.2008
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
