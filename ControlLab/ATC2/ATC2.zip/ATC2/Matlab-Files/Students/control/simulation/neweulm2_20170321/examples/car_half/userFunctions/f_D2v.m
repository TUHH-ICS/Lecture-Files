function D2v = f_D2v(t)
% f_D2v - definition of 2nd time-derivative of user-defined variable v

global sys;



% constant user-defined variables

c = sys.parameters.data.c;
excitation_phase = sys.parameters.data.excitation_phase;
z = sys.parameters.data.z;


% time dependent user-defined variables

D2v = zeros(1,1);

if(0.1560 < t && t < 0.7560)
    D2v(1) = 0.5*z*cos(c*t+excitation_phase)*c^2;
end
