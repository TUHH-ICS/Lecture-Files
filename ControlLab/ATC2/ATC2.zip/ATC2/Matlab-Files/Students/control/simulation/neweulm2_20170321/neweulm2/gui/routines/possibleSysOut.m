% [outlist, outtype] = possibleSysOut
% possibleSysOut - Create a list of all possible system outputs. Currently
% the following possibilities are offered:
% - generalized coordinates
% - generalized velocities
% - kinematic values of coordinate systems: 
%   r_rel, phi_rel, r, v, a, phi, omega, alpha
% - applied forces
% - reaction forces
% 
% Return values
% outlist ... List of all possible system output variables, passed together
%             with the option 'var' to newSysOut
% outtype ... Corresponding types to all possible system outputs
% 
% For more information, please type ''help newSysOut''
%
% First appearance: 01.07.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
