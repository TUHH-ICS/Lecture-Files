% Linking C and Fortran files
% Different compilers have different conventions:
% If you call a Fortran function "func" from C some compilers
% append an underscore (when compiling the Fortran file).
% Hence you have to append the underscore when calling: "func_".
% Some compilers need "FUNC_" and others "FUNC".

% There are two compile-time switches you can adapt
% the MEX-Interface to your compiler:
%  FORTRANUPP: if set, all Fortran-routines are called with uppercase letters
%  FORTRANNOUNDER: if set, all Fortran-routines are called without a trailing
%                  underscore
% The default: both switches are turned off (i.e. lowercase with underscore)
%
% Example:
% mex -DFORTRANUPP ...
%
if isunix
    mex radauMex.c options.c radau.f dc_lapack.f lapack.f lapackc.f 
else
    % change /MD in mexopts.bat to /MT
    mex -DFORTRANUPP -DFORTRANNOUNDER -c radauMex.c options.c
    % Compile Fortran code outside with ifort
    mex -v radauMex.obj options.obj radau.obj dc_lapack.obj lapack.obj lapackc.obj
end