% compileMatlabCode - Compile matlab and simulink source code
% 
%  Description:
% Compile the source create by exportSystem2C for a fast
% evaluation of the system dynamics.
%
%  Input arguments, given pairwise:
% Debug ........ Using the debug flag {false}
%
%  See also:
% exportSystem2C, createSimulinkLibrary
%
% First appearance: 25.07.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
