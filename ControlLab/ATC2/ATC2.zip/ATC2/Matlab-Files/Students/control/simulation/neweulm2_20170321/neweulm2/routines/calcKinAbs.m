% calcKinAbs(y,Dy,D2y,Yvars_,Yvars_D_,frame)
% calcKinAbs - computes the kinematics of a coordinate system 
% of a system of the type sys.settings.equation.kinematics = 'abs' 
% 
% If this function is used to calculate the kinematics of multibody system
% all kinematic values like position vectors r, velocities v, 
% acclerations a, rotation matrices S, Jacobian matrices J, ...
% are described in the inertial system ISYS. Therefore all values can be
% directly used to be written to the files linked in
% sys.model.frame.(anyFRAME).numkin
% As the calculation of the kinematics was reorganized in
% relativeKinematics and absoluteKinematics, this file was separated to
% keep the possibility of using absolute kinematics.
%
% Input arguments:
% y ........... Symbolic vector of the generalized coordinates
% Dy .......... Symbolic vector of the generalized velocities
% D2y ......... Symbolic vector of the generalized accelerations
% Yvars_ ...... State dependent parameters
% Yvars_D_ .... Derivatives of the state dependent parameters
% frame ....... Id of the coordinate system under consideration
%
% See also: relativeKinematics, absoluteKinematics, recursiveKinematics
%
% First appearance: 20.04.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
