% EDITFORCEELEMENT M-file for EditForceElement.fig
%      EDITFORCEELEMENT, by itself, creates a new EDITFORCEELEMENT or
%      raises the existing singleton*.
%
%      H = EDITFORCEELEMENT returns the handle to a new EDITFORCEELEMENT or
%      the handle to the existing singleton*.
%
%      EDITFORCEELEMENT('CALLBACK',hObject,eventData,handles,...) calls the
%      local function named CALLBACK in EDITFORCEELEMENT.M with the given
%      input arguments.
%
%      EDITFORCEELEMENT('Property','Value',...) creates a new
%      EDITFORCEELEMENT or raises the existing singleton*.  Starting from
%      the left, property value pairs are applied to the GUI before
%      EditForceElement_OpeningFunction gets called.  An unrecognized
%      property name or invalid value makes property application stop.  All
%      inputs are passed to EditForceElement_OpeningFcn via varargin.
%
% Graphical user interface to define or edit force elements.
% 
% For more information, please open the corresponding window and click on
% the help button, labeled with a question mark "?".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
%
% First appearance: 01.07.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
