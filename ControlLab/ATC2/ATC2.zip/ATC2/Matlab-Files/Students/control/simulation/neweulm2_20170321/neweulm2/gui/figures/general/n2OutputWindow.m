% N2OUTPUTWINDOW MATLAB code for n2OutputWindow.fig
% 
% This is a graphical user interface, which can be used to capture or
% display the system output. The corresponding output is created using the
% function n2StatusOutput.
% 
%      N2OUTPUTWINDOW, by itself, creates a new N2OUTPUTWINDOW or raises the existing
%      singleton*.
%
%      H = N2OUTPUTWINDOW returns the handle to a new N2OUTPUTWINDOW or the handle to
%      the existing singleton*.
%
%      N2OUTPUTWINDOW('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in N2OUTPUTWINDOW.M with the given input arguments.
%
%      N2OUTPUTWINDOW('Property','Value',...) creates a new N2OUTPUTWINDOW or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before n2OutputWindow_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to n2OutputWindow_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES, n2StatusOutput, neweulm2
%
% First appearance: 23.04.2012
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
