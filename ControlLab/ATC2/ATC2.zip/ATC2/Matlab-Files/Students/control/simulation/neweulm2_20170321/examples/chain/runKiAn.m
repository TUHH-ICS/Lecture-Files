function runKiAn
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                   %
%                             runKian                               %
%                                                                   %
%                   Do a kinematic analysis                         %
%                                                                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global sys

% Reset storage of prescribed functions
sys.settings.kinematic.genCoords = [];
for h_ = 1 : sys.counters.genCoord
    sys.settings.kinematic.genCoords.(sys.genCoords{h_}) = sym(0);
end

% functions for generalized coordinates
setfun('alpha1','0.5*sin(1/10*pi*t)','beta1','0.5*cos(1/10*pi*t)', ...
    'alpha2','0.5*cos(1/10*pi*t)','beta2','0.5*sin(1/10*pi*t)');

% calculate movement of the bodies
calcMov;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The initial values of the generalized coordinates are initial conditions
% for the root finding for consistent initial conditions
% Use the values from runTimeInt
y0 = sys.settings.timeInt.y0;
% Use different values
% y0(1) = 0;
% y0(2) = 0.01;
% y0(3) = 0.001;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Time interval
% Use the values from runTimeInt
t0 = sys.settings.timeInt.time(1); % Start time t0
t1 = sys.settings.timeInt.time(end); % End time t1
% Use different values
% t0 = 0;
% t1 = 10;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% stepsize for the time
stepsize = 0.1;

% evaluating the equations
sys.results.kinematic = getMov(y0,stepsize,t0,t1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Updating the plot of trajectories
plotTrajectories('','Result',sys.results.kinematic);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% animating kinematik analysis
animTimeInt(sys.results.kinematic,'Stride',0.8);

