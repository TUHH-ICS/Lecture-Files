function DMHV = f_DMHV(t,varargin)

DMHV = 0;
