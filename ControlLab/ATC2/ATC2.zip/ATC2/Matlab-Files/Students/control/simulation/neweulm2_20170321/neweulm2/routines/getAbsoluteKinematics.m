% [result_,commonCSys] = getAbsoluteKinematics(kinematic, frameFrom, frameTo)
% 
% Calculate relative kinematic between frameFrom and frameTo. For this the
% shortest path in the structure of coordinate systems is determined and
% then the values are calculated from relative values only. As the shortest
% path is used, the simplest formulation is in the coordinate system called
% commonCSys, which is the first being in the line of reference systems of
% both systems. If you want to use this function to obtain absolute values,
% simply use 'ISYS' for frameFrom, as this will then automatically be the
% one used for the description.
% 
% The values returned are described in the commonCSys described above. This
% is not always the most intuitive selection. However, this is the one used
% by the algorithm to obtain the values. Therefore this causes the least
% calculation effort and the user can easily transform the values. This is
% shown in the example below.
% 
% The rotation matrix S is a bit special. For example to obtain the
% absolute position vector of frame1, you would call
% getAbsoluteKinematics('r','ISYS','frame1'). However, to obtain the
% absolute rotation matrix of the same frame, the call is
% getAbsoluteKinematics('r','frame1','ISYS'), because this matrix
% transforms vectors from frame1 to ISYS. This may seem strange at first,
% but if you keep the names of the input values frameFrom and frameTo in
% mind, everything is clear.
% 
% Input arguments
% kinematic ... Kinematic value, e.g. 'v' or 'omega'. Available kinematic
%               values are:
%               r, v, omega, S, phi
% frameFrom ... For a relative kinematic value from frame1 to frame2, this
%               would be frame1.
% frameTo ..... For a relative kinematic value from frame1 to frame2, this
%               would be frame2.
% nextFrame ... Logical to omit the first coordinate system frameFrom.
%               This is useful for the calculation of applied forces
%               {false}
% 
% Return arguments
% result_ ...... The requested kinematic value
% commonCSys ... The coordinate system used for the description of the
%                kinematic value.
%
% See also: kardan2rotmat, rotmat2kardan
% 
% Example:
% [r_rel, commonCSys] = getAbsoluteKinematics('r', frame1, frame2);
% Sabs = getAbsoluteKinematics('S', commonCSys, 'ISYS');
% r_relAbs = Sabs * r_rel;
% 
% First appearance: 16.08.2010
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
