% [x,fVal_,exitFlag_,output_,DfVal_] = findroot(myFunc_,x,options,varargin)
% Similar to the function fsolve, this file also searches numerically for
% roots of the function FUN, starting at x. This function also provides
% some options which make the function call easier.
% 
% Input arguments:
% myFunc_ ... Function handle to the function being solved
% x ......... Initial configurations vector
% options ... Structure of options. This is mainly here to make the
%             function call as similar to fsolve as possible.
% Optional input arguments {Standard values}, can be given pairwise in 
% form: 'parameterName', Value; or pairwise in structure format
% absTol ............... Tolerance in the independent variables x to
%                        declare a root {1e-6}
% idxArg ............... If nothing is specified, all entries of x are
%                        used. Here the indices of the entries can be
%                        given. This restricts only the indices of the
%                        input vector x, not the output {1:length(x)}
% idxFun ............... If nothing is specified, all return values of
%                        myFunc_ are used. This allows the selection of
%                        specific elements. Can be used to extract
%                        equations of an overdetermined system of equations
%                        {1:numel(myFunc(...))} 
% Jacobian ............. Specify the Jacobian matrix. As a standard, the
%                        Jacobian is calculated via finite differences.
%                        However, this setting allows the specification of
%                        a function handle, a numerical value or a general
%                        expression in the parameter 'x'. {''}
% MaxIter .............. Maximum number of iterations {8}
% postArgs / preArgs ... The function call to myFunc_ looks like:
%                        myFunc_(preArgs{:}, x, postArgs{:}). So additional
%                        input arguments can be given to myFunc_ {}
% recomputeJacobian .... Logical, if true the jacobian is calculated in
%                        each step {true}
% stepsize ............. Stepsize to calculate the Jacobian Matrix with
%                        finiteDifferences. {1e-4}
% verbose .............. Verbose mode, currently some value between 0 and 4
%                        {0}
% 
% Return values:
% x .................... Configuration vector at the root value
% fVal_ ................ Residual function value, being considered a root
% exitFlag_ ............ Exit flag of the algorithm.
%               1  is considered a success
%               0  Number of iterations exceeded options.MaxIter or number
%                  of function evaluations exceeded options.FunEvals.
%               -5 Algorithm did not start iteration! Bad initial values or
%                  options. 
% output_ .............. Data structure, containing all x, fval_ and Dfval_
% DfVal_ ............... Gradient at the root configuration
% 
% Example
% x = findroot(myFunc_);
% x = findroot(@eqm_nonlin_ss, [sys.settings.timeInt.y0;sys.settings.timeInt.Dy0],'preargs',0);
% See also: calcEqMotNonLin, staticEquilibrium
%
% First appearance: 22.02.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
