% newmarkBeta(odefun,tspan,x0,varargin)
%
% newmarkBeta - The newmark beta method for nonlinear systems in
% state-space form
% 
% Required input arguments
% odefun ............. Function handle returning the acceleration vector
% tspan .............. Column vector containing the time interval
% x0 ................. Initial conditions x0 = [y0; Dy0]
% Optional input arguments (given pairwise):
% Beta ............... Parameter to define the used method (s. below)
% Gamma .............. Parameter to define the used method (s. below)
% MaxIter ............ Number of allowed iterations
% AbsTol ............. Scalar given an error bound for the iteration
%
% Choice of beta and gamma:
% for gamma < 1/2 the method is unstable
% for gamma >= 1/2 & 2*beta <= gamma the method is conditionally stable 
% for gamma >= 1/2 & gamma <= 2*beta the method is unconditionally stable
% 
% For the 
% * explicite Newmark method choose    gamma = 0   & beta = 0
% * midpoint rule choose               gamma = 1/2 & beta = 0
% * Fox-Goodwin method choose          gamma = 1/2 & beta = 1/12
% * linear acceleration method choose  gamma = 1/2 & beta = 1/6 (default)
% * average acceleration method choose gamma = 1/2 & beta = 1/4 (unconditionally stable)
%
% Author:    Dipl.-Ing. Markus Burkhardt
%
% e-Mail:    burkhardt@itm.uni-stuttgart.de
%
% Institute: Universitaet Stuttgart
%            Institut fuer Technische und Numerische Mechanik
%            Pfaffenwaldring 9
%            70597 Stuttgart
%
% First appearance: 03.01.2011
%
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
