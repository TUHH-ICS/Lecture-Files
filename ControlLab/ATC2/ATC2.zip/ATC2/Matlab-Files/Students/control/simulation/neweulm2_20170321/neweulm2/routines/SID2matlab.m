% Function name:    [SID_Data] = SID2matlab(file)
% Purpose:          This function creates a matlab structure of an elastic 
%                   body based on a given SID file. The format of the SID 
%                   file has to follow [SchwertassekWallrapp].
%
% Examples:
% ---------
%   ElasticBody=SID2matlab(fullfile(data_dir,[SID_file_name,'.SID_FEM']))
%
%   Input:  
%   =======
%     file ............. The string file contains the path of the *.SID_FEM 
%                        file that is supposed to be read. 
% 
%   Output:  
%   =======
%     SID_Data ........ (ElBody) reduced elastic body stored in a matlab
%                       structure the matlab structure is described in the 
%                       MOREMBS WIKI.The format of the created structure is
%                       illustrated in the enclosed file named
%                       structure.pdf.
%                 
% Subfunctions contained in this file:
%   [m0, varargout] = create_matrix(fid)
%
% See also SID2matlab>create_matrix, RedElasticBody_to_SID_ASCII
% 
%  MatMorembs   
%  A Toolbox for model reduction of elastic bodies
%  (c) ITM University of Stuttgart, http://www.itm.uni-stuttgart.de
% 
