function D2y = f_D2y(t)
% f_D2y - definition of 2nd time-derivative of user-defined variable y

global sys;



% constant user-defined variables

yAmp = sys.parameters.data.yAmp;
yOmega = sys.parameters.data.yOmega;
D2y = zeros(1,1);

D2y(1) = -1.0*yAmp*yOmega^2*cos(t*yOmega);


% END OF FILE

