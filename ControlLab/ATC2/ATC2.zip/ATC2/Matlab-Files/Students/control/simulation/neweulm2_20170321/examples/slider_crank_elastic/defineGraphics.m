function defineGraphics
% DEFINEGRAPHICS - create graphic visualization of modeling elements
%

% Inertial system
h = drawRotBody([0 0.03 0.03 0],[-0.04 -0.04 0.04 0.04], ...
    'Tag','Bolt_ISYS','FaceColor',[0 0 0.7],'EdgeColor',[0 0 0.7], 'FaceAlpha',0.3);
addGraphics('ISYS',h);

% Graphic representations
drawLine({'Crank_1','Crank_2','Crank_3','Crank_4','Crank_5'},'Crank','Linewidth',2,'Color',[1 0 0]);
drawLine({'Shaft_1','Shaft_2','Shaft_3','Shaft_4','Shaft_5'},'Shaft','Linewidth',2,'Color',[0 0 1]);
plotTrajectories('Slider','LineWidth',1,'Color',[0 0.7 0]);

drawLine({'Crank2_1','Crank2_2','Crank2_3','Crank2_4','Crank2_5'},'Crank2','Linewidth',2,'Color',[1 0 0]);
drawLine({'Shaft2_1','Shaft2_2','Shaft2_3','Shaft2_4','Shaft2_5'},'Shaft2','Linewidth',2,'Color',[0 0 1]);
plotTrajectories('Slider2','LineWidth',1,'Color',[0 0.7 0]);

% View
view(-0.5, 60);

% END OF defineGraphics
