% animTimeInt - animiate the results of a time integration.
%
%  Description: 
% Animiate the results of a time integration. If some view settings of 
% scenes were stored using 'n2CaptureScene' beforehand, this information 
% is used in the animation.
%
%  Mandatory inputs:
% tisol ............... Results of a time integration {sys.results.timeInt}
%
%  Optional Parameters:
% AdjustFigure ........ Boolean, telling if the figure shall be adjusted or
%                       not {false}
% AviObject ........... When recording an animation as .avi file, specify
%                       the handle of what shall be recorded. Usually this
%                       is either the axes or the figure handle
%                       {sys.graphics.gcf}
% CenterCS ............ View is centered to a given coordinate system, the
%                       view is only centered not rotated. When used, this
%                       option should be given to fitCanvas.m as well. The
%                       name of a coordinate system should be passed as an
%                       argument. This setting is stored in the data
%                       structure under sys.settings.graphics. {}
% FileType ............ When printing frames to a folder, you can select
%                       between eps and png files, {eps}
% FPS ................. Instead of giving the Stride factor, with which the
%                       animation time can be scaled, the rate of 
%                       Frames Per Second can be given {[]}
% PlotTrajectories .... Parameter if the trajectories shall be plotted
%                       again. If the second argument is 'animation', the
%                       same stepsize as the animation is used. If the
%                       second argument is 'integration' the integration
%                       stepsize is used. Depending on the system both ways
%                       may be advantageous. If the second parameter is a
%                       boolean true/false, animation with 'animation'
%                       stepsize is switched on or off. {'animation'}
% PreparationOnly ..... Option to quit after the preparation {false}
% PrintFrames ......... Passing this option causes the program to write one
%                       file for every frame of the animation to the folder
%                       specified in the second argument.
% RecordAvi ........... With this option the animation will be stored as a
%                       .avi file. The desired filename should be passed as
%                       an argument. This option disables the calculation
%                       of an optimal step size as an optimal stepsize for
%                       the .avi file cannot be determined so easily
%                       {'myMovie.avi'}
% Resolution .......... This option depends on the option 'PrintFrames'. If
%                       'PrintFrames' is used, this option calculates the
%                       dpi number to be used when printing the frames. In
%                       all other cases, it adjusts the current figure
%                       size. If a two element vector is given, this is
%                       considered as the resolution, e.g. [1024 768]. If
%                       only a scalar is passed, the width is adjusted to
%                       match this aspect ratio, e.g. 4/3. {}
% ScaleColorbar ....... When there is at least one patch object in the
%                       animation window, which uses the cdata property, a
%                       colorbar is very helpful. The parameter
%                       sys.settings.graphics.cdata.autoscale controls, whether
%                       such a scaling is always done. The parameter passed
%                       with this option may have one of the following
%                       values:
%           - true:   adjust colorbar, ignore global setting
%           - false:  do not adjust colorbar, ignore global setting
%           - 'auto': adjust colorbar, store setting
%           - 'none': do not adjust colorbar, store setting {true}
% ScaleElastic ........ For the animation, it may be necessary to scale the
%                       elastic coordinate in order to see the
%                       corresponding deformations. This setting scales
%                       only the elastic coordinates on position level.
%                       This setting is stored in the data structure under
%                       sys.settings.graphics. {1}
% scaleRigid .......... For the animation, it may be necessary to scale not
%                       only the elastic, but also the rigid body
%                       coordinates. This setting scales
%                       only the rigid body coordinates on position level.
%                       This setting is stored in the data structure under
%                       sys.settings.graphics. {1}
% Stride .............. Real time factor. If a value smaller than 1 is
%                       passed, slow motion is produced, e.g. 0.5 is half
%                       the velocity. For all values larger than 1 the
%                       animation runs faster, while 1 results in the
%                       original velocity. This setting is stored in the
%                       data structure under sys.settings.graphics.{1}
% SubplotStepsize ..... As a standard, the subplot curves use the animation
%                       stepsize. This option allows to prescribe a
%                       different stepsize, if not empty {[]}
% Time ................ The time interval of the animation can be
%                       specified, e.g. if the simulation has been started
%                       at a negative value in order to reach an
%                       equilibrium. Default value is the whole integrated
%                       time interval.
% TimeStep ............ Stepsize of the time, if 'Optimal' is passed as an
%                       argument the optimal stepsize is calculated first.
%                       This optimal time stepsize is determined by the
%                       first few time steps with some safety factor on
%                       top. It can still happen, that in some later step
%                       there should be a larger time step size. Then this
%                       optimal stepsize could be used as a first guess.
%                       This setting is stored in the data structure under
%                       sys.settings.graphics. {'Optimal'}
% CheckVarargin ....... An advanced feature to avoid errors if invalid
%                       parameters are passed. This is only if you know
%                       exactly what you are doing. {true}
%
%  Example:
%   animTimeInt(sys.results.timeInt, 'TimeStep','Optimal', 'Stride',1);
%   animTimeInt(sys.results.timeInt, 'TimeStep',1e-2, 'Stride',0.1, ...
%     'Record_avi','test.avi');
%   animTimeInt(sys.results.timeInt, ...
%     'Printframes',pwd, ...
%     'TimeStep',0.04,'Resolution',[1024 768],'FileType','png');
%
%  See also:
% animModeShape, n2CaptureScene, plotTrajectories, updateGeo
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
