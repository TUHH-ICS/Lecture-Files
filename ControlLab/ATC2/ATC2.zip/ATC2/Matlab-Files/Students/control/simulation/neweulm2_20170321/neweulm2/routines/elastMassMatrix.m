% res_ = elastMassMatrix(body,y_elast)
% compute the mass matrix of a flexible body, which consists of a constant
% and a state-dependent matrix. This function has several different
% applications, which are triggered by a different number of return
% arguments.
% 
% Input arguments:
% body ...... ID of the body under consideration
% y_elast ... Symbolic/Numeric vector of the elastic degrees of freedom of this
%             body
% 
% Return arguments:
% M_elast ... contains the mass matrix of the elastic body. This matrix 
%             can be used as a symbolic or numeric expression depending 
%             on the data type of the input argument y_elast.
%
% See also: calcFlexForces, calcEqMotNonLin, createInertia, computeHomega
% 
% First appearance: 18.05.2011 
%                   (As individual function, was a subfunction before)
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
