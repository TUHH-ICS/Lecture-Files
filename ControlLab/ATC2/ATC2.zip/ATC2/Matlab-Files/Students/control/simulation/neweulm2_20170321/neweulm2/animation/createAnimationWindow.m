% createAnimationWindow - create Neweulm2 animation window
%
%  Description:
% This function creates an animation window and initializes all previously
% defined graphical objects
% 
%  Optional Parameters, given pairwise:
% none defined yet
% Axes ............ Specify the axes which shall be used {[]}
% CameraUpVector .. Specify a numerical vector which points upwards. This
%                   vector is used as the corresponding axes property. As a
%                   standard, the opposite to the gravity vector is used.
%                   {-sys.model.gravity}
% ClearWindow ..... Show only the model, no axes, no background, no grid
%                   {false}
% DrawCS .......... create a graphic representation for each coordinate
%                   system {true}
% Subplot ......... The animation window can use subplots. Then specify the
%                   location of the animation as described at the command
%                   'subplot', e.g. {3,2,[1,2,4,5]}, so that the command
%                   can be called as subplot(varargin{2}{:}) {[]}
%
%  Example
%   createAnimationWindow;
%
%  See also:
% initGraphics, drawSys, setVisibility, plotTrajectories,
% addGraphics, drawLine, drawCube, drawRotBody, drawSphere, drawSTL
%
% First appearance: 19.05.2009
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
