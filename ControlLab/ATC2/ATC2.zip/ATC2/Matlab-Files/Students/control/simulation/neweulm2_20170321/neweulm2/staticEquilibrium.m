% staticEquilibrium - Calculate the static equilibrium of the system, using
% the fsolve algorithm
% 
%  Syntax:
%> [ye,res] = staticEquilibrium(t,ys, Options, varargin);
% 
%  Input parameters:
% t ......... Time, {0}
% ys ........ Start value for the root finding, {zeros(sys.counters.genCoord,1)}
% options ... Options structure for the fsolve algorithm
%             {optimset('MaxIter',1e3, 'MaxFunEvals',1e3*(sys.counters.genCoord))}
% 
%  Optional Parameters, given pairwise:
% fsolve .... Logical, whether to use the new manually implemented version,
%             or the older one, which uses fsolve {false}
% 
%  Output parameters:
% ye .... Position vector of the static equilibrium, if errors occur the
%         initial guess may be returned
% res ... The residual at ye, should be zeros
% 
% For systems with kinematic loops the lagrangian multipliers lambda are
% also necessary. But they are handled only internally, the in- and output
% parameters ys and ye are of the dimension of the degrees of freedom.
%
%  See also:
%   timeInt
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
