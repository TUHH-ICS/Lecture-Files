% modifyConstant(varargin) - modify constant parameters
%
%  Syntax:
%> modifyConstant
%> modifyConstant('Property', value, ...);
%     
%  Desciption: 
% Modify symbolic value defined by the function newConstant.
%
%
%  Optional parameters: 
% Either parameter names as strings or followed by their numerical values
%
% There are some parameter names, which are reserved, but this function
% issues warnings in these cases:
% g ......... Is created automatically to represent the gravitational constant
% t ......... Is reserved for the time
% [...]_s ... Names ending on '_s' are reserved for set values for
%             generalized coordinates, it can cause problems it they are
%             used as regular parameter names. As the set values are
%             necessary for every generalized coordinate (e.g. x) and its
%             first and second time derivative denoted with a leading 'D'
%             or 'D2' (e.g. Dx, D2x) these are also reserved.
% D[...] .... Reserved for first time derivatives of set values and time
%             dependent parameters.
% D2[...] ... Reserved for second time derivatives of set values and time
%             dependent parameters.
% [...]_ .... Names ending on an underscore '_' may cause problems as
%             internally used names always end on an underscore.
%
%  Examples:
% change the value of the  parameter 'VarName1' to 2:
%> modifyConstant('VarName1',2);
% change the numerical values of the two parameters 'VarName1' and 
%   'VarName2' to 2 and 3, respectively:
%> modifyConstant('VarName1',2,'VarName2',3);
% change the values the entries of the cell array to the defined values 
% in the numerical array given with the second parameter:
%> newConstant({cell array},[numerical array]);
%
%  See also: newBody, newForceElem, newGenCoord, newFrame, newConstraint,
%   newSys, newInput, newOutput, newTimeDependent, newStateDependent,
%   newVolume, calcEqMotNonLin
%
% First appearance: 01.04.2013
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
