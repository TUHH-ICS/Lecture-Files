% drawConnection(ye_,cnnames_,varargin)
%
% Input arguments
% ye_ ... 		  f x nsteps matrix containing the generalized coordinates
%			  of all bodies in the system. Each column represents one step.
% cnnames_ ... 		  cell array containing the names of the coordinate systems which should be connected
%			  
% Optional input arguments, should be specified in pairs, {default values}
% 'numpoints' ............ number of points used to draw the cylinder
% 'radius' ............ radius of the cylinder
%
%
% Example function calls:
% drawConnection(ye_,{'frame1','frame2'});
