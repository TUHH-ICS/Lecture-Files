function newVolume(varargin)
% newVolume(varargin) - create a new volume element
% 
%  Syntax:
%> newVolume;
%> newVolume(varargin);
%  
%  Optional Parameters, given pairwise:
% Id .............. Identifier of the volume element {'ELEMENT_1'}
% Name ............ Name of the element {'Element Number 1'}
% Type ............ Type of element {'Volume'}
% FrameSurf ........ Coordinate systems marking the outer planes of the
%                   volume {''}
% DirDef .......... Coordinate systems which define the force directions,
%                   in contrast to the force element, each coordinate
%                   system can have its own DirDef system. {''}
% RefArea ......... Reference areas, belonging to neighboring masses {''}
% Vdamp ........... Damping of volume element {[0 0 0]}
% Vinf ............ Inverse volume of the complete element {0}
% pin ............. Static pressure difference {0}
% p0 .............. Static nominal pressure to define the working point of
%                   the pressure change calculation {101300} [Pa]
% kappa ........... Parameter for the gas law, called 'Heat capacity ratio'
%                   or 'adiabatic index' or 'ratio of specific heats' 
%                   {1.4} for air
% dp .............. Pressure change resulting from displacement of the
%                   boundary surfaces of the element {[]}
% DV .............. Change of volume over the time depending on the
%                   velocities of the boundary surfaces for the calculation
%                   of gas damping. {[]}
%
%  See also: 
% newBody, newForceElem, newGenCoord, newFrame, newConstraint,
% newSys, newInput, newOutput, newConstant, newTimeDependent,
% newStateDependent, calcEqMotNonLin
%
% First appearance: 09.04.2009
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de

global sys;

numElements = 0;
if(~isempty(sys.model.other))
    numElements = length(fieldnames(sys.model.other));
end
% Create data structure
element.id = [];        % Identifier
element.name = [];      % Name
element.idx = [];       % Index
element.type = [];      % Type

element.framesurf = {};  % Coordinate systems of the boundary surfaces
element.dirdef = {};    % Definition of force directions
element.refarea = [];   % Reference surfaces
element.vdamp = [];     % Damping of volume element

element.vinf = [];      % Inverse of total volume
element.pin = [];       % Static pressure difference
element.p0 = [];        % Static nominal pressure, defining the working point
element.kappa = [];     % Heat capacity ratio

element.dp = [];        % Dynamic pressure change
element.DV = [];        % Dynamic volume change

% Set default values
element.id       = ['ELEMENT_',num2str(numElements+1)];
element.name     = ['Element number ',num2str(numElements+1)];
element.type     = 'Volume';

element.vinf     = 0;
element.pin      = 0;
element.p0       = 101300;      % [Pa], air pressure 1013 mbar
element.kappa    = 1.4;         % Kappa for Air
element.vdamp    = [0, 0, 0];

if(floor(nargin/2) ~= ceil(nargin/2))
    warning('Possible mistake: Odd number (%d) of input arguments passed to %s, ignoring last one!',nargin, mfilename);
end

% read optional parameters and overwrite default values
for h_ = 2 : 2 : length(varargin)
    switch regexprep(lower(varargin{h_-1}),'[ _-]','')
        case 'id'
            % Check if id is valid
            if(~isvarname(varargin{h_}))
                error('ID has to be a valid variable name, as it is used as fieldname of a structure, see ''isvarname.m''!');
            end
            % Create id
            element.id = varargin{h_};
        case 'name'
            element.name = varargin{h_};
        case 'type'
            element.type = varargin{h_};
        case {'framesurf','ksyssurf'}
            element.framesurf = varargin{h_};
       case 'dirdef'
            element.dirdef = varargin{h_}; 
        case 'refarea'
            element.refarea = sym(varargin{h_});
        case 'vdamp'
            element.vdamp = sym(varargin{h_});
        case 'vinf'
            element.vinf = sym(varargin{h_});
        case 'pin'
            element.pin = sym(varargin{h_});
        case {'p0','pO'} % zero and letter O to avoid strange behavior
            element.p0 = sym(varargin{h_});            
        case 'kappa'
            element.kappa = sym(varargin{h_});
        otherwise
            error('Unknown Option ''%s''!',any2str(varargin{h_-1}));
    end
end

% Check whether the id is unique
if(isfield(sys.model.other,element.id))
    error('The given Id ''%s'' is already occupied!',element.id);
end

% Check if all coordinate systems belong to a body, otherwise it wouldn't
% make much sense
for h_ = 1:length(element.framesurf)
    if(~isfield(sys.model.frame, element.framesurf{h_}))
        warning('Possible mistake while creating volume element ''%s''! Coordinate system ''%s'' does not exist yet!', element.id, element.framesurf{h_});
    elseif(isempty(sys.model.frame.(element.framesurf{h_}).body))
        warning('Possible mistake while creating volume element ''%s''! Coordinate system ''%s'' does not belong to a body!', element.id, element.framesurf{h_});
    elseif(strcmp(sys.model.body.(sys.model.frame.(element.framesurf{h_}).body).type,'flex') && ...
        ~strcmp(sys.model.frame.(element.framesurf{h_}).type,'node'))
        % coordinate system on flexible body, but no node
        error('Error creating volume element ''%s''! Coordinate system ''%s'' on a flexible body is no nodal frame!',element.id,element.framesurf{h_});
    end
end

% default setting for coordinate system defining the force directions
if isempty(element.dirdef)
    element.dirdef = element.framesurf;
end

if(length(element.dirdef) ~= length(element.framesurf)) % Ensure correct size
    error('Error creating volume element ''%s''! For each coordinate system in framesurf one dirdef system has to exist!', element.id);
end

% Check if ID is already occupied
if(~isempty(sys.model.other) && isfield(sys.model.other, element.id))
    error('Could not create volume element ''%s'', name is already occupied!',element.id);
end

% Index of the element
element.idx = numElements;

% Store element in data structure
sys.model.other.(element.id) = element;

% Handle waiting time or quit for demonstration purposes
if(isfield(sys.settings.equation,'waitTime') && ~isempty(sys.settings.equation.waitTime))
    if(isnumeric(sys.settings.equation.waitTime))
        % For demonstration purposes, wait a little bit
        pause(sys.settings.equation.waitTime);
    else
        sys.settings.equation = rmfield(sys.settings.equation,'waitTime');
        error('Demonstration run aborted!');
    end
end
% END OF FILE
