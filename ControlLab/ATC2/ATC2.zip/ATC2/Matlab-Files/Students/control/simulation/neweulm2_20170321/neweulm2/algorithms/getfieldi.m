% res = getfieldi(inStruct, field, standard, varargin)
% getfieldi - Function to obtain field values of a data structure. If the
% requested field would return an empty value, the standard value will be
% returned. If the field does not exist in inStruct an error is thrown,
% except when errOnMissingField is set to false. Then the standard value is
% inserted as well. This function ignores different ways of capitalization
% of the field names. Therefore it might be useful to handle user input.
%
% This function can handle several fields at once, given as a cell array.
% Then standard values in the same dimension should be given. The standard
% values can be a numerical array or a cell array.
% If inStruct and standard are both data structures, the call 
% getfieldi(inStruct,[],standard) will combine the two data strutures, where
% values of standard would be overwritten by thos from inStruct.
%
% Subfunction
% isfieldi: Similar to isfield, but ignores capitalization
% 
% Input arguments {standard value}
% inStruct ............ Data structure
% field ............... Name of the field, whose value shall be obtained
% standard ............ Standard value, to be returned, if this field is
%                       empty {[]}
% Optional input arguments, given pairwise {standard value}
% MissingField ........ Logical, if true, an error is thrown if the given
%                       field does not exist. Otherwise the standard value
%                       is returned. This also handles the case that
%                       inStruct is not a data structure {false}
% mergeFields ......... Logical, only valid if field is empty and standard
%                       is a structure. If true, the structures inStruct
%                       and standard are merged in a way that if fieldnames
%                       differ, the result will contain both, similar to
%                       the union() command. If false, only the fields
%                       contained in standard are allowed and contained in
%                       the result. However, if inStruct contains fields
%                       with the same name but different capitalization,
%                       those values are inserted. {false}
% recursive ........... Logical, if true, this function is called
%                       recursively if a field contains a substructure
%                       {true}
%
% Return arguments
% res ................. Value of the specified field of inStruct or
%                       standard value
%
% Example
%   getfieldi(odeset('RelTol',1e-4), {'RelTol','AbsTol'}, [1e-2,1e-5])
% See also: isfield, odeget, getfieldi>isfieldi
%
% First appearance: 14.12.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
