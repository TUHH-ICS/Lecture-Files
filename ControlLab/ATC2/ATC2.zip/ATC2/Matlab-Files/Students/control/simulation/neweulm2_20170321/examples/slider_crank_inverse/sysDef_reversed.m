function worked_ = sysDef_reversed(modelType_)
% sysDef_reversed(modelType_)
% System definition of a slider_crank mechanism to compare different ways
% to model the system. As the forward way of modeling does not show big
% differences, this inverse way is provided.
% 
% If the simulation ran smoothly true is returned, if there was any
% problem, e.g. the modelType_ does not exist, false is returned
%
% The degrees of freedom are:
% x ........ Position of the slider
% alpha1 ... Orientation of the rod connected to the slider
% beta1 .... Relative orientation of the second rod with respect to the
%            first rod
% 
% Input:
% modelType_ ... Select which way of modeling shall be used:
% 1 .... Analytical solution
% 2 .... DAE solution explicit, independent: x
% 3 .... DAE solution partialexplicit, independent: x
% 4 .... ODE solution, manual selection: x
% 5 .... ODE solution, manual selection: alpha1
% 6 .... ODE solution, manual selection: beta1
% 7 .... ODE solution, automatic selection using SVD, starting with: x
% 8 .... ODE solution, automatic selection using QR, starting with: x
% 9 .... DAE solution explicit, independent: alpha1
% 10 ... DAE solution explicit, independent: beta1
% 11 ... ODE solution, automatic selection using SVD, starting with: alpha1
% 12 ... ODE solution, automatic selection using SVD, starting with: beta1
% 13 ... ODE solution, automatic selection using QR, starting with: alpha1
% 14 ... ODE solution, automatic selection using QR, starting with: beta1
% 15 ... DAE solution, GGL, independent x

global sys;

worked_ = true; % Default return value

sys = newSys('Id','SK', 'Name','slider_crank_reversed');

if(nargin == 0)
    modelType_ = 1;
end

newConstant('m',1,'lrod',1,'Ixx',0.01,'Iyy',0.1);
newConstant('lcrank',0.5);
if(modelType_ == 1)
    fprintf('\n\t%% ## %% ## Analytical solution %% ## %% ## \n');

    newGenCoord('gamma1');
    
    newBody('Id','P2_crank', 'Name','P2, crank', ...
            'RefSys','ISYS', ...
            'RelPos','[0; 0; 0]', 'RelRot','[0; 0; gamma1]', ...
            'CgPos','[lcrank; 0; 0]', 'CgRot','[0; 0; 0]', ...
            'Mass','m', 'Inertia','[m*Ixx,0,0;0,m*Iyy,0;0,0,m*Iyy]');

    beta1 = sym('gamma1+asin(lcrank/lrod*sin(gamma1))');
    newBody('Id','P1_rod', 'Name','P1, rod', ...
            'RefSys','P2_crank_cg', ...
            'RelPos','[0; 0; 0]', 'RelRot',[0; 0; -beta1], ...
            'CgPos','[lrod; 0; 0]', 'CgRot','[0; 0; 0]', ...
            'Mass','m', 'Inertia','[m*Ixx,0,0;0,m*Iyy,0;0,0,m*Iyy]');
    sys.model.name = ['noLoop_genCoord_',any2str(sys.parameters.genCoord)];

    newOutput('Id','alpha1','Name','Evaluate genCoord alpha1','Type','userDef', ...
        'var','asin(lcrank/lrod*sin(gamma1))');
    newOutput('Id','x','Name','Evaluate genCoord x','Type','userDef', ...
        'var','lcrank*cos(gamma1)+lrod*cos(asin(lcrank/lrod*sin(gamma1)))');
    newOutput('Id','beta1','Name','Evaluate genCoord beta1','Type','userDef', ...
        'var','gamma1+asin(lcrank/lrod*sin(gamma1))');

else
    newGenCoord('x','alpha1');

    newBody('Id','P1_rod', 'Name','P 1, rod', ...
            'RefSys','ISYS', ...
            'RelPos','[x; 0; 0]', 'RelRot','[0; 0; -alpha1]', ...
            'CgPos','[0; 0; 0]', 'CgRot','[0; 0; 0]', ...
            'Mass','m', 'Inertia','[m*Ixx,0,0;0,m*Iyy,0;0,0,m*Iyy]');
    newFrame('Id','P1_P2_contact','Name','Contact between P1 and P2', ...
            'RefSys','P1_rod','RelPos','[-lrod;0;0]');

    newGenCoord('beta1');

    newBody('Id','P2_crank', 'Name','P 2, crank', ...
            'RefSys','P1_P2_contact', ...
            'RelPos','[0; 0; 0]', 'RelRot','[0; 0; beta1]', ...
            'CgPos','[0; 0; 0]', 'CgRot','[0; 0; 0]', ...
            'Mass','m', 'Inertia','[m*Ixx,0,0;0,m*Iyy,0;0,0,m*Iyy]');
    newFrame('Id','P2_ISYS_contact','Name','Contact between P2 and ISYS', ...
            'RefSys','P2_crank','RelPos','[-lcrank;0;0]');

    newOutput('Id','alpha1','Name','Evaluate genCoord alpha1','Type','genCoord', ...
        'var','alpha1');
    newOutput('Id','x','Name','Evaluate genCoord x','Type','genCoord', ...
        'var','x');
    newOutput('Id','beta1','Name','Evaluate genCoord beta1','Type','genCoord', ...
        'var','beta1');

    newConstraint('Id','S1', 'Name','kin Loop 1', ...
       'Ksys1','ISYS', 'Ksys2','P2_ISYS_contact', ...
       'Constraints', [1 1 0 0 0 0]);
   
    if(modelType_ == 2)
        fprintf('\n\t%% ## %% ## DAE solution explicit, yind = x, modelType = %d %% ## %% ## \n',modelType_);
        sys.settings.equation.index = 1;
        sys.settings.equation.equationType = 'explicit_Mconst';
        declareDependent('alpha1','beta1');
    elseif(modelType_ == 3)
        fprintf('\n\t%% ## %% ## DAE solution partialexplicit, yind = x, modelType = %d %% ## %% ## \n',modelType_);
        sys.settings.equation.index = 1;
        sys.settings.equation.equationType = 'partialexplicit';
        declareDependent('alpha1','beta1');

    elseif(modelType_ == 4)
        fprintf('\n\t%% ## %% ## ODE solution, manual selection, yind = x, modelType = %d %% ## %% ## \n',modelType_);
        sys.settings.equation.index = 0;
        sys.settings.equation.equationType = 'kane';
        declareDependent('beta1','alpha1');
    elseif(modelType_ == 5)
        fprintf('\n\t%% ## %% ## ODE solution, manual selection, yind = alpha1, modelType = %d %% ## %% ## \n',modelType_);
        sys.settings.equation.index = 0;
        sys.settings.equation.equationType = 'kane';
        declareDependent('x','beta1');
    elseif(modelType_ == 6)
        fprintf('\n\t%% ## %% ## ODE solution, manual selection, yind = beta1, modelType = %d %% ## %% ## \n',modelType_);
        sys.settings.equation.index = 0;
        sys.settings.equation.equationType = 'kane';
        declareDependent('x','alpha1');
    elseif(modelType_ == 7)
        fprintf('\n\t%% ## %% ## ODE solution, using SVD, yind = x, modelType = %d %% ## %% ## \n',modelType_);
        sys.settings.equation.index = 0;
        sys.settings.equation.equationType = 'svd';
        declareDependent('alpha1','beta1');
    elseif(modelType_ == 8)
        fprintf('\n\t%% ## %% ## ODE solution, using QR, yind = x, modelType = %d %% ## %% ## \n',modelType_);
        sys.settings.equation.index = 0;
        sys.settings.equation.equationType = 'qr';
        declareDependent('beta1','alpha1');

% From here on, there should be nothing happening but repetition of the
% results above
    elseif(modelType_ == 9)
        fprintf('\n\t%% ## %% ## DAE solution, yind = alpha1, modelType = %d %% ## %% ## \n',modelType_);
        sys.settings.equation.index = 1;
        sys.settings.equation.equationType = 'explicit_Mconst';
        declareDependent('beta1','x');
    elseif(modelType_ == 10)
        fprintf('\n\t%% ## %% ## DAE solution, yind = beta1, modelType = %d %% ## %% ## \n',modelType_);
        sys.settings.equation.index = 1;
        sys.settings.equation.equationType = 'explicit_Mconst';
        declareDependent('alpha1','x');
    elseif(modelType_ == 11)
        fprintf('\n\t%% ## %% ## ODE solution, using SVD, yind = alpha1, modelType = %d %% ## %% ## \n',modelType_);
        sys.settings.equation.index = 0;
        sys.settings.equation.equationType = 'svd';
        declareDependent('x','beta1');
    elseif(modelType_ == 12)
        fprintf('\n\t%% ## %% ## ODE solution, using SVD, yind = beta1, modelType = %d %% ## %% ## \n',modelType_);
        sys.settings.equation.index = 0;
        sys.settings.equation.equationType = 'svd';
        declareDependent('x','alpha1');
    elseif(modelType_ == 13)
        fprintf('\n\t%% ## %% ## ODE solution, using QR, yind = alpha1, modelType = %d %% ## %% ## \n',modelType_);
        sys.settings.equation.index = 0;
        sys.settings.equation.equationType = 'qr';
        declareDependent('x','beta1');
    elseif(modelType_ == 14)
        fprintf('\n\t%% ## %% ## ODE solution, using QR, yind = beta1, modelType = %d %% ## %% ## \n',modelType_);
        sys.settings.equation.index = 0;
        sys.settings.equation.equationType = 'qr';
        declareDependent('x','alpha1');
    elseif(modelType_ == 15)
        fprintf('\n\t%% ## %% ## DAE solution GGL, yind = x, modelType = %d %% ## %% ## \n',modelType_);
        sys.settings.equation.index = 2;
        sys.settings.equation.equationType = 'ggl';
        declareDependent('alpha1','beta1');
    else
        sys = [];
        warning('Unknown model identifier %s! Quit!',any2str(modelType_));
        worked_ = false;
        return;
    end
end

%% Initial conditions for time integration
sys.settings.timeInt = [];
% Initial conditions
sys.settings.timeInt.y0  = zeros(sys.counters.genCoord,1);
sys.settings.timeInt.Dy0 = zeros(sys.counters.genCoord,1);
% 'x'      = P2_cg_r(0,sys.settings.timeInt.y0)
%          = P1_rod_r(0,sys.settings.timeInt.y0)
%          = 1.1513878188698;
% 'Dx'     = -1.1062;
% 'beta1'  = rotmat2kardan(P2_crank_S_rel(0,sys.settings.timeInt.y0))(3)
%          = rotmat2kardan(P2_crank_S(0,sys.settings.timeInt.y0))(3) - alpha1
%          = rotmat2kardan(P1_S(0,sys.settings.timeInt.y0))(3)
%          = gamma1
%          = 1.0471975511966;
% 'Dbeta1' = 2;
% 'alpha1' = rotmat2kardan(P2_S(0,sys.settings.timeInt.y0))
%          = rotmat2kardan(P1_rod_S(0,sys.settings.timeInt.y0))(3)
%          = gamma1+delta1
%          = -0.44783239692025;
% 'Dalpha1'= -0.5547;
xIdx_ = strcmp(sys.parameters.genCoord,'x');
if(~isempty(xIdx_))
    sys.settings.timeInt.y0(xIdx_)  = 1.1513878188698;
    sys.settings.timeInt.Dy0(xIdx_) = -1.1062;
end
alphaIdx_ = strcmp(sys.parameters.genCoord,'alpha1');
if(~isempty(alphaIdx_))
%     alpha1 = -rotmat2kardan(sys.ksys.P1_rod_cg.symkin.S);
    sys.settings.timeInt.y0(alphaIdx_)  = 0.447832501255411;
    sys.settings.timeInt.Dy0(alphaIdx_) = 0.554691338719744;
end
betaIdx_ = strcmp(sys.parameters.genCoord,'beta1');
if(~isempty(betaIdx_))
%     beta1 = gamma1-alpha1
    sys.settings.timeInt.y0(betaIdx_)  = 1.4950299492054;
    sys.settings.timeInt.Dy0(betaIdx_) = 2.5546594676562;
end
gammaIdx_ = strcmp(sys.parameters.genCoord,'gamma1');
if(~isempty(gammaIdx_))
    sys.settings.timeInt.y0(gammaIdx_)  = 1.0471975511966;
    sys.settings.timeInt.Dy0(gammaIdx_) = 2;
end
deltaIdx_ = strcmp(sys.parameters.genCoord,'delta1');
if(~isempty(deltaIdx_))
    sys.settings.timeInt.y0(deltaIdx_)  = -1.49502994811685;
    sys.settings.timeInt.Dy0(deltaIdx_) = -2.55470019599485;
end

% Ensure correct size
sys.settings.timeInt.y0 = sys.settings.timeInt.y0(1:sys.counters.genCoord);
sys.settings.timeInt.Dy0 = sys.settings.timeInt.Dy0(1:sys.counters.genCoord);

% Consistency has been checked before with this command
% [y0, Dy0, D2y0, lambda0] = calcInitConditions(sys.settings.timeInt.time(1),sys.settings.timeInt.y0,sys.settings.timeInt.Dy0);

% END OF FILE
