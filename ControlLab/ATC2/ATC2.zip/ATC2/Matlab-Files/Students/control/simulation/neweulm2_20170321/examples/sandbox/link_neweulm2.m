function link_neweulm2
% This routine is a link which calls startneweulm2.m from any given model folder.

% Please enter here the path to the folder containing the gui.
% For the local version, you can set GUIpath_ = '../../neweulm2/gui';
% For the server version, please enter the full path.
GUIpath_ = '../../neweulm2/gui'; % Local version
% GUIpath_ = '/home/itm/itmsw/neweulm2/currentVersion/neweulm2/gui'; % ITM Server version

%%%%%%%%%%%%%%%%%%%%%%%%%%%
% store current path
current_ = pwd;
% Change the folder, if neweulm2 is running on a server, enter here the path
cd(GUIpath_);
% Call startneweulm2.m
startneweulm2(current_);