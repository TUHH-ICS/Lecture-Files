function D2MVL = f_D2MVL(t,varargin)

D2MVL = 0;
