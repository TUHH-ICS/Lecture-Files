% EDITCOORDINATESYSTEM M-file for EditCoordinateSystem.fig
%      EDITCOORDINATESYSTEM, by itself, creates a new EDITCOORDINATESYSTEM
%      or raises the existing singleton*.
%
%      H = EDITCOORDINATESYSTEM returns the handle to a new
%      EDITCOORDINATESYSTEM or the handle to the existing singleton*.
%
%      EDITCOORDINATESYSTEM('CALLBACK',hObject,eventData,handles,...) calls
%      the local function named CALLBACK in EDITCOORDINATESYSTEM.M with the
%      given input arguments.
%
%      EDITCOORDINATESYSTEM('Property','Value',...) creates a new
%      EDITCOORDINATESYSTEM or raises the existing singleton*.  Starting
%      from the left, property value pairs are applied to the GUI before
%      EditCoordinateSystem_OpeningFunction gets called.  An unrecognized
%      property text_name or invalid value makes property application stop.  All
%      inputs are passed to EditCoordinateSystem_OpeningFcn via varargin.
%
% Graphical user interface to define or edit coordinate systems.
% 
% For more information, please open the corresponding window and click on
% the help button, labeled with a question mark "?".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
%
% First appearance: 01.07.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
