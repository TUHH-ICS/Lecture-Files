% checkName(varName) - check if varname if a possible variable name
%
%  Syntax:
% checkName('alpha1')
%
%  Desciption:
% Checks if parameter identifier is acceptable
% 
%  Example:
% checkName('x1');
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
