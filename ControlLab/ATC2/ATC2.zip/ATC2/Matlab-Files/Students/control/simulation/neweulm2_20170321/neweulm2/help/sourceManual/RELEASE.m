%% NEWEULM2 - RELEASE NOTES
% 
% Current Version: 2.00 alpha 1
%
% 
%
%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2012 ITM University of Stuttgart
%        <tt class="minicdot">&#149;</tt>
%        <a href="http://www.itm.uni-stuttgart.de">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:./LICENSE.html">Terms of Use</a>
%   </p>
% </html>