%% Getting started
% 
% * <whatis.html What is Neweul-M²?>
% * <models.html Available Models>
% * <software_structure.html Structure of the software>

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2011 ITM University of Stuttgart
%        <tt class="minicdot">&#149;</tt>
%        <a href="http://www.itm.uni-stuttgart.de">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:./LICENSE.html">Terms of Use</a>
%   </p>
% </html>