% MANAGESUBPLOTS MATLAB code for manageSubplots.fig
%      MANAGESUBPLOTS, by itself, creates a new MANAGESUBPLOTS or raises the existing
%      singleton*.
%
%      H = MANAGESUBPLOTS returns the handle to a new MANAGESUBPLOTS or the handle to
%      the existing singleton*.
%
%      MANAGESUBPLOTS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MANAGESUBPLOTS.M with the given input arguments.
%
%      MANAGESUBPLOTS('Property','Value',...) creates a new MANAGESUBPLOTS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before manageSubplots_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to manageSubplots_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
