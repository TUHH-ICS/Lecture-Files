% newStateDependent(varargin) - create user-defined state dependent parameter
% 
%  Syntax:
%> newStateDependent('VarName1','Expression1','VarName2','Expresssion2');
% 
%  Description:
% For the current use as a state dependent stiffness or damping parameter
% no derivatives are necessary.
%
% State dependent parameters bring some problems, as to get the equations
% of motion, one has to calculate derivatives with respect to the
% generalized coordinates. The first occurence of such derivatives is
%
% - in the Jacobian matrices, e.g. Jt = dr/dy
% For nonlinear parameters of force elements this is not a problem. Only if
% the state dependent parameter is to be used to describe a coordinate
% system, derivatives are necessary. Here an intermediate step is
% introduced. The parameter has to be defined in a certain coordinate
% system, in which usually the directional derivatives in its coordinate
% axes (x1,y1,z1) are easy to define. Therefore the user can define these
% derivatives with respect to the local coordinate system.
%
% - in the linearization of equations of motion
% Here the derivatives of the nonlinear equations of motion are calculated
% with respect to the generalized coordinates and velocities. But it is
% impossible to recognize in which coordinate system the parameters have
% been defined. Therefore a symbolic expression is necessary. The user can
% provide a symbolic expression to be used for the derivative evaluated at
% the linearization point. From this the needed derivatives are calculated
% automatically.
%
% This way of defining the derivatives sounds quite complicated, but they
% both aim at completely different applications. The derivatives in the
% Jacobian matrix mentioned at first, are especially important for the
% large, nonlinear motion. The secondly mentioned derivatives in the
% linearization are used to get a good approximation for the small motion
% around the set values.
%
%  Example:
%> newStateDependent('u1','2*sin(t)+x1');
%
%  See also: newBody, newForceElem, newGenCoord, newFrame, newConstraint,
%   newSys, newInput, newOutput, newConstant, newTimeDependent, newVolume,
%   calcEqMotNonLin
%
% First appearance: 30.05.2008
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
