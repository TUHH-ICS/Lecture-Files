function conditions = initOpt
% Initializes the problemdependent parameters and options for the
% optimization

global sys

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Choice of design variables p by the user
sys.opt.p = cell(0); % Creation of an empty cell array
% Initialization of the parameters
%sys.opt.p{end+1} = 'Omega';
sys.opt.p{end+1} = 'k';
sys.opt.p{end+1} = 'd';
sys.opt.p{end+1} = 'm1';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Definition of the function criterion by the user. It has to be a symbolic
% expression or a string.
% psi = G1(t1,y1,z1,p) + \int_{t0} ^{t1} F(t,y,z,Dz,p) dt
% Definition of the part G1, evaluated only at t = t1

%sys.opt.psiG1 = ['abs(' sys.genCoords{1} ')+abs(' sys.genCoords{2} ')']; 
%sys.opt.psiG1 = ['sqrt(' sys.genCoords{1} '^2)'];
% sys.opt.psiG1 = ['x^2'];
% sys.opt.psiG1 = ['(x-l0)^2'];
sys.opt.psiG1 = '0';
%sys.opt.psiG1 = '1/max(abs(sys.results.timeInt.y(1,:)))';
%syms m1
%sys.opt.psiG1 = 0.1* m1;

% Definition of the function F, integrated over [t0,t1], F is only the function under neath the integral!
%sys.opt.psiF = '0';
%sys.opt.psiF = [sys.genCoords{1} '^2'];
% sys.opt.psiF = ['(x-l0)^2'];
sys.opt.psiF = ['x^2'];
%sys.opt.psiF = ['1/100*t^2'];
%sys.opt.psiF = ['1000 *abs(' sys.genCoords{1} ')'];
%sys.opt.psiF = ['abs(y_A)'];
%sys.opt.psiF = ['t^2 *abs(' sys.genCoords{1} ')'];
%sys.opt.psiF = sys.genCoords{1};
%sys.opt.psiF = ['100*' sys.genCoords{1} '^2'];
%sys.opt.psiF = '1';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Final conditions, must be a scalar function
% Initialization to standard value
sys.opt.Hend = sym(['t-' mat2str(sys.settings.timeInt.time(end))]); % Use the integration time set in runTimeInt
% Definition of userdefined functions
% sys.opt.Hend = ['(t-' mat2str(sys.settings.timeInt.time(end)) ')*(x-0.05)'];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initial values for the integration are set in runTimeInt
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Definition of constraints for the optimization

% If lb, ub are undefined: Medium-scale Algorithm
% If A, b are undefined: Large-scale Algorithm

% Inequality constraints
% A*p <= b
% Standard choices
% I. All design variables p >= 0
conditions.A = -eye(length(sys.opt.p));
conditions.b = zeros(length(sys.opt.p),1);

% II. No restrictions
% conditions.A = zeros(length(sys.opt.p));
% conditions.b = ones(length(sys.opt.p),1);

% III. Undefined / empty
% conditions.A = [];
% conditions.b = [];

% Free definitions
% conditions.A = -eye(length(sys.opt.p));
% conditions.b = -0.001*ones(length(sys.opt.p),1);
% conditions.A = -1;
% conditions.b = -0.001;
% conditions.A = zeros(length(sys.opt.p));
% conditions.A = -ones(length(sys.opt.p));
% conditions.A(1,1) = -1;
% conditions.b = zeros(length(sys.opt.p),1);

% Equality constraints
% Aeq*p = beq
% I. Undefined / empty
conditions.Aeq = [];
conditions.beq = [];
% Free definitions

% Lower and upper boundaries for design variables p
% lb <= p <= ub
% I. Undefined / empty: medium-scale
conditions.lb = []; % Lower boundary
conditions.ub = []; % Upper boundary
% II. Undefined: Large-scale
% conditions.lb = -Inf; % Lower boundary
% conditions.ub = Inf; % Upper boundary
% III. Free definition
%conditions.lb = 0.01; % Lower boundary
%conditions.ub = 1000; % Upper boundary

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Choice of the method used to calculate the gradient
% sys.opt.Method = 'dir_tog'; % Gradient calculated with the direct method, ODEs inegrated together
sys.opt.Method = 'adj_sep'; % Gradient calculated with the adjoint variable method, integrated seperately
% sys.opt.Method = 'comparison'; % Comparison of dir_tog and adj_sep

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Definition of options for the optimization
conditions.options = optimset; % Initialization to empty standard values
conditions.options = optimset(conditions.options, 'GradObj','on'); % Gradient has to be calculated by the user Function
%conditions.options = optimset(conditions.options, 'TolFun','0.001'); % Definition of the tolerance for the function value
conditions.options = optimset(conditions.options, 'MaxIter',300); % Maximum number of iterations
%conditions.options = optimset(conditions.options, 'DerivativeCheck','on'); % Compare calculated gradient with Finite differences

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Definition of tolerances for the integrations in the optimization
% Standard values:
% 'RelTol' = 1e-3
% 'AbsTol' = 1e-6
%Example: sys.opt.integrationTols = odeset('RelTol', 1e-3, 'AbsTol', 1e-6);

% The following line extracts tolerances from the existing options
% structure and neglects everything else
% Adjust Tolerances
% sys.settings.timeInt.intOpts = odeset(sys.settings.timeInt.intOpts, 'RelTol', 1e-4); % Relative tolerances
% sys.settings.timeInt.intOpts = odeset(sys.settings.timeInt.intOpts, 'AbsTol', 1e-9); % Absolute tolerances
sys.opt.quad_tol = 1e-6; % Tolerance for the integrations with quad, quadv, quadl, default 1e-6;

% All integration options are used in the optimization, so remove here any
% unwanted options!
