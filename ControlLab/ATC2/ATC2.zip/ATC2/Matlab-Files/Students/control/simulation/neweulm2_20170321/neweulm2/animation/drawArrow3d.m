% drawArrow3d - Draw an arrow in a 3D plot
%
%  Description:
% This function can be used to display dynamically adjusted arrows, e.g. to
% display applied forces. Let's say, we have a system with a system
% output with the Id 'appliedForce', which is applied at coordinate system
% 'frame1', acting in the local x-direction. Then you would need the
% following command:
%     drawArrow3d([], [1;0;0], [], [], [], ...
%         'frame','frame1', 'ScaleOut','appliedForce');
% Empty brackets [] cause the standard value for this option.
%
%  Input arguments, if not supplied or empty, the standard values are used:
% r ... Vector to the tip of the vector, 3x1 vector {[0;0;0]}
% v ... Vector which is represented by this arrow, 3x1 vector {[1;0;0]}
% s ... Size, diameter at the base of the arrow {0.05}
% c ... Color, given as RGB triplet  {[1 0 0]}
% n ... Number of support points on circumference {10}
% 
%  Optional input arguments
% Color ......... For compatibility, the color property is provided,
%                 setting the FaceColor and EdgeColor to this value
% EdgeColor ..... Property of this patch object {'none'}
% Frame ......... Specify the coordinate system of Neweul-M2 to attach this
%                 shape to. Otherwise you would have to call addGraphics
%                 manually {[]}
% ScaleOut ...... With the help of this option, the arrow size will be
%                 scaled using this system output. Therefore the ID of a
%                 valid system output is expected. The direction vector v
%                 will be normalized. For additional scaling, please use
%                 the 'ScaleFactor' property. {[]}
% ScaleFactor ... Scaling factor which is applied when using the system
%                 output. Otherwise the length of the arrow would be the
%                 absolute value of the system output {1}
% Tag ........... For identification, a Tag may be specified {'Arrow_1'}
% 
%  Return argument:
% h ............. Graphics handle of the created arrow
%
%
%  See also: drawCube, drawLine, drawRotBody, drawSphere, drawSTL
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
