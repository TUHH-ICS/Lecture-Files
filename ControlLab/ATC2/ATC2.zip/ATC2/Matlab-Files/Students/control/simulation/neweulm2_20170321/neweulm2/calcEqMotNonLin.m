% calcEqMotNonLin - Calculate the nonlinear equations of motion
% 
%  Syntax:
%> calcEqMotNonLin
%> calcEqMotNonLin('Property', value, ... )
% 
%  Description:
% This file is the centerpiece of NeweulM2 as it contains or calls
% functions to perform the most important tasks. From setting up the
% kinematics to formulating the equations of motion.
%
% In this file, the generalized coordinates are sorted to have first the
% rigid body motion and then the elastic deformations. You can find this
% order in sys.parameters.vectors. Apart from this, the generalized
% coordinates keep the order in which they have been defined or in which
% the user has arranged them.
%
%  Preliminaries:
% System definition, at least
%> newSys;
%
%  Subsequent operation:
%> writeMbsNonLin;
%
%  Input arguments, all optional, given pairwise:
% Abbreviations ........... Numerical value to specify, whether
%           abbreviations shall be used for the relative kinematic
%           expressions of elastic bodies. This makes smaller expressions
%           and sometimes improves evaluation speed. Values from 0 to 2 are
%           accepted, where 0 means no abbreviations are introduced. For 1
%           only scalar abbreviations are used, while 2 means to use
%           abbreviations for all expressions. A value of 2 allows the user
%           to exchange the .mat or .SID_FILE of an elastic body, without
%           recalculating the equations {1}
% CalcReactionForces ...... Boolean to specify whether reaction forces are
%           to be calculated or not {false}
% Combine ................. Flag to switch the use of the 'combine' command
%           on/off, value is represented in sys.settings.equation.simplify.
% ConstraintIndex ......... For systems with kinematic loops the index of
%           the system of equations of motion can be specified. For the
%           formulation 'ode' index is set to 0, for the other two options,
%           an index between 1 and 3 is available. {1}
% EquationType ............ For systems with kinematic loops, some
%           different formulations for the equations of motion are
%           available. For ode formulations they are clearly visible in the file
%           'constraint_equations.m'. 
%           The option 'partition' characterizes the method to use separation of
%           generalized coordinates to eliminate the constraint equations.
%           'ode_automatic' represents a method, where the independent
%           coordinates are selected automatically. 
%           'svd' and 'qr' are orthogonalization methods based on a
%           singular value decomposition respectively a QR decompostion.
%           Possibilities:
%           'explicit_Mconst', 'partialexplicit', 'partition', 'qr',
%           'svd' {'explicit_Mconst'}
% Formulation ............. Specify which part is to be done symbolically.
%           Possibilities are: 'minimal', 'newtonEuler', 'recursive', 
%           'recursiveMinimal','Hamilton'.
%           For newtonEuler the premultiplication of the global Jacobian matrix
%           is done numerically instead of symbolically as in minimal.
%           {'newtonEule myLine_ = fgetl( fidIn );r'}
% SortGenCoords ....... Bool defining if the vector of the generalized coordinates
%           is supossed to be sorted. {true}
% Kinematics .............. Calculate the kinematics in absolute or relative
%           coordinates {'abs'} or 'rel'
% MassMatrixInverse ....... Invert the matrix numerically or symbolically.
%           For the evaluation of the state space form, the
%           backslash \ operator is used, which is more
%           efficient. This only corresponds to what is done in
%           eqm_nonlin_Minv.m. Only available in absolute
%           kinematics mode. {'num'} or 'sym'
% MinimalInputVect ........ Logical: true/false.
%           When an input is defined, it is unknown whether this parameter
%           or one of its first two time derivatives will appear in the
%           equations of motion. Therefore this function checks for
%           appearances in the equations of motion. If you want to keep all
%           entries, e.g. for a parameter 'u' the complete vector 
%           [u; Du; D2u], pass false as a second argument {true}
% LicenseCheck ............ Flag to check whether this version of neweulm2
%           still has a valid license. {''}
% OnlyKinematics .......... Logical: true/false
%           Flag with which the function can be aborted after the
%           calculation of the kinematics, omits calculation of the
%           equations of motion. {false}
% OutType ................. Type to use for the status updates, see
%           'n2StatusOutput' for more information {'CMD'}
% OutHandle ............... Handle to use for the status updates, see
%           'n2StatusOutput' for more information {1}
% ReactionRefSys .......... Specify the DirDef for the reaction forces. If
%           set to 'reference', then the frame of reference of each body is
%           used, otherwise the inertial frame 'ISYS' is used to describe
%           the vectors {'reference'}
% SeparateInputs .......... Boolean determining if the input matrices
%           should be computed or not {true}  
% Simplify ................ Controls the use of simplifications. In
%           previous versions, this has been a logical parameter and
%           Maple's combine command has been handled separately. Now both
%           are controlled with this one option in the following way. An
%           integer parameter in the range [0,10] can be passed which
%           controls at how many positions simplifications are performed.
%           All odd values use only the simplify() command, while even
%           values in the case of Maple as the symbolic engine enable the
%           use of the combine() command. This means that there are 5
%           levels to adjust the simplifications and the combine command is
%           handled additionaly. The combine() command does not exist in
%           MuPad, but there this functionality is included in simplify().
%           0 ... No simplifications are done, which is usually not a good
%                 choice.
%           1 ... Only the most important simplifications are done.
%           2 ... Like 1, but using the combine() command
%           3 ... Very restricted use, still hardly any simplifications
%           4 ... Like 3, but using the combine() command
%           5 ... The really necessary simplifications are used.
%           6 ... Like 5, but using the combine() command
%           7 ... Some not really necessary simplifications are omitted.
%           8 ... Like 7, but using the combine() command
%           9 ... Means all simplifications are performed.
%           10 ... Like 9, but using the combine() command
% StartFrame .............. Start the calculation of the kinematics at this
%           given frame. As a recursive function is used, all lower frames
%           will be recalculated as well. {'ISYS'}
% UseIntermediateSave ..... Logical: true/false
%           Store intermediate results, useful if there are problems with
%           the setting up of equations. {false}
% CheckVarargin ........... An advanced feature to avoid errors if invalid
%           parameters are passed. This is only if you know exactly what
%           you are doing. {true}
% 
%  Example:
%  calcEqMotNonLin;
%> calcEqMotNonLin('Abbreviations', 2, 'OnlyKinematics', true);
%
%  See also: 
% calcEqMotLin, writeMbsNonLin, writeMbsLin, calcForcesFelem,
% scriptCalcEqMotNonLin, createInertia, elastMassMatrix, calcFlexForces
%
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
