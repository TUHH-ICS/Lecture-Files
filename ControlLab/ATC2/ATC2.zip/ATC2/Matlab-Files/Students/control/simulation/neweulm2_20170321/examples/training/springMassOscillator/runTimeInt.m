%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                   %
%                             runTimeInt                            %
%                                                                   %
% Perform a time integration of the nonlinear equations of motion   %
% and start an animation of the results                             %
%                                                                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% If no animation window exists, create one
if(isempty(sys.graphics.axes) || ~ishandle(sys.graphics.axes))
    createAnimationWindow;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initialize all values and parameters for the time integration

% Time Intervall [t0, t1] for the numerical integration
timeInterval = [0 10];

% Initial values for the integration, for both position and velocity of all
% generalized coordinates, at t = timeInterval(1);
% Attention!! Do not exceed system dimension

% If the following parameter is set to true, the static equilibrium will be
% calculated and the specified initial conditions added to these values
measureFromEquilibrium = false;

% Initialization
y0  = zeros(sys.counters.genCoord,1); % For the generalized coordinates on position level
Dy0 = zeros(sys.counters.genCoord,1); % For the generalized coordinates on velocity level

% Specify values
y0(1) = 0;
y0(2) = 0;
y0(3) = 1.48013139861891;
y0(4) = -0.7;
y0(5) = -0.707584376287113;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ensure that system dimension is not exceeded
y0  = y0(1:sys.counters.genCoord);
Dy0 = Dy0(1:sys.counters.genCoord);
% Calculation of the static equilibrium, if requested
if(sys.counters.constraint == 0 && measureFromEquilibrium)
    % Evaluate static equilibrium and add initial conditions
    % Attention! All time dependent functions are evaluated at t = t0 !
    fprintf(1,'Calculating Static Equilibrium ...\n');
    ye = staticEquilibrium(timeInterval, zeros(sys.counters.genCoord,1));
    sys.results.statEq = ye;
    updateGeo(0,ye); % Update animation window
    fprintf(1,'ok!\n');
    % Adjust initial values
    y0 = ye + y0;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Choose the integration algorithm, leave empty for standard choice
% There are several integration algorithms available, Matlab offers
% ode45, ode15s, ode23, ode113, ode23s, ode23t, ode23tb
% Other choices usually provided by Neweul-M2 are:
% ode1, ode1s, ode2, ode3, ode4, ode5, radauMex, dop853Mex
%
% Recommended choices are, if available:
% Systems with tree structure:       ode45, dop853Mex
% Systems with constraint equations: ode15s, radauMex
integrator = [];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Integration options and tolerances
sys.settings.timeInt.intOpts = odeset;
% sys.settings.timeInt.intOpts = odeset(sys.settings.timeInt.intOpts, 'RelTol', 1e-8); % Relative tolerances
% sys.settings.timeInt.intOpts = odeset(sys.settings.timeInt.intOpts, 'AbsTol', 1e-10); % Absolute tolerances, Increasing this value can worsen the results!

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Final conditions, must be a scalar function
% Initialization to standard value
% sys.settings.timeInt.finalCond = sym(['t-' mat2str(sys.settings.timeInt.t1)]); % Use the integration time set in runTimeInt
% Definition of userdefined functions
% sys.settings.timeInt.finalCond = ['(t-' mat2str(sys.settings.timeInt.t1) ')*(beta2)'];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Activate a measure to follow the progress of the integration
sys.settings.timeInt.display.type = 'waitbar';
% sys.settings.timeInt.display.type = 'odeplot';
% sys.settings.timeInt.display.type = 'animation';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Time integration
fprintf(1,'Integrating the System over the Time ...');
sys.results.timeInt = timeInt(y0, Dy0, 'time', timeInterval, 'integrator', integrator);
fprintf(1,' ok!\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Adjustment of the visible area

% Adjustment of the visible area by hand
% xlim([-1.5 1.5]);
% ylim([-1.5 1.5]);
% zlim([-1.5 1.5]);

% Automatic scaling of the plot area, by evaluating all trajectories,
% therefore it might take some time
fitCanvas('equal'); % decides the optimal graph size, with equal axis scales
% fitCanvas('CenterCS','P2_cg', 'with_ISYS',true); % decides the optimal graph size, centered to the passed coordinate system

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot trajectories for certain coordinate systems
% Has to be run only once for each desired coordinate system
names_ = fieldnames(sys.model.frame);
plotTrajectories(names_{end}); % Plots a red line
% plotTrajectories(names_{end},'b-', 'LineWidth', 2); % Plots a blue line, linewidth 2

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Animation of the results

animTimeInt;
% animTimeInt(sys.results.timeInt,'TimeStep',6e-2,'Stride',1);
% animTimeInt(sys.results.timeInt,'TimeStep',1e-2,'Stride',0.1,'CenterCS','P2_cg'); % View centered to P2_cg

% END OF FILE
