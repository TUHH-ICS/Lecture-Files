% returnLogical = writeMultiplication(myFid, resString, firstString,
%   secondString, firstValue, secondValue,varargin)
% In a multiplication of sparsely populated matrices, Matlab will perform
% all operations, even those clearly equal to zero. Therefore this function
% extracts all actually required expressions and writes them to a file.
% Tests have shown that this technique is either of the same speed for
% dense matrices and faster in every other case. This function only
% produces the expressions referencing the required fields and writes this
% information to a file. It does not perform any multiplication itself.
% 
% Input arguments (required)
% myFid ........... File identifier, as returned by fopen
% resString ....... Name of the resulting matrix
% firstString ..... Name of the first matrix to be multiplied
% secondString .... Name of the second matrix to be multiplied
% firstValue ...... Values of the first matrix, is only used to check which
%                   elements are equal to zero. Therefore a logical matrix
%                   would be valid.
% secondValue ..... Values of the second matrix, is only used to check
%                   which elements are equal to zero. Therefore a logical
%                   matrix would be valid.
% 
% Input arguments (optional, given in pairs, {Standard values})
% Append .............. Logical, whether the given expressions are to be
%                       appended to an existing expression or matrix
%                       {false}
% FirstTransposed ..... Logical, whether the first matrix shall be
%                       transposed {false}
% SecondTransposed .... Logical, whether the second matrix shall be
%                       transposed {false}
% Initialize .......... Logical, whether to print an initialization with
%                       zeros {false}
% Language ............ String, deciding whether m-code ('m') or C-code
%                       ('C') syntax shall be used {'m'}
% Offset .............. Integer, that provides an offset for the second
%                       input, if the second input is a vector {0}
% FirstArgOffset ...... {[0 0]}
% Vector .............. Logical, whether the second Value is a vector {false}
%
% First appearance: 14.06.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
