function D2u = f_D2u(t)
% f_D2u - definition of 2nd time-derivative of user-defined variable u

global sys;



% constant user-defined variables

c = sys.parameters.data.c;
z = sys.parameters.data.z;


% time dependent user-defined variables

D2u = zeros(1,1);

if(0 < t && t < 0.6)
    D2u(1) = 0.5*z*cos(c*t)*c^2;
end
