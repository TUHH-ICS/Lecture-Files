% freqResponse - Calculate the frequency response between system input in
% and system output out for the given frequencies.
% 
%  Syntax: 
%> freqResponse;
%> freqResponse('Property', value, ...);
%     
%  Description:
% If the System Control Toolbox is available, it is used to do this job. Otherwise the
% calculations are done manually, which is slower, especially for large
% systems and many frequency points.
%
%  Input arguments, given pairwise:
% Time .......... Simulation time {0}
% Input ......... System input, given as a cell array of the Ids of system
%                 inputs (see sys.model.input) {all system inputs}
% Output ........ System output, given as a cell array of the Ids of system
%                 outputs (see sys.model.output) {all system outputs}
% Frequency ..... Vector with frequencies, for which the response shall be
%                 calculated {auto}
% Numeric ....... If available, the linearized equations of motion, which
%                 have been set up symbolically, are used. However, should
%                 they not be present, the numerical linearization is
%                 applied. With this parameter, the user can select, which
%                 ones to use. {false}
% OutputType .... Determine what shall be used as output. If 'system' is
%                 passed as second argument, the system outputs are used.
%                 If 'states' is given, the state vector is used, or for
%                 'genCoords', only the generalized coordinates on position
%                 level are used. {'system'}
% Symbolic ...... Opposite of Numeric. {true}
% StepsizeNum ... When using a numerical linearization the stepsize has
%                 great influence on the results, making it necessary to be
%                 specified {1e-4}
% TypicalInputs . Specify the linearization point for the system inputs {zeros(numInputs,1)}
% TypicalStates . Specify the linearization point for the states  {zeros(2*sys.counters.genGoord,1)}
%
%  Return values (optional):
% g ......... Frequency response matrix, evaluated at freqs, is of
%             dimension size(g) = [length(out), length(in), length(freqs)]
% resData ... If additional data is available, this is passed in this data
%             structure.
%
%  Example:
%>   freqResponse;
%
%  See also: 
% freqResPlot, calcEqMotLin, eqm_lin_ssinout, modalAnalysis,
% calcNumericalLinearization
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
