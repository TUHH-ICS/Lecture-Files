% writeSolution.m

load sys

result = sys.results.timeInt;

n2StatusOutput('\nWriting solution in file solution_neweulm2.txt ... ');

fid = fopen('solution_neweulm2.txt','w');
for i=1:length(result.x)
    printLine(fid,'%1.9f\t%1.9f\t%1.9f',result.x(i),result.outControl(1,i),result.y(1,i))
end
fclose(fid);

n2StatusOutput('ok!\n\n');

