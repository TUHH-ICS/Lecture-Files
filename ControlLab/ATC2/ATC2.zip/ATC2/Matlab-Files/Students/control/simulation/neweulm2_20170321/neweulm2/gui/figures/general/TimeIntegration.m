% varargout = TimeIntegration(varargin)
% TimeIntegration M-file for TimeIntegration.fig
%      TimeIntegration, by itself, creates a new TimeIntegration or raises the existing
%      singleton*.
%
%      H = TimeIntegration returns the handle to a new TimeIntegration or the handle to
%      the existing singleton*.
%
%      TimeIntegration('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TimeIntegration.M with the given input arguments.
%
%      TimeIntegration('Property','Value',...) creates a new TimeIntegration or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before TimeIntegration_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to TimeIntegration_OpeningFcn via varargin.
%
% Graphical user interface to start a numerical time integration of the
% equations of motion of the system. This GUI offers the options being used
% most often. If you need some of the other options, please call the
% function timeInt.m directly.
% 
% For more information, please open the corresponding window and click on
% the help button, labeled with a question mark "?".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
%
% First appearance: 01.07.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
