% absoluteKinematics(frame)
% 
% absoluteKinematics - Calculate the necessary absolute kinematic values of
% coordinate systems from existing relative expressions. Therefore, this
% function requires a preceding call of relativeKinematics.
% This function calculates the values stored in
% sys.kinematics(idx_).absolute and
% sys.kinematics(idx_).intermediate
% The difference between those is that 'absolute' contains the absolute
% values in the inertial frame.
% The substructure 'intermediate' contains expressions necessary for the
% calculation of the equations of motion. Depending on the option
% 'frameOfReference' they are described in a different coordinate system.
% sys.settings.equation.frameOfReference == 'body': The frame of reference of this
% body is used.
% sys.settings.equation.frameOfReference == 'ISYS': The inertial system is used.
%
% After this function is finished it recursively calls itself for all
% children systems.
%
% Input:
% frame ... The ID of the coordinate system to be investigated
% 
% See also: relativeKinematics, calcEqMotNonLin, expandTimeVars,
%   jacobianMatrix, kardan2rotmat, rotmat2kardan
%
% First appearance: 14.03.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
