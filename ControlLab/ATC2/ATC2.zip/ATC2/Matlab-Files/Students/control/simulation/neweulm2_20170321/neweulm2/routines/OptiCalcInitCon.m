% Calculates the initial conditions 
% It distinguishes between the methods (direct - adjoint) of calculating a
% gradient. Furthermore the kinematic loops are respected.
%
% Input argument, optional
% varargin{1} ..... Integer. In the file optiCritTimeIntDir, the number of
%                   output arguments is passed to this function. Therefore,
%                   the value 1 denotes calculation only of the criterion
%                   value, value 2 denotes the additional calculation of
%                   the gradient.
%
% See also: newOpt, optiCritTimeIntAdj, optiCritTimeIntDir,
%   optiCritTimeIntFinite
%
% First appearance: 01.12.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
