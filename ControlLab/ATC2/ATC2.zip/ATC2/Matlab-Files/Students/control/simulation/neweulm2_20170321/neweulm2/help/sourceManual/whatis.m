%% What is Neweul-M²
% _NEWEULM2_ - When analyzing, simulating and optimizing multibody systems, it is often
% advantegeous to have the equations of motion in symbolic form. While for
% small systems, the derivation of the equations of motion can be done easily
% by hand, it can get very hard to do so for more sophisticated systems with
% several degrees of freedom. Therefore, the software Neweul-M² is developed
% at the Institute of Engineering and Computational Mechanics. It is based on
% Matlab's Symbolic Math Toolbox which allows symbolic algebraic computations
% within Matlab.
%%
% Neweul-M² is able to derive the symbolic equations of motion of many system
% types automatically. This includes systems with tree or loops structure,
% holonomic and to some extend non-holonomic systems consisting of a mixture 
% of rigid and elastic bodies. A symbolic or numerical linearization with 
% respect to an arbitrary symbolic reference motion is provided, which can 
% be helpful for the analysis and optimization of vibration problems.
% The field of contact simulation is currently not in the focus of our 
% interest. If the recursive numerical algorithm is used, of course some of 
% the symbolic features will be not available.
%%
% For the Matlab-based simulation of multibody systems, various functions for
% the numerical evaluation of the nonlinear and linearised equations of 
% motions and kinematic properties are provided. In the subsequent sections, 
% the structure and usage of the software is explained. A comprehensive 
% explanation of multibody system theory can be found in the textbook W. Schiehlen,
% P. Eberhard: Technische Dynamik. Wiesbaden: Teubner, 2004., which is also 
% listed in #Literature. 
% 
%% 
% NEWEULM-M² calculates the equations of motion symbolically. This means it
% uses names like m1 for the parameters and not numbers 5 [kg] to set up the 
% equations. This has several advantages, allowing the user to read and
% understand the expressions and allowing an explicit formulation. Also you 
% can change values without recalculating the equations of motion. As not 
% everything can be done symbolically, the numbers come in at some point in 
% the simulation. But always when you have two uses (symbolic and numeric) of
% the same things, there are some problems. To keep these as small as 
% possible the complete data is stored in two ways simultaneously: 
% * the symbolic expressions are stored in the structure sys, available in 
%  the workspace. 
% * files containing source code, which will evaluate numerical values. 
% Even if you only want the files to calculate numerical values, it might be
% good to save the system after modeling. When doing so in the menu of the 
% GUI, it will save the figure and the data structure containing the symbolic
% expressions. The advantage is that you can load the data structure, change
% something and recreate the files. If you forgot to save before closing or 
% the program crashed, you can still hope for the autosave. Every few minutes
% , your system is saved automatically to examples/sandbox/autosave.mat. In 
% this case you should make a copy of the autosave files, otherwise they 
% might be overwritten, the next time you do anything in Neweul-M².
% 
%
%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2011 ITM University of Stuttgart
%        <tt class="minicdot">&#149;</tt>
%        <a href="http://www.itm.uni-stuttgart.de">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:./LICENSE.html">Terms of Use</a>
%   </p>
% </html>
