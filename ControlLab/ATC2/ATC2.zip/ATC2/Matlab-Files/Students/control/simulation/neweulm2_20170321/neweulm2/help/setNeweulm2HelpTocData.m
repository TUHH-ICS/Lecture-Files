function result = setNeweulm2HelpTocData
% result = setNeweulm2HelpTocData
% Specify all properties to generate the tree view and the table of
% contents for the help browser for Neweul-M2.
% 
% Return values
% result.myData
% result.omitFiles
% result.omitEntries


% Initialization
% Files to omit, even if an entry exists
omitFiles = { ...
    'RELEASE'; ...
    'functions_help'; ...
    'getOutput'; ...
    'helptoc'; ...
    'helptoc_bac'; ...
    'neweulm2_product_page'; ...
    'software_structure'; ...
    'whatis'};
% Entries of the structure to omit, even if files exist
omitEntries = {'LICENSE'};

% Initialize the standard data structure for one entry
oneNode = struct('name','','image','','target','','children',struct([]),'explanation','','type',[]);
% Type:
% 0 ......... Do not create an entry in functions_help.m
% 1 ......... Section title in functions_help.m
% 2 or [] ... regular entry in functions_help.m
%% Set the data
myData = oneNode;
myData.name = 'Neweul-M2';
myData.image = '$toolbox/matlab/icons/book_mat.gif';
myData.target = './neweulm2_product_page.html';
myData.type = 0;
myData(1).children = oneNode;
    myData.children(1).name = 'Getting Started';
    myData.children(1).image = 'HelpIcon.GETTING_STARTED';
    myData.children(1).target = './getting_started.html';
    myData.children(1).type = 0;
    myData.children(1).children = oneNode;
        myData.children(1).children(1).name = 'What is Neweul-M&#178;?';
        myData.children(1).children(1).image = '';
        myData.children(1).children(1).target = './whatis.html';
        myData.children(1).children(1).type = 0;
        myData.children(1).children(2).name = 'Available Models';
        myData.children(1).children(2).image = '';
        myData.children(1).children(2).target = './availableModels.html';
        myData.children(1).children(2).type = 0;
        myData.children(1).children(3).name = 'Structure of the Software';
        myData.children(1).children(3).image = '';
        myData.children(1).children(3).target = './software_structure.html';
        myData.children(1).children(3).type = 0;
    myData.children(2).name = 'Functions Reference';
    myData.children(2).image = 'HelpIcon.FUNCTION';
    myData.children(2).target = './functions_help.html';
    myData.children(2).type = 0;
    myData.children(2).children = oneNode;
    % New section
        myData.children(2).children(1).name  = 'Preparations';
        myData.children(2).children(1).target = './functions_help.html';
        myData.children(2).children(1).type = 1;
            newPart = oneNode; % Introduce new substructure
            newPart.name = 'addpathNeweulm2';
            newPart.image = 'HelpIcon.FUNCTION';
            newPart.target = './addpathNeweulm2.html';
            newPart.explanation = ...
                'adjust the search path for Neweul-M2';
            myData.children(2).children(1).children = newPart; % Store information
    % New section
        myData.children(2).children(2).name  = 'System definition';
        myData.children(2).children(2).target = './functions_help.html';
        myData.children(2).children(2).type = 1;
            newPart = oneNode; % Introduce new substructure
            newPart.name = 'declareDependent';
            newPart.image = 'HelpIcon.FUNCTION';
            newPart.target = './declareDependent.html';
            newPart.explanation = ...
                'declare a generalized coordinate to be dependent';
            newPart(end+1).name = 'declareDependentInitCond';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './declareDependentInitCond.html';
            newPart(end).explanation = ...
                'declare a generalized coordinate to be dependent concerning implicit initial conditions';
            newPart(end+1).name = 'declareIndependent';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './declareIndependent.html';
            newPart(end).explanation = ...
                'declare a generalized coordinate to be independent';
            newPart(end+1).name = 'declareIndependentInitCond';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './declareIndependentInitCond.html';
            newPart(end).explanation = ...
                'declare a generalized coordinate to be independent concerning implicit initial conditions';
            newPart(end+1).name = 'fullModelRun';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './fullModelRun.html';
            newPart(end).explanation = ...
                'set up the system in the current folder and run all prepared simulations';
%             newPart(end+1).name = 'getting_started';
%             newPart(end).image = 'HelpIcon.FUNCTION';
%             newPart(end).target = './getting_started.html';
%             newPart(end).explanation = ...
%                 'open a graphical user interface to start models using input files';
            newPart(end+1).name = 'modifyBody';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './modifyBody.html';
            newPart(end).explanation = ...
                'modify properties of an existing body';
            newPart(end+1).name = 'modifyConstant';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './modifyConstant.html';
            newPart(end).explanation = ...
                'modify constants';
            newPart(end+1).name = 'modifyFrame';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './modifyFrame.html';
            newPart(end).explanation = ...
                'modify properties of an existing frame';
            newPart(end+1).name = 'newBody';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './newBody.html';
            newPart(end).explanation = ...
                'define a new body, rigid or elastic';
            newPart(end+1).name = 'newConstant';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './newConstant.html';
            newPart(end).explanation = ...
                'declare a constant parameter, optionally setting the value at the same time';
            newPart(end+1).name = 'newConstraint';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './newConstraint.html';
            newPart(end).explanation = ...
                'define an algebraic constraint equation';
            newPart(end+1).name = 'newForceElem';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './newForceElem.html';
            newPart(end).explanation = ...
                'define a force element for applied forces';
            newPart(end+1).name = 'newFrame';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './newFrame.html';
            newPart(end).explanation = ...
                'define a new massless frame';
            newPart(end+1).name = 'newGenCoord';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './newGenCoord.html';
            newPart(end).explanation = ...
                'declare a generalized coordinate';
            newPart(end+1).name = 'newImplicitInitCond';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './newImplicitInitCond.html';
            newPart(end).explanation = ...
                'specify an implicit initial condition';
            newPart(end+1).name = 'newInput';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './newInput.html';
            newPart(end).explanation = ...
                'define a new system input';
            newPart(end+1).name = 'newOpt';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './newOpt.html';
            newPart(end).explanation = ...
                'specify or start an optimization or sensitivity analysis';
            newPart(end+1).name = 'newOutput';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './newOutput.html';
            newPart(end).explanation = ...
                'define a new system output';
            newPart(end+1).name = 'newPeriodic';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './newPeriodic.html';
            newPart(end).explanation = ...
                'declare a periodic parameter';
            newPart(end+1).name = 'newRandomSignal';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './newRandomSignal.html';
            newPart(end).explanation = ...
                'declare a normal distribution';
            newPart(end+1).name = 'newSmoothTransition';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './newSmoothTransition.html';
            newPart(end).explanation = ...
                'declare a sufficiently smooth transition';
            newPart(end+1).name = 'newStateDependent';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './newStateDependent.html';
            newPart(end).explanation = ...
                'declare a state dependent parameter';
            newPart(end+1).name = 'newSys';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './newSys.html';
            newPart(end).explanation = ...
                'initialize a new multibody system and the corresponding data structure';
            newPart(end+1).name = 'newTimeData';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './newTimeData.html';
            newPart(end).explanation = ...
                'introduce a time history based on set points and interpolation';
            newPart(end+1).name = 'newTimeDependent';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './newTimeDependent.html';
            newPart(end).explanation = ...
                'declare a time dependent parameter';
            newPart(end+1).name = 'newVolume';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './newVolume.html';
            newPart(end).explanation = ...
                'define a volume element using pressure';
            myData.children(2).children(2).children = newPart; % Store information
    % New section
        myData.children(2).children(3).name  = 'Equations setup';
        myData.children(2).children(3).type = 1;
        myData.children(2).children(3).target = './functions_help.html';
            newPart = oneNode; % Introduce new substructure
            newPart(1).name = 'calcEqMotLin';
            newPart(1).image = 'HelpIcon.FUNCTION';
            newPart(1).target = './calcEqMotLin.html';
            newPart(1).explanation = ...
                'symbolically linearize the equations of motion';
            newPart(end+1).name = 'calcEqMotNonLin';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './calcEqMotNonLin.html';
            newPart(end).explanation = ...
                'set up the kinematics and the equations of motion';
            newPart(end+1).name = 'calcReacForce';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './calcReacForce.html';
            newPart(end).explanation = ...
                'calculate the reaction forces';
            newPart(end+1).name = 'replaceSymbolicValues';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './replaceSymbolicValues.html';
            newPart(end).explanation = ...
                'replace symbolical values';
            newPart(end+1).name = 'scriptCalcEqMotNonLin';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './scriptCalcEqMotNonLin.html';
            newPart(end).explanation = ...
                'script to incorporate user-defined functions in the workflow, here in calcEqMotNonLin';
            newPart(end+1).name = 'scriptWriteMbsNonLin';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './scriptWriteMbsNonLin.html';
            newPart(end).explanation = ...
                'script to incorporate user-defined functions in the workflow, here in writeMbsNonLin';
            newPart(end+1).name = 'writeMbsLin';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './writeMbsLin.html';
            newPart(end).explanation = ...
                'write the files for the linearized equations of motion';
            newPart(end+1).name = 'writeMbsNonLin';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './writeMbsNonLin.html';
            newPart(end).explanation = ...
                'write the files for the nonlinear equations of motion and the kinematics';
            myData.children(2).children(3).children = newPart; % Store information
    % New section
        myData.children(2).children(4).name  = 'Simulation and evaluation';
        myData.children(2).children(4).target = './functions_help.html';
        myData.children(2).children(4).type = 1;
            newPart = oneNode; % Introduce new substructure
            newPart(1).name = 'calcNomLength';
            newPart(1).image = 'HelpIcon.FUNCTION';
            newPart(1).target = './calcNomLength.html';
            newPart(1).explanation = ...
                'calculate nominal lengths of springs to match a given static equilibrium';
            newPart(end+1).name = 'calcNumericalLinearization';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './calcNumericalLinearization.html';
            newPart(end).explanation = ...
                'evaluate the numerical linearization at a given configuration';
            newPart(end+1).name = 'evalForces';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './evalForces.html';
            newPart(end).explanation = ...
                'evaluate forces, applied or reaction';
            newPart(end+1).name = 'freqResponse';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './freqResponse.html';
            newPart(end).explanation = ...
                'calculate the frequency response';
            newPart(end+1).name = 'kinematicAnalysis';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './kinematicAnalysis.html';
            newPart(end).explanation = ...
                'perform a kinematic analysis, prescribing values for generalized coordinates';
            newPart(end+1).name = 'modalAnalysis';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './modalAnalysis.html';
            newPart(end).explanation = ...
                'calculate eigenvectors and eigenvalues';
            newPart(end+1).name = 'setfun';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './setfun.html';
            newPart(end).explanation = ...
                'specify functions for a kinematic analysis';
            newPart(end+1).name = 'staticEquilibrium';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './staticEquilibrium.html';
            newPart(end).explanation = ...
                'numerically calculate a static equilibrium';
            newPart(end+1).name = 'timeInt';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './timeInt.html';
            newPart(end).explanation = ...
                'perform a numerical time integration';
            myData.children(2).children(4).children = newPart; % Store information
    % New section
        myData.children(2).children(5).name  = 'Animation';
        myData.children(2).children(5).target = './functions_help.html';
        myData.children(2).children(5).type = 1;
            newPart = oneNode; % Introduce new substructure
            % addGraphics
            newPart(1).name = 'addGraphics';
            newPart(1).image = 'HelpIcon.FUNCTION';
            newPart(1).target = './addGraphics.html';
            newPart(1).explanation = ...
                'add graphical objects to frame';
            % animFreqResponse
            newPart(end+1).name = 'animFreqResponse';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './animFreqResponse.html';
            newPart(end).explanation = ...
                'animate frequency response';
            % animModeShape
            newPart(end+1).name = 'animModeShape';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './animModeShape.html';
            newPart(end).explanation = ...
                'animate mode shapes';
            % animTimeInt
            newPart(end+1).name = 'animTimeInt';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './animTimeInt.html';
            newPart(end).explanation = ...
                'animate time integration';
            % createAnimationWindow
            newPart(end+1).name = 'createAnimationWindow';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './createAnimationWindow.html';
            newPart(end).explanation = ...
                'create animation window';
            % createSubplots
            newPart(end+1).name = 'createSubplots';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './createSubplots.html';
            newPart(end).explanation = ...
                'create subplots in the animation window';
            % drawArrow3d
            newPart(end+1).name = 'drawArrow3d';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './drawArrow3d.html';
            newPart(end).explanation = ...
                'draw a 3-dimensional arrow';
            % drawCube
            newPart(end+1).name = 'drawCube';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './drawCube.html';
            newPart(end).explanation = ...
                'draw a cube';
            % drawElasticBeam
            newPart(end+1).name = 'drawElasticBeam';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './drawElasticBeam.html';
            newPart(end).explanation = ...
                'draw a elastic body';
            % drawLine
            newPart(end+1).name = 'drawLine';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './drawLine.html';
            newPart(end).explanation = ...
                'draw a line between frames';
            % drawMesh
            newPart(end+1).name = 'drawMesh';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './drawMesh.html';
            newPart(end).explanation = ...
                'draw the mesh of an elastic body';
            % drawRotBody
            newPart(end+1).name = 'drawRotBody';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './drawRotBody.html';
            newPart(end).explanation = ...
                'draw a rotational-symmetric body';
            % drawSphere
            newPart(end+1).name = 'drawSphere';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './drawSphere.html';
            newPart(end).explanation = ...
                'draw a sphere';
            % drawSpring
            newPart(end+1).name = 'drawSpring';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './drawSpring.html';
            newPart(end).explanation = ...
                'draw a spring';
            % drawSTL
            newPart(end+1).name = 'drawSTL';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './drawSTL.html';
            newPart(end).explanation = ...
                'draw a object stored in a STL-container';
            % drawSys
            newPart(end+1).name = 'drawSys';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './drawSys.html';
            newPart(end).explanation = ...
                'redraw graphical representation of the system';
            % fitCanvas
            newPart(end+1).name = 'fitCanvas';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './fitCanvas.html';
            newPart(end).explanation = ...
                'adjust visible area with respect to simulation results';
            % framePlot
            newPart(end+1).name = 'framePlot';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './framePlot.html';
            newPart(end).explanation = ...
                'create graphical representation of a frame';
            % freqResPlot
            newPart(end+1).name = 'freqResPlot';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './freqResPlot.html';
            newPart(end).explanation = ...
                'plot frequency response plot';
            % initGraphics
            newPart(end+1).name = 'initGraphics';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './initGraphics.html';
            newPart(end).explanation = ...
                'initial graphical representation';
            % n2CaptureScene
            newPart(end+1).name = 'n2CaptureScene';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './n2CaptureScene.html';
            newPart(end).explanation = ...
                'capture the current view setting';
            % plotStandardResults
            newPart(end+1).name = 'plotStandardResults';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './plotStandardResults.html';
            newPart(end).explanation = ...
                'plot states, outputs, constraints, ...';
            % plotTimeSteps
            newPart(end+1).name = 'plotTimeSteps';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './plotTimeSteps.html';
            newPart(end).explanation = ...
                'plot different configurations';
            % plotTrajectories
            newPart(end+1).name = 'plotTrajectories';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './plotTrajectories.html';
            newPart(end).explanation = ...
                'add the trajectories of a frame to the animation window';
            % setVisibility
            newPart(end+1).name = 'setVisibility';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './setVisibility.html';
            newPart(end).explanation = ...
                'set visibility properties of graphic objects';
            % showModeShape
            newPart(end+1).name = 'showModeShape';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './showModeShape.html';
            newPart(end).explanation = ...
                'plot mode shapes';
            % transformGraphics
            newPart(end+1).name = 'transformGraphics';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './transformGraphics.html';
            newPart(end).explanation = ...
                'perform rotations and translations of graphical objects';
            % updateGeo
            newPart(end+1).name = 'updateGeo';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './updateGeo.html';
            newPart(end).explanation = ...
                'update graphical objects';
            
            myData.children(2).children(5).children = newPart; % Store information
    % New section
        myData.children(2).children(6).name  = 'Export';
        myData.children(2).children(6).target = './functions_help.html';
        myData.children(2).children(6).type = 1;
            newPart = oneNode; % Introduce new substructure
            newPart(1).name = 'compileMatlabCode';
            newPart(1).image = 'HelpIcon.FUNCTION';
            newPart(1).target = './compileMatlabCode.html';
            newPart(1).explanation = ...
                'compile created C code';
            newPart(end+1).name = 'createSimulinkLibrary';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './createSimulinkLibrary.html';
            newPart(end).explanation = ...
                'create Simulink library';
            newPart(end+1).name = 'exportEqMot';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './exportEqMot.html';
            newPart(end).explanation = ...
                'export the equations of motion to be independent of the system data structure';
            newPart(end+1).name = 'exportSystem2C';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './exportSystem2C.html';
            newPart(end).explanation = ...
                'export the equations of motion to C';
            myData.children(2).children(6).children = newPart; % Store information
    % New section
        myData.children(2).children(7).name  = 'General functions';
        myData.children(2).children(7).target = './functions_help.html';
        myData.children(2).children(7).type = 1;
            newPart = oneNode; % Introduce new substructure
            newPart(1).name = 'printSystemInformation';
            newPart(1).image = 'HelpIcon.FUNCTION';
            newPart(1).target = './printSystemInformation.html';
            newPart(1).explanation = ...
                'print some general information on the system, very useful for debugging';
            newPart(end+1).name = 'saveSession';
            newPart(end).image = 'HelpIcon.FUNCTION';
            newPart(end).target = './saveSession.html';
            newPart(end).explanation = ...
                'save the system with all settings and files';
            myData.children(2).children(7).children = newPart; % Store information
    % New section
%         myData.children(2).children(8).name  = 'Graphical user interface';
%         myData.children(2).children(8).target = './functions_help.html';
%         myData.children(2).children(8).type = 1;
%     % New section
%         myData.children(2).children(9).name = 'Background routines for the graphical user interface';
%         myData.children(2).children(9).target = './functions_help.html';
%         myData.children(2).children(9).type = 1;
%     % New section
%         myData.children(2).children(10).name = 'Routines, working in the background';
%         myData.children(2).children(10).target = './functions_help.html';
%         myData.children(2).children(10).type = 1;
%     % New section
%         myData.children(2).children(11).name = 'Algorithms, program independent functions';
%         myData.children(2).children(11).target = './functions_help.html';
%         myData.children(2).children(11).type = 1;
%     % New section
%         myData.children(2).children(12).name = 'Not yet classified functions';
%         myData.children(2).children(12).target = './functions_help.html';
%         myData.children(2).children(12).type = 1;
        
%% Clean up, collect data
result.myData      = myData;
result.omitFiles   = omitFiles;
result.omitEntries = omitEntries;

% END OF FILE
        