% varargout = n2StatusOutput(outString, varargin)
% Function to incorporate the different ways to display the status output
% of neweulm2.
%
% There is an alternative way of calling, then the all input values are
% expected pairwise. Then an even number of input arguments is expected.
%
% Input arguments
% outString ... String to be printed as output
%
% Optional input arguments, given pairwise {standard value}
% Error ....... Handle this message as an error, same as 'type','error'{''}
% Handle ...... File or graphics handle to which the user wants to write
%               {[]}
% Html ........ Logical whether the input is html code, then links and
%               formatting is removed {false}
% Init ........ Logical whether the existing log shall be cleared or new
%               messages are simply appended {false}
% InputError .. Handle this message as an error caused by invalid user
%               input, same as 'type','Inputerror'{''}
% String ...... The string to be printed can be specified using this option
%               instead {outString}
% Type ........ Use this type of output, {'CMD'}. Currently available are:
%               - CMD: Use the Matlab command window
%               - File: Write to the log file 'n2statuslog.txt'. A change
%                   of the file name is currently not supported
%               - GUI: Use the graphical user interface n2OutputWindow
%               - InputError: Mark this message as an error, which results
%                   from faulty user input, but write to the preselected
%                   type
%               - Error: Mark this message as an error, but write to the
%                   preselected type
%               - Warning: Mark this message as a warning, but write to the
%                   preselected type
%               - None: All output is suppressed
% TmpHandle ... Use this handle, but don't store it {[]}
% TmpType ..... Use this type, but don't store it {''}
% Warning ..... Handle this message as a warning, same as 'type','warning'
%               {''}
%
% Return value:
% status ...... Parameter to show the success, 1: no problems, -1, some
%               error occured
%
% See also: printf, n2OutputWindow
%
% First appearance: 23.04.2012
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
