#ifndef radau5Mexh
#define radau5Mexh

/* Optionsettings */
#define OPT_WARNMISS "OptWarnMiss"
#define OPT_WARNTYPE "OptWarnType"
#define OPT_WARNSIZE "OptWarnSize"

/* H and Tols */
#define OPT_INITIALSS "InitialStep"
#define OPT_RTOL "RelTol"
#define OPT_ATOL "AbsTol"

/* Output */
#define OPT_OUTPUTFUNCTION "OutputFcn"
#define OPT_OUTPUTCALLMODE "OutputCallMode"

/* StepSizeSelection */
#define OPT_RHO "rho"
#define OPT_SSMINSEL "StepSizeMinSelection"
#define OPT_SSMAXSEL "StepSizeMaxSelection"
#define OPT_FREEZESSLEFT "FreezeStepSizeLeftBound"
#define OPT_FREEZESSRIGHT "FreezeStepSizeRightBound"
#define OPT_MAXSS "MaxStep"
#define OPT_MAXSTEPS "MaxNumberOfSteps"
#define OPT_STEPSIZESTRATEGY "StepSizeStrategy"

/* Newton */
#define OPT_MAXNEWTONITER "MaxNewtonIterations"
#define OPT_NEWTONSTARTSWITCH "StartNewtonWithZeros"
#define OPT_NEWTONSTOPCRIT "NewtonStopCriterion"

/* Mass */
#define OPT_MASSMATRIX "Mass"
#define OPT_MASSLBAND "MassLowerBandwidth"
#define OPT_MASSUBAND "MassUpperBandwidth"

/* Jacobi */
#define OPT_TRANSJTOH "TransfromJACtoHess"
#define OPT_JACRECOMPFACTOR "RecomputeJACFactor"
#define OPT_JACOBIMATRIX "Jacobian"
#define OPT_JACOBILBAND "JacobianLowerBandwidth"
#define OPT_JACOBIUBAND "JacobianUpperBandwidth"

/* Index-Vars */
#define OPT_DIMOFIND1VAR "DimensionOfIndex1Vars"
#define OPT_DIMOFIND2VAR "DimensionOfIndex2Vars"
#define OPT_DIMOFIND3VAR "DimensionOfIndex3Vars"

/* Special structure */
#define OPT_M1 "M1"
#define OPT_M2 "M2"

/* Rest */
#define OPT_EPS "eps"
#define OPT_IGPIDO "IncludeGridPointsInDenseOutput"
#define OPT_FUNCCALLMETHOD "FuncCallMethod"

typedef void (*RadauRightSide)(int *n, double *t,
  double *x, double *f,double *rpar, int *ipar);

typedef void (*RadauSolout)(int *nr, double *told,
  double *t, double *x, double *cont, int *lrc, 
  int *n,	double *rpar, int *ipar, int *irtrn);
  
typedef void (*RadauMAS)(int *n, double *am,
  int *lmas, double *rpar, int *ipar);
  
typedef void (*RadauJAC)(int *n, double *t,
  double *x, double *dfy, int *ldfy, double *rpar, int *ipar);

struct ListElement
{ /* Verkettete Liste mit (t,x)-Paaren, also Vektoren der L�nge d+1 */
  double* values;
  struct ListElement *next;
};
typedef struct ListElement SListElement;
typedef SListElement* PListElement;

struct ParameterIO 
{ /* Parameter f�r Input/Output zwischen Matlab und C */    
  const mxArray *opt;  /* Optionen */
  int optCreated;      /* Flag, ob Optionen selbst generiert wurden */
};
typedef struct ParameterIO SParameterIO;

struct ParameterGlobal 
{ /* globale Variablen usw. */
  int d;              /* Dimension des Systems */
  int tLength;        /* L�nge des t-Vektors */  
  double* tPointer;   /* Pointer auf Zeitdaten in tArray */  
  double direction;   /* sign(tEnd-tStart) */
  int funcCallMethod; /* Methode, um Matlab-Funktionen aufzurufen */
};
typedef struct ParameterGlobal SParameterGlobal;

struct ParameterRadau
{ /* Parameter f�r Radau (soweit nicht ausgelagert) */
  double tStart;    /* Startzeitpunkt */
  double tEnd;      /* Endzeitpunkt */
  double h;         /* Startschrittweite */
  int denseFlag;    /* Flag, ob dense-Output aktiv */
  double *xStart;   /* Startwert */
  double *RTOL;     /* releative Toleranz */
  double *ATOL;     /* absolute Toleranz */
  int ITOL;         /* Switch f�r RTOL und ATOL */  
  int IOUT;         /* Switch f�r SOLOUT */  
  double *WORK;     /* Double-Arbeits-Array */
  int LWORK;        /* L�nge von WORK */
  int *IWORK;       /* Integer-Arbeits-Array */
  int LIWORK;       /* L�nge von IWORK */
  double *RPAR;     /* Zusatz double-array */
  int *IPAR;        /* Zusatz int-array */
  int IDID;         /* Status */  
  int mm;           /* m1=mm*m2, falls m1,m2!=0 */
};
typedef struct ParameterRadau SParameterRadau;

struct RadauDense
{ /* Argumente zum Aufruf von CONTR5 */
  double *cont;
  int *lrc;
};
typedef struct RadauDense SRadauDense;

struct ParameterRightSide 
{ /* Parameter f�r rechte Seite f */
  char *rightSideFcn;           /* Funktionsname f�r rechte Seite */
  const mxArray *rightSideFcnH; /* Funktionshandle oder inline-function f�r rightSide */
  mxArray *tArg;                /* Zum Aufruf von f: t */
  mxArray *xArg;                /* Zum Aufruf von f: x */
};
typedef struct ParameterRightSide SParameterRightSide;

struct ParameterMassmatrix
{ /* Parameter f�r Massenmatrix */
  int IMAS;              /* Switch zur Berechnungsmethode f�r Massenmatrix */
  int MLMAS;             /* untere Bandbreite von Massenmatrix */
  int MUMAS;             /* obere Bandbreite von Massenmatrix */  
  RadauMAS radauMASFunc; /* Funktion f�r Massenmatrix aus Radau */
};
typedef struct ParameterMassmatrix SParameterMassmatrix;

struct ParameterJacobimatrix
{ /* Parameter f�r Jacobimatrix */
  int IJAC;               /* Switch zur Berechnungsmethode f�r Jacobi */
  int MLJAC;              /* untere Bandbreite von Jacobi */
  int MUJAC;              /* obere Bandbreite von Jacobi */
  RadauJAC radauJACFunc;  /* Funktion f�r Jacobimatrix aus Radau */
  char *jacFcn;           /* Funktion zur Berechnung der Jacobimatrix */
  const mxArray *jacFcnH; /* Funktionshandle oder inline-function f�r Jacobi */
  mxArray *tArg;          /* Zum Aufruf von jac: t */
  mxArray *xArg;          /* Zum Aufruf von jac: x */
};
typedef struct ParameterJacobimatrix SParameterJacobimatrix;

struct ParameterOutput
{ /* Parameter zum Speichern der Radau-Ausgabe */
  SListElement txList;        /* Start der txListe */
  PListElement lastTXElement; /* letzter Eintrag in txListe */
  int numberOfElements;       /* Anzahl der Eintr�ge in txListe */
  int tPos;                   /* Position im t-Vektor */
  int includeGrid;            /* Flag, dense Ausgabe mit Gridpoints */
  char* outputFcn;            /* Outputfunction */
  const mxArray *outputFcnH;  /* Outputfunction: handle oder inline-function */
  int outputCallMode;         /* Modus f�r outputFcn-Aufruf */
  mxArray *tArg;              /* Zum Aufruf von outputFcn: t */
  mxArray *xArg;              /* Zum Aufruf von outputFcn: x */
  mxArray *emptyArg;          /* Zum Aufurf von outputFcn: empty array [] */
  mxArray *toldArg;           /* Zum Aufruf von outputFcn: tOld */
};
typedef struct ParameterOutput SParameterOutput;
  
#ifdef FORTRANNOUNDER
/* Fotran functions without underscore */
#ifdef FORTRANUPP
/* Fotran functions without underscore  & UPPERCASE letters */
#define RADAU5_ RADAU5
#define CONTR5_ CONTR5
#else
/* Fotran functions without underscore  & lowercase letters */
#define RADAU5_ radau5
#define CONTR5_ contr5
#endif
#else
/* Fortran functions with underscore */
#ifdef FORTRANUPP
/* Fortran functions with underscore & UPPERCASE letters */
#else
/* Fortran functions with underscore & lowercase letters */
#define RADAU5_ radau5_
#define CONTR5_ contr5_
#endif
#endif

extern double CONTR5_ (int *i,
  double *x, double *cont, int *lrc);

extern void RADAU5_ (int *n, RadauRightSide fcn, 
  double *t, double *x, double *tend, double *h, 
  double *rtol, double *atol,int *itol,
  RadauJAC jac, int *ijac, int *mljac, int *mujac,
  RadauMAS mas, int *imas, int *mlmas, int *mumas,
  RadauSolout solout, int *iout,
  double *work, int *lwork,
  int *iwork, int *liwork,
  double *rpar, int *ipar, int* idid);

#endif
