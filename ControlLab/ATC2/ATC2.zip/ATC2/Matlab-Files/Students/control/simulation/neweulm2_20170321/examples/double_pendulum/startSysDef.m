%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% startSysDef                                                        %
%                                                                    %
% Program to build a multi-body-system model                         %
% This model is very good to get to know neweulm2. Here a            %
% double pendulum, which is probably the most famous system, is      %
% presented. The nice thing about this model is that it is quite     %
% simple but still shows nonlinear effects quite clearly.            %
% This model is prepared to include a force element and a time       %
% dependent excitation, which are disabled in the standard           %
% configuration.
%                                                                    %
% The definition is in the file sysDef.m                             %
% After this file has run, the system is fully available in symbolic %
% form, the numerical values for constants have been set and an      %
% animation window with graphic representations has been created.    %
% Then you have several possibilities as to what you want to do with %
% this model:                                                        %
% - runTimeInt performs a time integration                           %
% - runKiAn performs a kinematic analysis                            %
% - runModalAnalysis calculates Eigenmodes and displays them         %
%                                                                    %
% Of the files, which are called from here, the following are        %
% model specific. This means that you are kindly asked to adjust     %
% them to your need or copy them to start modelling a new system.    %
% - sysDef.m contains the system definition                          %
% - setUserVar.m assigns numerical values to constants. If called,   %
%   overwrites any values set in sysDef.m                            %
% - defineGraphics.m define graphic representations in the animation %
%   window                                                           %
%                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Author:       Dipl.-Ing. Thomas Kurz
%
% e-Mail:       kurz@itm.uni-stuttgart.de
%
% Institute:    University of Stuttgart
%               Institute of Engineering and Computational Mechanics
%               Pfaffenwaldring 9
%               70569 Stuttgart
%               GERMANY
%

%%%%%%%%%%%%%%%%%%%%%%%%
% Extend path variable %
%%%%%%%%%%%%%%%%%%%%%%%%

run('../addpathNeweulm2');

%%%%%%%%%%%%%%%%%%%%%%%%
% Initialize workspace %
%%%%%%%%%%%%%%%%%%%%%%%%

close all;
clear all;
clear global;
global sys;
tic;

%%%%%%%%%%%%%%%%%%%%%
% Define the system %
%%%%%%%%%%%%%%%%%%%%%

sysDef; % model-specific, please edit this file

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create nonlinear equations of motion %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

calcEqMotNonLin;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate reaction forces %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% calcForcesReaction;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create functions for numerical evaluation %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

writeMbsNonLin;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Linearize the equations of motion %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

calcEqMotLin;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create functions for numerical evaluation %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

writeMbsLin;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set numeric values for user defined parameters %
% This can also be done directly in sysDef.m     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% setUserVar; % model-specific, please edit this file

%%%%%%%%%%%%%%%%%%%%%%%%
% Initialize animation %
%%%%%%%%%%%%%%%%%%%%%%%%

createAnimationWindow;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Add shapes in the animation window %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

defineGraphics; % model-specific, please edit this file

%%%%%%%%%%%%%%%%%%%
% Save the system %
%%%%%%%%%%%%%%%%%%%

fprintf(1,'\nSaving System ...');
save 'sys.mat' sys;
fprintf(1,' ok!\n');

fprintf(1,'\n---\n');
toc;

% END OF startSysDef
