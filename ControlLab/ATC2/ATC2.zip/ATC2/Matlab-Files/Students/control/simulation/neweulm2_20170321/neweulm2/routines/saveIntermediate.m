% saveIntermediate(useIntermediateSave_)
% Save sys to neweulm2_tmp.mat for debugging reasons if
% useIntermediateSave_ is true
