% modifyBody - Change selected properties of bodies
% 
%  Syntax:
%> modifyBody;
%> modifyBody(bodyID,'Property', value, ...);
%    
%  Input arguments:
% bodyID ...... ID of the body to be changed
%
%  Optional input arguments, given pairwise:
% ID ............ Specify a new ID
% I ............. Specify a new tensor of inertia, only for rigid bodies
% JointSys ...... Specify a new joint system for an elastic body
% m ............. Specify a new mass, only for rigid bodies
% Name .......... Specify a new Name
% Oblique ....... Logical whether this body uses an orthogonal reduction or
%                 an oblique one. This should only be touched, if you know
%                 exactly, what you're doing
% phi_cg ........ Specify a new relative angular description,
%                 only for rigid bodies
% phi/phi_rel ... Specify a new angular description of the orientation 
% refsys ........ Specify a new frame of reference, from which the body is
%                 defined
% r_cg .......... Specify a new relative position of the center of gravity,
%                 only for rigid bodies
% r/r_rel ....... Specify a new relative position vector
% rotation ...... Specify a new constant rotation of this body
% sidFile ....... Specify a different elastic information, as newBody is
%                 called to read the information, all possibilities like
%                 giving a mat file or the data structure directly are
%                 preserved. It is possible to exchange the elastic
%                 information of a body without recalculating the equations
%                 of motion, as long as all of the following conditions are
%                 fulfilled:
%                 - sys.settings.equation.abbreviations == 2
%                 - the number of nodes does not change
% Struct ........ Give a data structure of the new body
%
%  Return values:
% data_ ....... New data substructure of this body
% flag_ ....... Flag specifying the success and consequences of the
%               function call:
%       -1 .... Some error occured
%        0 .... Successfull run, but equations have to be set up by calling
%               calcEqMotNonLin.
%        1 .... Successfull run, calculation can continue without further
%               adjustment or recomputation
%
%  See also:
% newBody, modifyFrame
% 
% First appearance: 30.05.2011 
%
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
