% drawRotBody - create rotational symmetric body.
% 
%  Description:
% drawRotBody creates rotational symmetric body. A vector of radii can be 
% specified to describe tubes, solid cylinders or arbitrary rotational
% symmetric shapes. For a solid cylinder, the first and last radius should
% be equal to 0. When specifying arbitrary shapes, you have to specify
% their location, presumably in z-direction, thus called zVec. If the zVec
% contains values and the range [0;1] and both, the 0 and 1 are present,
% the zVec is considered to be normalized and will be scaled with
% norm(ToVector). The central axis of the shape can be specified, using the
% FromVector and ToVector properties to define the end points. If nothing
% is specified, this axis will point in positive z-direction.
%
% The standard shape is considered to be a solid cylinder. Therefore if
% settings are omitted, reasonable assumptions for this case are taken. For
% only one radius vector and no zVector, a solid cylinder will be created.
%
% For legacy reasons the function call h = drawRotBody(rvec,zvec,varargin)
% is still supported.
%
%  Optional arguments, given pairwise:
% CData ........... The resulting patch object can be colored depending on
%                   the generalized coordinates. Here the user can specify
%                   a numerical matrix A as second argument, which should
%                   be of the size
%                   size(A) = [numFaces, numel(GenCoords), X], where
%                   GenCoords corresponds to the option of this name. This
%                   is necessary as the actual color values have to be a
%                   vector, which is  calculated by 
%                   A*y(strcmp(sys.model.genCoords,GenCoords)). The size X
%                   means, that the matrix may have an arbitrary third
%                   dimension. The handling of this third dimension is
%                   controlled via the 'cdataSelect' property. Instead of
%                   specifying the matrix, you can give a function handle
%                   myFunc to a function, which should be of the syntax
%                   myFunc(t,y,idx_y,sysOut), where idx_y denote the
%                   indices of the generalized coordinates specified here.
%                   {[]}
% CDataOut ........ Similar to the CData property, the coloring may depend
%                   on the system outputs as evaluated by outputs_all.m.
%                   Here the user should specify a matrix, as otherwise the
%                   CData option can be used to use function handles. As
%                   the user has to adjust the matrix dimensions, this is
%                   an advanced feature {[]}
% CDataSelect ..... For the coloring, a scalar value is required. When the
%                   CData property returns a vector, this option is used to
%                   determine which element to use. If a logical or
%                   numerical value is given, this specifies the element to
%                   be used. One can also specify a function handle or
%                   string denoting a function. The function vectorLength
%                   is provided. This function calculates the vector norm,
%                   meaning its length, for each row. It is a vectorized
%                   implementation of the norm() command, which would
%                   return a matrix norm instead. Please see
%                   updateGeo>vectorLength for more information. 
% Color ........... Set face and edgecolor to the same, overwrites
%                   FaceColor_ specified before
% EdgeAlpha ....... Transparency of the edges {1}
% EdgeColor ....... Color of the edges {'none'}
% FaceAlpha ....... Transparency of the faces {1}
% FaceColor ....... Color of the faces {'none'}
% FromVector ...... A constant translation can be specified with this
%                   setting {[0;0;0]}
% GenCoords ....... Cell array of names of generalized coordinates to be
%                   used for the deformation and dynamic coloring with
%                   cdata. {[]}
% Frame ........... Specify the coordinate system of Neweul-M2 to attach
%                   this shape to. Otherwise you would have to call
%                   addGraphics manually {[]}
% NumPoints ....... Number of interpolation points on circumference, {32}
% rVec ............ radii, specified at the axial positions given with
%                   zVec. If the first and last entry are equal to zero, a
%                   closed structure will be created.This parameter may
%                   contain symbolic constants of Neweul-M2 {[0 0.5 0.5 0]}
% ShapeFun ........ The resulting patch object can be deformed depending on
%                   the generalized coordinates. Here the user can specify
%                   a matrix, which should provide one row for each vertex
%                   of the surface. The deformation d is evaluated as
%                   d=A*y(strcmp(sys.model.genCoords,GenCoords)), where A
%                   is the given matrix, y the values of the generalized
%                   coordinates and GenCoords is a list of names of
%                   generalized coordinates to be used {[]}.
% ShapeFunOut ..... Similar to ShapeFun, the resulting patch object can be
%                   deformed depending on the system outputs. The user can
%                   specify a matrix with one row for each vertex of the
%                   surface and one column for each system output as
%                   evaluated by outputs_all.m. As the user has to adjust
%                   the matrix dimensions, this is an advanced feature {[]}
% ShapeFunOutScale ... Scaling factor for ShapeFunOut. This is necessary to
%                   ensure that the length of the arrows or other objects
%                   to be scaled dynamically with the output is reasonable
%                   {1}
% Tag ............. Set Tag property, for identification {'RotBody_1'}
% ToVector ........ The rotational axis of the created shape will point in
%                   the direction of the relative vector
%                   ToVector-FromVector. Therefore this vector specifies
%                   the orientation of the graphic shape. {[0;0;1]}
% zVec ............ axial positions of radii, specified with rVec. If this
%                   vector contains values in the range and including
%                   [0;1], this vector will be scaled to match
%                   norm(ToVector). This parameter may contain symbolic
%                   constants of Neweul-M2 {[0 0 1 1]}
%
%  Output arguments:
% h ............... graphics handle
%
%  Examples:
% h = drawRotBody('rVec',[0 0.1 0.1 0.2 0], 'zVec',[1 1 0.2 0.2 0]);
% h = drawRotBody('rVec',0.2, 'ToVector',[1 1 0],'Color',[1 0 0]);
%
%  See also: 
% drawArrow3d, drawCube, drawElasticBeam, drawLine, drawSphere,
% drawSTL, drawSpring
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
