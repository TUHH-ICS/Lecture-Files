% errorflag_ = DeleteBody(bodyID)
% 
% This file has to tasks to perform
% First it checks if the body with the id denoted in bodyID is used for the
% definition of coordinate systems or force elements. 
% If this is the case then an error is displayed, saying that this body
% cannot be deleted. Second if this is not the case then the complete body
% with all its coordinate systems, graphical objects, ... is deleted.
%
% Input arguments
% bodyID ... Id of the body to be deleted, if nothing is specified
%
% First appearance: 01.07.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
