% freqResPlot - Plot the frequency response
%
%  Syntax:
%> freqResPlot;
%> freqResPlot('Property', value, ...);
% 
%  Description:
% Creates a plot of the frequency response curve at given frequencies. To
% calculate the frequency response, the function freqResponse is used.
% 
%  Optional arguments:
% AddToAxes .......... Keep the existing axes content and draw this curve
%                      additionally, with 'hold on'. A valid axes handle
%                      should be passed as second argument. The parent
%                      figure is selected automatically. Alternatively, you
%                      can pass the figure handle, especially if the figure
%                      was also created by freqResPlot {[]}
% AmplitudeScaling ... Axis scaling for the amplitude {'log'}
% Color .............. Color of the frequency response curve
%                      (as RGB Vector) {[0 0 1]}
% Input .............. System input (see sys.model.input) {all system inputs}
% Figure ............. Figure to display the curve {create new figure}
% FrequencyScaling ... Axis scaling for the frequency {'linear'}
% Frequency .......... Vector with frequencies, for which the response shall be
%                      calculated {auto}
% LineStyle .......... Linestyle of the curves {'-'}
% LineWidth .......... Linewidth of the curves {1}
% Marker ............. Marker property of the curve {'none'{
% OnlyAmplitude ...... Plot only the amplitude {false}
% OnlyPhase .......... Plot only the phase angle {false}
% Output ............. System output (see sys.model.output) {all system outputs}
% PhaseScaling ....... Axis scaling for the phase {'linear'}
% Time ............... Simulation time, {0}
% CheckVarargin ...... An advanced feature to avoid errors if invalid
%                      parameters are passed. This is only if you know
%                      exactly what you are doing. {true}
% 
%  Return values:
% fh ................. Figure Handle
% ah ................. Axes Handles
% g .................. Frequency response matrix, evaluated at freqs, is of
%                      dimension size(g) = [length(out), length(in)]
% result ............. Data structure containing all information with the
%                      fields:
%     t .............. Simulation time for the evaluation
%     in ............. System inputs
%     out ............ System outputs
%     frequency ...... Vector with frequencies
%     g .............. Frequency response matrix
%     AmpScaling ..... Cell array with axis scaling of amplitude plot
%                      {get(gca,'XScale') get(gca,'YScale')}
%     PhaseScaling ... Cell array with axis scaling of phase plot
%                      {get(gca,'XScale') get(gca,'YScale')}
%
%  Examples:
%>   freqResPlot;
%>   [fh, ah, g] = freqResPlot();
%>   result = freqResPlot('input',{'myIn1','myIn2'});
%
%  See also: 
% freqResponse, calcEqMotLin, modalAnalysis
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
