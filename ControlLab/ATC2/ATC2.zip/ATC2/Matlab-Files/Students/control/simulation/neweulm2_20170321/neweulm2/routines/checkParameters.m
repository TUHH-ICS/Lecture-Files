% checkParameters - Check strings, cells, syms, structs and combinations of
% those for defined parameters. 
%
%  Syntax:
%> [undefinedParamters, dependsOn]  = checkParameters(varargin) 
%
%  Description: 
% Called with one output argument, this 
% function passes all undefined parameters or empty. If  called with two 
% output parameters, the second parameter is a struct containing all 
% dependencies of generalized coordinates, constant, time- or 
% state-dependent parameters, etc.
%
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
