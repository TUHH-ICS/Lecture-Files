/* m�gliche Fehler, werden in bvpsolMex.c included */

/* allgemeine Fehler */
case 1:
  mexPrintf("English: \n");
  mexPrintf("Only 1 or 2 output arguments are possible, but %i were requested.\n",i1);
  mexPrintf("German: \n");
  mexPrintf("Es werden 1 oder 2 Ausgabeargumente unterst�tzt. Verlangt wurden\n");
  mexPrintf("aber %i Ausgabeargumente.\n",i1);
  msg="Invalid number of output arguments (Ung�ltige Anzahl von Ausgabeargumenten)";break;
case 2:
  mexPrintf("English: \n");
  mexPrintf("Only 5,6 or 7 input arguments are possible, but %i were passed.\n",i1);
  mexPrintf("German: \n");
  mexPrintf("Es werden 5,6 oder 7 Eingabeargumente unterst�tzt. Es wurden aber\n");
  mexPrintf("%i Argumente �bergeben.\n",i1);
  msg="Invalid number of input arguments (Ung�ltige Anzahl von Eingabeargumenten)";break;
case 3:
  mexPrintf("English: \n");
  mexPrintf("1st argument has to be a string (function name), a function handle\n");
  mexPrintf("or an inline function.\n");
  mexPrintf("German: \n");
  mexPrintf("1. Argument muss ein String (Funktionsname), ein Funktions-Handle\n");
  mexPrintf("oder eine inline-Funktion sein.\n");
  msg="1. Arg: Function (String,handle,inline) expected";break;
case 4:
  mexPrintf("English: \n");
  mexPrintf("1st argument has characters, but needs to be ONE string. ");
  if (i1!=2) 
    mexPrintf("Not a 0-, 1- or >=3-dimensional thing.");
  else
    if (i2!=1) mexPrintf("Not a matrix containing strings.");
  mexPrintf("\n");
  mexPrintf("German: \n");
  mexPrintf("1. Argument enth�lt Zeichen, muss aber EIN String sein. ");
  if (i1!=2) 
    mexPrintf("Kein 0-,1- oder >=3-dimensionales Gebilde."); 
  else
    if (i2!=1) mexPrintf("Keine Matrix aus Strings.");
  mexPrintf("\n");
  msg="1. Arg: only ONE string expected (nur EIN String erwartet)";break;
case 5:
  mexPrintf("English: \n");
  mexPrintf("2nd argument has to be a string (function name), a function handle\n");
  mexPrintf("or an inline function.\n");
  mexPrintf("German: \n");
  mexPrintf("2. Argument muss ein String (Funktionsname), ein Funktions-Handle\n");
  mexPrintf("oder eine inline-Funktion sein.\n");
  msg="2. Arg: Function (String,handle,inline) expected";break;
case 6:
  mexPrintf("English: \n");
  mexPrintf("2nd argument has characters, but needs to be ONE string. ");
  if (i1!=2) 
    mexPrintf("Not a 0-, 1- or >=3-dimensional thing.");
  else
    if (i2!=1) mexPrintf("Not a matrix containing strings.");
  mexPrintf("\n");
  mexPrintf("German: \n");
  mexPrintf("2. Argument enth�lt Zeichen, muss aber EIN String sein. ");
  if (i1!=2) 
    mexPrintf("Kein 0-,1- oder >=3-dimensionales Gebilde."); 
  else
    if (i2!=1) mexPrintf("Keine Matrix aus Strings.");
  mexPrintf("\n");
  msg="2. Arg: only ONE string expected (nur EIN String erwartet)";break;
case 7:
  mexPrintf("English: \n");
  mexPrintf("3rd argument has to be a string (function name), a function handle\n");
  mexPrintf("or an inline function.\n");
  mexPrintf("German: \n");
  mexPrintf("3. Argument muss ein String (Funktionsname), ein Funktions-Handle\n");
  mexPrintf("oder eine inline-Funktion sein.\n");
  msg="3. Arg: Function (String,handle,inline) expected";break;
case 8:
  mexPrintf("English: \n");
  mexPrintf("3rd argument has characters, but needs to be ONE string. ");
  if (i1!=2) 
    mexPrintf("Not a 0-, 1- or >=3-dimensional thing.");
  else
    if (i2!=1) mexPrintf("Not a matrix containing strings.");
  mexPrintf("\n");
  mexPrintf("German: \n");
  mexPrintf("3. Argument enth�lt Zeichen, muss aber EIN String sein. ");
  if (i1!=2) 
    mexPrintf("Kein 0-,1- oder >=3-dimensionales Gebilde."); 
  else
    if (i2!=1) mexPrintf("Keine Matrix aus Strings.");
  mexPrintf("\n");
  msg="3. Arg: only ONE string expected (nur EIN String erwartet)";break;
case 9:
  mexPrintf("English: \n");
  mexPrintf("4th argument has to be a double vector.\n");
  mexPrintf("German: \n");
  mexPrintf("4. Argument muss ein double-Vektor sein.\n");
  msg="4. Arg: double vector expected (double-Vektor erwartet)";break;
case 10:
  mexPrintf("English: \n");
  mexPrintf("4th argument has to be a double vector.\n");
  mexPrintf("Not a 0-, 1- or >=3-dimensional thing.\n");
  mexPrintf("German: \n");
  mexPrintf("4. Argument muss ein double-Vektor sein. Kein\n");
  mexPrintf("0-,1- oder >=3-dimensionales Gebilde.\n");
  msg="4. Arg: double vector expected (double-Vektor erwartet)";break;
case 11:
  mexPrintf("English: \n");
  mexPrintf("4th argument has to be a double vector.\n");
  mexPrintf("But I found a (%i,%i) matrix.\n",i1,i2);
  mexPrintf("German: \n");
  mexPrintf("4. Argument muss ein double-Vektor sein. Gefunden\n");
  mexPrintf("wurde aber eine (%i,%i) Matrix.\n",i1,i2);
  msg="4. Arg: double vector expected (double-Vektor erwartet)";break;
case 12:
  mexPrintf("English: \n");
  mexPrintf("4th argument has to be a double vector with at least\n");
  mexPrintf("two components. But I found a vector of length %i.\n",i1);
  mexPrintf("German: \n");
  mexPrintf("4. Argument muss ein double-Vektor mit mindestens\n");
  mexPrintf("der L�nge 2 sein. Der gefundene Vektor hat aber eine\n");
  mexPrintf("L�nge von %i.\n",i1);
  msg="4. Arg: double vector with two or more components expected (double-Vektor mit mindestens der L�nge 2 erwartet)";break;
case 13:
  mexPrintf("English: \n");
  mexPrintf("4th argument has to be ordered (ascending).\n");
  mexPrintf("German: \n");
  mexPrintf("4. Argument muss ein aufsteigend sortierter Vektor sein.\n");
  msg="4. Arg: has to be ordered (muss sortiert sein) ";break;
case 14:
  mexPrintf("English: \n");
  mexPrintf("5th argument has to be a double matrix.\n");
  mexPrintf("German: \n");
  mexPrintf("5. Argument muss eine double-Matrix sein.\n");
  msg="5. Arg: double matrix expected (double-Matrix erwartet)";break;
case 15:
  mexPrintf("English: \n");
  mexPrintf("5th argument has to be a double matrix.\n");
  mexPrintf("Not a 0-, 1- or >=3-dimensional thing.\n");
  mexPrintf("German: \n");
  mexPrintf("5. Argument muss eine double-Matrix sein, kein\n");
  mexPrintf("0-,1- oder >=3-dimensionales Gebilde.\n");
  msg="5. Arg: double matrix expected (double-Matrix erwartet)";break;
case 16:
  mexPrintf("English: \n");
  mexPrintf("In the 4th argument a found a vector with\n");
  mexPrintf("%i shooting nodes.\n",i1);
  mexPrintf("In the 5th argument I found (%i,%i) double matrix,\n",i2,i3);
  mexPrintf("but I expected a matrix with %i colums (one for\n",i1);
  mexPrintf("each shooting node).\n");
  mexPrintf("German: \n");
  mexPrintf("Im 4. Argument wurde ein St�tzstellen double-Vektor\n");
  mexPrintf("mit %i shooting nodes �bergeben.\n",i1);
  mexPrintf("Im 5. Argument wurde aber eine (%i,%i) double-Matrix\n",i2,i3);
  mexPrintf("�bergeben. Sie m�sste aber %i Spalten haben (f�r jeden\n",i1);
  mexPrintf("shooting node eine Spalte).\n");
  msg="4./5. Arg: inconsistent dimensions (inkonsistente Dimensionen)";break;
case 17:
  mexPrintf("English: \n");
  mexPrintf("6th argument has to be a struct (if given).\n");
  mexPrintf("German: \n");
  mexPrintf("6. Argument muss eine struct sein (falls angegeben).\n");
  msg="6. Arg: struct expected (struct erwartet)";break;
case 18:
  mexPrintf("English: \n");
  mexPrintf("7th argument has to be a struct (if given).\n");
  mexPrintf("German: \n");
  mexPrintf("7. Argument muss eine struct sein (falls angegeben).\n");
  msg="7. Arg: struct expected (struct erwartet)";break;
case 19:
  mexPrintf("English: \n");
  mexPrintf("The 3rd argument was empty. Hence difex1 is used as\n");
  mexPrintf("ODE solver. But this solver does not support any options.\n");
  mexPrintf("Then the 7th argument is useless.\n");
  mexPrintf("German: \n");
  mexPrintf("Das 3. Argument war leer, also wird difex1 als AWP-L�ser\n");
  mexPrintf("verwendet. Da werden aber keine zus�tzlichen Optionen\n");
  mexPrintf("unterst�tzt! Also ist das 7. Eingabeargument nutzlos.\n");
  msg="7. Arg: whole argument unexpected because built-in solver is used (unerwartet, da built-in AWP-L�ser zum Einsatz kommt)";break;
case 20:
  mexPrintf("English: \n");
  mexPrintf("Concerning Option '%s':\n",OPT_FUNCCALLMETHOD);
  mexPrintf("Requirement: '%s'==0 or '%s'==1\n",OPT_FUNCCALLMETHOD,OPT_FUNCCALLMETHOD);
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_FUNCCALLMETHOD);
  mexPrintf("Es muss gelten: '%s'==0 or '%s'==1\n",OPT_FUNCCALLMETHOD,OPT_FUNCCALLMETHOD);
  msg="Invalid call method (ung�ltige Methode f�r Funktionsaufruf)";break;
case 21:
  mexPrintf("English: \n");
  mexPrintf("1st argument contained inline-funcs or function handles, but I need only ONE. ");
  if (i1!=2) 
    mexPrintf("Not a 0-, 1- or >=3-dimensional thing.");
  else
    if ((i2!=1) || (i3!=1)) 
      mexPrintf("Not a matrix containing inline-funcs or function handles.");
  mexPrintf("\n");
  mexPrintf("German: \n");
  mexPrintf("1. Argument enth�lt zwar Inline-Funktionen oder Funktions-Handles, aber");
  mexPrintf("ben�tigt wird nur EIN Handle oder EINE Inline-Funktion. ");
  if (i1!=2) 
    mexPrintf("Kein 0-,1- oder >=3-dimensionales Gebilde."); 
  else
    if ((i2!=1) || (i3!=1)) 
      mexPrintf("Keine Matrix mit Inline-Funktionen oder Funktions-Handles .");
  mexPrintf("\n");
  msg="1. Arg: only ONE function expected (nur EINE Funktion erwartet)";break;
case 22:
  mexPrintf("English: \n");
  mexPrintf("Concerning Option '%s':\n",OPT_FUNCCALLMETHOD);
  mexPrintf("'%s'==0 was chosen. Hence all Matlab-functions must be given as string.\n",
    OPT_FUNCCALLMETHOD);
  mexPrintf("But the rightSide was not a string.\n");
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_FUNCCALLMETHOD);
  mexPrintf("Es wurde '%s'==0 gew�hlt. Also m�ssen alle Matlab-Funktionen als String angegeben werden.\n",
    OPT_FUNCCALLMETHOD);
  mexPrintf("Aber die rechte Seite war kein String mit Funktionsname.\n");
  msg="CallMethod 0 => all Matlab-Funcs must be given as Strings (Bei Aufrufmethode 0: m�ssen Funktionsnamen �bergeben werden)";break;
case 23:
  mexPrintf("English: \n");
  mexPrintf("2nd argument contained inline-funcs or function handles, but I need only ONE. ");
  if (i1!=2) 
    mexPrintf("Not a 0-, 1- or >=3-dimensional thing.");
  else
    if ((i2!=1) || (i3!=1)) 
      mexPrintf("Not a matrix containing inline-funcs or function handles.");
  mexPrintf("\n");
  mexPrintf("German: \n");
  mexPrintf("2. Argument enth�lt zwar Inline-Funktionen oder Funktions-Handles, aber");
  mexPrintf("ben�tigt wird nur EIN Handle oder EINE Inline-Funktion. ");
  if (i1!=2) 
    mexPrintf("Kein 0-,1- oder >=3-dimensionales Gebilde."); 
  else
    if ((i2!=1) || (i3!=1)) 
      mexPrintf("Keine Matrix mit Inline-Funktionen oder Funktions-Handles .");
  mexPrintf("\n");
  msg="2. Arg: only ONE function expected (nur EINE Funktion erwartet)";break;
case 24:
  mexPrintf("English: \n");
  mexPrintf("Concerning Option '%s':\n",OPT_FUNCCALLMETHOD);
  mexPrintf("'%s'==0 was chosen. Hence all Matlab-functions must be given as string.\n",
    OPT_FUNCCALLMETHOD);
  mexPrintf("But the boundary function was not a string.\n");
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_FUNCCALLMETHOD);
  mexPrintf("Es wurde '%s'==0 gew�hlt. Also m�ssen alle Matlab-Funktionen als String angegeben werden.\n",
    OPT_FUNCCALLMETHOD);
  mexPrintf("Aber die Boundary-Funktion war kein String mit Funktionsname.\n");
  msg="CallMethod 0 => all Matlab-Funcs must be given as Strings (Bei Aufrufmethode 0: m�ssen Funktionsnamen �bergeben werden)";break;
case 25:
  mexPrintf("English: \n");
  mexPrintf("3rd argument contained inline-funcs or function handles, but I need only ONE. ");
  if (i1!=2) 
    mexPrintf("Not a 0-, 1- or >=3-dimensional thing.");
  else
    if ((i2!=1) || (i3!=1)) 
      mexPrintf("Not a matrix containing inline-funcs or function handles.");
  mexPrintf("\n");
  mexPrintf("German: \n");
  mexPrintf("3. Argument enth�lt zwar Inline-Funktionen oder Funktions-Handles, aber");
  mexPrintf("ben�tigt wird nur EIN Handle oder EINE Inline-Funktion. ");
  if (i1!=2) 
    mexPrintf("Kein 0-,1- oder >=3-dimensionales Gebilde."); 
  else
    if ((i2!=1) || (i3!=1)) 
      mexPrintf("Keine Matrix mit Inline-Funktionen oder Funktions-Handles .");
  mexPrintf("\n");
  msg="3. Arg: only ONE function expected (nur EINE Funktion erwartet)";break;
case 26:
  mexPrintf("English: \n");
  mexPrintf("Concerning Option '%s':\n",OPT_FUNCCALLMETHOD);
  mexPrintf("'%s'==0 was chosen. Hence all Matlab-functions must be given as string.\n",
    OPT_FUNCCALLMETHOD);
  mexPrintf("But the ode solver function was not a string.\n");
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_FUNCCALLMETHOD);
  mexPrintf("Es wurde '%s'==0 gew�hlt. Also m�ssen alle Matlab-Funktionen als String angegeben werden.\n",
    OPT_FUNCCALLMETHOD);
  mexPrintf("Aber die AWP-L�ser-Funktion war kein String mit Funktionsname.\n");
  msg="CallMethod 0 => all Matlab-Funcs must be given as Strings (Bei Aufrufmethode 0: m�ssen Funktionsnamen �bergeben werden)";break;


/* Fehler bei den IOPT bzw. TOL */
case 101:
  mexPrintf("English: \n");
  mexPrintf("Concerning option '%s':\n",OPT_MAXITER);
  mexPrintf("Requirement: '%s'>0.\n",OPT_MAXITER);
  mexPrintf("But I found: '%s'=%i.\n",OPT_MAXITER,i1);
  mexPrintf("German: \n");
  mexPrintf("Betrifft Option '%s':\n",OPT_MAXITER);
  mexPrintf("Es sollte '%s'>0 sein. Gefunden wurde aber ein\n",OPT_MAXITER);
  mexPrintf("Wert von %i.\n",i1);
  msg="invalid number of maximal permitted iteration steps (ung�ltige Anzahl von maximalen Iterationen)";break;
case 102:
  mexPrintf("English: \n");
  mexPrintf("Concerning option '%s':\n",OPT_CLASS);
  mexPrintf("Requirement: 0<='%s'<=3.\n",OPT_CLASS);
  mexPrintf("But I found '%s'=%i.\n",OPT_CLASS,i1);
  mexPrintf("German: \n");
  mexPrintf("Betrifft Option '%s':\n",OPT_CLASS);
  mexPrintf("Es muss gelten: 0<='%s'<=3. Gefunden wurde aber ein\n",OPT_CLASS);
  mexPrintf("Wert von %i.\n",i1);
  msg="invalid problem classification (ung�ltige Problemklassifikation)";break;
case 103:
  mexPrintf("English: \n");
  mexPrintf("Concerning option '%s':\n",OPT_SOLMETHOD);
  mexPrintf("Requirement: 0<='%s'<=1.\n",OPT_SOLMETHOD);
  mexPrintf("But I found: '%s'=%i.\n",OPT_SOLMETHOD,i1);
  mexPrintf("German: \n");
  mexPrintf("Betrifft Option '%s':\n",OPT_SOLMETHOD);
  mexPrintf("Es muss gelten: 0<='%s'<=1. Gefunden wurde aber ein\n",OPT_SOLMETHOD);
  mexPrintf("Wert von %i.\n",i1);
  msg="invalid solution method (ung�ltige Angabe der Solution Method)";break;  
case 104:
  mexPrintf("English: \n");
  mexPrintf("Concerning option '%s':\n",OPT_RELTOL);
  mexPrintf("Requirement: 0<'%s':\n",OPT_RELTOL);
  mexPrintf("German: \n");
  mexPrintf("Betrifft Option '%s':\n",OPT_RELTOL);
  mexPrintf("Es muss gelten: 0<'%s'.\n",OPT_RELTOL);
  msg="invalid relative tolerance (ung�ltige relative Genauigkeit)";break;
 
/* Errors concerning rightSide */
/* Fehler beim Aufruf der rechten Seite */
case 201:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the right side.\n");
  mexPrintf("I have not got return values.\n");
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der rechten Seite.\n");
  mexPrintf("Habe keine R�ckgabe erhalten.\n");
  msg="Right side without return values (Rechte Seite ohne R�ckgabe)";break;
case 202:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the right side.\n");
  mexPrintf("Return value was not a double vector.\n");
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der rechten Seite.\n");
  mexPrintf("Die R�ckgabe war kein double-Vektor.\n");
  msg="Return value was not a double vector (R�ckgabe der rechten Seite kein double-Vektor)";break;
case 203:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the right side.\n");
  mexPrintf("The return value was not a (d,1) or (1,d) double Vector.\n");
  mexPrintf("A (%i,%i) double matrix was returned.\n",i1,i2);
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der rechten Seite.\n");
  mexPrintf("Die R�ckgabe war kein (d,1) oder (1,d) double-Vektor.\n");
  mexPrintf("Es wurde eine (%i,%i) double-Matrix zur�ckgegeben.\n",i1,i2);
  msg="Return value of right side was not a (d,1) or (1,d) double vector (R�ckgabe der rechten Seite kein (d,1) oder (1,d) double-Vektor)";break;
  
/* Errors concerning the boundary function */
/* Fehler beim Aufruf der Boundary Function */
case 301:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the boundary function.\n");
  mexPrintf("I have not got return values.\n");
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der Boundary-Funktion.\n");
  mexPrintf("Habe keine R�ckgabe erhalten.\n");
  msg="boundary function without return values (Boundry-Funktion ohne R�ckgabe)";break;
case 302:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the boundary function.\n");
  mexPrintf("Return value was not a double vector.\n");
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der Boundary-Funktion.\n");
  mexPrintf("Die R�ckgabe war kein double-Vektor.\n");
  msg="Return value was not a double vector (R�ckgabe der Boundry-Funktion kein double-Vektor)";break;
case 303:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the boundary function.\n");
  mexPrintf("The return value was not a (d,1) or (1,d) double Vector.\n");
  mexPrintf("A (%i,%i) double matrix was returned.\n",i1,i2);
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der Boundary-Funktion.\n");
  mexPrintf("Die R�ckgabe war kein (d,1) oder (1,d) double-Vektor.\n");
  mexPrintf("Es wurde eine (%i,%i) double-Matrix zur�ckgegeben.\n",i1,i2);
  msg="Return value of boundary function was not a (d,1) or (1,d) double vector (R�ckgabe der Boundary-Funktion kein (d,1) oder (1,d) double-Vektor)";break;
  
/* Fehler beim Aufruf des (externen) AWP-L�sers */
case 401:
  mexPrintf("English: \n");
  mexPrintf("Problem with ODE solver.\n");
  mexPrintf("Didn't get 4 return values:\n");
  mexPrintf("The output argument number %i was NULL.\n",i1);
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf des AWP-L�sers.\n");
  mexPrintf("Habe keine 4 R�ckgabewerte bekommen; genauer:\n");
  mexPrintf("Das Ausgabeargument %i war NULL.\n",i1);
  msg="ODE solver with missing return value (AWP-L�ser mit fehlender R�ckgabe)";break;
case 402:
  msg="This shouldn't happen (Das d�rfte nicht passieren)";break;
case 403:
  msg="This shouldn't happen (Das d�rfte nicht passieren)";break;
case 404:
  mexPrintf("English: \n");
  mexPrintf("Problem with ODE solver.\n");
  mexPrintf("The 2nd output argument was not a double matrix.\n");
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf des AWP-L�sers.\n");
  mexPrintf("Das 2. R�ckgabeargument war keine double-Matrix.\n");
  msg="2. output-arg: double matrix expected (double-Matrix erwartet)";break;
case 405:
  mexPrintf("English: \n");
  mexPrintf("Problem with ODE solver.\n");
  mexPrintf("The solver returned a (%i,%i) double matrix.\n",i1,i2);
  mexPrintf("I expected a matrix with d=%i columns and\n",paramBVPSOL.d);
  mexPrintf("at least one row.\n");
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf des AWP-L�sers.\n");
  mexPrintf("Es wurde eine (%i,%i) double-Matrix zur�ckgegeben.\n",i1,i2);
  mexPrintf("Es wurde aber eine Matrix mit %i Spalten erwartet\n",paramBVPSOL.d);
  mexPrintf("und mindestens einer Zeile.\n");
  msg="2. output-arg: matrix with d columns expected (double-Matrix mit d Spalten erwartet)";break;
case 406:
  mexPrintf("English: \n");
  mexPrintf("Problem with ODE solver.\n");
  mexPrintf("The 3rd output argument wasn't a double vector.\n");
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf des AWP-L�sers.\n");
  mexPrintf("Das 3. R�ckgabeargument war kein double-Vektor.\n");
  msg="3. output-arg: double vector expected (double-Vektor erwartet)";break;
case 408:
  mexPrintf("English: \n");
  mexPrintf("Problem with ODE solver.\n");
  mexPrintf("The 4th argument was not a double value.\n");
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf des AWP-L�sers.\n");
  mexPrintf("Das 4. R�ckgabeargument war kein double-Wert.\n");
  msg="4. output-arg: double value expected (double-Wert erwartet)";break;
  
/* Fehler mit dem built-in difex1 AWP-L�ser */
case 501:
  mexPrintf("English: \n");
  mexPrintf("Problem with the builtin difex1 ODE solver.\n");
  mexPrintf("This olver supports systems up to dimension 51. But\n");
  mexPrintf("your system dimension is %i>51.\n",paramBVPSOL.d);
  mexPrintf("Comment: For difex1 the maximal supported dimension\n");
  mexPrintf("is given at compile time (sigh!).\n");
  mexPrintf("German: \n");
  mexPrintf("Problem mit built-in difex1 AWP-L�ser.\n");
  mexPrintf("Dieser L�ser wird mit einem Satz von Standard-Parametern\n");
  mexPrintf("verwendet. Er kann h�chstens eine Systemdimension\n");
  mexPrintf("von 51 verarbeiten. Die Systemdimension hier ist\n");
  mexPrintf("nun aber %i>51.\n",paramBVPSOL.d);
  mexPrintf("Anmerkung: Bei difex1 wird die maximale Systemdimension\n");
  mexPrintf("bei der Kompilierungszeit festgelegt (leider).\n");
  msg="system dimension too high for built-in solver (zu gro�e Systemdimension f�r built-in difex1)";break;

/* Errors that should never occur */
/* Fehler, die niemals auftreten sollten */
case 1001:
  mexPrintf("bvpsol.f has not enough memory.\n");
  mexPrintf("�bergebener Speicher reicht nicht!\n");
  msg="Uups! This should never happen (Das sollte nie passieren)";break;
case 1002:
  msg="internal error: unknown funcCallMethod";
  break;
  
