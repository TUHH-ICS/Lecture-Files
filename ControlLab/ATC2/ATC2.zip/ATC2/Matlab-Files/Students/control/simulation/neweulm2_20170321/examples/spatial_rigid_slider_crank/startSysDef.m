%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% startSysDef                                                        %
%                                                                    %
% IFToMM Benchmark Problem - Spatial Rigid Slider-crank Mechanism    %
%                                                                    %
% The definition is in the file sysDef.m                             %
%                                                                    %
% Of the files, which are called from here, the following are        %
% model specific. This means that you are kindly asked to adjust     %
% them to your need or copy them to start modelling a new system.    %
% - sysDef.m contains the system definition                          %
% - defineGraphics.m define graphic representations in the animation %
%   window                                                           %
% - runTimeInt runs time integration                                 %
% - writeSolution writes the time vector, the slider position and    %
%   the Crank angle into a file solution_neweulm2.txt                %
%                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Author:       Dipl.-Ing. Christian Sperle
%
% Institute:    Universitaet Stuttgart
%               Institut fuer Technische und Numerische Mechanik
%               Pfaffenwaldring 9
%               70569 Stuttgart
%

%%%%%%%%%%%%%%%%%%%%%%%%
% Extend path variable %
%%%%%%%%%%%%%%%%%%%%%%%%
% The first time, Matlab needs to know where the files of neweulm2 are
% located. The following line is to make the function addpathNeweulm2
% available, which does everything else
addpath('..');
% If your models are not in the default location, e.g. in
% '/home/user/myneweulm2/' please change the following line so you specify
% the folder containing the file calcEqMotNonLin.m in the following way:
% addpathNeweulm2('Folder','/home/user/myneweulm2/');
addpathNeweulm2;

%%%%%%%%%%%%%%%%%%%%%%%%
% Initialize workspace %
%%%%%%%%%%%%%%%%%%%%%%%%

close all;
clear global;
global sys;

tic;

%%%%%%%%%%%%%%%%%%%%%
% Define the system %
%%%%%%%%%%%%%%%%%%%%%

formulation = 'minimal';
% formulation = 'newtonEuler';
% formulation = 'recursiveMinimal';

sysDef(formulation); % model-specific, please edit this file

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create nonlinear equations of motion %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

calcEqMotNonLin;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create functions for numerical evaluation %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

writeMbsNonLin;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Export system for faster calculation %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

exportSystem2C;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Add shapes in the animation window %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

defineGraphics; % model-specific, please edit this file

toc;

%%%%%%%%%%%%%%%%%%%%%%%%
% Run time integration %
%%%%%%%%%%%%%%%%%%%%%%%%

runTimeInt;

%%%%%%%%%%%%%%%%%%%
% Save the system %
%%%%%%%%%%%%%%%%%%%

n2StatusOutput('\nSaving results ... ');
save 'sys.mat' sys;
n2StatusOutput('ok!\n');

writeSolution;

% END OF startSysDef
