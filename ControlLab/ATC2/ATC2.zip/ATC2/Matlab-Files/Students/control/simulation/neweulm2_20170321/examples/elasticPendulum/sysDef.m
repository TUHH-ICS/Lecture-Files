% sysDef
% System definition elasticPendulum
% This model is meant as a comparison between two elastic bodies, modeled
% with different frames of reference and a rigid body.
% 
% Please consider the file setUserVar.m, which can be used to set numerical
% values to parameters.
%


% Create basic data structure
newSys('Id','elasticPendulum', 'Name','elastic pendulum','simplify',6);

%%%%%%%%%%%%%%%%%%%%
% Pendulum 1 and 2 %
%%%%%%%%%%%%%%%%%%%%
%% Create elastic bodies using Ansys
% The elastic beams have the following properties:
% Type: Bernoulli-Beams / Beam4 elements
% Cross-section: rectangular
% Width  (y'): 0.01 m
% Height (z'): 0.01 m
% Length (x'): 1 m
% Orientation: along negative z-axis
% Young's modulus: 7e10 N/m
% Poisson's ratio: 0.3
% Mass density: 2750 kg/m^3
% Number of nodes: 5
% Number of eigenmodes: 4
% Constraints on complete beam: y-trans, x-rot, z-rot: planar in yz-plane
% 
% The elastic beams can be created using Ansys:
% 
% createAnsysBeam('axis',-3, 'width',1e-2, 'height',1e-2, ...
%     'nnodes',5, 'nmodes',4, 'constraints',[0;1;0;0;0;0], ...
%     'sidName','BODY_5nodes_3modes_nodalfixed.SID_FEM');
% 
% createAnsysBeam('axis',-3, 'width',1e-2, 'height',1e-2, ...
%     'nnodes',5, 'nmodes',[4:7], 'constraints',[0;1;0;0;0;0], ...
%     'conRefSys',false(6,1), 'sidName','BODY_5nodes_3modes_freefree.SID_FEM');
%
% A creation of the beams using the GUI as shown in the screenshots is not
% recommended due to the orientation of the elastic beams.

%% Multibody modelling
% Generalized coordinates
newGenCoord('alpha1','alpha2','alpha3');

% Pendulum 1 is an elastic body, modeled with beam elements staying in the
% xz-Plane. Modeling is done by calling Create_Elastic_Body. This command
% can be entered in the command prompt or called from the GUI. To show the
% settings, 4 screenshots are available, showing the settings for a
% nodalfixed and a freefree supported system.

newGenCoord('x1','x2','x3');
newFrame('Id','support1','RelPos','[x1; -1;0]');
newFrame('Id','support2','RelPos','[x2;  0;0]');
newFrame('Id','support3','RelPos','[x3;  1;0]');
newConstant('alpha0',0);

% Frame of reference is nodalfixed
newBody('Id','P1', 'Name','Pendulum 1', ...
        'RefSys','support1', ...
        'RelPos','[0; 0; 0]', 'RelRot','[0; alpha0+alpha1; 0]', ...
        'SIDfile','BODY_5nodes_3modes_nodalfixed.SID_FEM');

% Frame of reference is a Buckens-frame in the center of gravity
newBody('Id','P2', 'Name','Pendulum 2', ...
        'RefSys','support2', ...
        'RelPos','[0; 0; 0]', 'RelRot','[0; alpha0+alpha2; 0]', ...
        'SIDfile','BODY_5nodes_3modes_freefree.SID_FEM', ...
        'JointSys','P2_1');

% rigid body
newConstant('mr3',0.275, 'Ir3x', 4.5833e-06, 'Ir3y', 0.022919, 'Ir3z', 0.022919);
newBody('Id','P3', 'Name','Rigid Pendulum 3', ...
        'RefSys','support3', ...
        'RelPos','[0; 0; 0]', 'RelRot','[0; alpha0+alpha3; 0]', ...
        'CgPos', '[0;0;-0.5]', 'Mass','mr3', ...
        'Inertia', diag(sym('[Ir3x,Ir3y,Ir3z]')));
newFrame('Id','P3_1','RefSys','P3','RelPos','[0;0;0]');
newFrame('Id','P3_5','RefSys','P3','RelPos','[0;0;-1]');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Weights at the end of the beams %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
newConstant('m1',2);
newBody('Id','Weight1','Name','Weight at the end of the beam 1', ...
    'RefSys','P1_5', ...
    'Mass','m1','Inertia',sym('0.01*m1')*eye(3));
newConstant('m2',2);
newBody('Id','Weight2','Name','Weight at the end of the beam 2', ...
    'RefSys','P2_5', ...
    'Mass','m2','Inertia',sym('0.01*m2')*eye(3));
newConstant('m3',2);
newBody('Id','Weight3','Name','Weight at the end of the beam 3', ...
    'RefSys','P3_5', ...
    'Mass','m3','Inertia',sym('0.01*m3')*eye(3));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Force element to support the elastic beams %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
newConstant('kt',25,'dt',2,'kr',5,'dr',0.2,'l0r',0);
newForceElem('Id','FelemSupport1','Name','Force element to support the elastic beam 1', ...
    'Type','SpringDampCmp','frame1','ISYS','frame2','P1_1', ...
    'Stiffness','[kt;0;0;0;kr;0]', 'Damping','[dt;0;0;0;dr;0]','NomLength','[0;0;0;0;l0r;0]');
newForceElem('Id','FelemSupport2','Name','Force element to support the elastic beam 2', ...
    'Type','SpringDampCmp','frame1','ISYS','frame2','P2_1', ...
    'Stiffness','[kt;0;0;0;kr;0]', 'Damping','[dt;0;0;0;dr;0]','NomLength','[0;0;0;0;l0r;0]');
newForceElem('Id','FelemSupport3','Name','Force element to support the rigid beam 3', ...
    'Type','SpringDampCmp','frame1','ISYS','frame2','P3_1', ...
    'Stiffness','[kt;0;0;0;kr;0]', 'Damping','[dt;0;0;0;dr;0]','NomLength','[0;0;0;0;l0r;0]');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Excitation for the elastic beams %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Prepare everything for a time excitation being position driven. 
% But set the amplitude to zero, so currently it is not active
newConstant('phi0',0,'omega',50*2*pi);
newTimeDependent('phi1','phi0*cos(omega*t)');
newForceElem('Id','Excitation1','Name','Excitation of elastic beam 1', ...
    'Type','General','frame1','P1_1','frame2','support1', ...
    'ForceLaw','[0;0;0;0;phi1;0]');
newForceElem('Id','Excitation2','Name','Excitation of elastic beam 2', ...
    'Type','General','frame1','P2_1','frame2','support2', ...
    'ForceLaw','[0;0;0;0;phi1;0]');
newForceElem('Id','Excitation3','Name','Excitation of elastic beam 3', ...
    'Type','General','frame1','P3_1','frame2','support3', ...
    'ForceLaw','[0;0;0;0;phi1;0]');

%%%%%%%%%%%%%%%%%
%% System input %
%%%%%%%%%%%%%%%%%
newInput('Id','Excitation1', ...
    'Name','Excitation via the force element 1', 'Var','phi1');

%%%%%%%%%%%%%%%%%%
%% System output %
%%%%%%%%%%%%%%%%%%
newOutput('Id','Weight1_x','Name','x-Position of Weight1', ...
    'Var','Weight1.r(1)','Type','kinematic');
newOutput('Id','Weight1_z','Name','z-Position of Weight1', ...
    'Var','Weight1.r(3)','Type','kinematic');
newOutput('Id','Weight2_x','Name','x-Position of Weight2', ...
    'Var','Weight2.r(1)','Type','kinematic');
newOutput('Id','Weight2_z','Name','z-Position of Weight2', ...
    'Var','Weight2.r(3)','Type','kinematic');
newOutput('Id','Weight3_x','Name','x-Position of Weight3', ...
    'Var','Weight3.r(1)','Type','kinematic');
newOutput('Id','Weight3_z','Name','z-Position of Weight3', ...
    'Var','Weight3.r(3)','Type','kinematic');

% newOutput('Id','Weight1_roty','Name','Orientation around y-axis of Weight', ...
%     'Var','Weight1.phi(2)','Type','kinematic');
% newOutput('Id','Excitation','Name','Time dependent excitation angle phi1', ...
%     'Var','phi1','Type','userDef','Group','additional');
% newOutput('Id','applForce1_my','Name','Applied force between ISYS and beam1', ...
%     'Var','FelemSupport1(4)','Type','appliedForce','Group','additional');

% END OF sysDef
