% calcJacobianMatrix - Compose the global Jacobian matrix
