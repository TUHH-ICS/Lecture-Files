% writeSfunction(S_name, mode, varargin)
% This routine exports the system stored in sys in a C S-function.
% The S-function is stored in the current directory under the name
% passed in S_name and will be compiled after creation. A m-file named
% ['init_',S_name] will also be created to initialize all parameters and
% give some help on how to use the S-function.
% mode has the two possibilities 'linear' and 'nonlinear' to distinguish
% the model to use.
% 
% Numeric ......... If the parameters shall be kept, or numerical values
%                   inserted instead {true}, meaning numerical values
% Symbolic ........ If the parameters shall be kept, or numerical values
%                   inserted instead {true}, meaning symbolic expressions
% CheckVarargin ... An advanced feature to avoid errors if invalid
%                   parameters are passed. This is only if you know
%                   exactly what you are doing. {true}
%
% See also: mcode2c, exportEqMot, writeSysDef
%
% First appearance: 29.02.2008
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
