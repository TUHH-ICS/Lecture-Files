% ===============================================================================
%
% ALPSO - Guaranteed Convergence Particle Swarm Optimizer with Augmented
%         Lagrange Multiplier Method
%          
%    extended Particle Swarm Optimizer that handles equality and inequality
%    constraints by applying the AUGMENTED LAGRANGIAN MULTIPLIER METHOD. 
%
%   ALPSO solves problems of the form:
%
%                        min F(P)  
%       subject to:          
%                       Gi(P)  = 0, i=1(1)ME
%                       Gj(P) <= 0, j=ME+1(1)M
%                         PLB <= P <= PUB 
%
%   ALPSO finds a Nx1-vector of optimal design variables P that minimizes  
%         the objective function F subject to the nonlinear equality and
%         inequality constraints G. 
%
%   The user should preferebly scale the problem appropriately. The problem
%   functions should be in the range 
%
%                         -10 <=  F(P)   <= 10
%                         -10 <= Gi,j(P) <= 10
%                         -10 <=    P    <= 10
%
%   Don't use too small tolerances ABSEQU, ABSINE, ABSLAG (see below). 
%   The default values are usually a good choice. Superflously tight 
%   tolerances lead to a rapidly increasing number of function evaluations 
%   and possibly to poor Lagrange multiplier estimates. Adjust all control 
%   parameters with care. If you don't know what you are doing, the default
%   values might be a good starting point. 
%
%   [Popt,Fopt] = ALPSO(FUN,N,PLOW,PUP) finds the minimum of the function FUN.
%   FUN accepts as input the 1xN-vector P with its lower and upper bounds 
%   PLB and PUB and returns a scalar function value F evaluated at P. ALPSO
%   returns the function value F at the solution P.
%
%   [Popt,Fopt,Gopt,LAMBDA,NF] = ALPSO(FUN,N,PLOW,PUP,M,ME) minimizes the 
%   objective function defined by FUN, subject to the M nonlinear constraints 
%   also defined in FUN. FUN is a function which accepts the 1xN-vector P as
%   input and returns as first output argument the objective function value
%   and as second output argument the 1xM vector of constraint function
%   values evaluated at P. The first ME constraint functions are considered
%   to be equality constraints. ALPSO returns the set of optimal parameters P,
%   the objective function values at the minimum, the Lagrangian multipliers
%   LAMBDA and the number of objective function evaluations NF.
%
%   [Popt,Fopt,Gopt,LAMBDA,NF,EXITFLAG] = ALPSO(FUN,N,PLOW,PUP,M,ME) returns
%   additionally and EXITFLAG variable. If the stopping criteria is used
%   (see below) but the maximum number of function evaluations is exceeded,
%   EXITFLAG = -1. If stopping criteria is satisfied within the maximum
%   number of function evaluations, exitfalg = 1. If no stopping criteria is
%   used, EXITFLAG = 0.  
%
%
%   [Popt,Fopt,Gopt,LAMBDA,NF,EXITFLAG,alpsoOpts] =
%   ALPSO(FUN,N,PLOW,PUP,alpsoOpts,varargin)
%   When an additional output argument is specified, a structure containing
%   all options of the algorithm is returned. This options structure can
%   also be used to set the options. Then the function call below with all
%   options can be replaced by giving all necessary inputs and one
%   structure. This structure may contain any of the fieldnames as the
%   options, e.g. alpsoOpts.NMAX, alpsoOpts.C1, ... Any empty or missing
%   fields are ignored and standard values are used.
%
%   [Popt,Fopt,Gopt,LAMBDA,NF,EXITFLAG] = ALPSO(FUN,N,PLOW,PUP,M,ME,PDIS,NP,
%                                 NMAX,NCORE,NOUT,STOP,NSTOP,ABSEQU,ABSINE,
%                                 ABSLAG,RELFUN,ABSFUN,ABSDIST,NM,NN,VSTART,
%                                 VCLAMP,C1,C2,W1,W2,NS,NF,VCRAZY,RINIT,RMAX,
%                                 SEED,FILEOUT,P1,P2,...) 
%   
%   The following control parameters can be specified:
%    
%     PDIS  Nx1 vector of zeroes and ones. A one specifies the appropriate
%     design variable to be of type integer. Default is zero (continuous) for 
%     all variables. Returned Lagrange multipliers are not meaningful for 
%     integer problems!  
%
%     NP is an integer and specifies the number of particles. Default is 20.
%     This number should be adapted to the dimension of the problem. For two 
%     dimensions, 20 to 40 particles seems to be a reasonable number for many 
%     optimization problems.
%
%     NMAX is the number of 'outer' iterations. The number of total ALPSO
%     iterations is NMAX times NCORE. Default is 200. This number should
%     be adapted to the problem in order to avoid premature abortion. 
%
%     NCORE is the NUMBER of 'inner' (basic) ALPSO iterations. Default is 3
%     and this number is appropriate for most constrained problems.
% 
%     NOUT specifies the number of 'outer' iterations without command shell 
%     output. Default is 0 (no output). If only final output is desired, set
%     to -1.
%
%     STOP is a flag (zero or one) that specifies the use of a stopping
%     criteria. Default is 0 which means the specified conditions will
%     not be checked. If STOP is 1 then the stopping criteria will be checked
%     and the algorithm stops when the criteria are satisfied. Otherwise
%     ALSPSO stops when the maximum number of outer iterations NMAX is reached.  
%     The overall stopping criteria is satisfied if all the specified
%     tolerances/critera (ABSEQU,ABSINE,ABSLAG,RELFUN,ABSFUN,ABSDIST)
%     as described in the following are met.
%
%     NSTOP specifies the number of successive iterations, where the
%     stopping criteria must be satisfied in order to abort opimization
%     process. Default value is 10. 
%
%     ABSEQU is the absolute accuracy of the equality constraints. Default
%     value is 1e-3. This condition is part of the stopping criteria.  
%
%     ABSINE is the absolute accuracy of the inequality constraints. Default 
%     value is 1e-3. This condition is part of the stopping criteria.  
%
%     ABSLAG is the absolute accuracy of the Lagrange multipliers. Default 
%     value is 1e-2. This condition is part of the stopping criteria.
%
%     RELFUN is the relative change of the pseudo objective (Augmented
%     Lagrange) function. Default value is 1e-2. This condition is part of
%     the stopping criteria. 
%
%     ABSFUN is the absolute change of the pseudo objective (Augmented
%     Lagrange) function. Default value is 1e-2. This condition is part of
%     the stopping criteria. 
%
%     ABSDIST is used to measure convergece and stop search process. It is 
%     compared with the mean distance (2-norm) of the particles in the
%     normalized search space [-1 1]. If this mean distance in less than
%     the given threshold in NSTOP successive iterations, this criterion
%     is satisfied. Default is 1e-5;
%
%     NM specifies the neighborhood model (indexed 0, spatial 1). Default 
%     is zero.
%
%     NN specifies the number of neighbors of each particle. Default is NP 
%     which means no active neighborhood model. 
%
%     VSTART specifies the initial velocity of the particles expressed as a 
%     fraction of the normalized parameter space [-1,1]. Default value is
%     0.01.  
%
%     VCLAMP specifies the velocity clamping factor. Default is 2.
%
%     C1 specifies the velocity update factor 1 (cognitive scaling factor). 
%     Default value is 0.8.
%
%     C2 specifies the velocity update factor 2 (social scaling factor).
%     Default value is 0.8.
%
%     W1 specifies the initial inertia factor. Default value is 0.6.
%
%     W2 specifies the final inertia factor. Default value is 0.6.
%
%     NS specifies the number of successes for the search radius update.
%     Default is 5. 
%
%     NF specifies the number of failures for the search radius update.
%     Default is 5.  
%
%     VCRAZY defines a craziness velocity, which is added to the particle 
%     velocity after updating penalty factors and Langangian multipliers. 
%     The default value is 0.
%
%     RINIT specifies the initial value for the penalty factors. Default
%     value is 1. 
%
%     RMAX defines an upper limit for the penalty factors. This might be a
%     crucial number for an accurate solution with good Lagrange multiplier
%     estimates. The default value is 1e6. If the update process tries to
%     increase the penalty factors beyond this value, a warning message is
%     displayed (in case NOUT > 0) that the problem is badly formulated
%     regarding constraint functions and constraint tolerances. 
%     set RMAX = 0 if you do not want to bound penalty factors.
%
%     SEED defines the initial state of the random number generator. SEED 
%     must be a scalar integer value from 0 to 2^32-1. If you do not want to
%     initialize random number generator, use SEED = -1.
%
%     FILEOUT is the name of the file where some data regarding optimization
%     history is written. If this is not wanted, set FILEOUT = '' or []. The 
%     default is '' (no output). The format of the text file is:
%        - iter_out iter_core N NOB number_of_best_particle
%          F(best_particle) mean_distance_of particles \n
%        - opt. vector particle 1
%        - opt. vector particle 2
%          ...
%        - opt. vector particle NOB
%
%     P1, P2, ... ALPSO passes the problem-dependent parameters P1, P2,
%     etc. directly to the function FUN. Pass empty matrices as
%     placeholders for other arguments (M,ME,PDIS,NP,NMAX,...) if these
%     arguments are not needed.  
%
% ===============================================================================
%
% EXAMPLE 
% 
%     [F,P,LAMBDA,NF] = ALPSO(@objfun,2,[-0.1 -5],[10 10],2,1)
%
% ===============================================================================
%
%    For more information about the algorithm (especially on contraint
%    optimization with pso used here), see
%       >> Using Augmented Lagrangian Particle Swarm Optimization for 
%          Constrained Problems in Engineering <<   
%       by Kai Sedlaczek and Peter Eberhard 
%       (Structural and Multidisciplinary Optimization, 32, 2006, 277-286
%    or contact authors.
%
%    For an introduction to Particle Swarm Optimizers, see
%       >> An Analysis of Particle Swar Optimizers <<
%          by Frans van den Bergh, University of Pretoria  
%
%    written by:
%      Kai Sedlaczek (09/2003)    
%      sedlaczek@itm.uni-stuttgart.de
%      Institute of Engineering and Computational Mechanics
%      University of Stuttgart
%      Germany
%
%    last modified: 07/2007
%
%    please send bugs to sedlaczek@itm.uni-stuttgart.de
%
% ===============================================================================         
