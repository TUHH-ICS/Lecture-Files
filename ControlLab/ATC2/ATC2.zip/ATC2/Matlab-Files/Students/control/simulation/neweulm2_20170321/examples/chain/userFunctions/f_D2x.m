function D2x = f_D2x(t)
% f_D2x - definition of 2nd time-derivative of user-defined variable x

global sys;



% constant user-defined variables

xAmp = sys.parameters.data.xAmp;
xOmega = sys.parameters.data.xOmega;
D2x = zeros(1,1);

D2x(1) = -1.0*xAmp*xOmega^2*sin(t*xOmega);


% END OF FILE

