% This function creates a file in the sandbox folder which returns the path
% stored in path_. If path_ is not passed to this function, the current
% folder pwd is used instead.
% This file can be read at startup to change to this directory.
%
% Input arguments:
% path_ ... Last working path
%
% Return arguments:
% res_ .... If everything worked fine, the path where getNeweulWorkingPath.m
% was created is returned. If there was some error during the creation, -1
% is returned.
%
% First appearance: 01.03.2008
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
