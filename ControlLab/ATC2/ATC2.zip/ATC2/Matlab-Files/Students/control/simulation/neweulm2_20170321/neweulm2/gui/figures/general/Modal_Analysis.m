% MODAL_ANALYSIS M-file for Modal_Analysis.fig
%      MODAL_ANALYSIS, by itself, creates a new MODAL_ANALYSIS or raises
%      the existing singleton*.
%
%      H = MODAL_ANALYSIS returns the handle to a new MODAL_ANALYSIS or the
%      handle to the existing singleton*.
%
%      MODAL_ANALYSIS('CALLBACK',hObject,eventData,handles,...) calls the
%      local function named CALLBACK in MODAL_ANALYSIS.M with the given
%      input arguments.
%
%      MODAL_ANALYSIS('Property','Value',...) creates a new MODAL_ANALYSIS
%      or raises the existing singleton*.  Starting from the left, property
%      value pairs are applied to the GUI before
%      Modal_Analysis_OpeningFunction gets called. An unrecognized property
%      name or invalid value makes property application stop.  All inputs
%      are passed to Modal_Analysis_OpeningFcn via varargin.
%
% Graphical user interface to start a modal analysis, calculating
% eigenmodes and displaying them.
% 
% For more information, please open the corresponding window and click on
% the help button, labeled with a question mark "?".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
%
% First appearance: 01.07.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
