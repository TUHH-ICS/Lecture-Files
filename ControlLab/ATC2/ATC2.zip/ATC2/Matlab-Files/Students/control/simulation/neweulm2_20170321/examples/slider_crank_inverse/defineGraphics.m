function defineGraphics
% DEFINEGRAPHICS - erzeuge graphische Darstellung von Koerpern
%

global sys;

sys.graphics.surfaces = []; % Reset any graphic objects

% {'pendulum1_Sphere','pendulum1_cylinder','pendulum2','slider'}
% myColors_ = {[1 0 0],[0 1 0],[1 1 0],[0 0 1]};
% myColors_ = {[0.7 0 0],[0.7 0 0],[0 0.7 0],[0 0 0.7]};
val_ = 0.9;
myColors_ = {[val_ 0 0],[val_ 0 0],[0 0 val_],[0 val_ 0]};
FaceAlpha_ = 0.4;
%%%%%%%%%%%%%%
% Pendulum 1 %
%%%%%%%%%%%%%%
h(1) = drawSphere([0 0 0],0.04,20,myColors_{1}, ...
                   'FaceAlpha',FaceAlpha_, ...
                   'Tag','P1_Sphere');
h(2) = drawRotBody([0.025 0.025],[0 sys.parameters.data.lrod], ...
                   'FaceColor',myColors_{2}, ...
                   'EdgeColor',0.6*myColors_{2}, ...
                   'FaceAlpha',FaceAlpha_, ...
                   'Tag','P1_Rod');
transformGraphics(h(2),'RotationAngles',[0,-0.5*pi, 0]); % Rotate body
addGraphics('P1_rod_cg',h);

%%%%%%%%%%%%
h = drawRotBody([0.025 0.025],[0 sys.parameters.data.lcrank], ...
                   'FaceColor',myColors_{3}, ...
                   'EdgeColor',0.6*myColors_{3}, ...
                   'FaceAlpha',FaceAlpha_, ...
                   'Tag','P2_crank');
transformGraphics(h(1),'RotationAngles',[0,-0.5*pi, 0]);
addGraphics('P2_crank_cg',h);

% Format figure suitable even for a paper
if(exist('itm_formatfig','file') == 2)
    itm_formatfig(2);
end
set(sys.model.frame.P1_P2_contact.geo,'visible','off');
set(sys.model.frame.P2_ISYS_contact.geo,'visible','off');

xlabelh = get(gca,'Xlabel');
set(xlabelh,'HandleVisibility','on');
set(xlabelh,'Units','normalized');
set(xlabelh,'Position',[0.5000 -0.1561 0]);
% get(gca,'Position',[0.1143 0.0924 0.8670 0.9073]);
view(0,90); axis([-0.6 1.6 -0.6 0.6]);
if(isfield(sys.settings,'timeInt') && isfield(sys.settings.timeInt,'y0') && length(sys.settings.timeInt.y0)==sys.counters.genCoord)
    updateGeo(0,sys.settings.timeInt.y0);
end
plotTrajectories('P2_crank_cg','Color','blue');
plotTrajectories('P1_rod_cg','Color','red');

% print -depsc sliderCrankModel.eps

% END OF FILE
