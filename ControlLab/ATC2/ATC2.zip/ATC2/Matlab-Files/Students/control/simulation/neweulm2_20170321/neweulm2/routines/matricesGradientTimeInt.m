% result = matricesGradientTimeInt
% matricesGradientTimeInt - Calculates matrices necessary for the
% calculation of the gradient. This function is necessary for the direct
% and the adjoint variable method. At the end of the calculations some
% Maple-specific syntax is replaced.
%
% Dimensions:
% n = sys.counters.genCoord
% m = length( sys.settings.opt.p )
% dimdep = number of dependent generalized coordinates
%
% Outgoing variables
% result.DM ....... dM / dt, calculated with the chain rule: n x n
% result.ODE_y .... d ODE / d y : n x n
%     result.ODE_y(m,i) = d ODE(m) / d y(i)
% result.ODE_z .... d ODE / d z : n x n
% result.ODE_p .... d ODE / d p : n x m
%
% result.Fy ....... d F / d y : n x 1
% result.Fz ....... d F / d z : n x 1
% result.FDz ...... d F / d Dz : n x 1
% result.Fp ....... d F / d p : m x 1
%
% result.Gy ....... d G / d y : n x 1
% result.Gz ....... d G / d z : n x 1
% result.Gp ....... d G / d p : m x 1
%
% result.Ht ....... d H / dt : 1 x 1
% result.Hy ....... d H / dy : 1 x n
% result.Hz ....... d H / dz : 1 x n
% result.Hp ....... d H / dp : m x 1
% result.tau1 ..... (\dot{G1} + F1) / \dot{H1} : 1 x 1
%
% If loops exist:
% result.c_1y ..... \partial c_1 / \partial y : dimdep x n
% result.c_2y ..... \partial c_2 / \partial y : dimdep x n
% result.c_1p ..... \partial c_1 / \partial p : dimdep x m
%
% Initial conditions
% result.Phi_y .... \partial Phi / \partial y : n x n
%     result.Phi_y(m,i) = d Phi(m) / d y(i)
% result.Phi_p .... \partial Phi / \partial p : n x m
% result.DPhi_y ... \partial DPhi / \partial y : n x n
% result.DPhi_z ... \partial DPhi / \partial y : n x n
% result.DPhi_p ... \partial DPhi / \partial y : n x m
%
% See also: newOpt, OptiCalcInitCon, writeFinalCond,
%   writeOptiAdjoint, writeOptiDirect, writePsiTimeInt
%
% First appearance: 01.12.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
