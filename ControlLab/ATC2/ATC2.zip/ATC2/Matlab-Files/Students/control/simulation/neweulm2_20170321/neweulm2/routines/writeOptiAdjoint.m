% writeOptiAdjoint(Matrices)
% Create all functions necessary for the calculation of the gradient with
% the direct method. This function also evaluates the values needed for
% these files using the derivatives passed in Matrices, but it does no
% calculations.
% This function creates the files:
% - adjoint_initVal.m ... Calculates the initial conditions of the adjoint
%                         variable ODE.
% - adj_ODE.m ........... Function containing adjoint ODE
% - adj_Mass.m .......... Mass matrix for the adjoint ODE
% - auto_grad_adj.m ..... Calculates the gradient
% - xi_function.m ....... Calculates the adjoint variables xi
%
% See also: newOpt, matricesGradientTimeInt, OptiCalcInitCon,
%   writeFinalCond, writeOptiDirect, writePsiTimeInt
%
% First appearance: 01.12.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
