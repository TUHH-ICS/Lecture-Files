% [csysList,commonCSys] = findFramePath(frame1,frame2)
% Determine the path from frame1 to frame2 which could be used to calculate
% relative kinematic values. This path is returned as csysList. The topmost
% coordinate system is given as the second return value commonCSys.
% 
% Input arguments
% frame1 ... First coordinate system, first in csysList
