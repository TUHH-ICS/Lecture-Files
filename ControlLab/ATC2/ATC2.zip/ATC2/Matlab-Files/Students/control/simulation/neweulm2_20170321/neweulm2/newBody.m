% newBody(varargin) - Create new body
% 
%  Syntax:
%> newBody;
%> newBody('Property', value, ...);
% 
%  Description:
% This function is used to define a new rigid or flexible body. Next to the
% inertia properties, which are passed as the symbolic values 'm' and 'I' in 
% case of a rigid body or in form of a SID file in case of a flexible body,
% the kinematics of the body's frames can be defined.
%
%  Optional parameters {default value}:
%
% Id .............. Identifier of the body {'BODY_1'}
% Name ............ Name of the body {'Body Number 1'}
% Type ............ Type of body, 'rigid' or 'flex' {'rigid'}
% RefSys .......... Reference system of the body  {'ISYS'}
% RelPos .......... Relative positition vector from reference system to
%                   primary coordinate system  {'[0;0;0]'}
% RelRot .......... Relative rotation angle {'[0;0;0]'}
% CgPos ........... For rigid bodies, relative position vector of the center
%                   of gravity, described in and with respect to primary
%                   system {'[0;0;0]'}
% CgRot ........... For rigid bodies, relative orientation of the center of
%                   gravity {'[0;0;0]'}
% Mass ............ For rigid bodies, mass of the body {1}
% Inertia ......... For rigid bodies, inertia tensor {eye(3)}
% SIDfile ......... For flexible bodies, specify path and filename to 
%                   SID-file containing the information of the flexible
%                   body. This information can be given in several ways,
%                   either as an SID-file, a mat-file or directly as the
%                   resulting data structure
% MATfile ......... For flexible bodies, same as SIDfile
% ElasticBody ..... For flexible bodies, same as SIDfile
% JointSys ........ For flexible bodies, specifies which frame is connected
%                   to the previous body, avoids constraint equations {[]}
% RelRotFrame ..... For flexible bodies,Specifies the orientation of which 
%                   coordinate system is specified by the RelRot property. 
%                   Only relevant for flexible bodies with a JointSys. 
%                   Either 'JointSys' or 'JointRef'. The selection of 
%                   'JointSys' defines the rotations between RefSys and the
%                   JointSys located on one node, similar to a nodal fixed 
%                   frame of reference. The selection of 'JointRef' defines
%                   the rotations to be between RefSys and the frame of 
%                   reference in the center of gravity. {'JointSys'}
% Rotation ........ For flexible bodies, this option allows the prescription of a
%                   constant rotation to avoid having these numbers in the
%                   relative rotation vector. This helps to avoid
%                   oscillations around singular configurations, which
%                   otherwise occur frequently. This option then uses the
%                   function rotateElBody. The rotation can be specified
%                   using a rotation matrix or the corresponding three
%                   parametric angular description {[0;0;0]}
%
%  Example:
%>   newBody('RefSys','ISYS', 'RelPos','[0;0;z1]', 'Mass', 5);
% 
%  See also: 
% newForceElem, newGenCoord, newFrame, newConstraint, newSys,
% newInput, newOutput, newConstant, newTimeDependent, newStateDependent,
% newVolume, calcEqMotNonLin
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
