% res = expandTimeVars(expr,tvars)
% expandTimeVars - Replace all time dependent parameters by a taylor series
% expansion up to the second order. This is sufficient because equations of
% motion are second order differential equations.
% 
% Input:
% expr .... Expression in which the parameters shall be replaced
% tvars ... List of time dependent parameters to be used for this
%           replacement
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
