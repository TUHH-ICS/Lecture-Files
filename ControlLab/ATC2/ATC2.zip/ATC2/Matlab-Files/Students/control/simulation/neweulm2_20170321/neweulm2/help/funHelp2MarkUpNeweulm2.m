%funHelp2MarkUp  extract function help comments and translate to mark-up
%                for publish function
% 
%   
%
% Input:
% 	-'Files': Cell array of strings; 
% 	-'OutputDir':, String {'./'};
% 	-'Footer': String {''}; If a non-empty string is given it will be
%           appended to every generated help m-file.
% 	-'Format': String ({'html'}, 'latex'); Output format.
% 	-'NSpace': Numeric scalar {4}; Number of spaces to be used for tab
%           replacement.
% 	-'WriteUnmatched: Boolean {true}; Toggles whether unmatched content
%           is written unmodifed, i.e. without markup, or is dismissed from
%           the output,.
% 	-'RepFunNames': Boolean {false}; If set to true, not only the name of
%           the current function is marked up to be displayed in typewriter
%           font, but all functions that are given by 'Files' are used.
%   -'FormatErrors': Boolean {false}; If set to true, non-conforming format
%           of a help comment issues an error. Otherwise, a warning is
%           displayed and the file is skipped.
% 
% Output:
%   -help_files: filenames of the created and marked-up help m-files
%           including the output directory.
% 
