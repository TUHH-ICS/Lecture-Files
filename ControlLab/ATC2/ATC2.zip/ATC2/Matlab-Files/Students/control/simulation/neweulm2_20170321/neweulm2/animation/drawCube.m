% drawCube - Create cuboid
%  Description: 
% Create a cuboid for the graphical representation of a body. 
%
%  Input arguments:
% c ............ Vector to center, [x y z], 1x3 or 3x1, {0 0 0}, 
%                this parameter may contain symbolic constants of Neweul-M2
% dx ........... edge length in x, {0.1}
%                this parameter may contain symbolic constants of Neweul-M2
% dy ........... edge length in y, {0.1}
%                this parameter may contain symbolic constants of Neweul-M2
% dz ........... edge length in z, {0.1}
%                this parameter may contain symbolic constants of Neweul-M2
%
%  Optional arguments, given pairwise:
% Tag ............. Set Tag property, for identification {'Cube_1'}
% FaceColor ....... Color of the faces {[0 0 1]}
% EdgeColor ....... Color of the edges {'none'}
% Color ........... Set face and edgecolor to the same, overwrites
%                   FaceColor_ specified before
% FaceAlpha ....... Transparency of the faces {1}
% EdgeAlpha ....... Transparency of the edges {1}
% Frame ........... Specify the coordinate system of Neweul-M2 to attach
%                   this shape to. Otherwise you would have to call
%                   addGraphics manually {[]}
%
%  Output arguments:
% h ............... Graphic-Handle
%
%  See also: drawArrow3d, drawElasticBeam, drawLine, drawRotBody,
% drawSphere, drawSTL, drawSpring
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
