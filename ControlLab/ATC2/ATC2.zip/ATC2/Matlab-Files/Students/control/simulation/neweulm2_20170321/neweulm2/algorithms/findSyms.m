% vars = findSyms(varargin)
% findSyms - Search for symbolic expressions and return them as a cell
% array
%
% varargin ... symbolic expressions of data type sym or string
%
% The function findsym of the Symbolic Math Toolbox returns all parameter
% names of a symbolic expression as a comma separated list, which is
% difficult to use. This function returns them as a cell array, no matter
% which symbolic engine is used.
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
