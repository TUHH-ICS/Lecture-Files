% writeHelpvarC(fid,varargin)
% writeHelpvarC - create m-files with definitions of the symbolic
% parameters contained in sys.parameters.data. This function searches for all
% occurences of these parameters and prints initializations in fid. If the
% expressions are very large and this function is called in sequence with
% writeGenCoordDef one can save computation time. Then the most time
% consuming operation is to find the symbolic parameters in the expression.
% Therefore one can search for those names and simply pass the cell array,
% which findSyms.m returns, thus omitting one of two searches.
%
% fid ..... Filedescriptor
%
% Optional input:
% +-YvarNoDy_ ... If the second input argument is this string, the state
%                 dependent parameters are initialized without the use of
%                 generalized velocities Dy_. By using such a strange
%                 string, it cannot be confused with any valid parameter
%                 name.
% \t ............ In order to print the initializations at indented
%                 positions, a row of such control signs can be passed.
% 
% See also: writeGenCoordDef, writeSetValDef
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
