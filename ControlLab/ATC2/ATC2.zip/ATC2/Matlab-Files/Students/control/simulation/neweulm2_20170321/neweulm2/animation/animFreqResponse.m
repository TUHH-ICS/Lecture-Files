% animFreqResponse - animate frequency response of the system
%
%  Optional parameters {default value}:
%
% Amplitude ........... Amplitude to scale the frequency response, meaning
%                       the value of the input {1}
% AnimBackground ...... Start anim in the background, logical {false}
% AnimationSoftware ... Which software to use for the animation 'matlab' or
%                       'anim' {'matlab'}
% Frequency ........... Frequency at which response shall be calculated {10}
% Input ............... Determine, which system input is used 
%                       {sys.model.input(1).data(1).id}
% NumLin .............. Use numerical linearization. This choice exists
%                       only if the symbolical linearization has been
%                       previously calculated, otherwise numerical is
%                       selected automatically {false}
% StartAnim ........... Shall anim be started {false}
% Stride .............. Stride factor for the animation. If nothing is
%                       specified an animation time period of 2 is used,
%                       see TimePerPeriod {[]}
% Stepsize ............ Stepsize to use for the numerical linearization, if
%                       nothing specified using the default of freqResponse
%                       {[]}
% Time ................ Specify at which time the nonlinear equations of
%                       motion are supposed to be linearized. {0}
% TimePerPeriod ....... Time period to be used for the animation {2}
% checkvarargin ....... Shall additional arguments be passed through
%                       {false}
%
%  Return values:
% result ......... structure containing the frequency response with the fields
% result.phi ..... frequency response
% result.ref.y ... reference point / linearization point
% result.f0 ...... evaluation frequency
%
%  Example:
% [result ye_ t_] = animFreqResponse(0,[],1,20);
% [result ye_ t_] = animFreqResponse(t,in,2e-2, 2e3);
% [result ye_ t_] = animFreqResponse(t,in,2e-2, 2e3,'StartAnim',true,'NumLin',true);
%
%  See also:
% modAnim, matlab2anim
%
% First appearance: 27.03.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
