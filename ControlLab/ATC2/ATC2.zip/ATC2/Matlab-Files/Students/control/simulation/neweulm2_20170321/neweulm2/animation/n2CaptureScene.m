% n2CaptureScene - Function to capture the current view setting 
%
%  Description:
% Function to capture the current view setting of this
% scene. This can be used to move the camera of the animation window during
% an animation. The best way is to set up the view step by step for each
% scene using the 'Camera Toolbar'.
% 
% When this function is called the cameratoolbar is shown in the current
% figure. You can switch this off by typing cameratoolbar('Hide');
% 
%  Optional arguments, given pairwise:
% Capture .......... Logical parameter, whether the current view settings
%                    shall be captured and stored {true}
% Data ............. Allows direct manipulation of the data structure.
% DistributeEven ... Logical parameter, whether the recorded scenes shall
%                    be distributed evenly over the animation interval.
%                    Otherwise the specified time or frame is used {false}
% FrameGoal ........ Id of a coordinate system of Neweul-M2. If one is
%                    given, the view is always centered on this frame. When
%                    this setting is used, the data like axis limits,
%                    CameraPosition, ... are measured with respect to the
%                    initial configuration. Therefore, when using this
%                    setting, set up the camera path at the initial system
%                    configuration. The motion of this frame is added
%                    automatically {''}
% Reset ............ Option to reset the stored data structure. Only if
%                    logical false is passed, this option does not reset
%                    the data. This resets only the camera path, not the
%                    other settings {true}
%
%  Output arguments:
% res_ ............. Current view settings
%
%  Example:
%   n2CaptureScene('reset',true);
%   n2CaptureScene;
%
%  See also:
% animTimeInt, updateGeo
%
% First appearance: 13.07.2012
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
