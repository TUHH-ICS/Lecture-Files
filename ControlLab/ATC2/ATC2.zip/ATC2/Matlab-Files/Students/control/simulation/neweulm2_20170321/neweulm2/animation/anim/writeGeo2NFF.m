% writeGeo2NFF(varargin)
% writeGeo2NFF - This function reads the information of all surface or
% patch objects in the current animation window and writes them to an .nff
% file. An .nff file is a very basic standard for the description of
% surfaces, e.g. used in old CAD-software. The surfaces are described as
% triangles with the order of points being chosen so they are
% mathematically positively oriented according to a normal vector pointing
% to the inside of the object.
% 
% The surface objects should be created with the corresponding functions
% from the software package neweulm2. As far as we tested this function it
% worked well for all general surfaces except cuboids. They worked only if
% they have been created with drawCube.m, otherwise the faces were multiply
% defined.
% 
% All input arguments are optional and to be passed in a pairwise manner
% Filename ........ A filename for the nff file can be passed as second
%                   argument {'SurfaceObjects.nff'}.
% Axes ............ Use the given axes instead of the currently selected
%                   one {gca}.
% CheckVarargin ... An advanced feature to avoid errors if invalid
%                   parameters are passed. This is only if you know
%                   exactly what you are doing. {true}
% 
% See also: writeAnimGeo, writeStrFile
%
% Description of the .nff filetype:
% http://local.wasp.uwa.edu.au/~pbourke/dataformats/nff/nff2.html
% Neutral ASCII File Format
% 
% 
% Author:   Dipl.-Ing. Thomas Kurz
%           Based on the work by Madlen Hopp
%
% e-Mail:   kurz@itm.uni-stuttgart.de
%
% Date:     09.03.2010 (First appearance)
%
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
