% res_ = findExpressions(expr_)
% Function which can determine elements from a mathematic expression. It
% returns a list of all variables or numbers contained.
%
% All variables are returned in the order of appearance. If one element
% appears more often, it is returned in the corresponding number. Even
% zeros are returned in the occuring number. An encoding of their
% mathematical relation would be to complicated, but is usually not
% necessary when the original string is known. This function considers
% brackets and the results do not contain them. Except if they are part of
% the variable name, like in 'ISYS.r(1)'. As mathematical signs, the
% following list is considered: {'+','-','*','/','^','\'}
%
% Input argument
% expr_ ... String/Sym/Cell array of mathematic expressions
% 
% Return argument
% res_ .... Cell array of all expressions contained as strings. This
%           includes numerics, symbolics and arbitrary strings not
%           interrupted by a mathematical sign.
%
% Example: findExpressions('2*ISYS.r(a1)^3+(ISYS.v(1))+(4+(a2)^1.2-a3)/12')
%
% First appearance: 30.03.2012
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
