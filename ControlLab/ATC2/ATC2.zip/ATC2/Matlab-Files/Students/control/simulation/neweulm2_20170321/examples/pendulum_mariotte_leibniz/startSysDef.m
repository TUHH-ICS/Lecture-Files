%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% startSysDef                                                        %
%                                                                    %
% Programm to build a multi-body-system-model                        %
% This model is the pendulum of mariotte and leibniz (Mariotte-      %
% Leibnizsches Pendel).                                              %
%                                                                    %
% The definition is in the file sysDef.m                             %
%                                                                    %
% Of the files, which are called from here, the following are        %
% model specific. This means that you are kindly asked to adjust     %
% them to your need or copy them to start modelling a new system.    %
% - sysDef.m contains the system definition                          %
% - defineGraphics.m define graphic representations in the animation %
%   window                                                           %
% - runTimeInt runs time integration                                 %
% - runTimeIntBenchmark runs time integration with of the two        %
%   Benchmark examples                                               %
%                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Author:       Dipl.-Ing. Christian Sperle
%
% Institute:    Universitaet Stuttgart
%               Institut fuer Technische und Numerische Mechanik
%               Pfaffenwaldring 9
%               70569 Stuttgart
%

%%%%%%%%%%%%%%%%%%%%%%%%
% Extend path variable %
%%%%%%%%%%%%%%%%%%%%%%%%

run('../addpathNeweulm2');

%%%%%%%%%%%%%%%%%%%%%%%%
% Initialize workspace %
%%%%%%%%%%%%%%%%%%%%%%%%

close all;
clear global;
global sys;
tic;

%%%%%%%%%%%%%%%%%%%%%
% Define the system %
%%%%%%%%%%%%%%%%%%%%%

formulation = 'minimal';
% formulation = 'newtonEuler';
% formulation = 'recursive';
% formulation = 'recursiveMinimal';

sysDef(formulation); % model-specific, please edit this file

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create nonlinear equations of motion %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

calcEqMotNonLin;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create functions for numerical evaluation %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

writeMbsNonLin;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Linearize the equations of motion %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% calcEqMotLin;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create functions for numerical evaluation %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% writeMbsLin;

%%%%%%%%%%%%%%%%%%%%%%%%
% Initialize animation %
%%%%%%%%%%%%%%%%%%%%%%%%

createAnimationWindow;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Add shapes in the animation window %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

defineGraphics; % model-specific, please edit this file
toc;

%%%%%%%%%%%%%%%%%%%%%%%%
% Run time integration %
%%%%%%%%%%%%%%%%%%%%%%%%
tic;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% run integration in a static        %
% equilibrium with disturbance       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% alpha0  = rand(1);
% gamma0  = 0; % disturbance
% Dalpha0 = 0;
% runTimeInt(alpha0, gamma0, Dalpha0);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% run benchmark examples (1 or 2)    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

example = 1;
runTimeIntBenchmark(example);

toc;

%%%%%%%%%%%%%%%%%%%
% Save the system %
%%%%%%%%%%%%%%%%%%%

fprintf(1,'\nSaving results ...');
save 'sys.mat' sys;
fprintf(1,' ok!\n');

% END OF startSysDef
