% newConstraint(varargin) - Create new kinematic or control constraint
%
%  Syntax:
%> newConstraint;
%> newConstraint('Property', value, ...);
%     
%  Description:
% Define a constraint equation to enforce a kinematic loop. There are three
% different ways to define a constraint. The first is called _Directions_
% and locks up to six relative degrees of freedom between the specified
% frames. The second one is called _Distance_ and define a fixed distance,
% which needs to be a positive number greater than zero, between the two 
% frames. The third possibilty is _Equation_. Here, the user can define a
% arbitrary equation defining the constraint.
%
% Next to the constraint definition, it is possible to specify the Lagrange
% multipliers and how the act on the system. This can be used to state the
% Lagrange multipliers in a fixed frame or to define servo constraints.
% These servo constraints might cause instabilities in the equations of
% motion.
%
%  Optional parameters, given pairwise:
% Id ................... Identifier of the constraint {'CONSTRAINT_1'}
% Name ................. Name of the constraint {'Constraint number 1'}
% Index ................ Index of this constraint equation. A number out of
%                        {1,2,3} for {acceleration, velocity, position}. 
%                        Default is 3 (position level)
% Frame1 ............... First frame {'ISYS'}
% Frame2 ............... Second frame {'ISYS'}
% DirDef ............... The constraints are described in this coordinate
%                        system, so the vector _Directions_ is with respect to
%                        this coordinate system. {Frame1}
% Directions ........... 1x6 Vector with blocked dofs between the coordinate
%                        systems, 1 means constrained, 0 free {'[0 0 0 0 0 0]'}
% Equation ............. A symbolic equation providing the constraint equation.
% Distance ............. A numerical/symbolical value provided the distance
%                        between frame1 and frame2. If possible, try to use the
%                        _Directions_ option instead. The given value for the
%                        distance has to be NON-ZERO! Otherwise you may
%                        encounter strange simulation results as the Jacobian
%                        will be singular.
% ReactionForce ........ Specify the reaction forces/torques to enforce the
%                        specified constraints. If not specified, Lagrange
%                        multipliers which are not physical will be chosen.
%                        {zeros(_numberOfConstraintEquations_,1)}
% LagrangeMultipliers ... Specify Lagrange Multiplier used in _ReactionForce_ 
%                        as a cell array. Mandatory if _ReactionForce_ is 
%                        defined, otherwise without effect. 
% FAP1 ................. Force application point 1 specified by coordinate
%                        identifier. Mandatory if _ReactionForce_ is defined,
%                        otherwise without effect.
% FAP2 ................. Force application point 2 specified by coordinate 
%                        identifier. Mandatory if _ReactionForce_ is defined,
%                        otherwise without effect.
% FDirDef .............. The reaction force is defined in this coordinate 
%                        system. Optional if _ReactionForce_ is defined,
%                        otherwise without effect.
%
%  Examples:
%> newConstraint('Id', 'myConstraint', 'Frame1', 'myFrame', 'Frame2', ...
%>   'ISYS', 'Directions', [1;0;0;0;0;0]);
%> newConstraint('Id', 'myConstraint', 'Frame1', 'myFrame', 'Frame2', ...
%>   'ISYS', 'Distance', '1');
%> newConstraint('Id', 'myConstraint', 'Equation', 'alpha1 - 4');
%
%  See also: 
% declareDependent, newBody, newForceElem, newGenCoord, newFrame,
% newSys, newInput, newOutput, newConstant, newTimeDependent,
% newStateDependent, newVolume, calcEqMotNonLin
%
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
