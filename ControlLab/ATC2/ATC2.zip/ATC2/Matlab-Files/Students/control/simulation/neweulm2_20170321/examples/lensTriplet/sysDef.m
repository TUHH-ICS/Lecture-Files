%
% System definition for Multibody System
% This example demonstrates the visualization of an EMBS. The model
% consists of a rigid ring where an elastic housing for three elastic
% lenses is fixed. The rigid ring is connected by a spring with an x-,
% y- and z-component to a frame. The elastic part is reduced by modal
% reduction keeping the first 5 eigenfrequencies. So this EMBS has 8
% degrees of freedom.
%

% Create basic data structure

global sys;
load elbody
sys = newSys('Gravity', '[0;0;0]');


%%%%%%%%%%%%%%
% Create constant parameters and set numeric values

%%%%%%%%%%%%%%
% Create time dependent parameters

%%%%%%%%%%%%%%
% Create state dependent parameters

%%%%%%%%%%%%%%
% Create generalized coordinates
newGenCoord('x1','y1','z1');

%%%%%%%%%%%%%%
% System definition

%%%%%%%%%%%%%%
% Frame
% rigid ring (rigid part of the objective)
newBody('Id','F', 'Name','Frame', ...
        'RefSys','ISYS', ...
        'RelPos','[x1;y1;z1 + 0.27]', 'RelRot','[0;0;0]', ...
        'Mass','3', 'Inertia','[1,0,0;0,1,0;0,0,1]');

%%%%%%%%%%%%%%
% Objective
% elastic part of the objective (with lenses)
newBody('Id','OBJ', 'Name','Objective', ...
        'RefSys','F', 'Type','flex', ...
        'RelPos','[0;0;-0.27]', 'RelRot','[0;0;0]', ...
        'ElasticBody',elbody);
% note1: The mesh has been added previously to the elbody structure with the
% function 'elbodyAddMesh', see MatMorembs for more information
% note2: The kept nodes will appear as coordinate systems. These are the
% center nodes of each lens surface. 

%%%%%%%%%%%%%%
% coordinate systems for the visualization of the springs

newFrame('Id','Ko1', 'RefSys','OBJ', ...
        'RelPos','[0.09*3^(1/2);0.09;0.3]', 'RelRot','[0;0;0]');
newFrame('Id','Ko2', 'RefSys','OBJ', ...
        'RelPos','[-0.09*3^(1/2);0.09;0.3]', 'RelRot','[0;0;0]');
newFrame('Id','Ko3', 'RefSys','OBJ', ...
        'RelPos','[0;-0.18;0.3]', 'RelRot','[0;0;0]');
newFrame('Id','Ki1', 'RefSys','ISYS', ...
        'RelPos','[0.09*3^(1/2);0.09;0.35]', 'RelRot','[0;0;0]');
newFrame('Id','Ki2', 'RefSys','ISYS', ...
        'RelPos','[-0.09*3^(1/2);0.09;0.35]', 'RelRot','[0;0;0]');
newFrame('Id','Ki3', 'RefSys','ISYS', ...
        'RelPos','[0;-0.18;0.35]', 'RelRot','[0;0;0]');
% note: there is only one spring at the center, the three springs at the
% ring are only for visualization

%%%%%%%%%%%%%%
% Create force elements
% spring between frame and objective
newFrame('Id','IF', 'RefSys','ISYS', ...
        'RelPos','[0;0;0.27]', 'RelRot','[0;0;0]');

newForceElem('Id','S1', 'Name','Spring01', ...
             'Type','SpringDampCmp', ...
             'frame1','F', 'frame2','IF', ...
             'DirDef','F', ...
             'Stiffness', '[2e7; 2e7; 1e7; 0; 0; 0]');

% End of sysDef.m

