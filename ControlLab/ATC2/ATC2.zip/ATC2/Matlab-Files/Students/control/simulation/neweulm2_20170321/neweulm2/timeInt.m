% timeInt(y0,Dy0,varargin) - Perform a time integration
%
%  Syntax:
%>  timeInt
%>  result = timeInt(y0,Dy0, 'Property', value, ...);
% 
%  Description:
% Input arguments:
% y0 .............. Initial displacement {zeros(sys.counters.genCoord,1)}
% Dy0 ............. Initial velocities
% 
%  Optional Parameters, given pairwise:
% All fields of sys.settings.timeInt are valid, except the initial conditions
% constraintTol ....... For systems with constraint equations, this
%                       parameter controls the tolerance which is given to
%                       constraint violations to trigger stabilization
%                       {1e-4}
% ensureConsistency ... Logical whether the consistency of initial
%                       conditions has to be given. This is done by either
%                       producing warnings or errors if the function
%                       calcInitConditions encounters any problems. If
%                       true, an error is produced upon a problem {true}
% Display ............. Allows the specification of the display during
%                       integration {'none'}, possibilities are:
%                       'waitbar','odeplot','animation','none'
% evalOutput .......... Logical parameter, if true, the system outputs are
%                       evaluated at each time step after the integration
%                       was finished. This includes the evaluation of
%                       reaction forces and Lagrange multipliers as well
%                       {true}
% Function ............ Specify a different function to be integrated, as
%                       string or function handle {'eqm_nonlin_ss'}
% integrator .......... Specify the integration algorithm {@ode45}
% intOpts ............. Integration options structure {odeset}
% isRest .............. Specify if the initial conditions represent a
%                       position of rest {true}/false
% linear .............. Uses the linearized equations of motion {false}
% minStepsize ......... Minimal stepsize when using stabilization of
%                       constraint equations. This stops instable systems
%                       to perform one stabilization after the other
%                       without really making any progress. This value
%                       specifies the minimal integration time between each
%                       stabilization step {1e-8}
% nameIntegrationOut ... A cell array of names for the outputs defined with
%                       'numIntOut' can be given 
%                       {'x','y','data1','data2', ...}
% numIntegrationOut ... If an integration algorithm is used, which is not
%                       one of the ode-suite, then you can specify the
%                       number of output arguments here. As a default, two
%                       output arguments are assumed, additional ones are
%                       added to a structure and named data1, data2, ...
%                       {2} Example: [T,Y, data1,data2] = integrator()
% stabilization ....... Specify the algorithm to be used for stabilization.
%                       Currently the only options are 'none', 'projection'
%                       and 'rootsearch', but probably others will follow.
%                       Logical values are also accepted. {'none'}
% t0 .................. Start time {0}
% t1 .................. Final time {10}
% time ................ Time interval {[0 10]}
% timestep ............ Time step size for solvers without stepsize control
%                       {1e-2}
% waitbar ............. Displays a progress bar during integration {false}
%
%  Output arguments:
% result .......... Result structure of solver, see 'ode45' for more
%                   details. If no output parameter is specified, results
%                   are stored in the default location sys.results.timeInt
%
% Available integrators beside the matlab solvers: ode1, ode1s, ode2, ode3, ode4,
% ode5, radau5mex, radaumex, dop853mex, dopri5mex,odexmex, seulexmex, newm,
% hhtm, gena
%
%  Example:
%> sys.results.timeInt = timeInt(ones(sys.counters.genCoord,1),zeros(sys.counters.genCoord,1));
%> sys.results.timeInt = timeInt(ones(sys.counters.genCoord,1),zeros(sys.counters.genCoord,1), ...
%>  'integrator',@ode45, 'intOpts',odeset, 'time',[0,10], 'linear',true);
%
%  See also: 
%   animTimeInt, plotTrajectories, calcInitConditions,
%   timeInt>eqm_t, timeInt>Check_Band_Mass, timeInt>stabilizedIntegration
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
