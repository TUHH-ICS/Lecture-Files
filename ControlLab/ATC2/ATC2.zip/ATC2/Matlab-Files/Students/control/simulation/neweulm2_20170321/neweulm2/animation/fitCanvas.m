% fitCanvas - automatically adjust axis of the animation window
%
%  Description:
% This function finds the best limits for the axes of the
% graph, so that the complete motion is visible. It respects only the
% trajectories of the coordinate systems, ignoring any attached shapes.
%
%  Input arguments:
% figureOpt .... Option defining priorities for the fitting
%                square: with square axes properties, lengths in all
%                  directions the same, default {'equal'}
%                small: smallest possible area
%                equal: with axis equal properties (same scaling), but
%                  different lengths
% CenterCS ..... Centered view to one coordinate system, given in
%                varargin{1}. Then the animation should be called with
%                animTimeInt(sys.results.timeInt,'CenterCS','Coordinate_system_1');
%                This causes the animation to be centered to
%                Coordinate_system_1.
%
%  Optional parameters, given pairwise:
% with_ISYS ....... decides whether ISYS is contained in the plot area
%                   {true}
% min_length ...... minimal axis length, without allowance {0}
% allowance ....... additional space on each side of the picture as
%                   percentage of width {0.05}
% result .......... Pass the result structure used for the animation.
%                   {sys.results.timeInt}
% keepTimeStep .... If specified, the complete integration result is used in
%                   any case to determine the positions of the frames.
%                   Otherwise the complete integration result is only used
%                   if it consists of less points than a fixed stepsize of
%                   0.05 s. {false}
% ScaleElastic .... For the animation, it may be necessary to scale the
%                   elastic coordinate in order to see the corresponding
%                   deformations. This setting scales only the elastic
%                   coordinates on position level. This option should be
%                   used with the same option in animTimeInt {1}
% ScaleRigid ...... For the animation, it may be necessary to scale not
%                   only the elastic, but also the rigid body coordinates.
%                   This setting scales only the rigid body coordinates on
%                   position level.  This option should be
%                   used with the same option in animTimeInt {1}
% setTimeStep ..... A fixed stepsize for the integration result to determine
%                   the necessary window range can be specified {0.05}
% 
%  Example:
%   fitCanvas('equal'); % Static window
%   To center the view on coordinate system 'BODY_1'
%   fitCanvas('CenterCS','BODY_1'); % To be used with animTimeInt(sys.results.timeInt,'CenterCS','BODY_1');
%   
%  See also:
% animTimeint, updateGeo, fitCanvas>csys_call
%
% First appearance: 01.08.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
