%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% startSysDef                                                        %
%                                                                    %
% This is a very simple example for a multibody system with          %
% non-holonomic constraints. The model consists of a linkage,        %
% modeled with a holonomic constraint and a ball rolling on the      %
% linkage, modeled with a non-holonomic constraint.                  %
%                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Author:       Dipl.-Ing. Markus Burkhardt
%
% e-Mail:       markus.burkhardt@itm.uni-stuttgart.de
%
% Institute:    University of Stuttgart
%               Institute of Engineering and Computational Mechanics
%               Pfaffenwaldring 9
%               70569 Stuttgart
%               GERMANY
%

%%%%%%%%%%%%%%%%%%%%%%%%
% Extend path variable %
%%%%%%%%%%%%%%%%%%%%%%%%
% The first time, Matlab needs to know where the files of neweulm2 are
% located. The following line is to make the function addpathNeweulm2
% available
addpath('..');
% If your models are not in the default location, e.g. in
% '/home/user/myneweulm2/' please change the following line so you specify
% the folder containing the file calcEqMotNonLin.m in the following way:
% addpathNeweulm2('Folder','/home/user/myneweulm2/');
addpathNeweulm2;

%%%%%%%%%%%%%%%%%%%%%%%%
% Initialize workspace %
%%%%%%%%%%%%%%%%%%%%%%%%

close all;
clear all;
clear global;
global sys;
tic;

%%%%%%%%%%%%%%%%%%%%%
% Define the system %
%%%%%%%%%%%%%%%%%%%%%

sysDef; % model-specific, please edit this file

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create nonlinear equations of motion %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

calcEqMotNonLin;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate reaction forces %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% calcReacForce;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create functions for numerical evaluation %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

writeMbsNonLin;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Linearize the equations of motion %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% calcEqMotLin;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create functions for numerical evaluation %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% writeMbsLin;

%%%%%%%%%%%%%%%%%%%%%%%%
% Initialize animation %
%%%%%%%%%%%%%%%%%%%%%%%%

createAnimationWindow;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Add shapes in the animation window %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

defineGraphics; % model-specific, please edit this file

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Run a numerical simulation %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

runTimeInt;

%%%%%%%%%%%%%%%%%%%
% Save the system %
%%%%%%%%%%%%%%%%%%%

fprintf(1,'\nSaving System ...');
save('sys.mat','sys');
fprintf(1,' ok!\n');

fprintf(1,'\n---\n');
toc;

% END OF startSysDef
