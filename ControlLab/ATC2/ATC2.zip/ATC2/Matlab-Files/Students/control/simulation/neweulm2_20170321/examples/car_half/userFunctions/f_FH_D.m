function res_ = f_FH_D(t,y_,varargin)
% res_ = f_FH_D(t,y_,varargin)
% f_FH_D - definition of state-depending user-defined variable FH_D
% Positions, velocities, ... of coordinate systems can be calculated by
% calling the functions in 'sysFunctions', e.g. body1_r

% res_ = 2750;
% return;

global sys;

res_ = 0; % Default return value
Dy_ = zeros(sys.counters.genCoord,1); % Default value for derivatives
calcDerivatives_ = false;
% Treat optional input arguments
if(length(varargin) == 1)
	% Call was f_FH_D(t,y_,Dy_)
	% Generalized velocities have been passed
	Dy_ = varargin{1};
elseif(length(varargin)>1 && ischar(varargin{1}) && strcmp(varargin{1},'derivative'))
	% Call was f_...(t,y_,'derivatives', ...)
	calcDerivatives_ = true;
	component_ = varargin{2}; % Define axis direction
elseif(length(varargin)>2 && ischar(varargin{2}) && strcmp(varargin{2},'derivative'))
	% Call was f_...(t,y_,Dy_,'derivatives', ...)
	Dy_ = varargin{1};
	calcDerivatives_ = true;
	component_ = varargin{3}; % Define axis direction
elseif(nargin==1 && ischar(t) && strcmp(t,'linearization'))
	% Case IV: Call was f_...('linearization')
	% Return symbolic expression to calculate the linearization
	% Necessary for all parameters appearing in the equations of motion to linearize!
	res_ = sym(0);
	return;
end
% If you have any parameters to define, do that here
% Definitions start #######################################################

% Constant parameters
dr = sys.parameters.data.dr;
dprr = sys.parameters.data.dprr;
dpcr = sys.parameters.data.dpcr;

% relative velocity vector
ksys1v = str2func('RAD_v');
ksys2v = str2func('CARRD_v');
% v = norm(ksys2v(t,y_,Dy_)-ksys1v(t,y_,Dy_));
v = ksys2v(t,y_,Dy_)-ksys1v(t,y_,Dy_);
v = sign(sum(v)) * norm(v);

% state dependent user defined functions
res_ = dampParam(v,dr, dpcr,dprr);

