% stoermer_verlet
% This is a symplectic integrator of order 2
%
% for systems like:
%
% dq/dt = p
% dp/dt = f(q)
%
% with p = dy/dt and q = y
