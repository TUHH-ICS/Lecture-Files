% varargout = SystemInformation(varargin)
% SystemInformation M-file for SystemInformation.fig
%      SystemInformation, by itself, creates a new SystemInformation or raises the existing
%      singleton*.
%
%      H = SystemInformation returns the handle to a new SystemInformation or the handle to
%      the existing singleton*.
%
%      SystemInformation('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SystemInformation.M with the given input arguments.
%
%      SystemInformation('Property','Value',...) creates a new SystemInformation or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before SystemInformation_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to SystemInformation_OpeningFcn via varargin.
%
% Graphical user interface to display information about the system. This
% may be the perturbation of all generalized coordinates, which helps to
% get a feel for the system. Or the user can print some general information
% about the system. This is basically a collection of information which has
% been useful in the analysis of other systems, being available in the data
% structure.
% 
% For more information, please open the corresponding window and click on
% the help button, labeled with a question mark "?".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
%
% First appearance: 04.08.2009
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
