% writePsiTimeInt - This function prepares the userdefined parts of the
% functional criterion and then creates the files for numerical evaluation.
% 
% This file has several purposes:
% - ensure that G1 and F are stored as symbolic values. 
% - initialize a default value of Hend if it is undefined.
% - initialize a default value for the integration tolerance of the F part
%   of the criterion function. 
% - replace any occurences of names of coordinate systems in the user
%   defined criterion functions.
% - create functions for the numerical evaluation of the criterion
%   function.
% - calculate the vectors of initial conditions in the general implicit form
% 
% If coordinate systems are used to formulate the criterion function they
% should be used in the following way:
% The name of the coordinate system has to be followed by the name of the
% required property like r (Position) or omega (angular velocity). These
% should be separated by a dot. As the functional criterion is a scalar
% function, but the functions are vector functions the required coordinate
% has to be specified. 
% KSYS1.a(2) is interpreted as the x2-coordinate of the acceleration of KSYS1.
%
% The best way to understand how the initial conditions are to be
% formulated is to run the sensitivity analysis once without specifying the
% initial conditions and observe the initial conditions in sys.settings.opt.initCon
%
% See also: newOpt, matricesGradientTimeInt, OptiCalcInitCon,
%   writeFinalCond, writeOptiAdjoint, writeOptiDirect
%
% First appearance: 01.12.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
