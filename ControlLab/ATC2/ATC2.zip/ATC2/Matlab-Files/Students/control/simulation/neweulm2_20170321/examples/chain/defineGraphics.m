function defineGraphics(p)
% DEFINEGRAPHICS - create graphic visualization of bodies
%

% slide
ObjectHandle = drawCube([0 0 0],0.1,0.8,0.05,[0.6 0.6 0.6]);
addGraphics('S1', ObjectHandle);
ObjectHandle = drawCube([0 0 0.04],0.1,0.1,0.07,[0.3 0.3 0.3]);
addGraphics('S2', ObjectHandle);
h = drawSTL('chainLink2.stl', [0, 0, 0.01], 1, 1, 1, [0.5 0.5 0.5],[0.5 0.5 0.5]);
addGraphics('S2', h);

% 1. chain link
h = drawSTL('chainLink1.stl', [0, 0, 0], 1, 1, 1, [0.5 0.5 0.5],[0.5 0.5 0.5]);
addGraphics('P1_cg', h);

% p-1 chain links
for i=2:p
    P = 'P';
    num = num2str(i);
    cgSys = strcat(P,num,'_cg'); 
    if rem(i,2)
        h = drawSTL('chainLink1.stl', [0, 0, 0], 1, 1, 1, [0.5 0.5 0.5],[0.5 0.5 0.5]);
        addGraphics(cgSys, h);
    else
        h = drawSTL('chainLink2.stl', [0, 0, 0], 1, 1, 1, [0.5 0.5 0.5],[0.5 0.5 0.5]);
        addGraphics(cgSys, h);
    end
end

if rem(p,2)
    h = drawSTL('chainLink2.stl', [0, 0, -0.01], 1, 1, 1, [0.5 0.5 0.5],[0.5 0.5 0.5]);
    addGraphics('B', h);
else
    h = drawSTL('chainLink1.stl', [0, 0, -0.01], 1, 1, 1, [0.5 0.5 0.5],[0.5 0.5 0.5]);
    addGraphics('B', h);
end
h = drawSTL('box.stl', [0, 0, -0.005], 1.5, 1.5, 1.5, [0.68235 0.46667 0],[0.68235 0.46667 0]);
addGraphics('B', h);

