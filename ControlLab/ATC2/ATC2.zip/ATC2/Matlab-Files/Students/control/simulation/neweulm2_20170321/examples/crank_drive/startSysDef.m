%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% startSysDef                                                        %
%                                                                    %
% Programm to build a multi-body-system-model of a 2-cylinder        %
% V-engine, which can be found e.g. in a motorcycle. Central         %
% mechanical elements of the crank drive are the pistons, the        %
% piston rods and the crankshaft with the counter-mass.              %
% The external loads are the combustion gas forces, which act on     %
% the pistons and lead to the accessory drive torque on the          %
% crankshaft. The gas dorce uses a precalculated gas pressure, wich  %
% can be defined by the compression ratio and the maximum pressure.  %
%                                                                    %
% However, in this part of the example, only rigid bodys are         %
% modeled.                                                           %
%                                                                    %
% The definition is in the file sysDef.m                             %
% After this file has run, the system is fully available in symbolic %
% form, the numerical values for constants have been set and an      %
% animation window with graphic representations has been created.    %
% Then please call runTimeInt to perform a time integration.         %
%                                                                    %
% Of the files, which are called from here, the following are        %
% model specific. This means that you are kindly asked to adjust     %
% them to your need or copy them to start modelling a new system.    %
% - sysDef.m contains the system definition                          %
% - defineGraphics.m define graphic representations in the animation %
%   window                                                           %
%                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Author:       Dipl.-Ing. Christine Nowakowski
%               Dipl.-Ing. Thomas Kurz
%
% e-Mail:       kurz@itm.uni-stuttgart.de
%
% Institute:    Universitaet Stuttgart
%               Institut fuer Technische und Numerische Mechanik
%               Pfaffenwaldring 9
%               70569 Stuttgart
%

%%%%%%%%%%%%%%%%%%%%%%%%
% Extend path variable %
%%%%%%%%%%%%%%%%%%%%%%%%
run('../addpathNeweulm2.m');

%%%%%%%%%%%%%%%%%%%%%%%%
% Initialize workspace %
%%%%%%%%%%%%%%%%%%%%%%%%

% close all;
% clear all;
% clear global;
global sys;
tic;

%%%%%%%%%%%%%%%%%%%%%
% Define the system %
%%%%%%%%%%%%%%%%%%%%%

sysDef; % model-specific, please edit this file

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create nonlinear equations of motion %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

calcEqMotNonLin;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate reaction forces %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% calcForcesReaction;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create functions for numerical evaluation %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

writeMbsNonLin;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Linearize the equations of motion %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% calcEqMotLin;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create functions for numerical evaluation %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% writeMbsLin;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set numeric values for user defined parameters %
% This can also be done directly in sysDef.m     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% setUserVar; % model-specific, please edit this file

%%%%%%%%%%%%%%%%%%%%%%%%
% Initialize animation %
%%%%%%%%%%%%%%%%%%%%%%%%

% createAnimationWindow;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Add shapes in the animation window %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% defineGraphics; % model-specific, please edit this file

%%%%%%%%%%%%%%%%%%%
% Save the system %
%%%%%%%%%%%%%%%%%%%

% fprintf(1,'\nSaving System ...');
% save 'sys.mat' sys;
% fprintf(1,' ok!\n');
% 
% fprintf(1,'\n---\n');
toc;

% END OF startSysDef
