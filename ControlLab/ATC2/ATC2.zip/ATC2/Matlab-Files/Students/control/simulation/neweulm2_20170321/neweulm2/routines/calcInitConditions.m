% calcInitConditions(t0,y0,Dy0,varargin) - Find consistent intial
% conditions
%
%  Syntax:
% [y0, Dy0, D2y0, lambda0] = calcInitConditions(t0,y0,Dy0)
%
%  Description:
% Calculate initial conditions which are consistent with the constraint 
% equations. If only one return argument is specified, depending on the 
% currently selected system formulation, the vector of initial conditions 
% is returned. This consists of the usual return arguments combined in one 
% vector, if they are required.
%
%  Input arguments:
% t0 ........... Start time of the time interval {0}
% y ............ Generalized coordinates {zeros(sys.counters.genCoord,1)}
% Dy ........... Generalized velocities {zeros(sys.counters.genCoord,1)}
% 
%  Optional parameters {default value}
% UseWarning ... Logical, if true, only warnings are used. If false errors
%                are thrown instead {true}
% Method ....... Determine the method used to find the consistent initial
%                values {'DynamicRelaxation'}:
%                - 'FindRoot' for root search
%                - 'DynamicRelaxation' for dynamic relaxation 
% 
%  Return arguments:
% y0 ........ Consistent generalized coordinates or vector of initial
%             conditions depending on the system formulation.
% Dy0 ....... Consistent generalized velocities
% D2y0 ...... Consistent generalized velocities
% lambda0 ... Consistent lagrangian multipliers for the equations of motion
% exitflag .. Array containing the exitflags of the rootsearches
%
%  Example
%    x0 = calcInitConditions(0,zeros(sys.counters.genCoord,1),zeros(sys.counters.genCoord,1));
%    [y0, Dy0, D2y0, lambda0] = ...
%        calcInitConditions(0,zeros(sys.counters.genCoord,1),zeros(sys.counters.genCoord,1));
%
%  See also: timeInt
%
% First appearance: 01.07.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
