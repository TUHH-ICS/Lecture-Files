%% Definition of elastic beams, planar in xy-plane
% Crank: length 0.5, nodalfixed frame in [0;0;0]

%% Length 1
% length 1, nodalfixed frame in [0;0;0], z-axis
cd('/scratch/tmp/kurz/Models/dissertation/ansys_beam/')
createAnsysBeam('constraints',[0 0 0 0 0 0],'length',1,'nnodes',5,'axis',3);
cd('ansysTmp');
unix('/usr/local/ansys_13/v130/ansys/bin/ansys130 -b < myInputfile.inp > /dev/null');
cd('..')
[ElasticBody, ModRes] = ModalRed([1:5],8);
cd(fileparts(mfilename('fullpath')));
save('beam_3d_5n_4m_zAxis_length1_nodalfixed.mat', 'ElasticBody');
RedElasticBody_to_SID_ASCII(ElasticBody,'beam_3d_5n_4m_zAxis_length1_nodalfixed.SID_FEM');

% length 1, Buckens frame in [0.5;0;0], z-axis
cd('/scratch/tmp/kurz/Models/dissertation/ansys_beam/')
createAnsysBeam('constraints',[0 0 0 0 0 0],'length',1,'nnodes',5,'axis',3,'conRefSys',false(6,1));
cd('ansysTmp');
unix('/usr/local/ansys_13/v130/ansys/bin/ansys130 -b < myInputfile.inp > /dev/null');
cd('..')
[ElasticBody, ModRes] = ModalRed([1:5],[7:14]); % Omit Rigid body modes
cd(fileparts(mfilename('fullpath')));
save('beam_3d_5n_4m_zAxis_length1_freefree.mat', 'ElasticBody');
RedElasticBody_to_SID_ASCII(ElasticBody,'beam_3d_5n_4m_zAxis_length1_freefree.SID_FEM');

% length 1, nodalfixed frame in [0;0;0], y-axis
cd('/scratch/tmp/kurz/Models/dissertation/ansys_beam/')
createAnsysBeam('constraints',[0 0 0 0 0 0],'length',1,'nnodes',5,'axis',2);
cd('ansysTmp');
unix('/usr/local/ansys_13/v130/ansys/bin/ansys130 -b < myInputfile.inp > /dev/null');
cd('..')
[ElasticBody, ModRes] = ModalRed([1:5],8);
cd(fileparts(mfilename('fullpath')));
save('beam_3d_5n_4m_yAxis_length1_nodalfixed.mat', 'ElasticBody');

% length 1, Buckens frame in [0.5;0;0], y-axis
cd('/scratch/tmp/kurz/Models/dissertation/ansys_beam/')
createAnsysBeam('constraints',[0 0 0 0 0 0],'length',1,'nnodes',5,'axis',2,'conRefSys',false(6,1));
cd('ansysTmp');
unix('/usr/local/ansys_13/v130/ansys/bin/ansys130 -b < myInputfile.inp > /dev/null');
cd('..')
[ElasticBody, ModRes] = ModalRed([1:5],[7:14]); % Omit Rigid body modes
cd(fileparts(mfilename('fullpath')));
save('beam_3d_5n_4m_yAxis_length1_freefree.mat', 'ElasticBody');

% length 1, nodalfixed frame in [0;0;0], x-axis
cd('/scratch/tmp/kurz/Models/dissertation/ansys_beam/')
createAnsysBeam('constraints',[0 0 0 0 0 0],'length',1,'nnodes',5,'axis',1);
cd('ansysTmp');
unix('/usr/local/ansys_13/v130/ansys/bin/ansys130 -b < myInputfile.inp > /dev/null');
cd('..')
[ElasticBody, ModRes] = ModalRed([1:5],8);
cd(fileparts(mfilename('fullpath')));
save('beam_3d_5n_4m_xAxis_length1_nodalfixed.mat', 'ElasticBody');

% length 1, Buckens frame in [0.5;0;0], x-axis
cd('/scratch/tmp/kurz/Models/dissertation/ansys_beam/')
createAnsysBeam('constraints',[0 0 0 0 0 0],'length',1,'nnodes',5,'conRefSys',false(6,1));
cd('ansysTmp');
unix('/usr/local/ansys_13/v130/ansys/bin/ansys130 -b < myInputfile.inp > /dev/null');
cd('..')
[ElasticBody, ModRes] = ModalRed([1:5],[7:14]); % Omit Rigid body modes
cd(fileparts(mfilename('fullpath')));
save('beam_3d_5n_4m_xAxis_length1_freefree.mat', 'ElasticBody');


%% Length 2
% length 1, nodalfixed frame in [0;0;0], z-axis
cd('/scratch/tmp/kurz/Models/dissertation/ansys_beam/')
createAnsysBeam('constraints',[0 0 0 0 0 0],'length',2,'nnodes',5,'axis',3);
cd('ansysTmp');
unix('/usr/local/ansys_13/v130/ansys/bin/ansys130 -b < myInputfile.inp > /dev/null');
cd('..')
[ElasticBody, ModRes] = ModalRed([1:5],8);
cd(fileparts(mfilename('fullpath')));
save('beam_3d_5n_4m_zAxis_length2_nodalfixed.mat', 'ElasticBody');


% length 2, Buckens frame in [0.5;0;0], z-axis
cd('/scratch/tmp/kurz/Models/dissertation/ansys_beam/')
createAnsysBeam('constraints',[0 0 0 0 0 0],'length',2,'nnodes',5,'axis',3,'conRefSys',false(6,1));
cd('ansysTmp');
unix('/usr/local/ansys_13/v130/ansys/bin/ansys130 -b < myInputfile.inp > /dev/null');
cd('..')
[ElasticBody, ModRes] = ModalRed([1:5],[7:14]); % Omit Rigid body modes
cd(fileparts(mfilename('fullpath')));
save('beam_3d_5n_4m_zAxis_length2_freefree.mat', 'ElasticBody');

% length 2, nodalfixed frame in [0;0;0], y-axis
cd('/scratch/tmp/kurz/Models/dissertation/ansys_beam/')
createAnsysBeam('constraints',[0 0 0 0 0 0],'length',2,'nnodes',5,'axis',2);
cd('ansysTmp');
unix('/usr/local/ansys_13/v130/ansys/bin/ansys130 -b < myInputfile.inp > /dev/null');
cd('..')
[ElasticBody, ModRes] = ModalRed([1:5],8);
cd(fileparts(mfilename('fullpath')));
save('beam_3d_5n_4m_yAxis_length2_nodalfixed.mat', 'ElasticBody');

% length 2, Buckens frame in [0.5;0;0], y-axis
cd('/scratch/tmp/kurz/Models/dissertation/ansys_beam/')
createAnsysBeam('constraints',[0 0 0 0 0 0],'length',2,'nnodes',5,'axis',2,'conRefSys',false(6,1));
cd('ansysTmp');
unix('/usr/local/ansys_13/v130/ansys/bin/ansys130 -b < myInputfile.inp > /dev/null');
cd('..')
[ElasticBody, ModRes] = ModalRed([1:5],[7:14]); % Omit Rigid body modes
cd(fileparts(mfilename('fullpath')));
save('beam_3d_5n_4m_yAxis_length2_freefree.mat', 'ElasticBody');

% length 2, nodalfixed frame in [0;0;0], x-axis
cd('/scratch/tmp/kurz/Models/dissertation/ansys_beam/')
createAnsysBeam('constraints',[0 0 0 0 0 0],'length',2,'nnodes',5,'axis',1);
cd('ansysTmp');
unix('/usr/local/ansys_13/v130/ansys/bin/ansys130 -b < myInputfile.inp > /dev/null');
cd('..')
[ElasticBody, ModRes] = ModalRed([1:5],8);
cd(fileparts(mfilename('fullpath')));
save('beam_3d_5n_4m_xAxis_length2_nodalfixed.mat', 'ElasticBody');

% length 2, Buckens frame in [0.5;0;0], x-axis
cd('/scratch/tmp/kurz/Models/dissertation/ansys_beam/')
createAnsysBeam('constraints',[0 0 0 0 0 0],'length',2,'nnodes',5,'conRefSys',false(6,1));
cd('ansysTmp');
unix('/usr/local/ansys_13/v130/ansys/bin/ansys130 -b < myInputfile.inp > /dev/null');
cd('..')
[ElasticBody, ModRes] = ModalRed([1:5],[7:14]); % Omit Rigid body modes
cd(fileparts(mfilename('fullpath')));
save('beam_3d_5n_4m_xAxis_length2_freefree.mat', 'ElasticBody');


