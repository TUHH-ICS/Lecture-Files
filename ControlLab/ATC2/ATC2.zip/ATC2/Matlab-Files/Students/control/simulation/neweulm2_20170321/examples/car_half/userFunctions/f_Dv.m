function Dv = f_Dv(t)
% f_Dv - definition of 1st time-derivative of user-defined variable v

global sys;



% constant user-defined variables

c = sys.parameters.data.c;
excitation_phase = sys.parameters.data.excitation_phase;
z = sys.parameters.data.z;


% time dependent user-defined variables

Dv = zeros(1,1);

if(0.1560 < t && t < 0.7560)
    Dv(1) = 0.5*z*sin(c*t+excitation_phase)*c;
end
