% val_ = fastinterp1(xData,yData,x_cur)
% fastinterp1 - Fast 1D look-up table, using linear interpolation.
%
% For values of x_cur outside the given range by xData, no extrapolation is
% being done, the boundary value (yData(1) or yData(end)) is returned.
% If the set points are not evenly spaced, interp1q is called.
%
% Input values
% xData ... Independent variables
% yData ... Known dependent variables, so [xData,yData] describe the given
%           set values
% x_cur ... New independent variables for which the corresponding y_cur or
%           val_ respectively, shall be calculated
%
% Return values
% val_ .... Interpolated data points
% 
% See also: interp1, interp1q
%
% First appearance: 01.08.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
