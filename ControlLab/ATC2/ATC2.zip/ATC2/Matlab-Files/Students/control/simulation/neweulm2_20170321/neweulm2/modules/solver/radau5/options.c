#include <string.h>
#include "mex.h"
#include "options.h"

int opt_getSizeOfOptField (const mxArray *opt, const char *name, int *m, int *n)
{
  mxArray *field;
  
  field=mxGetField(opt,0,name);
  if (field==NULL) return 1;
  
  if (mxGetNumberOfDimensions(field)!=2) return 2;  
  
  if (mxIsEmpty(field)) return 3;
  
  *m=mxGetM(field);*n=mxGetN(field);
  return 0;
}

double opt_getDoubleFromOpt (const mxArray *opt, POptionSettings optSet,
  const char *name, double defaultValue)
{
  mxArray *field;
  
  field=mxGetField(opt,0,name);
  if ((field==NULL) ||  (mxIsEmpty(field)))
  {
    if (optSet->warnMiss) 
      mexPrintf("Option '%s' fehlt, nehme default %e\n",name,defaultValue);    
    return defaultValue;
  }    
  if (!mxIsDouble(field))
  {
    if (optSet->warnType)
      mexPrintf("Option '%s' hat falschen Typ, nehme default %e\n",name,defaultValue);
    return defaultValue;
  }
  if ((mxGetNumberOfDimensions(field)!=2) ||
      (mxGetM(field)!=1) || (mxGetN(field)!=1))
  {
    if (optSet->warnSize)
      mexPrintf("Option '%s' hat falsche Gr��e, nehme default %e\n",name,defaultValue);
    return defaultValue;
  }
  return mxGetScalar(field);
}

int opt_getDoubleVectorFromOpt (const mxArray *opt, POptionSettings optSet,
  const char *name, int m, int n, double *dpointer)
{
  int i,l;
  mxArray *field;
  double *dataPointer;
  
  mxAssert(m==1 || n==1,"getDoubleVectorFromOpt: m!=1 && n!=1");

  field=mxGetField(opt,0,name);
  if ((field==NULL) ||  (mxIsEmpty(field)))
  {
    if (optSet->warnMiss) mexPrintf("Option '%s' fehlt\n",name);    
    return 1;
  }    
  if (!mxIsDouble(field))
  {
    if (optSet->warnType) mexPrintf("Option '%s' hat falschen Typ\n",name);
    return 2;
  }
  if (((int)mxGetM(field)!=m) || ((int)mxGetN(field)!=n))
  {
    if (optSet->warnSize) mexPrintf("Option '%s' hat falsche Gr��e\n");
    return 3;
  }
  if (m>n) l=m; else l=n;
  
  dataPointer=mxGetPr(field);
  for (i=0; i<l; i++, dpointer++,dataPointer++)
    *dpointer= *dataPointer;
  
  return 0;
}

int opt_getIntFromOpt (const mxArray *opt, POptionSettings optSet,
  const char *name, int defaultValue)
{
  mxArray *field;
  mxClassID classID;
  
  field=mxGetField(opt,0,name);
  if ((field==NULL) ||  (mxIsEmpty(field)))
  {
    if (optSet->warnMiss) 
      mexPrintf("Option '%s' fehlt, nehme default %i\n",name,defaultValue);    
    return defaultValue;
  }    
  
  classID=mxGetClassID(field);
  switch (classID)
  {
    case mxDOUBLE_CLASS: case mxINT8_CLASS:   case mxUINT8_CLASS:
    case mxINT16_CLASS:  case mxUINT16_CLASS: case mxINT32_CLASS:
    case mxUINT32_CLASS: case mxINT64_CLASS:  case mxUINT64_CLASS:
    break;
    default:
    if (optSet->warnType)
      mexPrintf("Option '%s' hat falschen Typ, nehme default %i\n",
        name,defaultValue);
    return defaultValue;    
  }
    
  if ((mxGetNumberOfDimensions(field)!=2) ||
     (mxGetM(field)!=1) || (mxGetN(field)!=1))
  {
    if (optSet->warnSize)
      mexPrintf("Option '%s' hat falsche Gr��e, nehme default %i\n",
        name,defaultValue);
    return defaultValue;
  } 
  
  switch (classID)
  {
    case mxDOUBLE_CLASS: return (int)*((double*)mxGetData(field));break;
    case mxINT8_CLASS:   return (int)*((char*)mxGetData(field));break;
    case mxUINT8_CLASS:  return (int)*((unsigned char*)mxGetData(field));break;
    case mxINT16_CLASS:  return (int)*((short*)mxGetData(field));break;
    case mxUINT16_CLASS: return (int)*((unsigned short*)mxGetData(field));break;
    case mxINT32_CLASS:  return (int)*((int*)mxGetData(field));break;
    case mxUINT32_CLASS: return (int)*((unsigned int*)mxGetData(field));break;
    case mxINT64_CLASS:  return (int)*((long long*)mxGetData(field));break;
    case mxUINT64_CLASS: return (int)*((unsigned long long*)mxGetData(field));break;
    default:
      /* Cannot happen */
      break;
  }

  mxAssert(0,"getIntFromOpt: should not happen");
  return 0;
}

char* opt_getStringFromOpt (const mxArray *opt, POptionSettings optSet,
  const char *name, char* defaultValue)
{
  static char* noString = "<NULL>";
  
  mxArray *field;
  int buflen,takeDefault;
  char* erg;

  takeDefault=0;
  field=mxGetField(opt,0,name);
  if ((field==NULL) ||  (mxIsEmpty(field)))
  {
    if (optSet->warnMiss) 
      mexPrintf("Option '%s' fehlt, nehme default '%s'\n",name,
        defaultValue==NULL?noString:defaultValue);    
    takeDefault=1;
  } 
  
  if ((!takeDefault) && (!mxIsChar(field)))
  {
    if (optSet->warnType)
      mexPrintf("Option '%s' hat falschen Typ, nehme default %s\n",
        name,defaultValue==NULL?noString:defaultValue);
    takeDefault=1;
  }
  
  if (!takeDefault)
  {
    if ((mxGetNumberOfDimensions(field)!=2) || (mxGetM(field)!=1))
    {
      if (optSet->warnSize)
        mexPrintf("Option '%s' hat falsche Gr��e, nehme default %s\n",
          name,defaultValue==NULL?noString:defaultValue);
      takeDefault=1;
    }
  } 
  
  if (takeDefault)
  {
    if (defaultValue==NULL) return NULL;
    buflen=strlen(defaultValue)+1;
    erg=(char*)mxMalloc(buflen);
    strcpy(erg,defaultValue);
  } else
  {
    buflen=mxGetN(field)*sizeof(mxChar)+1;
    erg=(char*)mxMalloc(buflen);
    mxGetString(field,erg,buflen);
  }
  return erg;
}
