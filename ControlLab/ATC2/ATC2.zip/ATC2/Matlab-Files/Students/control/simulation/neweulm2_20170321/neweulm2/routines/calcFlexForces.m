% [h_e, h_g, h_omega, M] = calcFlexForces(body)
% Calculate force vectors for one flexible body, which has to be specified
% as input argument
%
% This function consists of four parts, which are returned
% - h_e ....... Vector of internal forces
% - h_g ....... Vector of external forces due to gravitation
% - h_omega ... Vector of coriolis and centrifugal forces
% - M ......... Mass matrix of this body as calculated by elastMassMatrix
%
% See also: calcEqMotNonLin, elastMassMatrix, computeHomega
% 
% First appearance: 18.05.2011 
%                   (As individual function, was a subfunction before)
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
