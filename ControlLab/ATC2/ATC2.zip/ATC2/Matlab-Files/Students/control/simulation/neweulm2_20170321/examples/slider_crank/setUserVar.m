%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                    %
% Definition of userdefined parameters                               %
% for the modell 'slider crank'                                      %
%                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%

global sys;

fprintf(1,'Setting Numerical Values ...');

% Gravitation
sys.parameters.data.g = 9.81;

% Pendulum 1
sys.parameters.data.m1 = 1;
sys.parameters.data.l1 = 0.5;

% Pendulum 2
sys.parameters.data.m2 = 1;
sys.parameters.data.l2 = 1;

% Pendulum 3
sys.parameters.data.m3 = 2;

fprintf(1,' ok!\n');
