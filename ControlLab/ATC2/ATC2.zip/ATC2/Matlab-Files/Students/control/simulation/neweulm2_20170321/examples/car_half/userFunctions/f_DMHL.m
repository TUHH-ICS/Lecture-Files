function DMHL = f_DMHL(t,varargin)

DMHL = 0;
