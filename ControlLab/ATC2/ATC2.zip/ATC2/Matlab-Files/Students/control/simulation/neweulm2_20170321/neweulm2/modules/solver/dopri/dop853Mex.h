#ifndef dop853Mexh
#define dop853Mexh

#include "dopriMex.h"

extern void DOP853_ (int *n, 
  DOPRIRightSide fcn, double *tStart, double *x, double *tEnd,
	double  *rtol, double *atol, int *itol,
	DOPRISolout solout, int *iout,
	double *work, int *lwork, int *iwork, int *liwork,
	double *rpar, int *ipar, int *idid);
	
extern double CONTD8_ (int *i,
  double *x,double *con,int *icomp,int *nd);

#endif
