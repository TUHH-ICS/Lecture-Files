% phi = rotmat2kardan(S,useSimplify, formulation_)
% ROTMAT2KARDAN - calculate kardan-angles from the rotation matrix. Can be
% used for symbolic or numeric input arguments.
% 
% Input arguments
% S .............. Rotation matrix
% useSimplify .... Optional logical parameter, whether the simplify command
%                  is to be used {true}
% formulation_ ... Parameter to specify the angular formulation,
%                  'kardan', 'euler', or any three element combination of
%                  the letters 'x','y','z'. E.g. 'xyz', numerical vectors
%                  are also accepted and then converted to letters. The
%                  parameter 'kardan' means 'xyz'; 'euler' means 'zxz'.
%                  {'kardan'}
% 
% Return arguments
% phi ........... Kardan-angles (rad)
%
% range of values:
%
% phi(1) : -pi/2 ... pi/2
% phi(2) : -pi/2 ... pi/2
% phi(3) : -pi/2 ... pi/2
%
% See also: kardan2rotmat
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
