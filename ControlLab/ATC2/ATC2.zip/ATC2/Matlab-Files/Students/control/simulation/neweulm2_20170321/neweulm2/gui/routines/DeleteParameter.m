% DeleteParameter(variable)
% DeleteParameter - Deletes the given parameter variable from sys.userVar.
% This function does not check if this parameter is still in use, which
% should be done beforehand. One easy way to do this is with the function
% subVar.m
%
% Function deletes parameter from
% sys.parameters.genCoord
% sys.parameters.constant
% sys.parameters.timeDependent
% sys.parameters.stateDependent
% 
% Input
% variable ... One parameter to be deleted
%
% First appearance: 01.07.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
