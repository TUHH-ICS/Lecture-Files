% English:
% =======
% RADAU5MEX: Interface for radau5
% [tNodes,xNodes,stats,taupred]=radau5Mex(f,t,x0,opt)
%
% Input:
%   f       right side: Either the name of a function 
%           or a function handle or an inline function
%           function must be declared as
%               function dx=f(t,x)
%   t       row (double) vector containing the t nodes where the
%           solution has to be evaluated. Minimal requirement:
%           two components (start- and end-value). If t has more
%           than two components then dense output will be 
%           enabled.
%   x0      (d,1) double start vector (d dimension)
%   opt     optional struct with options; see below
%
% Output:
%   tNodes  evaluated t nodes
%   xNodes  solution at nodes in t
%   stats   optional (1,8) vector with statistics
%           1. IDID of radau5
%              1 successfull integration
%              2 successfull integration (interrupted by OutputFunction)
%             <0 integration failed
%             -1 input is not consistent
%             -3 step size becomes too small
%             -4 matrix is repeatedly singular
%           2. number of f-evaluations (evaluations for
%              numerical differentiation to get the jacobian
%              are not counted)
%           3. number of jacobi-evaluations (either the given
%              function or the numerical approximation)
%           4. number of calculated steps
%           5. number of accepted steps
%           6. number of discarded steps
%           7. number of LU decompositions
%           8. number of forward and backward substitutions
%   taupred optional scalar with the next predicted step size
% 
% Options:
% (in round braces: defaults)
% [in square brackets: parameter name in RADAU5]
%
% If a option is needed and not found in the opt struct (or even
% the opt struct is missing), then the default-value in braces
% are used.
%
%  * RelTol (1e-3) [RTOL]
%      relative tolerance
%      either RelTol and AbsTol are both scalars or both are
%      (d,1) double vectors with RelTol and AbsTol for each
%      component.
%  * AbsTol (1e-6) [ATOL]
%      absolute tolerance 
%      either RelTol and AbsTol are both scalars or both are
%      (d,1) double vectors with RelTol and AbsTol for each
%      component.
%  * eps (1e-16) [WORK(1)]
%      rounding unit
%  * rho (0.9) [WORK(2)]
%      safety factors for step size control
%  * StepSizeMinSelection (0.2) [WORK(8)] and
%  * StepSizeMaxSelection (8.0) [WORK(9)]
%      parameters for step size selection
%      StipSizeMinSelection <= tauNew/tauOld <= StepSizeMaxSelection
%  * MaxStep (tEnd-tStart) [WORK(7)]
%      maximal step size
%  * InitialStep (1e-6) [H]
%      initial step size guess
%  * MaxNumberOfSteps (100000) [IWORK(2)]
%      maximal number of allowed steps
%  * FreezeStepSizeLeftBound (1.0) [WORK(5)] and
%  * FreezeStepSizeRightBound (1.2) [WORK(6)]
%      If FreezeStepSizeLeftBound<=tauNeu/tauOld<=FreeStepSizeRightBound,
%      then the step size is not changed. This saves LU-decompositions
%  * StepSizeStrategy (1) [IWORK(8)]
%      switch for step size strategy; possible values are 1 and 2
%      1: mod. predictive controller (Gustaffson)
%      2: classical step size control
%  * MaxNewtonIterations (7) [IWORK(3)]
%      the maximal number of Newton iterations for the solution of
%      the implicit system in each step.
%  * StartNewtonWithZeros (0) [IWORK(4)]
%      flag for starting value for Newton's method.
%       =0: extrapolated collocation solution is taken as starting value
%      ~=0: zero starting values are used
%  * NewtonStopCriterion ( min(0.03,sqrt(RelTol(1))) ) [WORK(4)]
%      stopping criterion for Newtons's method 
%  * DimensionOfIndex1Vars (d) [IWORK(5)]
%      dimension of the index 1 variables (must be >0)
%  * DimensionOfIndex2Vars (0) [IWORK(6)]
%      dimension of the index 2 variables
%  * DimensionOfIndex3Vars (0) [IWORK(7)]
%      dimension of the index 3 variables
%  * M1 (0) [IWORK(9)] and
%  * M2 (0) [IWORK(10)]
%      parameters for special structure. A problem has special
%      structure if 
%         x(i)' = x(i+M2)   for i=1,...,M1 
%      and M1=mm*M2 with an integer number mm>0. 
%      In this case only the nontrivial parts of the massmatrix
%      and the jacobian has to be given (cf. options Mass and 
%      Jacobian)
%  * MassLowerBandwidth (depends on Mass) [MLMAS]
%      switch for banded structure of the massmatrix; need not 
%      be defined, if Mass is not given.
%      If MassLowerBandwidth=d-M1 then the massmatrix is full 
%      (not banded) and the algebra is done by full-matrix
%      Gauss-Elimination.
%      If MassLowerBandwidth<d-M1 then the massmatrix is banded.
%      cf. Mass how to pass the matrix. 
%  * MassUpperBandwidth (depends on Mass) [MUMAS]
%      upper bandwidth of the massmatrix. Need not be defined if
%      Mass is not given or if MassLowerBandwidth=d-M1.
%      cf. Mass how to pass the matrix. 
%  * Mass (<none>) [MAS]
%      If no massmatrix is given, then the identity is assumed.
%      If MassLowerBandwidth=d-M1 then Mass has to be a full
%      (d-M1,d-M1) double matrix. If M1>0 then Mass has to be the
%      nontrivial lower right block of the massmatrix. 
%      If MassLowerBandwidth<d-M1 then the lower right (d-M1,d-M1) 
%      block of the Massmatrix is banded. Then Mass can be a 
%      (1+MassLowerBandwidth+MassUpperBandwidth,d-M1) double-matrix
%      or a (1,1+MassLowerBandwidth+MassUpperBandwidth) cell 
%      containing the diagonals. 
%      (type help radau5MexBanded for a detailed descritption how
%      to pass banded matrices.)
%  * JacobianLowerBandwidth (d-M1) [MLJAC]
%      switch for banded structure of the jacobian. 
%      If JacobianLowerBandwidth=d-M1 then the jacobian is full
%      (not banded) and the algebra is done by fill-matrix
%      Gauss-Elimination. 
%      If JacobianLowerBandwidth<d-M1 then the lower (d-M1,d)
%      block of the Jacobian is banded. 
%      cf. Jacobian how to pass the matrix.
%  * JacobianUpperBandwidth (d-m1) [MUJAC]
%      upper bandwidth of the jacobian. Need not be defined if
%      JacobianLowerBandwidth=d-M1.
%      cf. Jacobian how to pass the matrix.
%  * Jacobian (<none>) [JAC]
%      Function (string, function handle or inline) for the Jacobian.
%        function df=jacobian(t,x)
%      What to return depends on JacobianLowerBandwidth and M1.
%      If JacobianLowerBandwidth=d-M1 then the Jacobian is full
%      an this function has to return a (d-M1,d) double matrix.
%      The case JacobianLowerBandwidth<d-M1 is only supported, if
%      M1+M2=d (Remember: M1=mm*M2).
%      In this case the lower (d-M1,d) block of the Jacobian is
%      divided into mm+1 subblocks of size (M2,M2). Then the function 
%      has to return a (1,mm+1) cell containing the subblocks.
%      (type help radau5MexBanded for a detailed description hot
%      to pass the banded subblock matrices.)
%  * RecomputeJACFactor (0.001) [WORK(3)]
%      decides whether the jacobian should be recomputed.
%      The higher this value (like 0.1) the less often
%      the jacobian is evaluated. If evaluation of the jacobian 
%      is cheap, take a smaller value.
%      If RecomputeJACFactor<0 then the Jacobian is evaluated
%      after every accepted step.
%  * TransfromJACtoHess (0) [IWORK(1)]
%      switch to transform the jacobian to Hessenberg form.
%      This is only supported for M1=0 and not banded jacobians.
%
% --- Below are the options for the MEX-File; they do not belong to Radau5
%
%  * IncludeGridPointsInDenseOutput (0) 
%      if t has more than two components, dense output will be
%      enabled to make it possible to evaluate the solution at the
%      given t nodes. For the output vectors (tNodes,xNodes) there
%      are two possibilites:
%      If IncludeGridPointsInDenseOutput is 0, then (tNodes,xNodes) 
%      consists only of the evaluted solution at the given nodes.
%      If IncludeGridPointsInDenseOutput is not 0, then also the
%      additionally generated nodes are included.
%  * OutputFcn (<none>)
%      Output Function (name, handle or inline)
%      Let the name of the output function be outfcn. At the
%      beginning of the integration outfcn is called:
%      outfcn([tStart,tEnd],x0,'init')
%      After every successfull integration step outfcn is called:
%      status=outfcn(t,x,[],tOld) 
%      If outfcn returns status=1, then the integration is stopped/aborted
%      (even if tEnd was not reached).
%      At the end of the integration outfcn is called:
%      outfcn([],[],'done')
%      If dense output is enabled you can call radau5Mex INSIDE the
%      OutputFcn to get the solution at intermediate values in
%      the intervall [tOld,t], e.g.
%        xCenter = radau5Mex(tOld + 0.5*(t-tOld));
%      This is called an inner call or an call inside the output routine.
%      You can use this for Event Location.
%      There are already output functions available in Matlab:
%      cf: odeplot, odephas2, odephas3, odeprint
%  * OutputCallMode (1)
%      only relevant if dense output is enabled and an output function is given.
%      OutputCallMode defines when outfcn got called:
%        1 at the nodes given in t
%        2 at the nodes generated by seulex
%        3 case 1 and 2
%  * FuncCallMethod (1)
%      option to indicate, which method to use for calling external functions 
%      (like the right side or the output function) 
%        0 call maxCALLMATLAB direct
%          then ONLY names (strings) can be passed for functions
%        1 use maxCALLMATLAB to call feval
%          then ALSO function handles and inline-functions can be used
%  * OptWarnMiss (0)
%      Flag to warn if option is missing 
%        1 Warn if needed option in opt-struct is missing
%        0 don't warn
%  * OptWarnType (1)
%      Flag to warn if wrong type is found in options 
%        1 warn if a entry with wrong type is found in opt struct
%        0 don't warn
%  * OptWarnSize (1)
%      Flag to warn if option value has wrong size 
%        1 warn if a option value has wrong size 
%        0 don't warn
%
% The opt struct can be generated with odeset, although there are
% some additional entries and some other entries are missing. With
% odeset ONLY the following parameters can be set:
%  AbsTol,RelTol,OutputFcn,InitialStep,MaxStep,Jacobian,Mass
%
%  IMPORTANT NOTICE (if the right side is also a MEX-File)
%     the right side must not "garble" the passed mxArrays:
%     the size must not be changed and the memory must not
%     be freed. 
%     Hence: the right side has to take care, that the
%     passed mxArrays have the same size and enough memory
%     when returning. The values in the memory(-block)
%     may be overwritten.
%     If the right side is an m-file MATLAB obeys this
%     restriction automatically.
%
%
%
%
% German:
% =======
% RADAU5MEX: Interface zu radau5
% [tGitter,xGitter,stats,taupred]=radau5Mex(f,t,x0,opt)
% 
% Input:
%   f       rechte Seite: entweder name oder Funktion oder
%           ein function handle oder eine inline Funktion der Form
%               function dx=f(t,x)
%   t       Zeilenvektor mit auszuwertenden t Stellen, muss mindestens
%           2 Werte (Start- und Endwert) enthalten. Bei mehr als zwei
%           Werten wird auf dense-Output umgeschaltet
%   x0      (d,1) double-Startvektor (d Systemdimension)
%   opt     optionale struct mit Optionen: vgl. Beschreibung unten
%
% Output:
%   tGitter ausgewertete Zeitpunkte
%   xGitter L�sung f�r Zeitpunkte tGitter
%   stats   optionaler (1,8)-Vektor mit Statistik:
%           1. IDID von radau5:
%              1 Erfolgreiche Integration
%              2 Erfolgreiche Integration (vorz. Abbruch durch OutputFunction)
%             <0 erfolglose Integration
%             -1 inkonsistente Eingaben
%             -3 Schrittweite wurde zu klein
%             -4 Matrix wiederholt singul�r
%           2. Anzahl der f-Auswertungen (die evtl. numerische Berechnung 
%              der Jacobimatrix wird nicht mitgez�hlt)
%           3. Anzahl der Jacobi-Auswertungen (durch Aufruf einer
%              Funktion, die diese berechnet, oder auch die numerische
%              Approximation)
%           4. Anzahl der berechneten Schritte
%           5. Anzahl der akzeptierten Schritte
%           6. Anzahl der verworfenen Schritte
%           7. Anzahl der LR-Zerlegungen 
%           8. Anzahl der Vorw�rts- und R�ckw�rtssubstitutionen
%   taupred optionaler Skalar mit dem n�chsten Schrittweitenvorschlag
%
% Optionen:
% (in runden Klammern: defaults)
% [in eckigen Klammern: entsprechender Name bei radau5]
%
% Falls eine Option ben�tigt wird und nicht in der opt-struct vorhanden ist
% (oder die opt-struct selbst fehlt), so wird der in Klammern angegebene
% default-Wert verwendet.
%
%  * RelTol (1e-3) [RTOL]
%      relative Toleranz 
%      entweder sind RelTol und AbsTol beide Skalare oder beide 
%      (d,1)-double-Vektoren f�r die einzelnen Zustands-Komponenten
%  * AbsTol (1e-6) [ATOL]
%      absolute Toleranz 
%      entweder sind RelTol und AbsTol beide Skalare oder beide 
%      (d,1)-double-Vektoren f�r die einzelnen Zustands-Komponenten
%  * eps (1e-16) [WORK(1)]
%      Maschinengenauigkeit 
%  * rho (0.9) [WORK(2)]
%      Sicherheitsfaktor bei der Schrittweitensteuerung 
%  * StepSizeMinSelection (0.2) [WORK(8)]
%      Untere Grenze bei der Schrittweitensteuerung
%        StepSizeMinSelection <= tauNew/tauOld
%  * StepSizeMaxSelection (8.0) [WORK(9)]
%      Obere Grenze bei der Schrittweitensteuerung
%         tauNeu/tauOld <= StepSizeMaxSelection
%  * MaxStep (tEnd-tStart) [WORK(7)]
%      maximale Schrittweite
%  * InitialStep (1e-6) [H]
%      Startschrittweite, falls InitialStep=0.0 ist, so wird die 
%      Startschrittweite auf 1e-6 gesetzt.
%  * MaxNumberOfSteps (100000) [IWORK(2)]
%      maximale Anzahl von Schritten
%  * FreezeStepSizeLeftBound (1.0) [WORK(5)] und
%  * FreezeStepSizeRightBound (1.2) [WORK(6)]
%      Gilt FreezeStepSizeLeftBound<=tauNew/tauOld<=FreeStepSizeRightBound,
%      so wird die Schrittweite nicht ver�ndert.
%      Damit k�nnen f�r gro�e Systeme LR-Zerlegungen
%      gespart werden. 
%  * StepSizeStrategy (1) [IWORK(8)]
%      Switch, welche Strategie bei der Schrittweitenwahl
%      verfolgt werden soll. M�gliche Werte: 1 oder 2.
%       1: Predictive Controller (Gustafsson)
%       2: klassische Schrittweitenwahl
%  * MaxNewtonIterations (7) [IWORK(3)]
%      Die maximale Anzahl von Newton-Iterationen pro Schritt
%      zur L�sung des impliziten Systems 
%  * StartNewtonWithZeros (0) [IWORK(4)]
%      Flag, ob die Newton-Iteration mit dem Nullvektor
%      gestartet werden soll. Ist StartNewtonWithZeros=0,
%      so wird die extrapolierte Kollokationsl�sung
%      als Startwert verwendet.
%  * NewtonStopCriterion ( min(0.03,sqrt(RelTol(1))) ) [WORK(4)]
%      Der Standardwert wird so berechnet:
%      Genauigkeitsschranke f�r Abbruch der Newtoniteration.
%  * DimensionOfIndex1Vars (d) [IWORK(5)]
%      Dimension der Index 1 Variablen. 
%  * DimensionOfIndex2Vars (0) [IWORK(6)]
%      Dimension der Index 2 Variablen.
%  * DimensionOfIndex3Vars (0) [IWORK(7)]
%      Dimension der Index 3 Variablen.  
%  * M1 (0) [IWORK(9)] und
%  * M2 (0) [IWORK(10)]
%      Parameter f�r Spezialstruktur. Ein Problem hat Spezialstruktur, 
%      falls
%         x(i)' = x(i+M2)   for i=1,...,M1 
%      und M1=mm*M2 mit einer nat�rlichen Zahl mm>0 gilt.
%      In diesem Fall muss nur der nicht-triviale Teil der 
%      Massenmatrix und der Jacobimatrix angegeben werden (vgl.
%      Mass und Jacobian).
%  * MassLowerBandwidth (von Mass abh�ngig) [MLMAS]
%      Schalter f�r Bandstruktur bei der Massenmatrix; braucht nicht
%      angegeben werden, falls Mass nicht angegeben wird.
%      Falls MassLowerBandwidth=d-M1 dann ist die Massenmatrix 
%      vollbesetzt (hat keine Bandstruktur) und die lineare Algebra
%      wird mit voller Gauss-Elimination durchgef�hrt.
%      Falls MassLowerBandwidth<d-M1 hat die Massenmatrix 
%      Bandstruktur. 
%      vgl. dann Mass, wie die Matrix zu �bergeben ist.
%  * MassUpperBandwidth (von Mass abh�ngig) [MUMAS]
%      Gibt die obere Bandbreite der Massenmatrix an.
%      Falls Mass fehlt oder MassLowerBandwidth=d-m1 ist,
%      so muss diese Option nicht angegeben werden.
%  * Mass (<keine>) [MAS]
%      Eine Matrix oder eine cell mit Vektoren, die
%      die Massenmatrix beschreibt. Wenn Mass nicht
%      vorhanden ist, wird davon ausgegangen, dass die Massenmatrix
%      die Identit�t ist. Was erwartet wird  h�ngt auch von 
%      MassLowerBandwidth ab. Der einfachste Fall ist eine 
%      vollbesetzte  Massenmatrix der Dimension (d,d). 
%      Dann muss MassLowerBandwidth=d sein (au�er es handelt sich
%      um ein Problem mit Spezialstruktur). N�here Informationen
%      in der pdf-Dokumentation.
%  * JacobianLowerBandwidth (d-m1) [MLJAC]
%      Gibt die untere Bandbreite der Jacobimatrix an.
%      Falls JacobianLowerBandwidth=d-m1 ist, so wird die Jacobimatrix
%      als vollbesetzt vorausgesetzt. Ist dann unter Jacobian eine 
%      Funktion angegeben, so muss diese dann die vollbesetzte Jacobimatrix
%      zur�ckliefern. 
%      F�r JacobianLowerBandwidth<d-m1 hat der untere (d-M1,d) Block
%      der Jacobimatrix Bandstruktur. 
%      vgl. dann Jacobian, wie die Jacobi-Matrix zu �bergeben ist.
%  * JacobianUpperBandwidth (d-m1) [MUJAC]
%      Gibt die obere Bandbreite der Jacobimatrix an. Wird nur ben�tigt
%      falls JacobianLowerBandwidth!=d-m1 ist. N�here Informationen
%      in der pdf-Dokumentation.
%  * Jacobian (<keine>) [JAC]
%      Funktion (string, function handle oder Inline) f�r die Jacobimatrix.
%      Diese Funktion muss die Form 
%        function df=jacobian(t,x)
%      haben. Was diese Funktion zur�ckgeben muss, h�ngt von 
%      JacobianLowerBandwidth und M1 ab.
%      Falls JacobianLowerBandwidth=d-M1 dann ist die Jacobimatrix
%      vollbesetzt und die Funktion muss eine (d-M1,d) double Matrix
%      zur�ckliefern. 
%      Der Fall JacobianLowerBandwidth<d-M1 wird nur unterst�tzt, falls
%      M1+M2=d (beachten Sie: M1=mm*M2).
%      In diesem Fall ist der untere (d-M1,d) Block der Jacobimatrix in
%      mm+1 Unterbl�cke der Gr��e (M2,M2) unterteilt. Dann muss die
%      Funktion eine (1,mm+1) cell zur�ckgeben, welche die Unterbl�cke
%      enth�lt. 
%      (mit help radau5MexBanded gibt es eine ausf�hrliche Beschreibung
%      wie Matrizen mit Bandstrukturen �bergeben werden.)
%  * RecomputeJACFactor (0.001) [WORK(3)]
%      Indikator, wann die Jacobimatrix neuberechnet werden soll.
%      Je h�her dieser Wert (etwa 0.1), desto seltener wird die
%      Jacobimatrix ausgewertet. Wenn die Jacobimatrix einfach auszuwerten
%      ist, etwa bei kleinen Systemen, so ist ein kleinerer Wert,
%      wie 0.001, angebracht. Falls RecomputeJACFactor<0 ist, so
%      wird nach jedem akzeptierten Schritt die Jacobimatrix neu
%      ausgewertet. 
%  * TransfromJACtoHess (0) [IWORK(1)]
%      Flag, ob die Jacobimatrix auf Hessenberggestalt gebracht
%      werden soll. Dies wird nur unterst�tzt, falls die Massenmatrix
%      die Identit�t ist und m1=0 und die Jacobimatrix nicht
%      Bandstruktur hat.
%
% --- Ab jetzt kommen Optionen, die zum MEX-File geh�ren,
% --- nicht mehr zu radau5.
%
%  * IncludeGridPointsInDenseOutput (0) 
%      falls t mehr als zwei Werte enth�lt, wird auf dense-Output 
%      umgeschaltet, damit an den angegeben Stellen ausgewertet werden kann.
%      F�r die Ausgabe (tGitter,xGitter) gibt es nun zwei M�glichkeiten: 
%      IncludeGridPointsInDenseOutput ist 0, dann enth�lt (tGitter,xGitter) 
%      nur die Ausgabe an den vorgegebenen Stellen. Ist  
%      IncludeGridPointsInDenseOutput verschieden von 0, so werden 
%      zus�tzlich auch noch die von radau5 generierten Gitterpunkte 
%      ausgegeben.
%  * OutputFcn (<keine>)
%      Output Funktion (Name oder Handle oder Inline)
%      Sei der Name der OutputFunction outfcn. Dann wird zu Beginn der 
%      Integration aufgerufen: 
%      outfcn([tStart,tEnd],x0,'init'). 
%      Nach jedem erfolgreichen Integrationsschritt wird aufgerufen: 
%      status=outfcn(t,x,[],tOld).
%      Liefert outfcn einen status=1, so wird die Integration abgebrochen 
%      (auch wenn tEnd noch nicht erreicht). Sonst geht es weiter. Am Ende 
%      der Integration wird aufgerufen: 
%      outfcn([],[],'done')
%      Falls die kontinuierliche Ausgabe (dense output) aktiviert ist,
%      kann man radau5Mex INNERHALB der OutputFcn aufrufen, um die
%      L�sung an Zwischenstellen im Intervall [tOld,t] zu bekommen, z.B.
%        xCenter = radau5Mex(tOld + 0.5*(t-tOld));
%      Das wird inner call oder Aufruf aus der Output Routine genannt.
%      Dies kann f�r Event Location verwendet werden.
%      Es gibt schon vorgefertigte OutputFunctions in Matlab:
%      vgl.: odeplot, odephas2, odephas3, odeprint
%  * OutputCallMode (1)
%      nur bei dense-Output mit OutputFunction interessant. Bestimmt wann 
%      outfcn aufgerufen wird:
%        1 bei den in t angegeben Stellen
%        2 bei den von radau5 erstellen Gitterpunkten
%        3 sowohl 1 und 2
%  * FuncCallMethod (1)
%      gibt an, welche Methode zum Aufruf "externer" Funktionen (z.B.
%      rechte Seite oder Output-Funktion) verwendet werden soll:
%        0 direkt mexCallMATLAB verwenden 
%          dann k�nnen NUR Funktionsnamen �bergeben werden
%        1 feval mit mexCALLMATLAB verwenden
%          dann k�nnen AUCH Funktions-Handle und Inline-Funktionen
%          �bergeben werden.
%  * OptWarnMiss (0)
%      Warnungsflag bei fehlenden Optionen
%        1 Warnung, wenn in opt-struct eine ben�tigte Option fehlt
%        0 keine Warnung
%  * OptWarnType (1)
%      Warnungsflag bei Optionen mit falschem Typ
%        1 Warnung, wenn in opt-struct ein Eintrag den falschen Datentyp hat
%        0 keine Warnung
%  * OptWarnSize (1)
%      Warnungsflag bei Optionen mit falscher Gr��e
%        1 Warnung, wenn in opt-struct ein Eintrag die falsche Gr��e hat
%        0 keine Warnung
%
% opt kann auch mit odeset generiert werden, obwohl dort dann  mehr 
% Felder generiert werden, als ben�tigt und einige Optionen von hier 
% nicht unterst�tzt werden. Also kann man mit odeset NUR einstellen:
%  AbsTol,RelTol,OutputFcn,InitialStep,MaxStep,Jacobian,Mass
%
%  WICHTIGE Anmerkung (falls "f" oder "Jacobian" auch MEX-File ist)
%     diese MEX-Files d�rfen die �bergebenen mxArrays nicht "verst�mmeln": 
%     die Gr��e darf nicht ver�ndert werden und auch der Speicherplatz 
%     darf nicht freigegeben werden. Also: es muss  sichergestellet sein, 
%     dass die �bergebenen mxArrays am Ende wieder diesselbe Gr��e und 
%     ausreichend Speicher haben. Der Speicher selbst darf nat�rlich zu 
%     rechenzwecken �berschrieben werden.
%     Bei m-Files muss man darauf keine R�cksicht nehmen, denn da achtet 
%     MATLAB automatisch darauf.
%
