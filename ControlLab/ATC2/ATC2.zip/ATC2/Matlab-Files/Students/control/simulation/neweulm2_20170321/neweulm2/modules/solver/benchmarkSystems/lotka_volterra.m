% lotka_volterra
% The Lotka-Volterra equations, also known as predator-prey 
% equations, are a very simple system with an invariant. The 
% system can be used to test symplectic integrators because 
% all solutions are closed trajectories. 
