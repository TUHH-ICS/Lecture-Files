%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% startSysDef                                                        %
%                                                                    %
% Program to build a multi-body-system model                         %
% This example is a very simple, linear multibody system. The model  %
% consists of n rigid bodies connected with springs. The             %
% time-dependent force is applied at the first body and the last     %
% body is connected to a wall by a spring. The generalized           %
% coordinates are used as output, whereas  the force acting on the   %
% first body is used as an input. In dependency of the chosen        %
% output, a different number of system zeros can be observed in      %
% the frequency response plot.                                       %
%                                                                    %
% The definition is in the file sysDef.m                             %
% After this file has run, the system is fully available in symbolic %
% form, the numerical values for constants have been set and an      %
% animation window with graphic representations has been created.    %
% Then you have several possibilities as to what you want to do with %
% this model:                                                        %
% - runTimeInt performs a time integration                           %
% - runKiAn performs a kinematic analysis                            %
% - runModalAnalysis calculates Eigenmodes and displays them         %
%                                                                    %
% Of the files, which are called from here, the following are        %
% model specific. This means that you are kindly asked to adjust     %
% them to your need or copy them to start modelling a new system.    %
% - sysDef.m contains the system definition                          %
% - defineGraphics.m define graphic representations in the animation %
%   window                                                           %
%                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Author:       Dipl.-Ing. Markus Burkhardt
%
% e-Mail:       markus.burkhardt@itm.uni-stuttgart.de
%
% Institute:    University of Stuttgart
%               Institute of Engineering and Computational Mechanics
%               Pfaffenwaldring 9
%               70569 Stuttgart
%               GERMANY
%

%%%%%%%%%%%%%%%%%%%%%%%%
% Extend path variable %
%%%%%%%%%%%%%%%%%%%%%%%%

run('../addpathNeweulm2');

%%%%%%%%%%%%%%%%%%%%%%%%
% Initialize workspace %
%%%%%%%%%%%%%%%%%%%%%%%%

close all;
clear all;
clear global;
global sys;
tic;

%%%%%%%%%%%%%%%%%%%%%
% Define the system %
%%%%%%%%%%%%%%%%%%%%%

sysDef; % model-specific, please edit this file

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create nonlinear equations of motion %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

calcEqMotNonLin;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create functions for numerical evaluation %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

writeMbsNonLin;

%%%%%%%%%%%%%%%%%%%%%%%%
% Initialize animation %
%%%%%%%%%%%%%%%%%%%%%%%%

createAnimationWindow;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Add shapes in the animation window %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

defineGraphics; % model-specific, please edit this file

%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Frequency response plot %
%%%%%%%%%%%%%%%%%%%%%%%%%%%

freqResPlot;

%%%%%%%%%%%%%%%%%%%
% Save the system %
%%%%%%%%%%%%%%%%%%%

fprintf(1,'\nSaving System ...');
save 'sys.mat' sys;
fprintf(1,' ok!\n');

fprintf(1,'\n---\n');
toc;

% END OF startSysDef
