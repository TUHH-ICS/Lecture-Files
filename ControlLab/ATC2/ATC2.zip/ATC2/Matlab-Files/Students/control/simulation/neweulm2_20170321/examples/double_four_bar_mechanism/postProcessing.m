function postProcessing
% postProcessing - Compute potential and kinetic energies of the double
% four-bar mechanism

global sys;

g_ = sys.parameters.data.g;
m_ = sys.parameters.data.m;

t        = sys.results.timeInt.x; 
y        = sys.results.timeInt.y; 
position = sys.results.timeInt.outPosition;
velocity = sys.results.timeInt.outVelocity;

W_kin = zeros(size(t));
W_pot = zeros(size(t));

if ~(exist('sysFunctions/eqm_nonlin_Mq','file') == 2)
    Mq_ = blkdiag(sys.dynamics.nonlinear.generic.Mq{:});
    fid = fopen('sysFunctions/readMassMatrix.m','w');
    printLine(fid,'function Mq_ = readMassMatrix(t_,y_)');
    printLine(fid);
    printLine(fid,'global sys;');
    printLine(fid);
    vars_ = findSyms(Mq_);
    writeHelpvarDef(fid,'useInput',vars_);
    writeGenCoordDef(fid,'gcvector',vars_);
    printLine(fid);
    fprintf(fid,sym2mcode('Mq_',Mq_,'Optimize',sys.settings.equation.optimize));
    fclose(fid);
    newFile = 1;
    addpath('sysFunctions/');
else
    newFile = 0;
end

for i_ = 1:length(t);
    t_ = t(i_);
    y_ = y(:,i_);
    v_ = velocity(:,i_);
    if newFile
        M_ = readMassMatrix(t_,y_);
    else
        M_ = eqm_nonlin_Mq(t_,y_);
    end
    W_kin(i_) = 0.5*v_.'*M_*v_;
end

for i_ = 1:length(t);
    p_ = position(:,i_);
    for j_ = 1:length(p_)
        W_pot(i_) = W_pot(i_) + m_*g_*p_(j_);
    end    
end

W_pot_start = W_pot(1);
W_pot = W_pot - W_pot_start;

save W_kin W_kin
save W_pot W_pot




