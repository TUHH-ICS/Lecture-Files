% newKinematic(varargin)
% Declare kinematic used to set up the multibody system and improve the
% performance. Usually users do not have to worry about them.
% The function call is similar to the definition of time or state dependent
% parameters. As abbreviations are internal parameters by definition, they
% have to end on an underscore. If this is not provided, an underscore is
% appended.
%
% See also: newConstant, newTimeDependent, newStateDependent
%
% First appearance: 14.04.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
