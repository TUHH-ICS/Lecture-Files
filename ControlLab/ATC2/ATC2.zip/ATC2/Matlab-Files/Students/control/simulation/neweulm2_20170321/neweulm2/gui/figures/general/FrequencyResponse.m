% FREQUENCYRESPONSE M-file for FrequencyResponse.fig
%      FREQUENCYRESPONSE, by itself, creates a new FREQUENCYRESPONSE or
%      raises the existing singleton*.
%
%      H = FREQUENCYRESPONSE returns the handle to a new FREQUENCYRESPONSE
%      or the handle to the existing singleton*.
%
%      FREQUENCYRESPONSE('CALLBACK',hObject,eventData,handles,...) calls
%      the local function named CALLBACK in FREQUENCYRESPONSE.M with the
%      given input arguments.
%
%      FREQUENCYRESPONSE('Property','Value',...) creates a new
%      FREQUENCYRESPONSE or raises the existing singleton*. Starting from
%      the left, property value pairs are applied to the GUI before
%      FrequencyResponse_OpeningFcn gets called. An unrecognized property
%      name or invalid value makes property application stop. All inputs
%      are passed to FrequencyResponse_OpeningFcn via varargin.
%
% Graphical user interface to calculate frequency response curves from
% system inputs to system outputs at given frequency sample points.
% 
% For more information, please open the corresponding window and click on
% the help button, labeled with a question mark "?".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
%
% First appearance: 17.03.2010
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
