% exportEqMot(varargin) - Write the equations of motion, or some interesting
% values to a file, where all parameter values are defined in the file 
% itself.
% 
%  Syntax:
%> exportEqMot;
%> exportEqMot('Property', value, ...);
%     
%  Description:
% This makes it independent of the global structure sys. Therefore it is
% called export,
% because there is no way back to the actual system.
%
%  Input arguments, given pairwise:
% all optional, have to be followed pairwise by a boolean value true/false
% Numeric .......... If the parameters shall be kept, or numerical values
%                    inserted instead {true}, meaning numerical values
% Symbolic ......... If the parameters shall be kept, or numerical values
%                    inserted instead {true}, meaning symbolic expressions
% Nonlinear ........ If the nonlinear or the linearized equations of motion
%                    are to be exported {true}, meaning nonlinear equations
% Linear ........... If the nonlinear or the linearized equations of motion
%                    are to be exported {true}, meaning linear equations
% Expression ....... A given expression is written in a file. For this a
%                    filename should be specified. This allows the export
%                    of any given symbolic expression. The second
%                    argument has to be the expression, or a structure
%                    containing the expressions to be exported, if several.
% SystemMatrices ... Creates a file similar to eqm_lin_ssinout.m only
%                    containing the numerical values.
% WhiteList ........ Here a list of parameters can be passed. Then if
%                    'Numeric',true is selected, these parameters still
%                    remain as symbolic values. {}
% Input ............ Here a list of names of parameters can be passed. {}
%                    These parameters will be regarded as the system
%                    input vector u_ and the equations of motion will
%                    contain another input argument, giving them the
%                    form: eqm_nonlin_ss(t,x_,u_)
%
%          Attention! The user has to make sure that this definition
%             of an input makes sense! Here nothing is checked!! 
% 
% Filename ......... A filename can be specified.
% CheckVarargin ... An advanced feature to avoid errors if invalid
%                   parameters are passed. This is only if you know
%                   exactly what you are doing. {true}
% 
%  Return argument:
% mydata ... The structure containing the symbolic expressions which have
%            been exported. This is exactly what has been written in the
%            file, so some parameters may be replaced.
% 
%  Example:
%>  exportEqMot;
%>  exportEqMot('Linear',true','Symbolic',false);
%
%  See also: writeSysDef, writeSfunction, symStruct2num, sym2mcode
%
% First appearance: 19.12.2008
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
