%% Neweulm2 
% <html>
% <hr>
%   <h2>Getting Started</h2>
% </html>
% 
% * <whatis.html What is Neweulm2>
% * <model.html Available models>
% * <software_structure.html Structure of the software>
%
%
% <html>
%   <hr>
%   <h2>Function Reference</h2>
% </html>
% 
% * <functions_help.html Functions by Category>
%
%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2012 ITM University of Stuttgart
%        <tt class="minicdot">&#149;</tt>
%        <a href="http://www.itm.uni-stuttgart.de">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:./LICENSE.html">Terms of Use</a>
%   </p>
% </html>