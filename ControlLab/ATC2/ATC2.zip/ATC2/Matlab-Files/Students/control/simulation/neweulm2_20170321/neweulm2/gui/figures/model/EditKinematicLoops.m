%EDITKINEMATICLOOPS M-file for EditKinematicLoops.fig
%      EDITKINEMATICLOOPS, by itself, creates a new EDITKINEMATICLOOPS or
%      raises the existing singleton*.
%
%      H = EDITKINEMATICLOOPS returns the handle to a new
%      EDITKINEMATICLOOPS or the handle to the existing singleton*.
%
%      EDITKINEMATICLOOPS('Property','Value',...) creates a new
%      EDITKINEMATICLOOPS using the given property value pairs.
%      Unrecognized properties are passed via varargin to
%      EditKinematicLoops_OpeningFcn.  This calling syntax produces a
%      warning when there is an existing singleton*.
%
%      EDITKINEMATICLOOPS('CALLBACK') and
%      EDITKINEMATICLOOPS('CALLBACK',hObject,...) call the local function
%      named CALLBACK in EDITKINEMATICLOOPS.M with the given input
%      arguments.
%
% Graphical user interface to edit and define kinematic loops.
% 
% For more information, please open the corresponding window and click on
% the help button, labeled with a question mark "?".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
%
% First appearance: 01.07.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
