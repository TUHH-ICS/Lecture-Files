function Dy = f_Dy(t)
% f_Dy - definition of 1st time-derivative of user-defined variable y

global sys;



% constant user-defined variables

yAmp = sys.parameters.data.yAmp;
yOmega = sys.parameters.data.yOmega;
Dy = zeros(1,1);

Dy(1) = -1.0*yAmp*yOmega*sin(t*yOmega);


% END OF FILE

