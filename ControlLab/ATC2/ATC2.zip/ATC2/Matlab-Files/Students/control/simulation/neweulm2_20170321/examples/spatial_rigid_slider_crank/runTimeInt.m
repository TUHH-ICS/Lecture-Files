%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                   %
%                             runTimeInt                            %
%                                                                   %
% Perform a time integration of the nonlinear equations of motion   %
% and start an animation of the results and plot result             %
%                                                                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global sys

% If no animation window exists, create one
if(isempty(sys.graphics.axes) || ~ishandle(sys.graphics.axes))
    defineGraphics;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initialize all values and parameters for the time integration

% Time Intervall [t0, t1] for the numerical integration
timeInterval = [0, 5];

% Initialization
y0  = zeros(sys.counters.genCoord,1); % For the generalized coordinates on position level
Dy0 = zeros(sys.counters.genCoord,1); % For the generalized coordinates on velocity level

% Specify values

Ay = sys.parameters.data.Ay;
Az = sys.parameters.data.Az;
l_AB = sys.parameters.data.l_AB;
l_BC = sys.parameters.data.l_BC;

l_0B = sqrt(Ay^2 + (Az+l_AB)^2);

eta = asin(Ay/l_0B);
beta = acos(l_0B/l_BC);
s = sqrt(l_BC^2 - l_0B^2);

y0(1,1) = 0;
y0(2,1) =  - eta;
y0(3,1) = beta;
y0(4,1) = s;

Dy0(1,1) = 6;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ensure that system dimension is not exceeded
y0  = y0(1:sys.counters.genCoord);
Dy0 = Dy0(1:sys.counters.genCoord);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Choose the integration algorithm, leave empty for standard choice
% There are several integration algorithms available, Matlab offers
% ode45, ode15s, ode23, ode113, ode23s, ode23t, ode23tb
%
% Recommended choices are, if available:
% Systems with tree structure:       ode45, dop853Mex
% Systems with constraint equations: ode15s, radauMex
integrator = @ode45;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Integration options and tolerances
sys.settings.timeInt.intOpts = odeset;
sys.settings.timeInt.intOpts = odeset(sys.settings.timeInt.intOpts, 'RelTol', 1e-4); % Relative tolerances
sys.settings.timeInt.intOpts = odeset(sys.settings.timeInt.intOpts, 'AbsTol', 1e-4); % Absolute tolerances, Increasing this value can worsen the results!

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Activate a measure to follow the progress of the integration
% sys.settings.timeInt.display.type = 'waitbar';
sys.settings.timeInt.display.type = 'none';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Time integration
n2StatusOutput('\nIntegrating the System over the Time ...\n');
tic;
sys.results.timeInt = timeInt(y0, Dy0, 'time', timeInterval, 'integrator', integrator);
toc;
n2StatusOutput('ok!');
save sys sys

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Animation of the results

animTimeInt(sys.results.timeInt,'Stride',0.5);

% END OF FILE
