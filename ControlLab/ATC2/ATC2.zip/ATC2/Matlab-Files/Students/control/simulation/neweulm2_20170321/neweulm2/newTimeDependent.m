% newTimeDependent(varargin) - declare time dependent auxiliary variables
%
%  Syntax:
%> newTimeDependent('VarName1','Expression1','VarName2','Expresssion2');
%
%  Description:
% As Expression a symbolic expression can be passed to newTimeDependent, if
% an empty string '' is passed, as a default empty functions are created.
% These empty functions will return 0 as a parameter value and should be
% edited to provide the required functions.
%
% There are some parameter names, which are reserved, but this function
% issues warnings in these cases:
% g ......... Is created automatically to represent the gravitational constant
% t ......... Is reserved for the time
% [...]_s ... Names ending on '_s' are reserved for set values for
%             generalized coordinates, it can cause problems it they are
%             used as regular parameter names. As the set values are
%             necessary for every generalized coordinate (e.g. x) and its
%             first and second time derivative denoted with a leading 'D'
%             or 'D2' (e.g. Dx, D2x) these are also reserved.
% D[...] .... Reserved for first time derivatives of set values and time
%             dependent parameters.
% D2[...] ... Reserved for second time derivatives of set values and time
%             dependent parameters.
% [...]_ .... Names ending on an underscore '_' may cause problems as
%             internally used names always end on an underscore.
%
% To avoid warnings when automatically creating parameters, e.g. the
% correct set values, the calling function is checked. If the calling
% function is in the following cell array whiteList_, no warning is issued.
%
%  Example:
%> newTimeDependent('u1','2*sin(t)');
%
%  See also: 
% newBody, newForceElem, newGenCoord, newFrame, newConstraint,
% newSys, newInput, newOutput, newConstant, newStateDependent, newVolume,
% calcEqMotNonLin
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
