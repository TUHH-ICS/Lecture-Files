% scriptCalcEqMotNonLin - Script to allow the user to extend the call of
% calcEqMotNonLin by own functions.
% 
%  Syntax:
% scriptCalcEqMotNonLin
%
%  Description:
% Script which contains the important commands of the file calcEqMotNonLin
% The reason this script exists is that then every user can easily extend
% Neweul-M2 and insert custom functions in here. Any user-written functions
% should be located in a folder in neweulm2/modules/ and should use telling
% names so they can be identified easily. As this is a script the visible
% variable space is the one of calcEqMotNonLin. This means e.g. that the
% data structure sys is available. You are strongly advised against
% changing the order of the commands here and against removing any of them.
% This script is called after the calculation of the kinematics. After this
% the equations of motion are composed from the parts stored in 
% sys.dynamics.nonlinear.generic and constraint equations for kinematic
% loops calculated.
%
%  See also: calcEqMotNonLin, scriptWriteMbsNonLin
%
% First appearance: 15.03.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
