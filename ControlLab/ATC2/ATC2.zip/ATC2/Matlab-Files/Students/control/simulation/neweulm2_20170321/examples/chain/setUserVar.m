%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                    %
% Definition of userdefined parameters                               %
% for the modell 'double pendulum'                                   %
%                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global sys;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% constant userdefined parameters        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Gravitation

sys.parameters.data.g = 9.81;

% Pendulum 1

sys.parameters.data.m1 = 10;
sys.parameters.data.l1 = 0.1;

% Pendulum 2

sys.parameters.data.m2 = 10;
sys.parameters.data.l2 = 0.2;

% Pendulum 3

sys.parameters.data.m3 = 10;
sys.parameters.data.l3 = 0.3;

% Pendulum 4

sys.parameters.data.m4 = 10;
sys.parameters.data.l4 = 0.4;

% Force element
sys.parameters.data.k = 0;
sys.parameters.data.c = 0;

% Excitation
sys.parameters.data.z0 = 0.0;
sys.parameters.data.omega = 50*2*pi;

