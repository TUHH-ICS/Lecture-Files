% BVPRadau(ode_fun,bc_fun,initial_guess,varargin) - TPBVP solver
%
%   Two point boundary value problem solver using the RadauIIA quadrature
%   formula.
%
%   This solver implements a n-stage implicit Runge-Kutta scheme using the 
%   Radau IIA quadrature formula to solve two-point boundary value problems.
%
%   Required arguments
%
%   ode_fun ........... Function handle for the system dynamics
%                       dx/dt = ode_fun(t, x)
%   bc_fun ............ Function handle for the boundary conditions
%                       res = bc_fun(x(:,1),x(:,end))
%   initial_guess ..... Structure containing an initial guess for the solution
%                       initial_guess.x: Time vector
%                       initial_guess.y: State vector for each mesh point
%
%   Optional arguments, given pairwise
%
%   AbsTol ............ Absolute solver tolerance {1e-6}
%   AdditionalParams .. Additional parameters for the functions {''}
%   Algebraic ......... Boolean vector marking algebraic equations {false(1,dim)}
%   AllowSwitching .... Boolean, deciding if the sign of the Runge-Kutta 
%                       steps scan be switched {false}
%   AllowJacUpdate .... Boolean, deciding if the Jacobians shall be recomputed  
%                       during the Newton iteration {false}
%   BC_Jacobian ....... Function handle providing the Jacobian of the boundary
%                       conditions {[]}
%   CalcMode .......... Defines which finite differences method is suppossed to be
%                       used ('central' or 'forward') {'forward'}
%   FDStep ............ Step size of the finite differences method {1e-6}
%   Jacobian .......... Function handle providing the Jaconian of the system 
%                       dynamics {[]}
%   MaxIterations ..... Maximum number of iterations {30}
%   MaxNewton ......... Maximum number of Newton steps {7}
%   MaxProbes ......... Maximum number of line search steps {4}
%   MeshMax ........... Maximum number of mesh points {400}
%   PrintOut .......... Enable print outs during the evaluation {false}
%   RefineMesh ........ Allow the mesh refinement if needed {true}
%   RelTol ............ Relative solver tolerance {1e-3}
%   Safety ............ Safety factor for the line search {0.9}
%   Stage ............. Stage number of the Runge-Kutta method {5}
%   StartDirection .... Define the sign of the Runge-Kutta steps (1 or -1) {1}
%   UnknownParams ..... Vector containing the initial guess of unknown
%                       parameters {[]}
%
%   Author:    Markus Burkhardt
%
%   e-Mail:    markus.burkhardt@itm.uni-stuttgart.de
%
%   Institute: University of Stuttgart
%              Institute of Engineering and Computational Mechanics
%              Pfaffenwaldring 9
%              70599 Stuttgart
%              Germany
%
%   Date:      2011/09/29 (First appearance)
%
%   See also: contra, radau5Mex, radauMex
%
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
