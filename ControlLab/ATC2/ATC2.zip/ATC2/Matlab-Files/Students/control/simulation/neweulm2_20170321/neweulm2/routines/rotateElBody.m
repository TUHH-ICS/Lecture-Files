% res_ = rotateElBody(ElBody, S_, formulation_)
% Function to rotate an elastic body with a constant numerical rotation
% matrix S_. This is useful as some programs prefer elastic bodies to point
% into one direction, e.g. beams along the x-axis. Then this function can
% be used to rotate them to point into other directions as initial
% configurations. In some cases this helps to avoid oscillations around
% singular angular configurations or just to shorten expressions.
% 
% Input arguments
% Elbody .......... Data describing an elastic body, e.g. as returned by
%                   SID2matlab.
% S_ .............. Rotation matrix with which to rotate the elastic body.
%                   If this parameter consists of less than 5 entries, it
%                   is considered an angular description like euler-/ or
%                   kardan-angles and kardan2rotmat is called.
% formulation_ .... Optional. If the rotation matrix is not given directly.
%                   Parameter to specify the angular description. If
%                   nothing is specified, the system wide setting stored
%                   under sys.parameters.equation.angles is used. For more
%                   information, please type 'help kardan2rotmat' as this
%                   parameter is only passed through.
%                   {sys.parameters.equation.angles}
% 
% Example
% ElBody = rotateElBody(SID2matlab('myFile.SID_FEM', [0;pi/2;0]);
% See also: newBody, kardan2rotmat, SID2matlab
%
% First appearance: 29.09.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
