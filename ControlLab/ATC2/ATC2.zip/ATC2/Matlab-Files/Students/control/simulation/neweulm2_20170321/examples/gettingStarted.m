function varargout = gettingStarted(varargin)
% GETTINGSTARTED M-file for gettingStarted.fig
%      GETTINGSTARTED, by itself, creates a new GETTINGSTARTED or raises the existing
%      singleton*.
%
%      H = GETTINGSTARTED returns the handle to a new GETTINGSTARTED or the handle to
%      the existing singleton*.
%
%      GETTINGSTARTED('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GETTINGSTARTED.M with the given input arguments.
%
%      GETTINGSTARTED('Property','Value',...) creates a new GETTINGSTARTED or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before gettingStarted_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to gettingStarted_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help gettingStarted

% Last Modified by GUIDE v2.5 18-Apr-2011 12:36:32

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @gettingStarted_OpeningFcn, ...
                   'gui_OutputFcn',  @gettingStarted_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before gettingStarted is made visible.
function gettingStarted_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to gettingStarted (see VARARGIN)

% Choose default command line output for gettingStarted
handles.output = hObject;

% Change to the location of this file
cd(fileparts(mfilename('fullpath')));

% Update handles structure
guidata(hObject, handles);

% Make a list of examples, remove sandbox all without startSysDef, sort it
% and read description
popup_examples_Callback(handles.popup_examples, [], handles);

echo off all; % Switch off echo for all functions

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes gettingStarted wait for user response (see UIRESUME)
% uiwait(handles.fig_gettingStarted);


% --- Outputs from this function are returned to the command line.
function varargout = gettingStarted_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


function popup_examples_Callback(hObject, eventdata, handles)
% Update the GUI according to the selected example
    % Change to the location of this file
    cd(fileparts(mfilename('fullpath')));
    currentDir_ = pwd;
    % Determine model folder
    modelDir_ = get(hObject,'String');
    modelDir_ = modelDir_{get(hObject,'Value')};
    myText_ = {['Description of Model ''',modelDir_,'''']};
    handles.data.startSysDef = '';
    % Scroll to the top
    set(handles.list_description,'Value',1);
    set(handles.list_description,'ListboxTop',1);
    % Enable the start button
    set(handles.button_start,'Enable','on');
    set(handles.button_start,'String','Start');
    if(~isempty(modelDir_) && exist(modelDir_,'dir') == 7)
        cd(modelDir_);
        % Determine file name, sth. like startSysDef.m
        allFiles_ = dir;
        handles.data.startSysDef = '';
        for g_ = 1:length(allFiles_)
            [myBuffer_,currentName_,fileExt_] = fileparts(allFiles_(g_).name);
            if(strcmp(fileExt_,'.m') && strncmp(currentName_, 'startSysDef', 11))
                handles.data.startSysDef = currentName_;
                break;
            end
        end
        % Read help message to be used as model description
        if(~isempty(handles.data.startSysDef))
            fid = fopen([handles.data.startSysDef,'.m'],'r');
            if(fid ~= -1)
                newString_ = fgetl(fid);
                while(strncmp(newString_, '%', 1) || strncmp(newString_, 'function ',9))
                    % Read help message at file top, reformat it
                    if(strncmp(newString_, '%', 1))
                        if(strcmp(newString_(end),'%'))
                            newString_(end) = ''; % Remove trailing %
                            newString_ = strtrim(newString_); % Remove all trailing blanks
                        end
                        if(~isempty(newString_) && strcmp(newString_(1), '%'))
                            newString_(1) = ''; % Remove leading %
                        end
                        if(length(newString_) > 1 && strcmp(newString_(1),' '))
                            newString_(1) = ''; % Remove one leading blank
                        end
                        % Store text
                        myText_{end+1,1} = newString_; %#ok<AGROW>
                    end
                    newString_ = fgetl(fid);
                end
                myText_{end+1} = '';
                fclose(fid);
            else
                myText_{end+1} = 'Sorry, no information available.';
            end
        else
            myText_{end+1} = 'Sorry, no information available.';
        end
        % Assign text
        set(handles.list_description,'String',myText_);
        cd(currentDir_)
    end
    % Update handles structure
    guidata(hObject, handles);

function popup_examples_CreateFcn(hObject, eventdata, handles)
    % Change to the location of this file
    cd(fileparts(mfilename('fullpath')));
    % Find all model folders
    allDir_ = dir;
    dirCell = cell(numel(allDir_),1);
    idx_ = 0;
    for g_ = 1 : length(allDir_)
        if(allDir_(g_).isdir && ...
                ~strncmp(allDir_(g_).name,'.',1))
            % Extract all non-hidden directories
            subDir_ = dir(allDir_(g_).name);
            if(any(strncmpi({subDir_(:).name}, 'startSysDef',11)))
                % Only if a file starting with startSysDef is contained in
                % the directory, add it to the list
                idx_ = idx_+1;
                [myBuffer,dirCell{idx_}] = fileparts(allDir_(g_).name);
            end
        end
    end
    dirCell(idx_+1:end) = []; % Remove all empty fields
    dirCell(strcmpi(dirCell,'sandbox')) = []; % Remove the sandbox folder
    [myBuffer,idx_] = sort(dirCell);
    firstEx_ = {'double_pendulum', 'slider_crank','elasticPendulum'};
    for g_ = length(firstEx_) : -1 : 1
        newIdx_ = find(strcmp(dirCell, firstEx_{g_}));
        if(~isempty(newIdx_))
            idx_ = [idx_(idx_==newIdx_(end)); idx_(idx_~=newIdx_(end))];
        end
    end
    dirCell = dirCell(idx_);
    % Assign list
    set(hObject,'String',dirCell);
    set(hObject,'Value',1);
    
% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function button_start_Callback(hObject, eventdata, handles)

    global sys;
    % Avoid this GUI from being closed
    set(handles.fig_gettingStarted,'HandleVisibility','off');
    set(handles.popup_examples,'Enable','off');
    % Reset structure entry if available
    if(isfield(sys,'settings') && isfield(sys.settings,'equation') && ...
            isfield(sys.settings.equation,'waitTime'))
        sys.settings.equation = rmfield(sys.settings.equation,'waitTime');
    end

    % Distinguish the mode, whether it is start or stop
    if(strcmp(get(hObject,'String'), 'Start'))
        % Start modeling and simulation
        % Ensure that a model has been selected
        popup_examples_Callback(handles.popup_examples, [], handles);
        % Relabel the button
        set(hObject,'String','Stop');
        handles = guidata(hObject);
        % Change to the corresponding model folder
        modelDir_ = get(handles.popup_examples,'String');
        modelDir_ = modelDir_{get(handles.popup_examples,'Value')};

        try
            % call this start file, usually called startSysDef and
            % subsequently all simulation files
            fullModelRun('folder',modelDir_, 'startSysDef',handles.data.startSysDef, 'displayCommands',true);
        catch myErr_
            % Check whether the last error was due to an exit caused by the
            % user or not
            eval('global sys;'); % Avoid M-LINT warnings
            myMessage_ = 'Demonstration run aborted!';
            handles = guidata(hObject);
            popup_examples_Callback(handles.popup_examples, [], handles);
            
            if(~strcmp(myErr_.message(end-length(myMessage_)+1:end),myMessage_))
                rethrow(myErr_);
            else
                fprintf(2,'\nUser aborted modeling and simulation.\n');
                if(isfield(sys.settings.equation,'waitTime'))
                    sys.settings.equation = rmfield(sys.settings.equation,'waitTime');
                end
            end
        end
        eval('global sys;'); % Avoid M-LINT warnings
        fprintf('\n%% ## Finished! ##\n');
        set(hObject,'String','Start'); % Relabel the button
        set(handles.popup_examples,'Enable','on');
        if(isfield(sys.settings.equation,'waitTime'))
            sys.settings.equation = rmfield(sys.settings.equation,'waitTime'); % Remove wait time
        end
    else
        % Stop the simulation run
        % Relabel the button
        set(hObject,'String','Start');
        fprintf(2,'\nUser chose to abort simulation, stopping at next possibility.\nOtherwise, please try CTRL+c\n');
        sys.settings.equation.waitTime = 'abort';
        set(hObject,'Enable','off');
        set(handles.popup_examples,'Enable','on');
    end
    % Clean up
    echo off all; % Switch off echo for all functions
    set(handles.fig_gettingStarted,'HandleVisibility','Callback');
	button_help_CreateFcn(handles.button_help, [], handles);

function button_cancel_Callback(hObject, eventdata, handles)
    % Close GUI
    set(handles.fig_gettingStarted,'HandleVisibility','Callback');
    close(mfilename);

function list_description_Callback(hObject, eventdata, handles)


function list_description_CreateFcn(hObject, eventdata, handles)

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function button_help_CreateFcn(hObject, eventdata, handles)
    if(exist('neweulm2HelpMsgs','file') == 2 && exist('help_window','file') == 2 )
        % Enable or disable this button, if a message exists
        set(hObject, 'enable', neweulm2HelpMsgs(get(get(hObject, 'Parent'), 'Name'), 'flag', 'init'));
    elseif(exist('../neweulm2/gui/routines/neweulm2HelpMsgs.m','file') == 2 && ...
            exist('../neweulm2/gui/routines/help_window.m','file') == 2)
        % The files exist, but as a relative path is used, they're
        % currently unavailable
        addpath('../neweulm2/gui/routines/');
        addpath('../neweulm2/gui/figures/general/');
        set(hObject, 'enable', neweulm2HelpMsgs(get(get(hObject, 'Parent'), 'Name'), 'flag', 'init'));
    else
        % Currently the path is not yet available, disable button
        set(hObject, 'enable', 'off');
    end
    
% --- Executes on button press in button_help.
function button_help_Callback(hObject, eventdata, handles)
    % Open Help
    help_window('Calling_Name', get(get(hObject, 'Parent'), 'Name'));

% END OF FILE
