function defineGraphics
% DEFINEGRAPHICS - create graphic visualization of modeling elements
%

global sys;

sys.settings.graphics.frame.size = 0.03;
createAnimationWindow;

%-------- representation of elastic body via mesh --------
drawMesh('OBJ','FaceAlpha',{1 0.1}, 'EdgeAlpha',{0.2 0.1}, ...
    'FaceColor',{[0 0 1], [0 0 0]});

%-------- rotationalsymmetric body --------
h = drawRotBody([0.18 0.18 0.11 0.11 0.18],[0.27 0.3 0.3 0.27 0.27],32);
set(h,'Tag','RotBody_1','FaceAlpha',0.4,'EdgeAlpha',0.1,'FaceColor',[0 0 0],'EdgeColor',[0 0 0]);
addGraphics('OBJ',h);

%-------- Cube --------
h = drawCube([0;0;0.375],0.4,0.5,0.05,[0.5 0.5 0.5]);
set(h,'Tag','MainFrame','FaceAlpha',1,'EdgeAlpha',1,'EdgeColor',[0 0 0]);
addGraphics('ISYS',h);

%-------- rotationalsymmetric body --------
h = drawRotBody([0.05 0.05 0 0 0.05],[0.35 0.345 0.345 0.35 0.35],32);
set(h,'Tag','RotBody_2','FaceAlpha',1,'EdgeAlpha',1,'FaceColor',[0.1 0.1 0.1],'EdgeColor',[0.01 0.01 0.01]);
addGraphics('ISYS',h);

% Animation window, view settings
axis([-0.35 0.35 -0.35 0.35 0 0.45])
set(gca,'zdir','reverse')
set(gca,'ydir','reverse')

setVisibility('off','type','text');

% springs
drawSpring('Ki1','Ko1','spring1','linewidth',2.5)
drawSpring('Ki2','Ko2','spring2','linewidth',2.5)
drawSpring('Ki3','Ko3','spring3','linewidth',2.5)

% END OF defineGraphics
