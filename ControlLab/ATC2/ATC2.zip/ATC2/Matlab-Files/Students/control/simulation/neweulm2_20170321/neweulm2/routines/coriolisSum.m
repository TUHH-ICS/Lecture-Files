% vector = coriolisSum(matrix,omega,displac,calcCase)
% This function computes the matrices Gr and Ge according to the formula
% [3*nq, 3] = size(matrix);
% matrix = [G1, G2, ..., Gnq], matrix_i denotes the i-th 3x3 block
% vector = \sum_{i=1}^{nq} {matrix_i * displac(i) * omega}
% 
% This function is used, e.g. for the Ge matrix in the following way
% Ge ........ Ge-matrix as in 
%             sys.model.sid(sys.model.body.(body).data.sidIdx).Ge.m0, this
%             is of the form Ge = 2*[Kr1 Kr2 Kr3] so 
%             \sum_{i=1}^{nq}{Ge_i*Dq_i} = 2*[Kr1*Dq Kr2*Dq Kr3*Dq]
%               = 2*Ge*[Dq;Dq;Dq]
%             The result is a nqx3 matrix which is multiplied with omega
% omega ..... Rotational velocity vector, e.g. omega=sym('[a1;a2;a3]');
% displac ... Time derivative of the elastic coordinates, e.g.
%             displac=sym('[Dq01;Dq02;Dq03;Dq04]')
% calcCase .. Case, whether the Ge or Gr matrix is to be calculated
%
% Example:
%   omega=sym('[omega1;omega2;omega3]'); body='P1';
%       coriolisSum(sys.model.sid(sys.model.body.(body).data.sidIdx).Gr.m0,
%       omega, sys.body.(body).data.edof.Dy)
%   omega=sym('[omega1;omega2;omega3]');
%       GeTest=reshape([1:16,17.1:32.1,33.2:48.2],4,12);
%       coriolisSum(GeTest, omega, ...
%       sym('[Dq01;Dq02;Dq03;Dq04]')) % Theoretical example 1
%   omega=sym('[omega1;omega2;omega3]');
%       GeTest=rand(5,15);
%       coriolisSum(GeTest, omega, ...
%       sym('[Dq01;Dq02;Dq03;Dq04;Dq05]')) % Theoretical example 2
% 
% See also: calcEqMotNonLin
%
% First appearance: 18.04.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
