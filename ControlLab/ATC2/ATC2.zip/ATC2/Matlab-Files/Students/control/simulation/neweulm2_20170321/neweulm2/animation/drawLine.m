% drawLine - Draws a line object to the animation window
% 
%  Description:
%
% This line connects all coordinate systems specified in ListofFrames,
% assigns it the given ID, while properties can be passed in varargin
%
%  Syntax:
% [handle, error_msg] = drawLine(ListOfFrames, ID, varargin);
%
%  Input arguments:
% ListofFrames ... Cell array containing the ids of all coordinate systems
%                  to be connected by the line. The order of the coordinate
%                  systems is important, as they are connected in this way.
%                  If two coordinate systems are given, they are connected
%                  by a straight line, otherwise a spline interpolation is
%                  used.
% ID ............. ID for this line object, which is used in the system
%                  data structure {'Line_1'}
% 
%  Optional properties:
%
% All of Matlab's line properties are valid, as they are passed directly
% through. They should be given in the pairwise manner. Here are some
% useful specifications:
% 'Color', '[0 0 1]';
% 'LineStyle', '-' or '--' or ':' or '-.';
% 'LineWidth', 2;
% 
%  Output arguments:
% handle ......... Handle for the created line object
% error_msg ...... Message of the error that occured, please display
%
%  Example:
% drawLine({ 'Frame1', 'Frame2', 'Frame3'}, 'myLineId');
% drawLine({ 'Frame1', 'Frame2', 'Frame3'}, 'myLineId', 'Color', [1 0 0]);
% 
%  See also: drawArrow3d, drawCube, drawElasticBeam, drawRotBody,
% drawSphere, drawSTL, drawSpring
%
% First appearance: 29.02.2008
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
