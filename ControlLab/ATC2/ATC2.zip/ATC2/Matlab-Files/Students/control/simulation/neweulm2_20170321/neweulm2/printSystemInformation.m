% printSystemInformation(varargin) - Function to print an overview of important system informations
% If nothing is specified, the information is displayed on the STDOUT, the
% Matlab command prompt. 
% 
%  Syntax:
%> printSystemInformation
%> printSystemInformation('Property', value, ...);
%     
%  Optional Parameters, given pairwise:
% Filename .... If a filename is given, the information is stored in a file
%               instead of being passed to 1 (STDOUT), meaning the Matlab
%               command window {1}
% General ..... Show general system information {true}
% Numerical ... Show numerical values of coordinate systems, ... instead of
%               general information {false}
% Settings  ... Show all options selected, stored under sys.settings together
%               with explanations {false}
% ShowAll ..... Show general information and numerical values {false}
% t0 .......... Time for the evaluation of numerical values {0}
% x0 .......... State vector for the evaluation of numerical values.
%               However, elastic coordinates are always set to 0.
%               {zeros(2*sys.counters.genCoord,1)}
% y0 .......... Vector of generalized coordinates for the evaluation of
%               numerical values. However, elastic coordinates are always
%               set to 0. {zeros(sys.counters.genCoord,1)}
% Dy0 ......... Vector of generalized velocities for the evaluation of
%               numerical values. However, velocities corresponding to
%               elastic coordinates are always set to 0. {zeros(sys.counters.genCoord,1)}
% CheckVarargin ... To support the standard, this suppresses checking in
%                   order to pass parameters to subfunctions {false}
%
%  Example:
%>   printSystemInformation;
%
%  See also: SystemInformation, printSystemInformation>printFrameStructure
%
% First appearance: 05.12.2008
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
