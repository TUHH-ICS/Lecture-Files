% NUMERICALVALUES M-file for NumericalValues.fig
%      NUMERICALVALUES, by itself, creates a new NUMERICALVALUES or raises the existing
%      singleton*.
%
%      H = NUMERICALVALUES returns the handle to a new NUMERICALVALUES or the handle to
%      the existing singleton*.
%
%      NUMERICALVALUES('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in NUMERICALVALUES.M with the given input arguments.
%
%      NUMERICALVALUES('Property','Value',...) creates a new NUMERICALVALUES or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before NumericalValues_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to NumericalValues_OpeningFcn via varargin.
%
% Graphical user interface to edit the numerical values assigned to
% parameters.
% 
% For more information, please open the corresponding window and click on
% the help button, labeled with a question mark "?".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
%
% First appearance: 01.07.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
