function res_ = f_MHV(t,y_,varargin)
% res_ = f_MHV(t,y_,varargin)
% f_MHV - Definition of user-defined variable MHV
% For a better template, please call the appropriate function
% newUserVarTvar for time dependent parameters
% newUserVarYvar for state dependent parameters

global sys;

if(nargin==1 && ischar(t) && strcmp(t,'linearization'))
	% Case IV: Call was f_...('linearization')
	% Return symbolic expression to calculate the linearization
	% Necessary for all parameters appearing in the equations of motion to linearize!
	res_ = sym('cerz*(1+(ze+aer*sin(be)-her*cos(be)+her)^2/xd_erz^2)');
	return;
end

% constant user-defined variables

xdm = sys.parameters.data.xd_erz;
c = sys.parameters.data.cerz;

% relative vector
% ksys1 = str2func('KARHV_r');
ksys1 = str2func('CARER_r');
ksys2 = str2func('ER_r');
SDirdef = CARER_S(t,y_);

r_ = transpose(SDirdef)*(ksys2(t,y_) - ksys1(t,y_));

% state dependent user defined functions
x = r_(3);
res_ = springParam(x, c, 0, -xdm, 0, xdm);

