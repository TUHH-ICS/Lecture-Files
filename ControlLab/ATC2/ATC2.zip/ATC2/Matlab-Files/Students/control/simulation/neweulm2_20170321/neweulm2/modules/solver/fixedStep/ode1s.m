%ODE1s  Symplectic euler scheme for Hamiltonian systems. 
%   [T, X] = ODE1S(ODEFUN,TSPAN,X0) with TSPAN = [T1, T2, T3, ... TN] integrates 
%   the system of differential equations x' = f(t,x) by stepping from T0 to 
%   T1 to TN. Function ODEFUN(T,X) must return f(t,x) in a column vector.
%   The vector X0 is the initial conditions at T0. Each row in the solution 
%   array X corresponds to a time specified in TSPAN.
%
%   SOL = ODE1S(ODEFUN,TSPAN,Y0) returns a structure containing all neccessary values. 
%
%   This is a symplectic, energy conserving solver for Hamiltonian (undamped) systems.
%   The step sequence is determined by TSPAN. The solver implements the semi-implicite
%   Euler method of order 1, also known as Newton–Størmer–Verlet.
%
%   Example 
%         tspan = 0:0.1:20;
%         [t, x] = ode1(@vdp1,tspan,[2 0]);  
%         plot(t,x(:,1));
%     solves the system x' = vdp1(t,x) with a constant step size of 0.1, 
%     and plots the first component of the solution.   
%
% See also: ode1i, ode1, ode2, ode3, ode4, ode5
% 
% First appearance: 03.01.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
