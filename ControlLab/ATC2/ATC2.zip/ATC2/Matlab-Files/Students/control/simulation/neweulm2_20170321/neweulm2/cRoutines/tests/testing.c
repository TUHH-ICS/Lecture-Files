#include "neweul.h"
#include <time.h>

#define OWN_RAND_MAX (10.0)
#define OWN_RAND_MIN (-10.0)

int choleskyTest(unsigned short dim);
int LDLTest(unsigned short dim);
int LUTest(unsigned short dim);
int QRTest(unsigned short dim);
int QRTest_vec(unsigned short dim);
int HouseholderTest(unsigned short dim);
int multiplicationTest(unsigned short dim);


int main( int argc, const char* argv[] )
{
  int res_ = 0;
  unsigned short matSize = 10;
  
  if (argc>1)
    matSize = (unsigned short) atoi(argv[1]);
  
  printf("Matrix size is set to %d!\n",matSize);
  
  /* LES with Cholesky  */
  res_ += choleskyTest(matSize);
  
  /* LES with Cholesky  */
  res_ += LDLTest(matSize);
  
  /* LES with LU+pivot */
  res_ += LUTest(matSize);
  
  /* LES with Householder QR */
  res_ += QRTest(matSize);
  
  /* LES with Householder QR (rhs is a vector) */
  res_ += QRTest_vec(matSize);
  
  res_ += HouseholderTest(matSize);
  
  res_ += multiplicationTest(matSize);
  
  return res_;
  
}

int choleskyTest(unsigned short dim){
  
  clock_t c0, c1;
  
  double **M = createRandomMatrix(dim,dim,OWN_RAND_MIN,OWN_RAND_MAX);
  double **A = callocMatrix(dim, dim);
  
  double **B = callocMatrix(dim, dim);
  double **I = callocMatrix(dim, dim);
  
  unsigned short i_;
  
  double res_ = 0.0;
  
  int err_;
  
  for (i_=0; i_<dim; i_++)
    B[i_][i_] = 1.0;
  
  MatrixMultiplication('T', 'N', dim, dim, dim, 1.0, M, M, 0.0, A);
  
  c0 = clock();
  err_ = cholDecomposition2dim(dim, dim, A, B);
  c1 = clock();
  
  printf("\nCholesky: error code = %d\n", err_);
  printf("          execution time = %f s\n", (float) (c1 - c0)/CLOCKS_PER_SEC);
  MatrixMultiplication('T', 'N', dim, dim, dim, 1.0, M, M, 0.0, A);
  
  MatrixMultiplication('N', 'N', dim, dim, dim, 1.0, A, B, 0.0, I);
   
  for (i_=0; i_<dim; i_++)
    res_ = maximum(res_, maximumNorm_vec(dim, &(I[i_][0])));
  
  /* Since I is supposed to be an identity matrix, subtract 1.0 */
  res_ = res_ - 1.0;
  
  freeMatrix(dim, dim, M);
  freeMatrix(dim, dim, A);
  freeMatrix(dim, dim, B);
  freeMatrix(dim, dim, I);
  
  printf("Cholesky: residuum = %e\n", res_);
  
  if ((res_ - 1.0) < sqrt(EPS))
    return 0;
  else
    return 1;
  
}

int LDLTest(unsigned short dim){
  
  clock_t c0, c1;
  
  double **M = createRandomMatrix(dim,dim,OWN_RAND_MIN,OWN_RAND_MAX);
  double **A = callocMatrix(dim, dim);
  
  double **B = callocMatrix(dim, dim);
  double **I = callocMatrix(dim, dim);
  
  unsigned short i_;
  
  double res_ = 0.0;
  
  int err_;
  
  for (i_=0; i_<dim; i_++)
    B[i_][i_] = 1.0;
  
  MatrixMultiplication('T', 'N', dim, dim, dim, 1.0, M, M, 0.0, A);
  
  c0 = clock();
  err_ = LDLTDecomposition2dim(dim, dim, A, B);
  c1 = clock();
  
  printf("\nLDL^T: error code = %d\n", err_);
  printf("       execution time = %f s\n", (float) (c1 - c0)/CLOCKS_PER_SEC);
  MatrixMultiplication('T', 'N', dim, dim, dim, 1.0, M, M, 0.0, A);
  
  MatrixMultiplication('N', 'N', dim, dim, dim, 1.0, A, B, 0.0, I);
  
  for (i_=0; i_<dim; i_++)
    res_ = maximum(res_, maximumNorm_vec(dim, &(I[i_][0])));
  
  /* Since I is supposed to be an identity matrix, subtract 1.0 */
  res_ = res_ - 1.0;
  
  freeMatrix(dim, dim, M);
  freeMatrix(dim, dim, A);
  freeMatrix(dim, dim, B);
  freeMatrix(dim, dim, I);
  
  printf("LDL^T: residuum = %e\n", res_);
  
  if ((res_ - 1.0) < sqrt(EPS))
    return 0;
  else
    return 2;
  
}

int LUTest(unsigned short dim){
  
  clock_t c0, c1;
  
  double **A = createRandomMatrix(dim,dim,OWN_RAND_MIN,OWN_RAND_MAX);
  double **A_ = callocMatrix(dim, dim);
  
  unsigned short *z = (unsigned short *) calloc(dim, sizeof(unsigned short));
  
  double **B = callocMatrix(dim, dim);
  double **I = callocMatrix(dim, dim);
  
  unsigned short i_;
  
  int err_;
  double res_ = 0.0;
  
  for (i_=0; i_<dim; i_++)
    memcpy(A_[i_], A[i_], dim*sizeof(double));
  
  for (i_=0; i_<dim; i_++)
    B[i_][i_] = 1.0;
  
  c0 = clock();
  err_ = InversionByLU(dim, dim, z, A, B);
  c1 = clock();
  
  printf("\nLU: error code = %d\n", err_);
  printf("    execution time = %f s\n", (float) (c1 - c0)/CLOCKS_PER_SEC);
  
  MatrixMultiplication('N', 'N', dim, dim, dim, 1.0, A_, B, 0.0, I);
  
  for (i_=0; i_<dim; i_++)
    res_ = maximum(res_, maximumNorm_vec(dim, I[i_]));
  
  /* Since I is supposed to be an identity matrix, subtract 1.0 */
  res_ = res_ - 1.0;
  
  freeMatrix(dim, dim, A);
  freeMatrix(dim, dim, A_);
  freeMatrix(dim, dim, B);
  freeMatrix(dim, dim, I);
  
  free(z);
  
  printf("LU: residuum = %e\n", res_);
  
  if ((res_ - 1.0) < sqrt(EPS))
    return 0;
  else
    return 4;
  
}

int QRTest(unsigned short dim){
  
  clock_t c0, c1;
  
  double **A = createRandomMatrix(dim,dim,OWN_RAND_MIN,OWN_RAND_MAX);
  double **A_ = callocMatrix(dim, dim);
  
  double **B = callocMatrix(dim, dim);
  double **I = callocMatrix(dim, dim);
  
  unsigned short i_;
  
  int err_;
  
  double res_ = 0.0;
  
  for (i_=0; i_<dim; i_++)
    memcpy(A_[i_], A[i_], dim*sizeof(double));
  
  for (i_=0; i_<dim; i_++)
    B[i_][i_] = 1.0;
  
  c0 = clock();
  err_ = solveLES2dim(dim, dim, A, B);
  c1 = clock();
  
  printf("\nQR: error code = %d\n", err_);
  printf("    execution time = %f s\n", (float) (c1 - c0)/CLOCKS_PER_SEC);
  
  MatrixMultiplication('N', 'N', dim, dim, dim, 1.0, A_, B, 0.0, I);
  
  for (i_=0; i_<dim; i_++)
    res_ = maximum(res_, maximumNorm_vec(dim, I[i_]));
  
  /* Since I is supposed to be an identity matrix, subtract 1.0 */
  res_ = res_ - 1.0;
  
  freeMatrix(dim, dim, A);
  freeMatrix(dim, dim, A_);
  freeMatrix(dim, dim, B);
  freeMatrix(dim, dim, I);
  
  printf("QR: residuum = %e\n", res_);
  
  if ((res_ - 1.0) < sqrt(EPS))
    return 0;
  else
    return 8;
  
}

int QRTest_vec(unsigned short dim){
  
  clock_t c0, c1;
  
  double **A = createRandomMatrix(dim,dim,OWN_RAND_MIN,OWN_RAND_MAX);
  double **A_ = callocMatrix(dim, dim);
  
  double *b = (double *) calloc(dim, sizeof(double));
  double *b_ = (double *) calloc(dim, sizeof(double));
  
  unsigned short i_;
  
  int err_;
  double res_ = 0.0;
  
  for (i_=0; i_<dim; i_++)
    memcpy(A_[i_], A[i_], dim*sizeof(double));
  
  for (i_=0; i_<dim; i_++){
    b[i_] = (double) i_/(double) dim ;
  }
  
  c0 = clock();
  err_ = solveLES(dim, A, b);
  c1 = clock();
  
  printf("\nQR vector: error code = %d\n", err_);
  printf("           execution time = %f s\n", (float) (c1 - c0)/CLOCKS_PER_SEC);
  
  MatrixVectorMultiplication('N', dim, dim, 1.0, A_, b, 0.0, b_);
  
  for (i_=0; i_<dim; i_++)
    b_[i_] = b_[i_] - ((double) i_/(double) dim );
  
  res_ = maximumNorm_vec(dim, b_);
 
  
  freeMatrix(dim, dim, A);
  freeMatrix(dim, dim, A_);
  free(b);
  free(b_);
  
  printf("QR vector: residuum = %e\n", res_);
  
  if ((res_) < sqrt(EPS))
    return 0;
  else
    return 16;
  
}

int HouseholderTest(unsigned short dim){
  
  clock_t c0, c1;
  
  double **A = createRandomMatrix(dim,dim,OWN_RAND_MIN,OWN_RAND_MAX);
  double **A_ = callocMatrix(dim, dim);
  
  double **Q = callocMatrix(dim, dim);
  double **B = callocMatrix(dim, dim);
  
  unsigned short i_, j_;
  
  int err_;
  double res_ = 0.0;
  
  for (i_=0; i_<dim; i_++)
    memcpy(A_[i_], A[i_], dim*sizeof(double));
  
  c0 = clock();
  err_ = householderQR(dim, dim, A, Q);
  c1 = clock();
  
  printf("\nQR: error code = %d\n", err_);
  printf("    execution time = %f s\n", (float) (c1 - c0)/CLOCKS_PER_SEC);
  
  MatrixMultiplication('N', 'N', dim, dim, dim, 1.0, Q, A, 0.0, B);
  
  for (i_=0; i_<dim; i_++){
      for (j_=0; j_<dim; j_++){
	  A_[i_][j_] -= B[i_][j_];
      }
  }
  
  for (i_=0; i_<dim; i_++)
    res_ = maximum(res_, maximumNorm_vec(dim, A_[i_]));
  
  freeMatrix(dim, dim, A);
  freeMatrix(dim, dim, A_);
  freeMatrix(dim, dim, Q);
  freeMatrix(dim, dim, B);
  
  printf("QR: residuum = %e\n", res_);
  
  if (res_ < sqrt(EPS))
    return 0;
  else
    return 32;
  
}

int multiplicationTest(unsigned short dim){
 
  clock_t c0, c1;
  
  double **A = createRandomMatrix(dim,dim,OWN_RAND_MIN,OWN_RAND_MAX);
  double **B = createRandomMatrix(dim,dim,OWN_RAND_MIN,OWN_RAND_MAX);
  
  double **C = callocMatrix(dim, dim);
  
  /* First test case: A*B */
  if (dim <=12 ){
      printMatrix(dim, dim, A, "A");
      printMatrix(dim, dim, B, "B");
  }
  
  c0 = clock();
  MatrixMultiplication('N', 'N', dim, dim, dim, 1.0, A, B, 0.0, C);
  c1 = clock();
  
  if (dim <=12 ){
      printMatrix(dim, dim, C, "C1");
  }
  
  printf("multiplication N, N: execution time = %f s\n", (float) (c1 - c0)/CLOCKS_PER_SEC);
  
  /* Second test case: A*B^T */
  
  c0 = clock();
  MatrixMultiplication('N', 'T', dim, dim, dim, 1.0, A, B, 0.0, C);
  c1 = clock();

  if (dim <=12 ){
      printMatrix(dim, dim, C, "C2");
  }
  printf("multiplication N, T: execution time = %f s\n", (float) (c1 - c0)/CLOCKS_PER_SEC);
  
  /* Third test case: (A^T)*B */
  
  c0 = clock();
  MatrixMultiplication('T', 'N', dim, dim, dim, 1.0, A, B, 0.0, C);
  c1 = clock();
  
  if (dim <=12 ){
      printMatrix(dim, dim, C, "C3");
  }
  
  printf("multiplication T, N: execution time = %f s\n", (float) (c1 - c0)/CLOCKS_PER_SEC);
  
  /* Fourth test case: (A^T)*(B^T) */
  
  c0 = clock();
  MatrixMultiplication('T', 'T', dim, dim, dim, 1.0, A, B, 0.0, C);
  c1 = clock();

  if (dim <=12 ){
      printMatrix(dim, dim, C, "C4");
  }
  
  printf("multiplication T, T: execution time = %f s\n", (float) (c1 - c0)/CLOCKS_PER_SEC);
  
  return 0;
  
}