% tensor_out = tensorTranspose(tensor_in,keepDim)
% The function tensorTranspose provides the transpose of a third order
% tensor. As such a tensor has three dimensions, there are three
% possibilities on how to transpose the tensor. As a transpose is defined
% as a switching of two dimensions, the third one is kept the same.
% Therefore all three cases can be distinguished by the dimension which
% remains unchanged.
% 
% Input arguments:
% tensor_in .... Tensor to be transposed
% keepDim ...... Dimension which remains unchanged, default: {2}
% 
% Output arguments:
% tensor_out ... Transposed tensor
% 
% First appearance: 01.12.2008
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
