% newImplicitInitCond(varargin) - Create new implicit initial condition
%  
%  Syntax:
%> newImplicitInitCond
%> newImplicitInitCond('Property', value, ...);
%
%  Description:
% Define a implicit initial condition. 
%
% Optional parameters, given pairwise:
% Id ................. Identifier of the implicit initial condition {'IC_1'}
% Name ............... Name of the implicit initial condition {'Initial Condition Number 1'}
% Index .............. Index of this implicit initial condition. A number out of
%                      {1,2,3} for {acceleration, velocity, position}. Default
%                      is 3 (=position)
% Frame1 ............. 1. Coordinate system {'ISYS'}
% Frame2 ............. 2. Coordinate system {'ISYS'}
% DirDef ............. The initial conditions are described in this coordinate
%                      system, so the vector 'Directions' is with respect to
%                      this coordinate system. {Frame1}
% Directions ......... 1x6 Vector with blocked dofs between the coordinate
%                      systems, 1 means constrained, 0 free {'[0 0 0 0 0 0]'}
% Equation ........... A symbolic equation providing the initial condition.
% Distance ........... A numerical/symbolical value provided the distance
%                      between frame1 and frame2. If possible, try to use the
%                      'Directions' option instead. The given value for the
%                      distance has to be NON-ZERO! Otherwise you may
%                      encounter strange simulation results as the Jacobian
%                      will be singular.
% ReactionForce ...... Specify the reaction forces/torques to enforce the
%                      specified initial condition. If not specified, Lagrange
%                      multipliers which are not physical will be chosen.
%                      {zeros(6,1)}
% LagrangeMultiplier . Specify Lagrange Multiplier used in ReactionForce.
%                      Mandatory if ReactionForce is defined, otherwise
%                      without effect.
% FAP1 ............... Force application point 1 specified by coordinate
%                      identifier. Mandatory if 'ReactionForce' is defined,
%                      otherwise without effect.
% FAP2 ............... Force application point 2 specified by coordinate 
%                      identifier. Mandatory if 'ReactionForce' is defined,
%                      otherwise without effect.
% FDirDef ............ The reaction force is defined in this coordinate 
%                      system. Optional if 'ReactionForce' is defined,
%                      otherwise without effect.
%
%  Examples:
%> newImplicitInitCond('Id','myIC','Frame1','myFrame','Frame2', ...
%>  'ISYS','Constraints',[1;0;0;0;0;0]);
%> newImplicitInitCond('Id','myIC','Frame1','myFrame','Frame2,'ISYS', ...
%>  'Distance','1');
%> newImplicitInitCond('Id','myLoop','Equation','alpha-4');
% 
%  See also: 
% newConstraint, declareDependent, newBody, newForceElem, 
% newSys, newInput, newOutput, newConstant, newTimeDependent, newGenCoord, 
% newFrame, newStateDependent, newVolume, calcEqMotNonLin
%
% First appearance: 01.07.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
