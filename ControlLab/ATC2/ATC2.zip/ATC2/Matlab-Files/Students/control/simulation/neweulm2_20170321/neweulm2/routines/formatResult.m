% res = formatResult(inputRes_, varargin)
% formatResult - This function formats the result of a time integration
% performed outside of Neweul-M2. In addition, the system outputs, lagrange
% multipliers and reaction forces will be evaluated, if available. This
% function can be used on the one hand to convert results from SIMULINK, 
% supporting most of its result types. On the other hand it supports the
% conversion of SIMPACK results. In this case you have to save the SIMPACK
% results as m-file.
% 
% Input arguments
% inputRes_ ........ Result from a time integration
% 
% Optional input arguments, given pairwise
% Time ............. Double vector containing the time of the integration,
%                    has to have the same number of elements as
%                    inputRes_ (only for SIMULINK results)
% NewTime .......... Time vector to which the given results shall be
%                    interpolated, if empty, the time is kept {[]}
% Evaluate ......... Logical parameter, whether additional values, like
%                    outputs, lagrange multipliers, ... are to be evaluated
%                    (Only for SIMULINK results) {true} 
% reactionForces ... M-file with reaction forces. (Only for SIMPACK
%                    results)
% struct ........... Matlab structure in which you want to save your
%                    results. If structure already contains a time vector
%                    the result will be interpolated on this time vector.
%                    If you pass an additional time vector (newTime) also
%                    old results in structure, if there are any, will be
%                    interpolated on new time vector. (only for SIMPACK
%                    results)
%
% Return values
% res .............. Reformated result
%
% Examples for SIMPACK results with files SimTimeInt.m and SimReacForce.m
%           res = formatResults(1,'reactionForces','SimReacForce');
%           res = formatResults('SimTimeInt','struct',res);
% 
% First appearance: 03.10.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
