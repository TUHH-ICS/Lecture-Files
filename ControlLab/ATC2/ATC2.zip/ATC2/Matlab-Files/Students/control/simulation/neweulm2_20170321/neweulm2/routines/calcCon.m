% calcCon
% CALCON -  Calculate algebraic constraint equations for the kinematic
% loops
%
% Subfunctions contained in this file:
% - comcon
% - con2loop
% 
% See also: newLoop, declareDependent, calcEqMotNonLin, calcCon>comcon,
%   calcCon>con2loop
%
% First appearance: 01.07.2007
% Last amendment:   27.05.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
