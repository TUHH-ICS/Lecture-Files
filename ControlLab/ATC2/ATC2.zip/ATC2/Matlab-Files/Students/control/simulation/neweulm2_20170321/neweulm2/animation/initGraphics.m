% initGraphics - Initialize graphical animation
%
%  Description:
% This function initializes graphical animation. If only some fields of
% the data structure exist, these settings are kept and all other settings
% are added. The available options are all fields of the substructures of
% sys.settings.graphics. So you can either use the given options or the
% corresponding field names.
%
%  Optional parameters for coordinate systems, given pairwise:
% FrameArrowSize ......... Size of arrows {0.08}
% FrameArrowColors ....... Colors of the vectors {'red','yellow','blue'}
% FrameArrowNumPoints .... Number of points on circumference for display {10}
% FrameArrowShapeRatio ... Ratio length/thickness {1/20}
% FrameFontSize .......... Fontsize for labels {12}
%
%  Optional parameters for the colorbar:
% AutoScale .............. Logical if animTimeInt() shall attempt to adjust
%                          the scaling automatically before each animation
%                          {true}
% Range .................. Storage of the currently used range of the
%                          colorbar {[-1 1]}
%  Optional parameters for general settings:
% Reset .................. Reset all options to default values {false}
% 
%  Return values:
% res .................... system data structure, res = sys
%
%  See also:
% drawSys, framePlot, createAnimationWindow
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
