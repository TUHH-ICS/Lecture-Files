This folder contains all files for the import and export to the animation software "Anim".
