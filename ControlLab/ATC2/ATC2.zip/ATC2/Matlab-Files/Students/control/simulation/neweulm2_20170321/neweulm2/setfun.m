% setfun(varargin) -  Enter functions for each generalized coordinate into the system
% data structure in order to perform a kinematic analysis.
% 
%  Syntax:
%> setfun;
%> setfun('Property', value, ...);
%     
%  Description:
% In order to avoid confusion about previously entered functions, all
% undefined functions are reset to zeros.
% 
%  Optional Parameters, given pairwise: 
% VarName ... Name of generalized coordinate
% Exp ....... Symbolic expression of the prescribed function
%
%  See also:
% kinematicAnalysis, plotTrajectories, animTimeInt
%
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
