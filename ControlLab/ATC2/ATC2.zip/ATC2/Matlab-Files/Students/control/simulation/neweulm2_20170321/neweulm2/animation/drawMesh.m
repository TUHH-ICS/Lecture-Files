% drawMesh - draw the nodal mesh of an elastic body.
%
%  Description:
% Draw the nodal mesh of an elastic body. For this, the information of 
% the elastic body has to contain the necessary information.
% 
%  Input arguments:
% ID_ ............. Id of the body to being animated
% 
%  Optional arguments, given pairwise:
% CData ........... Allow dynamic update of colors. {'stresses'}
%                   You may want to have a look at the options stored under
%                   sys.settings.graphics.cdata, which are set via initGraphics
%                   to control the scaling of the colorbar.
%                   Available options are:
%       - 'stresses' If the model of the elastic body provides the data, as a
%                   standard, the stresses are used for coloring. This can
%                   be expressively selected by  passing 'stresses' as
%                   second option. 
%                   When using MatMorembs to obtain the elastic body, the
%                   stresses are sorted in the following order:
%                   [sig_x, sig_y, sig_z, sig_xy, sig_yz, sig_xz]
%       - 'deformations' The elastic translational deformations are used for
%                   the coloring.
%                   Or: You can also directly give a numerical matrix A 
%                   as second argument, which should be of the size
%                   size(A) = [numFaces, numel(idx_y), X], where idx_y
%                   corresponds to the indices of the generalized
%                   coordinates in use for this Mesh. This is necessary as
%                   the actual color values have to be a vector, which is
%                   calculated by A*y(idx_y). The size X means, that the
%                   matrix may have an arbitrary third dimension.
%                   The handling of this third dimension is controlled via
%                   the 'cdataSelect' property. Instead of specifying the
%                   matrix, you can give a function handle myFunc to a
%                   function, which should be of the syntax
%                   myFunc(t,y,idx_y).
% CDataOut ........ Similar to the CData property, the coloring may depend
%                   on the system outputs as evaluated by outputs_all.m.
%                   Here the user should specify a matrix, as otherwise the
%                   CData option can be used to use function handles. As
%                   the user has to adjust the matrix dimensions, this is
%                   an advanced feature {[]}
% CDataSelect ..... This setting specifies how to treat the case that the
%                   matrix or function of the CData property returns a
%                   matrix with more than one column. It can be a numerical
%                   or logical expression to select the desired column. Or
%                   it can be a function handle, which is passed the matrix
%                   obtained by the CData property. As a return value, a
%                   column vector is expected, with one entry per Vertex.
%                   For this you can specify the function as a string or
%                   function handle. If this setting is set to empty, the
%                   surface will be colored uniformely. {1}
%                   There are two functions already available:
%       - vonMises: When the stresses are used for CData, this function
%                   evaluates the von Mises stresses. This function
%                   expects a matrix with 6 columns. Please see
%                   updateGeo>vonMises for more information. 
%       - vectorLength: This function calculates the vector norm, meaning
%                   its length, for each row. It is a vectorized
%                   implementation of the norm() command, which would
%                   return a matrix norm instead. Please see
%                   updateGeo>vectorLength for more information. 
% Color ........... Set face and edgecolor to the same, overwrites
%                   FaceColor_ specified before
% EdgeAlpha ....... Transparency of the edges {1}
% EdgeColor ....... Color of the edges {[0.4 0.4 0.4]}
% FaceAlpha ....... Transparency of the faces {1}
% FaceColor ....... Color of the faces. As the meshes are usually created
%                   automatically, the colors are just taken out of the
%                   following list in the order of creation:
%                   {[1 0 0],[0 0 1],[0 0.7 0],[0.7 0.7 0],[0 0.7 0.7],
%                    [0.7 0 0.7],[0.7 0 0],[0 1 0],[0 0 0.7],[1 1 0],
%                    [0 1 1],[1 0 1],[0 0 0]}
% Idx ............. When several separate meshes are available, specify
%                   which one to chose, if empty, adds all {[]}
% ShapeFun ........ The resulting patch object can be deformed depending on
%                   the generalized coordinates. Here the user can specify
%                   a matrix, which should provide one row for each vertex
%                   of the surface. The deformation d is evaluated as
%                   d=A*y(strcmp(sys.parameters.genCoord,GenCoords)), where A is the
%                   given matrix, y the values of the generalized
%                   coordinates and GenCoords is a list of names of
%                   generalized coordinates to be used {[]}.
% ShapeFunOut ..... Similar to ShapeFun, the resulting patch object can be
%                   deformed depending on the system outputs. The user can
%                   specify a matrix with one row for each vertex of the
%                   surface and one column for each system output as
%                   evaluated by outputs_all.m. As the user has to adjust
%                   the matrix dimensions, this is an advanced feature {[]}
% ShapeFunOutScale ... Scaling factor for ShapeFunOut. This is necessary to
%                   ensure that the length of the arrows or other objects
%                   to be scaled dynamically with the output is reasonable
%                   {1}
% Tag ............. Set Tag property, for identification {'Cube_1'}
%
%  Output arguments:
% h ... Graphic-Handle
%
%  See also:
% drawArrow3d, drawElasticBeam, drawLine, drawRotBody,
% drawSphere, drawSTL, drawSpring
%
% First appearance: 22.08.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
