function res_ = f_FV_D(t,y_,varargin)
% res_ = f_FV_D(t,y_,varargin)
% f_FV_D - definition of state-depending user-defined variable FV_D
% Positions, velocities, ... of coordinate systems can be calculated by
% calling the functions in 'sysFunctions', e.g. body1_r

% res_ = 3000;
% return;

global sys;

res_ = 0; % Default return value
Dy_ = zeros(sys.counters.genCoord,1); % Default value for derivatives
calcDerivatives_ = false;
% Treat optional input arguments
if(length(varargin) == 1)
	% Call was f_FV_D(t,y_,Dy_)
	% Generalized velocities have been passed
	Dy_ = varargin{1};
elseif(length(varargin)>1 && ischar(varargin{1}) && strcmp(varargin{1},'derivative'))
	% Call was f_...(t,y_,'derivatives', ...)
	calcDerivatives_ = true;
	component_ = varargin{2}; % Define axis direction
elseif(length(varargin)>2 && ischar(varargin{2}) && strcmp(varargin{2},'derivative'))
	% Call was f_...(t,y_,Dy_,'derivatives', ...)
	Dy_ = varargin{1};
	calcDerivatives_ = true;
	component_ = varargin{3}; % Define axis direction
elseif(nargin==1 && ischar(t) && strcmp(t,'linearization'))
	% Case IV: Call was f_...('linearization')
	% Return symbolic expression to calculate the linearization
	% Necessary for all parameters appearing in the equations of motion to linearize!
	res_ = sym(0);
	return;
end
% If you have any parameters to define, do that here
% Definitions start #######################################################

% Constant parameters
df = sys.parameters.data.df;
dprf = sys.parameters.data.dprf;
dpcf = sys.parameters.data.dpcf;

% relative vector
% ksys1 = str2func('VA_v');
% ksys2 = str2func('KARV_v');
% 
% % state dependent user defined functions
% v = norm(ksys2(t,y_,Dy_)-ksys1(t,y_,Dy_));
v = Dy_(3); % zf
res_ = dampParam(v,df, dpcf,dprf);

