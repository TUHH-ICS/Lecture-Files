function Dx = f_Dx(t)
% f_Dx - definition of 1st time-derivative of user-defined variable x

global sys;



% constant user-defined variables

xAmp = sys.parameters.data.xAmp;
xOmega = sys.parameters.data.xOmega;
Dx = zeros(1,1);

Dx(1) = xAmp*xOmega*cos(t*xOmega);


% END OF FILE

