% newForceElem(varargin) - generate new force element
% 
%  Syntax:
%> newForceElem
%> newForceElem('Property', value, ...);
%      
%  Desciption:
% This function can be used to define force elements between two frames.
% Next to different typres of spring-damper combinations, user-defined
% force laws can be defined. In case of a user-defined force law, the force
% act positive on the first frame and negative on the second frame.
%
% Optional parameters, given pairwise:
% Id .............. Identifier of force element {'FELEM1'}
% Name ............ Name of force element {'Forceelement Number 1'}
% Type ............ Type of force element, one of this list:
%                       {'SpringDampCmp'}, 'SpringDampCmpRotmat',
%                       'SpringDampCmpLin', 'SpringDampPtp', 'General'
%                   All types starting with _SpringDamp_ represent
%                   spring-damper-combinations. 
%           - General: allows the user to specify an arbitrary applied 
%                   force, often using time or state dependent parameters. 
%           - SpringDampCmp: Standard force element, stiffness and damping
%                   given in each coordinate direction separately.
%           - SpringDampPtp: Standard force element, scalar stiffness and
%                   damping given. Force acting in direction of connecting
%                   line.
%           - SpringDampLin: Similar to SpringDampCmp, but with linearized
%                   rotations.
%           - SpringDampRotmat: Similar to SpringDampCmp, but as the
%                   rotations are based on the relative rotation matrix,
%                   the Jacobian matrices of the rotation are used for the
%                   angular differences.
% Frame1 .......... Coordinate system 1. Select this as one of the
%                   coordinate systems, where the force shall be applied.
%                   For any spring-damper-combination, this coordinate
%                   system is used together with Frame2 to calculate the
%                   relative displacement and velocity. The force will be
%                   applied in positive direction on this coordinate
%                   system. {'ISYS'}
% Frame2 .......... Coordinate system 2 Select this as one of the
%                   coordinate systems, where the force shall be applied.
%                   For any spring-damper-combination, this coordinate
%                   system is used together with Frame1 to calculate the
%                   relative displacement and velocity. The force will be
%                   applied in negative direction on this coordinate
%                   system. {'ISYS'}
% DirDef .......... Coordinate system defining the force directions. This
%                   is important for any spring-damper or generalized
%                   force, which specifies separate directions. Then this
%                   coordinate system defines these axes. {Frame1}
% FAP1 ............ Force application point for body 1, or frame1,
%                   respectively. Only in very special cases, should this
%                   option be different to the standard value of Frame1.
%                   Therefore, please only use this setting, if you know
%                   exactly, what you are doing. {Frame1}
% FAP2 ............ Force application point for body 2, or frame2,
%                   respectively. Only in very special cases, should this
%                   option be different to the standard value of Frame2.
%                   Therefore, please only use this setting, if you know
%                   exactly, what you are doing. {Frame2}
% ForceLaw ........ Force law for element of type _General_. This may be a
%                   scalar value or a six element vector, which then
%                   decides, if the force law is defined similar to a
%                   _SpringDampPtp_ or _SpringDampCmp_. Either the
%                   force is acting on the connecting line (scalar) or for
%                   each coordinate axis separately (vector). {zeros(6,1)}
% Stiffness ....... Stiffness parameter for spring-damper-combinations.
%                   Depending on the Type, this should be a scalar for
%                   _SpringDampPtp_, or a 6-element vector or 6x6 matrix
%                   for _SpringDampCmp_. {zeros(6,1)}
% Damping ......... Damping parameter for spring-damper-combinations.
%                   Depending on the Type, this should be a scalar for
%                   _SpringDampPtp_, or a 6-element vector or 6x6 matrix
%                   for _SpringDampCmp_. {zeros(6,1)}
% NomLength ....... Nominal lengths of the same dimension as _Stiffness_.
%                   {zeros(6,1)}
% NomForce ........ Nominal force, as pretension of the same dimension as
%                   _Stiffness_. {zeros(6,1)}
% Symbolic ........ Use symbolic expressions for the relative kinematic
%                   values or files for solely numerical evaluation {true}
% 
% This is replaced by a force application point for each side of the force
% element, as the force usually does not act in direction of the relative
% position vector. If given anyway, this option sets both FAP1 and FAP2 to
% the same coordinate system.
%
%  Examples:
%>   newForceElem('Frame1','ISYS','Frame2','BODY1','Type','SpringDampCmp', ...
%>       'Stiffness','[10;10;10;0;0;0]','NomLength',[1;0;0;0;0;0]);
%>   newForceElem('Frame1','ISYS','Frame2','BODY1','Type','SpringDampPtp', ...
%>       'Stiffness',20,'Damping',0.5,'NomLength',1);
%>   newForceElem('Frame1','ISYS','Frame2','BODY1','Type','General', ...
%>       'ForceLaw','[5*sin(t); 0; 0; 0; 0; 0]');
% 
%  See also: newBody, newGenCoord, newFrame, newConstraint, newSys, newInput,
%   newOutput, newConstant, newTimeDependent, newStateDependent, newVolume,
%   calcEqMotNonLin
%
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
