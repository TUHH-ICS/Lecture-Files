% setVersionNeweulm2(varargin)
% Function to update the file getVersionNeweulm2 to contain the correct
% version. The file getVersionNeweulm2 will then be used to enter this
% information into the system data structure. The current file is only
% functional at the Institute of Engineering and Computational Mechanics,
% University of Stuttgart.
%
% Optional input arguments, given pairwise
% Version .......... Previous version number, e.g. v1.0.0, otherwise read
%                    from file
% increaseNumber ... Logical, if false, the number is kept {true}
%
% First appearance: 09.08.2010
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
