% varargout = writeHelpvarDef(fid, option, varargin)
% WRITEHELPVARDEF - create m-files with definitions of the symbolic
% parameters contained in sys.parameters.stateDependent. This function searches for all
% occurences of these parameters and prints initializations in fid. If the
% expressions are very large and this function is called in sequence with
% writeGenCoordDef one can save computation time. Then the most time
% consuming operation is to find the symbolic parameters in the expression.
% Therefore one can search for those names and simply pass the cell array,
% which findSyms.m returns, thus omitting one of two searches.
%
% Input values
% fid ........... Filedescriptor
% option ........ Parameter specifying some options concerning this
%                 initialziation. If several options shall be given at
%                 once, use a cell array, then all specified options are
%                 set to true. Or you can pass a structure selecting each
%                 value. If no options are desired, pass an empty array []
%                 instead.
%   onlyInput ... Initializes the input vector by calling the corresponding
%                 functions, e.g. control_inputs.m
%   useInput .... Expect the existance of the input vector u_, initialize
%                 corresponding time dependent parameters accordingly and
%                 not via the time t
%   YvarNoDy .... The state dependent parameters are initialized without
%                 the use of generalized velocities Dy.
%   \t .......... In order to print the initializations at indented
%                 positions, a row of such control signs can be passed.
% Optional input:
% \t ............ In order to print the initializations at indented
%                 positions, a row of such control signs can be passed.
% 
% Return value
% varargout ..... List of all symbolic parameters found in input, only if
%                 an output is specified
% 
% See also: writeGenCoordDef, writeSetValDef
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
