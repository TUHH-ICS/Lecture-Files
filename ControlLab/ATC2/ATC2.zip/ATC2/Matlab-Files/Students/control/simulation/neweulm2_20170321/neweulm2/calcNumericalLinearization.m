% calcNumericalLinearization - Numerically linearize a multibody system of
% neweulm2 by using the finite differences method.
%
%  Syntax:
%> calcNumericalLinearization;
%> [A,B,C,D,X] = calcNumericalLinearization(t,x_,u_,'Property',value,...);
% 
%  Description:
% The matrices given correspond to the equations:
% (x_ is the state vector, u_ the vector of system inputs, y the vector of
% system outputs)
% Dx_ = A * x_ + B * u_
%  y  = C * x_ + D * u_
% 
%  Input arguments, {standard values}:
% t ........... Time for the evaluation of the equations of motion {0}
% x_ .......... State vector for the evaluation of the equations of motion.
%               It is ensured that these set values are consistent with the
%               constraint equations. If nothing is given, the set values
%               are read from sys.dynamics.linear.generic.ref and evaluated at t if necessary.
% u_ .......... System input vector for the evaluation of the equations of
%               motion {all time dependent inputs evaluated at t}
% 
%  Optional input arguments, given pairwise:
% output ...... What shall be used as outputs. If 'system' is given as
%               second argument, the defined outputs are used, for
%               'states', all states are used {'system'}
% stepsize .... Stepsize to be used for the finite differences method
%               {1e-4}
%
%  Return arguments:
% A .... System matrix
% B .... Input matrix
% C .... Output matrix
% D .... Feedthrough matrix
% x_ ... As if no set values have been specified in the vector x_ or they
%        might change for systems with kinematic loops so that they are
%        consistent with the constraint equations, they are passed back
%
%  See also:
% calcEqMotLin, modalAnalysis, finiteDifferences, freqResPlot
%
% First appearance: 14.03.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
