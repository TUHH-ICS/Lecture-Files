% evalKinematics - Evaluate the kinematics without calling 
% calcEqMotNonLin and writeMbsNonLin first.
%
%  Syntax:
% evalKinematics;
% evalKinematics(t, y_);
%
%  Description:
% Needed by updateGeo, if the system is not alreay set up. 
% 
%  Optional parameters {default value}:
% t ..... Current time {0}
% y_ .... Current generalized coordinates {zeros(sys.counters.genCoord,1)}
%
%  See also: updateGeo
%
% First appearance: 19.01.2013
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
