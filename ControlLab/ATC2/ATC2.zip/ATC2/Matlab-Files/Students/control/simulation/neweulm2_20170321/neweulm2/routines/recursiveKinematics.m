% recursiveKinematics - Calculate the relative kinematic values of
% bodies in a loop over all bodies for the recursive algorithm
%
% All values calculated by this function are stored under
% sys.dynamics.nonlinear.generic.(body). and are described in the respective frame of
% reference.
% 
% Subfunctions contained in this file:
% - body2Body
% - identTop
% - identifyIndexes
%
% See also: relativeKinematics, absoluteKinematics,
% recursiveKinematics>body2body, recursiveKinematics>identTop,
% recursiveKinematics>identifyIndexes
%
% First appearance: 18.04.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
