// Class definition of the basic graphical objects used in Neweul-M²

#include "basicObjects.h"

boxes::boxes(const osg::Vec3 &center, float lengthX, float lengthY, float lengthZ, const osg::Vec4 &color)
{
	basicBox = new osg::Box( center, lengthX, lengthY, lengthZ);
	basicBoxDrawable = new osg::ShapeDrawable(basicBox);
    
    osg::Material *material = new osg::Material();
	material->setDiffuse(osg::Material::FRONT,  color);
	material->setSpecular(osg::Material::FRONT, osg::Vec4(0.0, 0.0, 0.0, 1.0));
	material->setAmbient(osg::Material::FRONT,  osg::Vec4(0.1, 0.1, 0.1, 1.0));
	material->setEmission(osg::Material::FRONT, osg::Vec4(0.0, 0.0, 0.0, 1.0));
	material->setShininess(osg::Material::FRONT, 25.0);
    
// 	basicBoxDrawable->setColor(color);
    osg::StateSet *boxStateSet = basicBoxDrawable->getOrCreateStateSet();
    boxStateSet->setMode(GL_BLEND, osg::StateAttribute::ON);
    boxStateSet->setAttribute(material);

	patchGeode = new osg::Geode();

	patchGeode->addDrawable(basicBoxDrawable);
}

spheres::spheres(const osg::Vec3 &center, float radius, const osg::Vec4 &color)
{
	basicSphere = new osg::Sphere( center, radius);
	basicSphereDrawable = new osg::ShapeDrawable(basicSphere);
	osg::Material *material = new osg::Material();
	material->setDiffuse(osg::Material::FRONT,  color);
	material->setSpecular(osg::Material::FRONT, osg::Vec4(0.0, 0.0, 0.0, 1.0));
	material->setAmbient(osg::Material::FRONT,  osg::Vec4(0.1, 0.1, 0.1, 1.0));
	material->setEmission(osg::Material::FRONT, osg::Vec4(0.0, 0.0, 0.0, 1.0));
	material->setShininess(osg::Material::FRONT, 25.0);

    osg::StateSet *sphereStateSet = basicSphereDrawable->getOrCreateStateSet();
    sphereStateSet->setMode(GL_BLEND, osg::StateAttribute::ON);
    sphereStateSet->setAttribute(material);
	patchGeode = new osg::Geode();

	patchGeode->addDrawable(basicSphereDrawable);
}

cones::cones(const osg::Vec3 &center, float radius, float height, const osg::Vec4 &color)
{
	basicCone = new osg::Cone( center, radius, height);
	basicConeDrawable = new osg::ShapeDrawable(basicCone);
	osg::Material *material = new osg::Material();
	material->setDiffuse(osg::Material::FRONT,  color);
	material->setSpecular(osg::Material::FRONT, osg::Vec4(0.0, 0.0, 0.0, 1.0));
	material->setAmbient(osg::Material::FRONT,  osg::Vec4(0.1, 0.1, 0.1, 1.0));
	material->setEmission(osg::Material::FRONT, osg::Vec4(0.0, 0.0, 0.0, 1.0));
	material->setShininess(osg::Material::FRONT, 25.0);

    osg::StateSet *coneStateSet = basicConeDrawable->getOrCreateStateSet();
    coneStateSet->setMode(GL_BLEND, osg::StateAttribute::ON);
    coneStateSet->setAttribute(material);
	patchGeode = new osg::Geode();

	patchGeode->addDrawable(basicConeDrawable);
}

cylinders::cylinders(const osg::Vec3 &center, float radius, float height, const osg::Vec4 &color, const osg::Vec4f &quadVec)
{
	basicCylinder = new osg::Cylinder( center, radius, height);
	basicCylinder->setRotation(osg::Quat(quadVec));
	basicCylinderDrawable = new osg::ShapeDrawable(basicCylinder);
	osg::Material *material = new osg::Material();
	material->setDiffuse(osg::Material::FRONT,  color);
	material->setSpecular(osg::Material::FRONT, osg::Vec4(0.0, 0.0, 0.0, 1.0));
	material->setAmbient(osg::Material::FRONT,  osg::Vec4(0.1, 0.1, 0.1, 1.0));
	material->setEmission(osg::Material::FRONT, osg::Vec4(0.0, 0.0, 0.0, 1.0));
	material->setShininess(osg::Material::FRONT, 25.0);

    osg::StateSet *cylinderStateSet = basicCylinderDrawable->getOrCreateStateSet();
    cylinderStateSet->setMode(GL_BLEND, osg::StateAttribute::ON);
    cylinderStateSet->setAttribute(material);
	patchGeode = new osg::Geode();

	patchGeode->addDrawable(basicCylinderDrawable);
}

cylinders::~cylinders()
{   
}

patchProto::patchProto(const char *fileName)
{
    vertCoords=NULL;
    faces=NULL;
    lines=NULL;
    shapeFuns=NULL;
    faceColor=NULL;
    vertNormals=NULL;

    hid_t h5FileHandle;
    hid_t h5DataSet;
    hsize_t numDatasets;
    hsize_t i = 0;
    ssize_t strLength;
    herr_t  status;
    int allocSize;
    
    if (!std::ifstream(fileName))
    {
         char *statusMessage = (char *) calloc(256, sizeof(char));
         sprintf(statusMessage, "Unable to find %s!", fileName);
         free(statusMessage);
         return;
    }

    char *grpName= (char *) calloc(256, sizeof(char));

    h5FileHandle = H5Fopen( fileName, H5F_ACC_RDONLY, H5P_DEFAULT );

    if (h5FileHandle<0){
        char *statusMessage = (char *) calloc(256, sizeof(char));
        sprintf(statusMessage, "Unable to open HDF5 file: %s!", fileName);
        free(statusMessage);
        free(grpName);
        return;
    } else {

        /* Get number of objects */
        status =  H5Gget_num_objs(h5FileHandle, &(numDatasets));

        for (i=0; i< numDatasets; i++){

            // Get dataset name
            strLength =  H5Gget_objname_by_idx(h5FileHandle, i, grpName, 256);

            // Cut string
            char * grpName_tmp = (char *) realloc(grpName,strLength+1);
            if (grpName_tmp == NULL) {
                free(grpName);
                return;
            } else {
                grpName = grpName_tmp;
            }

            // Dataset open
            h5DataSet = H5Dopen(h5FileHandle, grpName, H5P_DEFAULT);
         
            // read data from HDF5 Datasets
            if (strcmp("vertices", grpName)==0) {
                allocSize = (int) H5Dget_storage_size(h5DataSet)/ (int) sizeof(float);
                if (vertCoords==NULL)
                    vertCoords = (float *) calloc(allocSize, sizeof(float));
                else
                    vertCoords = (float *) realloc(vertCoords, allocSize*sizeof(float));
                clock_t start = clock();
                status = H5Dread(h5DataSet, H5T_IEEE_F32LE, H5S_ALL, H5S_ALL, H5P_DEFAULT, vertCoords);
                clock_t end = clock();
                double time = (double) (end-start) / CLOCKS_PER_SEC * 1000.0;
                std::cout << "HDF5 import vertices: " << time << std::endl;
            } else if (strcmp("normals", grpName)==0) {
                allocSize = (int) H5Dget_storage_size(h5DataSet)/ (int) sizeof(float);
                if (vertNormals==NULL)
                    vertNormals = (float *) calloc(allocSize, sizeof(float));
                else
                    vertNormals = (float *) realloc(vertNormals, allocSize*sizeof(float));
                clock_t start = clock();
                status = H5Dread(h5DataSet, H5T_IEEE_F32LE, H5S_ALL, H5S_ALL, H5P_DEFAULT, vertNormals);
                clock_t end = clock();
                double time = (double) (end-start) / CLOCKS_PER_SEC * 1000.0;
                std::cout << "HDF5 import vertex normals: " << time << std::endl;
            } else if (strcmp("faces", grpName)==0) {
                allocSize = (int) H5Dget_storage_size(h5DataSet)/ (int) sizeof(int32_t);
                if (faces==NULL)
                    faces = (int32_t *) calloc(allocSize, sizeof(int32_t));
                else
                    faces = (int32_t *) realloc(faces, allocSize*sizeof(int32_t));
                clock_t start = clock();
                status = H5Dread(h5DataSet, H5T_STD_I32LE, H5S_ALL, H5S_ALL, H5P_DEFAULT, faces);
                clock_t end = clock();
                double time = (double) (end-start) / CLOCKS_PER_SEC * 1000.0;
                std::cout << "HDF5 import faces: " << time << std::endl;
            } else if (strcmp("lines", grpName)==0) {
                allocSize = (int) H5Dget_storage_size(h5DataSet)/ (int) sizeof(int32_t);
                if (faces==NULL)
                    lines = (int32_t *) calloc(allocSize, sizeof(int32_t));
                else
                    lines = (int32_t *) realloc(lines, allocSize*sizeof(int32_t));
                clock_t start = clock();
                status = H5Dread(h5DataSet, H5T_STD_I32LE, H5S_ALL, H5S_ALL, H5P_DEFAULT, lines);
                clock_t end = clock();
                double time = (double) (end-start) / CLOCKS_PER_SEC * 1000.0;
                std::cout << "HDF5 import lines: " << time << std::endl;
            } else if (strcmp("shapeFun", grpName)==0) {
                allocSize = (int) H5Dget_storage_size(h5DataSet)/ (int) sizeof(float);
                if (shapeFuns==NULL)
                    shapeFuns = (float *) calloc(allocSize, sizeof(float));
                else
                    shapeFuns = (float *) realloc(shapeFuns, allocSize*sizeof(float));
                status = H5Dread(h5DataSet, H5T_IEEE_F32LE, H5S_ALL, H5S_ALL, H5P_DEFAULT, shapeFuns);
            } else if (strcmp("faceColor", grpName)==0) {
                allocSize = (int) H5Dget_storage_size(h5DataSet)/ (int) sizeof(float);
                if (faceColor==NULL)
                    faceColor = (float *) calloc(allocSize, sizeof(float));
                else
                    faceColor = (float *) realloc(faceColor, allocSize*sizeof(float));
                status = H5Dread(h5DataSet, H5T_IEEE_F32LE, H5S_ALL, H5S_ALL, H5P_DEFAULT, faceColor);
            } else if (strcmp("numTriangles", grpName)==0) {
                allocSize = (int) H5Dget_storage_size(h5DataSet)/ (int) sizeof(int32_t);
                if (allocSize==1){
                    status = H5Dread(h5DataSet, H5T_STD_I32LE, H5S_ALL, H5S_ALL, H5P_DEFAULT, &numTriangles);
                }
            } else if (strcmp("numQuads", grpName)==0) {
                allocSize = (int) H5Dget_storage_size(h5DataSet)/ (int) sizeof(int32_t);
                if (allocSize==1){
                    status = H5Dread(h5DataSet, H5T_STD_I32LE, H5S_ALL, H5S_ALL, H5P_DEFAULT, &numQuads);
                }
            } else if (strcmp("numVertices", grpName)==0) {
                allocSize = (int) H5Dget_storage_size(h5DataSet)/ (int) sizeof(int32_t);
                if (allocSize==1){
                    status = H5Dread(h5DataSet, H5T_STD_I32LE, H5S_ALL, H5S_ALL, H5P_DEFAULT, &numVertices);
                }
            } else if (strcmp("numCoordinates", grpName)==0) {
                allocSize = (int) H5Dget_storage_size(h5DataSet)/ (int) sizeof(int32_t);
                if (allocSize==1){
                    status = H5Dread(h5DataSet, H5T_STD_I32LE, H5S_ALL, H5S_ALL, H5P_DEFAULT, &numCoordinates);
                }
            } else if (strcmp("frameNumber", grpName)==0) {
                allocSize = (int) H5Dget_storage_size(h5DataSet)/ (int) sizeof(int32_t);
                if (allocSize==1){
                    status = H5Dread(h5DataSet, H5T_STD_I32LE, H5S_ALL, H5S_ALL, H5P_DEFAULT, &frameNumber);
                }
            } else if (strcmp("firstCoord", grpName)==0) {
                allocSize = (int) H5Dget_storage_size(h5DataSet)/ (int) sizeof(int32_t);
                if (allocSize==1){
                    status = H5Dread(h5DataSet, H5T_STD_I32LE, H5S_ALL, H5S_ALL, H5P_DEFAULT, &firstCoord);
                }
            }

            //Close dataset
            status = H5Dclose(h5DataSet);

            // Realloc original size
            grpName_tmp = (char *) realloc(grpName,256);
            if (grpName_tmp == NULL) {
                free(grpName);
                return;
            } else {
                grpName = grpName_tmp;
            }
        }
    }

    // Close file
    H5Fclose(h5FileHandle);

    // Free string
    free(grpName);


    patchGeode     = new osg::Geode();
    patchGeometry  = new osg::Geometry();
    patchVertices  = new osg::Vec3Array(numVertices);
    patchNormals   = new osg::Vec3Array(numVertices);
    patchColors    = new osg::Vec4Array();
    patchTriangles = new osg::DrawElementsUInt(osg::PrimitiveSet::TRIANGLES, 3*numTriangles);
    patchQuads     = new osg::DrawElementsUInt(osg::PrimitiveSet::QUADS, 4*numQuads);
    
    // Copy memory block to vertices array
    float *VerticesPtr = (float *) patchVertices->getDataPointer();
    memcpy(VerticesPtr, vertCoords, 3*numVertices*sizeof(float));
    
    patchGeometry->setVertexArray( patchVertices );
    
    if (vertNormals!=NULL){

        // Copy memory block to vertices array
        float *normalsPtr = (float *) patchNormals->getDataPointer();
        memcpy(normalsPtr, vertNormals, 3*numVertices*sizeof(float));

        patchGeometry->setNormalArray( patchNormals );
        patchGeometry->setNormalBinding(osg::Geometry::BIND_PER_VERTEX);
    }

    if (numTriangles!=0){

        int32_t *patchPtr = (int32_t *) patchTriangles->getDataPointer();
        memcpy(patchPtr, faces, 3*numTriangles*sizeof(int32_t));

        patchGeometry->addPrimitiveSet(patchTriangles);
        
//         patchLines     = new osg::DrawElementsUInt(osg::PrimitiveSet::LINES, 2*3*numTriangles);
//         start = clock();
//         int32_t *linePtr = (int32_t *) patchLines->getDataPointer();
//         memcpy(linePtr, lines, 2*3*numTriangles*sizeof(int32_t));
// 
//         patchGeometry->addPrimitiveSet(patchLines);
//         end = clock();
//         time = (double) (end-start) / CLOCKS_PER_SEC * 1000.0;
//         std::cout << "fill up line array: " << time << std::endl;
        
    } else if (numQuads!=0) {
        int32_t *patchPtr = (int32_t *) patchQuads->getDataPointer();
        memcpy(patchPtr, faces, 4*numQuads*sizeof(int32_t));

        patchGeometry->addPrimitiveSet(patchQuads);
    }

    osg::StateSet *patchStateSet = patchGeometry->getOrCreateStateSet();

    osg::BlendFunc* bf = new
        osg::BlendFunc(osg::BlendFunc::SRC_ALPHA, osg::BlendFunc::ONE_MINUS_SRC_ALPHA );
    patchStateSet->setAttributeAndModes(bf);

    patchStateSet->setRenderingHint(osg::StateSet::TRANSPARENT_BIN);
    patchStateSet->setMode(GL_LIGHTING, osg::StateAttribute::ON);
    
    patchStateSet->ref();
    patchStateSet->setMode(GL_BLEND, osg::StateAttribute::ON);

    // osgUtil::SmoothingVisitor::smooth(*patchGeometry);
    
    patchColors->push_back(osg::Vec4(faceColor[0], faceColor[1], faceColor[2], faceColor[3]) );
    patchGeometry->setColorArray(patchColors);
    patchGeometry->setColorBinding(osg::Geometry::BIND_OVERALL);
    
    osg::StateSet *geodeStateSet = patchGeode->getOrCreateStateSet();
    geodeStateSet->setMode(GL_NORMALIZE, osg::StateAttribute::ON);
    patchGeode->addDrawable(patchGeometry);

}

patchProto::~patchProto()
{
    free(vertCoords);
    free(faces);
    free(lines);
    free(shapeFuns);
    free(faceColor);
    free(vertNormals);
}

void patchProto::updateStructure(double* genCoords)
{
    double* y_needed = &(genCoords[firstCoord]);
    int i_, j_, k_;

    if (numCoordinates!=0){
        float *patchPtr = (float *) patchVertices->getDataPointer();

        for (i_=0; i_< numVertices; i_++){
            for (j_=0; j_< 3; j_++){
                patchPtr[i_*3+j_] = vertCoords[i_*3+j_];
                for (k_=0; k_< numCoordinates; k_++){
                    patchPtr[i_*3+j_]+=shapeFuns[(i_*3*numCoordinates)+(j_*numCoordinates)+k_]*(float)y_needed[k_];
                }
            }
        }
        patchGeometry->setVertexArray (patchVertices);
    }

}
