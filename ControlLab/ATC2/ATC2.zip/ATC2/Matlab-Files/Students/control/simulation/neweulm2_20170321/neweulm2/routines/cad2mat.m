function [faces, verts, normals, colors, CAD_object_name] = cad2mat(filename)
% cad2mat - Import patches from *.stl/*.ast/*.spl files
%
%  Input arguments:
% filename ... Filename of exported CAD data, {required}
%
%  Return parameters:
% faces .......... Faces of the patch
% verts .......... Vertices of the patch
% colors ......... Color information (if defined in file)
% 
%  See also: 
% drawSTL
%
% First appearance: 09.04.2009
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de

if nargin == 0
    error('No file specified: Please specify a CAD file for import!');
end

CAD_object_name = '';

result = getSTLType(filename);


% Read the CAD data file:
switch result
    case 'ast'
        [faces, verts, normals, CAD_object_name] = ast2matlab(filename); colors = [];
    case 'slp'
        [faces, verts, colors, normals, CAD_object_name] = slp2matlab(filename);
    case 'stl'
        [faces, verts, normals] = stl2matlab(filename); colors = [];
end
        
end

function [faces_, verts_, normals] = stl2matlab(filename)
% ast2matlab - Import binary STL-file (*.stl) to matlab

fid=fopen(filename, 'r'); %Open the file, assumes STL ASCII format.
if fid == -1 
    error('File could not be opened, check name or path.')
end

fseek(fid,80,-1);

numFaces = fread(fid, 1, 'uint32=>double');
numVerts = 3*numFaces;

verts_  = zeros(numVerts,3);
normals = zeros(numVerts,3);

for k_ = 1 : numFaces
    normals((k_-1)*3+1,:) = fread(fid, 3, 'float=>double',0,'l');
    normals((k_-1)*3+2,:) = normals((k_-1)*3+1,:);
    normals((k_-1)*3+3,:) = normals((k_-1)*3+1,:);
    verts_((k_-1)*3+1, :) =  fread(fid, 3, 'float=>double',0,'l');
    verts_((k_-1)*3+2, :) =  fread(fid, 3, 'float=>double',0,'l');
    verts_((k_-1)*3+3, :) =  fread(fid, 3, 'float=>double',0,'l');
    temp = fread(fid, 1, 'uint16=>double');
end

% [verts_, unId1, unid2] = unique(verts_,'rows');
flist = 1:numVerts;
faces_ = reshape(flist, 3,numFaces)';
% faces_ = unid2(faces_);

fclose(fid);
    
end

function [faces_, verts_, normals_, CAD_object_name] = ast2matlab(filename)
% ast2matlab - Import ASCII STL-file (*.ast) to matlab
  
Nrows = countLines(filename);
    
numFaces = (Nrows-2)/7;
numVerts = 3*numFaces;

normals_ = zeros(numVerts,3);
verts_   = zeros(numVerts,3);

fid=fopen(filename, 'r'); %Open the file, assumes STL ASCII format.
if fid == -1 
    error('File could not be opened, check name or path.')
end

CAD_object_name = sscanf(fgetl(fid), '%*s %s');

for k_ = 1 : numFaces
    normals_((k_-1)*3+1, :) =  sscanf(fgetl(fid), '%*s %*s %f %f %f');
    normals_((k_-1)*3+2, :) = normals_((k_-1)*3+1, :);
    normals_((k_-1)*3+3, :) = normals_((k_-1)*3+1, :);
    fgetl(fid); % Skit second line
    verts_((k_-1)*3+1, :) =  sscanf(fgetl(fid), '%*s %f %f %f');
    verts_((k_-1)*3+2, :) =  sscanf(fgetl(fid), '%*s %f %f %f'); 
    verts_((k_-1)*3+3, :) =  sscanf(fgetl(fid), '%*s %f %f %f');
    fgetl(fid); % Skip line
    fgetl(fid); % Skit line
end

% [verts_, unId1, unid2] = unique(verts_,'rows');
flist = 1:numVerts;
faces_ = reshape(flist, 3,numFaces)';
% faces_ = unid2(faces_);

fclose(fid);
    
end

function [fout, vout, cout, nout, CAD_object_name] = slp2matlab(filename)
% slp2matlab - Import ASCII SLP-file (*.stl/*.slp) to matlab. This file format is
% similar to the STL file format but it contains additional color
% information. 
%
% Render files take the form:
%   
%solid BLOCK
%  color 1.000 1.000 1.000
%  facet
%      normal 0.000000e+00 0.000000e+00 -1.000000e+00
%      normal 0.000000e+00 0.000000e+00 -1.000000e+00
%      normal 0.000000e+00 0.000000e+00 -1.000000e+00
%    outer loop
%      vertex 5.000000e-01 -5.000000e-01 -5.000000e-01
%      vertex -5.000000e-01 -5.000000e-01 -5.000000e-01
%      vertex -5.000000e-01 5.000000e-01 -5.000000e-01
%    endloop
% endfacet
%
% The first line is object name, then comes multiple facet and vertex lines.
% A color specifier is next, followed by those faces of that color, until
% next color line.

fid=fopen(filename, 'r'); %Open the file, assumes STL ASCII format.

CAD_object_name = sscanf(fgetl(fid), '%*s %s'); 
  
vnum = 0;
nnum = 0;

VColor = zeros(3,1);

while feof(fid) == 0
    tline = fgetl(fid);
    fword = sscanf(tline, '%s ');
    
    if strncmpi(fword, 'c',1) == 1;
        VColor = sscanf(tline, '%*s %f %f %f');
    elseif strncmpi(fword, 'n',1) == 1;
        nnum = nnum + 1;
        n(:,nnum) = sscanf(tline, '%*s %f %f %f');
    elseif strncmpi(fword, 'v',1) == 1;
        vnum = vnum + 1;
        v(:,vnum) = sscanf(tline, '%*s %f %f %f');
        c(:,vnum) = VColor;
    end                                          
end
% Build face list; The vertices are in order, so just number them.

fnum = vnum/3;      %Number of faces, vnum is number of vertices.  STL is triangles.
flist = 1:vnum;     %Face list of vertices, all in order.
F = reshape(flist, 3,fnum); %Make a "3 by fnum" matrix of face list data.

% Return the faces and vertexs.

fout = F';
vout = v';
cout = c';
nout = n';

fclose(fid);

end

function count = countLines(fname)
fh = fopen(fname, 'rt');
assert(fh ~= -1, 'Could not read: %s', fname);
x = onCleanup(@() fclose(fh));
count = 0;
while ~feof(fh)
    count = count + sum( fread( fh, 16384, 'char' ) == char(10) );
end
end

function result = getSTLType(filename)

result = '';

fid=fopen(filename, 'r'); %Open the file, assumes STL ASCII format.

if fid == -1 
    error('File could not be opened, check name or path.')
end

isMesh = fgetl(fid);

if ~strcmp(isMesh(1:5),'solid')
    result = 'stl';
    return;
%     error([filename,' is not a valid STL-file! Aborting ...']);
end

tline = fgetl(fid);

while ~isempty(tline)
    [part_, tline] = strtok(tline,' '); %#ok<STTOK>
    if strcmpi(part_,'color')
        result = 'slp';
        break;
    elseif strcmpi(part_,'facet')
        [part_, tline] = strtok(tline,' '); %#ok<STTOK>
        if strcmpi(part_,'normal')
            result = 'ast';
            break;
        end
    end
end

fclose(fid);

end
