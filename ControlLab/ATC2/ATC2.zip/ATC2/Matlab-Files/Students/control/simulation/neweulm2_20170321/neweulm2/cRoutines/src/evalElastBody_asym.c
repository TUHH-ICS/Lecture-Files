/* evalElastBody.c */

#include "mex.h"
#include <stdlib.h>

#define INDEX_2(i_,j_,numrow) ((j_)*(numrow)+(i_))
#define INDEX_3(i_,j_,k_,numrow,numcol) ((k_)*(numrow)*(numcol)+(j_)*(nmodes)+(i_)) 

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {
    
    /* Outputs */
    double *elastMassMatrix;
    double *qa_out;
    
    /* Inputs */
    double *y_elast;
    double *Dy_elast;
    double *omega;
    double *gravity;
    double *qa_in;
    
    int nmodes = 0;
    int nnodes = 0;
    
    double mass = 0.0;
    
    /* Temporary pointers */
    double *mCM_m0;
    double *mCM_m1_v;
    double *mCM_m1_w;
    
    double *Ct_m0_v;
    double *Ct_m0_w;
    
    double *Cr_m0_v;
    double *Cr_m0_w;
    double *Cr_m1_v;
    double *Cr_m1_w;
    
    double *mmi_m0;
    double *mmi_m1;
    double *mmi_m2;
    
    double *Me_m0;
    
    double *Gr_m0;
    double *Gr_m1;
    
    double *Ge_m0;
    double *Ge_m1;
    
    double *Oe_m0;
    double *Oe_m1;
    
    double *Ke_m0;
    
    double *De_m0;
    
    /* Allocated pointers */
    double *h_omega_t;
    double *h_omega_r;
    double *omega_q;
    double Oe_temp = 0.0;
    
    int i_, j_, k_;
    
    
    /* There should be 5 input arguments */
    
    if ( nrhs != 6 ) {
        mexErrMsgIdAndTxt("MATLAB:evalElastBody:rhs","This function expects six input arguments.");
    }
    
    if ( nlhs != 2 ) {
        mexErrMsgIdAndTxt("MATLAB:evalElastBody:lhs","This function passes two output arguments.");
    }
    
    if (!mxIsStruct(prhs[0]))
        mexErrMsgIdAndTxt("MATLAB:evalElastBody:strcut","The first argument has to be the SID data of the elastic body.");
    
    /* Get number of nodes and modes */
    nnodes = (int) mxGetPr(mxGetField(prhs[0], 0, "nnodes"))[0];
    nmodes = (int) mxGetPr(mxGetField(prhs[0], 0, "nmodes"))[0];
    
    if ( (int) mxGetNumberOfElements(prhs[1]) != nmodes )
        mexErrMsgIdAndTxt("MATLAB:evalElastBody:yelast","The second argument has to be a %dx1 vector.",nmodes);
    
    if ( (int) mxGetNumberOfElements(prhs[2]) != nmodes )
        mexErrMsgIdAndTxt("MATLAB:evalElastBody:yelast","The third argument has to be a %dx1 vector.",nmodes);
    
    if ( (int) mxGetNumberOfElements(prhs[3]) != 3 )
        mexErrMsgIdAndTxt("MATLAB:evalElastBody:yelast","The fourth argument has to be a 3x1 vector.");
    
    if ( (int) mxGetNumberOfElements(prhs[4]) != 3 )
        mexErrMsgIdAndTxt("MATLAB:evalElastBody:yelast","The fifth argument has to be a 3x1 vector.");
    
    if ( (int) mxGetNumberOfElements(prhs[5]) != (nmodes+6) )
        mexErrMsgIdAndTxt("MATLAB:evalElastBody:yelast","The sixth argument has to be a %dx1 vector.",(nmodes+6) );
    
    /* mexPrintf("Number of modes: %d, number of nodes: %d!\n",nmodes, nnodes); */ 
    
    plhs[0] = mxCreateNumericMatrix(6+nmodes, 6+nmodes, mxDOUBLE_CLASS, mxREAL);
    elastMassMatrix = mxGetPr(plhs[0]);
    
    y_elast  = mxGetPr(prhs[1]);
    Dy_elast = mxGetPr(prhs[2]);
    
    /* == Rigid body mass == */
    mass = mxGetPr(mxGetField(mxGetField(prhs[0], 0, "refmod"), 0, "mass"))[0];
    
    elastMassMatrix[INDEX_2(0,0,nmodes+6)] = mass;
    elastMassMatrix[INDEX_2(1,1,nmodes+6)] = mass;
    elastMassMatrix[INDEX_2(2,2,nmodes+6)] = mass;
    
    /* == Tensor of inertia (m0 & m1) == */
    mmi_m0 = mxGetPr(mxGetField(mxGetField(prhs[0], 0, "mmi"), 0, "m0"));
    
    elastMassMatrix[INDEX_2(3,3,nmodes+6)] = mmi_m0[0];
    elastMassMatrix[INDEX_2(4,4,nmodes+6)] = mmi_m0[1];
    elastMassMatrix[INDEX_2(5,5,nmodes+6)] = mmi_m0[2];
    
    elastMassMatrix[INDEX_2(3,4,nmodes+6)] = mmi_m0[3];
    elastMassMatrix[INDEX_2(3,5,nmodes+6)] = mmi_m0[4];
    elastMassMatrix[INDEX_2(4,5,nmodes+6)] = mmi_m0[5];
    
    mmi_m1 = mxGetPr(mxGetField(mxGetField(prhs[0], 0, "mmi"), 0, "m1"));
    
    if ((int) mxGetPr(mxGetField(mxGetField(prhs[0], 0, "mmi"), 0, "order"))[0] != 0){
    
        for (i_ = 0; i_ < nmodes; i_++){
            elastMassMatrix[INDEX_2(3,3,nmodes+6)] += y_elast[i_]*mmi_m1[INDEX_2(0,i_,6)];
            elastMassMatrix[INDEX_2(4,4,nmodes+6)] += y_elast[i_]*mmi_m1[INDEX_2(1,i_,6)];
            elastMassMatrix[INDEX_2(5,5,nmodes+6)] += y_elast[i_]*mmi_m1[INDEX_2(2,i_,6)];

            elastMassMatrix[INDEX_2(3,4,nmodes+6)] += y_elast[i_]*mmi_m1[INDEX_2(3,i_,6)];
            elastMassMatrix[INDEX_2(3,5,nmodes+6)] += y_elast[i_]*mmi_m1[INDEX_2(4,i_,6)];
            elastMassMatrix[INDEX_2(4,5,nmodes+6)] += y_elast[i_]*mmi_m1[INDEX_2(5,i_,6)];
        }
    }
    
    elastMassMatrix[INDEX_2(4,3,nmodes+6)] = elastMassMatrix[INDEX_2(3,4,nmodes+6)];
    
    elastMassMatrix[INDEX_2(5,3,nmodes+6)] = elastMassMatrix[INDEX_2(3,5,nmodes+6)];
    
    elastMassMatrix[INDEX_2(5,4,nmodes+6)] = elastMassMatrix[INDEX_2(4,5,nmodes+6)];
    
    /* == Elastic mass matrix (only m0) == */
    Me_m0 = mxGetPr(mxGetField(mxGetField(prhs[0], 0, "Me"), 0, "m0"));
    
    for (i_ = 0; i_ < nmodes; i_++){
        for (j_ = 0; j_ < nmodes; j_++){
            elastMassMatrix[INDEX_2(6+i_,6+j_,nmodes+6)] = Me_m0[j_*nmodes + i_];
        }
    }
    
    /* == mCM (m0 & m1) == */
    mCM_m0 = mxGetPr(mxGetField(mxGetField(prhs[0], 0, "mCM"), 0, "m0"));
    
    elastMassMatrix[INDEX_2(5,1,nmodes+6)] = mCM_m0[0];
    elastMassMatrix[INDEX_2(1,5,nmodes+6)] = mCM_m0[0];
    elastMassMatrix[INDEX_2(3,2,nmodes+6)] = mCM_m0[1];
    elastMassMatrix[INDEX_2(2,3,nmodes+6)] = mCM_m0[1];
    elastMassMatrix[INDEX_2(4,0,nmodes+6)] = mCM_m0[2];
    elastMassMatrix[INDEX_2(0,4,nmodes+6)] = mCM_m0[2];
    
    if ((int) mxGetPr(mxGetField(mxGetField(prhs[0], 0, "mCM"), 0, "order"))[0] != 0){
    
        mCM_m1_v = mxGetPr(mxGetField(mxGetField(prhs[0], 0, "mCM"), 0, "m1_v"));

        for (i_ = 0; i_ < nmodes; i_++){
            elastMassMatrix[INDEX_2(1,5,nmodes+6)] += y_elast[i_]*mCM_m1_v[INDEX_2(0,i_,3)];
            elastMassMatrix[INDEX_2(2,3,nmodes+6)] += y_elast[i_]*mCM_m1_v[INDEX_2(1,i_,3)];
            elastMassMatrix[INDEX_2(0,4,nmodes+6)] += y_elast[i_]*mCM_m1_v[INDEX_2(2,i_,3)];
        }
        /* m1_w is already transposed */
        mCM_m1_w = mxGetPr(mxGetField(mxGetField(prhs[0], 0, "mCM"), 0, "m1_w"));

        for (i_ = 0; i_ < nmodes; i_++){
            elastMassMatrix[INDEX_2(5,1,nmodes+6)] += y_elast[i_]*mCM_m1_w[INDEX_2(i_,0,3)];
            elastMassMatrix[INDEX_2(3,2,nmodes+6)] += y_elast[i_]*mCM_m1_w[INDEX_2(i_,1,3)];
            elastMassMatrix[INDEX_2(4,0,nmodes+6)] += y_elast[i_]*mCM_m1_w[INDEX_2(i_,2,3)];
        }
        
    }
    
    elastMassMatrix[INDEX_2(4,2,nmodes+6)] = -elastMassMatrix[INDEX_2(5,1,nmodes+6)];
    elastMassMatrix[INDEX_2(2,4,nmodes+6)] = -elastMassMatrix[INDEX_2(1,5,nmodes+6)];
    
    elastMassMatrix[INDEX_2(5,0,nmodes+6)] = -elastMassMatrix[INDEX_2(3,2,nmodes+6)];
    elastMassMatrix[INDEX_2(0,5,nmodes+6)] = -elastMassMatrix[INDEX_2(2,3,nmodes+6)];
    
    elastMassMatrix[INDEX_2(3,1,nmodes+6)] = -elastMassMatrix[INDEX_2(4,0,nmodes+6)];
    elastMassMatrix[INDEX_2(1,3,nmodes+6)] = -elastMassMatrix[INDEX_2(0,4,nmodes+6)];
    
    
    /* == Ct (only m0) == */
    Ct_m0_v = mxGetPr(mxGetField(mxGetField(prhs[0], 0, "Ct"), 0, "m0_v"));
    Ct_m0_w = mxGetPr(mxGetField(mxGetField(prhs[0], 0, "Ct"), 0, "m0_w"));
    
    for (i_ = 0; i_ < nmodes; i_++){
        for (j_ = 0; j_ < 3; j_++){
            elastMassMatrix[INDEX_2(6+i_,j_,nmodes+6)] = Ct_m0_w[j_*nmodes + i_];
            elastMassMatrix[INDEX_2(j_,6+i_,nmodes+6)] = Ct_m0_v[j_*nmodes + i_];
        }
    }
    
    /* == Cr (m0 & m1) == */
    Cr_m0_v = mxGetPr(mxGetField(mxGetField(prhs[0], 0, "Cr"), 0, "m0_v"));
    Cr_m0_w = mxGetPr(mxGetField(mxGetField(prhs[0], 0, "Cr"), 0, "m0_w"));
    
    Cr_m1_v = mxGetPr(mxGetField(mxGetField(prhs[0], 0, "Cr"), 0, "m1_v"));
    Cr_m1_w = mxGetPr(mxGetField(mxGetField(prhs[0], 0, "Cr"), 0, "m1_w"));
    
    if ((int) mxGetPr(mxGetField(mxGetField(prhs[0], 0, "Cr"), 0, "order"))[0] != 0){
        for (i_ = 0; i_ < nmodes; i_++){
            for (j_ = 0; j_ < 3; j_++){
                elastMassMatrix[INDEX_2(3+j_,6+i_,nmodes+6)] = Cr_m0_v[j_*nmodes + i_];
                elastMassMatrix[INDEX_2(6+i_,3+j_,nmodes+6)] = Cr_m0_w[j_*nmodes + i_];
                for (k_ = 0; k_ < nmodes; k_++){
                    elastMassMatrix[INDEX_2(3+j_,6+i_,nmodes+6)] += y_elast[k_]*Cr_m1_v[INDEX_3(i_,k_,j_,nmodes,nmodes)];
                    elastMassMatrix[INDEX_2(6+i_,3+j_,nmodes+6)] += y_elast[k_]*Cr_m1_w[INDEX_3(i_,k_,j_,nmodes,nmodes)];
                }
            }
        }
    } else {
        for (i_ = 0; i_ < nmodes; i_++){
            for (j_ = 0; j_ < 3; j_++){
                elastMassMatrix[INDEX_2(3+j_,6+i_,nmodes+6)] = Cr_m0_v[j_*nmodes + i_];
                elastMassMatrix[INDEX_2(6+i_,3+j_,nmodes+6)] = Cr_m0_w[j_*nmodes + i_];
            }
        }
        
    }

    /* == ! MASS MATRIX DONE ! == */
    
    /* == Right hand side == */
    
    plhs[1] = mxCreateNumericMatrix(6+nmodes, 1, mxDOUBLE_CLASS, mxREAL);
    qa_out = mxGetPr(plhs[1]);
    
    /* == qa + h_g == */
    qa_in = mxGetPr(prhs[5]);
    
    omega = mxGetPr(prhs[3]);
    gravity = mxGetPr(prhs[4]);
        
    for (i_ = 0; i_ < 6+nmodes; i_++){
        qa_out[i_] = qa_in[i_];
        for (j_ = 0; j_ < 3; j_++){
            qa_out[i_] += elastMassMatrix[INDEX_2(i_, j_, nmodes+6)]*gravity[j_];
        }
    }
    
    /* == h_e == */
    
    Ke_m0 = mxGetPr(mxGetField(mxGetField(prhs[0], 0, "Ke"), 0, "m0"));
    De_m0 = mxGetPr(mxGetField(mxGetField(prhs[0], 0, "De"), 0, "m0"));
    
    if (((int) mxGetPr(mxGetField(mxGetField(prhs[0], 0, "Ke"), 0, "structure"))[0] == 1) && ((int) mxGetPr(mxGetField(mxGetField(prhs[0], 0, "De"), 0, "structure"))[0] == 1) ){
        for (i_ = 0; i_ < nmodes; i_++){
            qa_out[i_+6] += -y_elast[i_]*Ke_m0[INDEX_2(i_,i_,nmodes)] - Dy_elast[i_]*De_m0[INDEX_2(i_,i_,nmodes)];
        }
    } else {
        for (i_ = 0; i_ < nmodes; i_++){
            for (j_ = 0; j_ < nmodes; j_++){
                qa_out[i_+6] += -y_elast[j_]*Ke_m0[INDEX_2(i_,j_,nmodes)] - Dy_elast[j_]*De_m0[INDEX_2(i_,j_,nmodes)];
            }
        }
    }
    
    /* == h_omega == */
    
    /* h_omega_t */
    
    h_omega_t = (double *) calloc(3, sizeof(double));
    
    for (i_ = 0; i_ < 3; i_++){
        for (j_ = 0; j_ < nmodes; j_++){
            h_omega_t[i_] += 2.0*elastMassMatrix[INDEX_2(i_, 6+j_, nmodes+6)]*Dy_elast[j_];
        }
        for (j_ = 0; j_ < 3; j_++){
            h_omega_t[i_] += elastMassMatrix[INDEX_2(i_, 3+j_, nmodes+6)]*omega[j_];
        }
    }
    
    qa_out[0] += omega[2]*h_omega_t[1] - omega[1]*h_omega_t[2];
    qa_out[1] += omega[0]*h_omega_t[2] - omega[2]*h_omega_t[0];
    qa_out[2] += omega[1]*h_omega_t[0] - omega[0]*h_omega_t[1];
    
    free(h_omega_t);
    
    /* h_omega_r */
    
    h_omega_r = (double *) calloc(3, sizeof(double));
    
    for (i_ = 0; i_ < 3; i_++){
        for (j_ = 0; j_ < 3; j_++){
            h_omega_r[i_] += elastMassMatrix[INDEX_2(3+i_, 3+j_, nmodes+6)]*omega[j_];
        }
    }
    
    qa_out[3] += omega[2]*h_omega_r[1] - omega[1]*h_omega_r[2];
    qa_out[4] += omega[0]*h_omega_r[2] - omega[2]*h_omega_r[0];
    qa_out[5] += omega[1]*h_omega_r[0] - omega[0]*h_omega_r[1];
    
    Gr_m0 = mxGetPr(mxGetField(mxGetField(prhs[0], 0, "Gr"), 0, "m0"));
    
    for (k_ = 0; k_ < 3; k_++){
        for (i_ = 0; i_ < 3; i_++){
            for (j_ = 0; j_ < nmodes; j_++){
                qa_out[3+i_] += -Gr_m0[INDEX_2(i_, k_*nmodes + j_, 3)]*omega[k_]*Dy_elast[j_];
            }
        }
    }
    
    free(h_omega_r);
    
    /* h_omega_e */
    
    omega_q = (double *) calloc(6, sizeof(double));
    
    omega_q[0] = omega[0]*omega[0];
    omega_q[1] = omega[1]*omega[1];
    omega_q[2] = omega[2]*omega[2];
    omega_q[3] = omega[0]*omega[1];
    omega_q[4] = omega[1]*omega[2];
    omega_q[5] = omega[0]*omega[2];
    
    Ge_m0 = mxGetPr(mxGetField(mxGetField(prhs[0], 0, "Ge"), 0, "m0"));
    
    for (k_ = 0; k_ < 3; k_++){
        for (i_ = 0; i_ < nmodes; i_++){
            for (j_ = 0; j_ < nmodes; j_++){
                qa_out[6+i_] += -Ge_m0[INDEX_2(i_, k_*nmodes + j_, nmodes)]*omega[k_]*Dy_elast[j_];
            }
        }
    }
    
    Oe_m0 = mxGetPr(mxGetField(mxGetField(prhs[0], 0, "Oe"), 0, "m0"));
    
    if ((int) mxGetPr(mxGetField(mxGetField(prhs[0], 0, "Cr"), 0, "order"))[0] != 0){
    
        Oe_m1 = mxGetPr(mxGetField(mxGetField(prhs[0], 0, "Oe"), 0, "m1"));
    
        for (i_ = 0; i_ < nmodes; i_++){
            for (j_ = 0; j_ < 6; j_++){
                Oe_temp = Oe_m0[INDEX_2(i_, j_, nmodes)];
                for (k_ = 0; k_ < nmodes; k_++){
                    Oe_temp += Oe_m1[INDEX_3(i_, k_, j_, nmodes, nmodes)]*y_elast[k_]; 
                }
                qa_out[6+i_] += -Oe_temp*omega_q[j_];
            }
        }
    
    } else {
        
        for (i_ = 0; i_ < nmodes; i_++){
            for (j_ = 0; j_ < 6; j_++){
                qa_out[6+i_] += -Oe_m0[INDEX_2(i_, j_, nmodes)]*omega_q[j_];
            }
        }
        
    }
    
    free(omega_q);
    
}
