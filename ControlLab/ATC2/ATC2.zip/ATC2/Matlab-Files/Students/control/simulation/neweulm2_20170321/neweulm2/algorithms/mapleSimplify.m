% res = mapleSimplify(expr,varargin)
% 
%  Description:
% Simplify symbolic expressions using the symbolic toolbox.
% At the beginning the Symbolic Math Toolbox was using Maple. Then calling
% Maple directly offered more options and a higher performance then using
% the built in function 'simplify'. In newer Versions of this Toolbox MuPad
% is used for the symbolic calculations, currently requiring the built-in
% functions, see 4.). Please be careful with MuPad as it supports the two
% different (!!!) functions 'simplify' and 'Simplify'.
% 
%  Input values:
% expr ... Symbolic expression (Scalar, vector, matrix or cell array) of
%          data type symbolic or string.
% mode ... Optional. Mode of the simplify command. Maple and MuPad offer
%          some options, which shall not be all repeated here. However,
%          there is a pair of noteworthy options:
%             Maple: symbolic / Mupad: IgnoreAnalyticConstraints
%          These two options cause the symbolic engine to apply
%          simplifications ignoring the values of the symbolic parameters.
%          This results in the following to example equations:
%             alpha = asin(sin(alpha))
%             alpha = sqrt(alpha^2))
%          These options are especially handy in the function
%          rotmat2kardan, but may do more bad than good in other places.
%          To unify this option, it can be accessed by
%             mapleSimplify(expr,'crude');
%          Please have a look at the specific documentation of the symbolic
%          engine.
% 
%  Return values:
% res .... Simplified expression of data type symbolic.
% 
%  Explanation:
% In the first versions, the version of the 'Matlab Symbolic Toolbox' and
% the connected Maple Kernel made restrictions to the simplify command. It
% caused errors for non-symbolic expressions. Its computation time also was
% very high when handling vectors and matrices, which if called for each
% element seperately has shrunk to a fraction of its value.
% 
% In the currently used version however the simplify command is much faster
% if called for the complete matrix at once. To allow the adjustment to the
% used version, here the unused part is only commented, so it can still be
% used if necessary.
% 
% This function also exists, because Matlabs simplify command doesn't
% accept the definition of a mode (see above). Because this can be useful,
% this function acts as a connection.
% 
% Restrictions of the simplify command:
% The simplify command of Maple cannot treat addition theorems of
% trigonometric functions. For this the command
%   res = maple('map','combine',expr);
%   res = maple('map','combine',expr,'trig');
% is necessary. Here the command 'map' again is necessary to ensure, that
% for each expression the shortest way is found and not in total for all
% elements together. The lower one has shown to be faster in an example,
% but this may depend on the expressions as well. MuPads simplify
% recognizes these expressions.
%
%  See also: 
% mapleSubs
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
