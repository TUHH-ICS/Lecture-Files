% res = mapleSubs(expr,old,new)
% mapleSubs - Interface function to Maple or MuPad for the substitution of
% variables in symbolic expressions
%
% expr      symbolic expression (Scalar, Vector or Matrix)
% old       Variable to be replaced (several variables as a vector)
% new       Replacement variables for old (several variables as a vector)
%
% res       Result
% 
% This function has to distinguish between the two possible symbolic
% engines available: Maple and MuPad.
%
% Remark:
%
% The substitution is performed seperately for each element of 'expr' and 'old' or
% 'new' respectively . This shortens the computation time compared to the
% direct usage of matlab's own command 'subs'. Additional shorting is
% accomplished by using the maple interface, instead of matlab's routines.
%
% See also: mapleSimplify
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
