% mmi = createInertia(J)
% Convert between different formulations of vectors, matrices and tensors.
% One application is the description of inertia properties for elastic
% bodies.
% Case 1:
% Transform a 6x1 vector to a 3x3 tensor, e.g. the inertia tensor
% Case 2:
% Transform a 6xnq matrix (an agglomeration of several vectors of case 1)
% into a 3xnqx3 third order tensor
%
% See also: calcFlexForces, calcEqMotNonLin, elastMassMatrix
%
% First appearance: 18.05.2011 
%                   (As individual function, was a subfunction before)
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
