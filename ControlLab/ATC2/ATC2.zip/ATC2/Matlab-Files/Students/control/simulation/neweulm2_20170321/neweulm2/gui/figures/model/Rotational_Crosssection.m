% ROTATIONAL_CROSSSECTION M-file for Rotational_Crosssection.fig
%      ROTATIONAL_CROSSSECTION, by itself, creates a new
%      ROTATIONAL_CROSSSECTION or raises the existing singleton*.
%
%      H = ROTATIONAL_CROSSSECTION returns the handle to a new
%      ROTATIONAL_CROSSSECTION or the handle to the existing singleton*.
%
%      ROTATIONAL_CROSSSECTION('CALLBACK',hObject,eventData,handles,...)
%      calls the local function named CALLBACK in ROTATIONAL_CROSSSECTION.M
%      with the given input arguments.
%
%      ROTATIONAL_CROSSSECTION('Property','Value',...) creates a new
%      ROTATIONAL_CROSSSECTION or raises the existing singleton*.  Starting
%      from the left, property value pairs are applied to the GUI before
%      Rotational_Crosssection_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property
%      application stop.  All inputs are passed to
%      Rotational_Crosssection_OpeningFcn via varargin.
%
% Graphical user interface to edit rotational symmetric crosssections of
% graphic objects. When defining such an object, the user should enter the
% line which is the rotated around a given axis.
% 
% For more information, please open the corresponding window and click on
% the help button, labeled with a question mark "?".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
%
% First appearance: 01.03.2008
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
