% [C, c3, Dc_, D2c_] = constraintDynamics(frame1,frame2,dirdef,calcType_)
% Calculates the dynamic values for algebraic constraint equations due to
% kinematic loops.
%
% calcType_ = 0 --> translations and rotations
% calcType_ = 1 --> translations only
% calcType_ = 2 --> rotations only
%
% See also: calcCon, calcEqMotNonLin
%
% First appearance: 16.03.2012
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
