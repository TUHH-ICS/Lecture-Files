% writeForceVector(fid,vector,bodylist,name)
% Write all lines necessary for the evaluation of a given vector
