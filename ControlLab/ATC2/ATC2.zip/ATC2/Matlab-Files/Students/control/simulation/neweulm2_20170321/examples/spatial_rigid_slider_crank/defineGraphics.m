function defineGraphics
% DEFINEGRAPHICS - create graphic visualization of modeling elements

global sys;

%%%%%%%%%%%%%%%%%%%%%%%%
% Initialize animation %
%%%%%%%%%%%%%%%%%%%%%%%%

createAnimationWindow('drawcs',false);

view(120,20);

axis([-0.03 0.35 -0.02 0.2 -0.01 0.25]);

if ~isfield(sys.graphics,'surfaces')
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % add graphic elements if are not already defined %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    h = drawSphere([0,0,0], 0.01, 20, [0,0,0]);
    addGraphics('A',h);

    h = drawCube([0,0,0],0.01,0.01,sys.parameters.data.l_AB,'color',[0.5 0 0]);
    addGraphics('CR_cg',h);

    h = drawCube([0,0,0],sys.parameters.data.l_BC,0.01,0.01,'color',[0 0.5 0]);
    addGraphics('CO_cg',h);

    h = drawCube([0,0,0],0.05,0.02,0.02,'color',[0 0 0.5]);
    addGraphics('S_cg',h);
end

