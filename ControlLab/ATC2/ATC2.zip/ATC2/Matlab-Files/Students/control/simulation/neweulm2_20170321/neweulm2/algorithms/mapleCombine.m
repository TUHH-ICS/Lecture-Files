% res = mapleCombine(expr)
% 
% mapleCombine - Simplify trigonometric functions using the Maple/MuPad commands
% 'combine'. Expressions like 'sin(alpha)^2+cos(alpha)^2' are simplified to
% 1. This function is, especially for MuPad, faster than mapleSimplify.
% 
% Input values
% expr ... Symbolic expression (Scalar, vector, matrix or cell array) of
%          data type symbolic or string.
% 
% Return values
% res .... Simplified expression of data type symbolic.
%
% See also: mapleSubs, mapleSimplify
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
