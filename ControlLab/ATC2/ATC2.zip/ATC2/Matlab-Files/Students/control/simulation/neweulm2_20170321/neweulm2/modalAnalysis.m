% modalAnalysis(varargin) - Perform modal analysis of the linearized system.
% This function now can handle undamped and damped systems, arguments can
% be passed to select the mode.
% 
%  Syntax:
%> result = modalAnalysis('Property', value, ...);
% 
%  Description:
% The mass scaling of the matrix Phi containing the eigenvectors caused
% problems. For undamped systems and systems with proportional damping,
% this can easily be done by the user. But for general systems with
% damping, this is a difficult task. Therefore the matrix Phi containing
% the eigenvectors and the eigenvalues lambda are taken from the eig
% command. Then both are sorted by the eigenfrequencies. As the Phi matrix
% was obtained of the system matrix A, only the upper half for the position
% is kept, which is then normalized to length 1. One reason for using eig
% instead of polyeig is the better consistency whether real, complex or
% mixed eigenvectors are returned.
%
%  Input arguments, given pairwise:
% t ................ Simulation time
% verbose .......... Parameter to control the printouts of the function.
%                    0 denotes off, values range up to 1 {1}
% Optional input arguments, given pairwise
% CheckVarargin .... An advanced feature to avoid errors if invalid
%                    parameters are passed. This is only if you know
%                    exactly what you are doing. {true}
% Numeric .......... If available, the linearized equations of motion,
%                    which have been set up symbolically, are used.
%                    However, should they not be present, the numerical
%                    linearization is applied. With this parameter, the
%                    user can select, which ones to use. {false}
% SetValues ........ A vector of set values can be specified. This is only
%                    a reasonable option, if either a symbolic
%                    linearization was performed keeping symbolic set
%                    values, or if a numerical linearization shall be
%                    attempted. If nothing is given, all values are kept
%                    {[]}
% Symbolic ......... Opposite of Numeric. {true}
% StepsizeNum ...... When using a numerical linearization the stepsize has
%                    great influence on the results, making it necessary to
%                    be specified {1e-4}
% Time ............. Specify at which time the nonlinear equations of
%                    motion are supposed to be linearized. {0}
% 
%  Return values:
% result.t ......... Time at which the system matrices are evaluated
% result.ref ....... Reference configuration
% result.lambda .... Eigenvalues of damped system
% result.Phi ....... Corresponding Eigenvectors
% result.omega ..... Eigenfrequencies in [rad/s]
% result.f ......... Eigenfrequencies in [1/s]
% result.delta ..... Damping coefficient = -real(lambda_)
% result.D ......... Damping ratio = -real(lambda_) / abs(lambda_)
% result.lambda0 ... Eigenvalues of undamped system
% result.omega0 .... Eigenfrequencies of undamped system in [rad/s]
% result.f0 ........ Eigenfrequencies of undamped system in [1/s]
%
%  See also:
%   freqResPlot, freqResonse, calcEqMotLin, eqm_lin_ssinout,
%   modalAnalysis, animModeShape, showModeShape, polyeig
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
