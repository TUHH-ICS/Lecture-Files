#ifndef bvpsolMexh
#define bvpsolMexh

/* Optionsettings */
#define OPT_WARNMISS "OptWarnMiss"
#define OPT_WARNTYPE "OptWarnType"
#define OPT_WARNSIZE "OptWarnSize"

/* IOPT */
#define OPT_MAXITER "MaxIter"
#define OPT_CLASS "Classification"
#define OPT_SOLMETHOD "SolutionMethod"

/* TOL */
#define OPT_RELTOL "RelTol"

/* Rest */
#define OPT_FUNCCALLMETHOD "FuncCallMethod"

typedef void (*BVPRightSide) (int *n, double *t,
  double *y, double *dy);

typedef void (*BVPBoundaryCond) (double *ya, 
  double *yb, double *r);

typedef void (*BVPODESolver) (int *n,
  BVPRightSide f, double *t, double *y, double *tend,
  double *TOL, double *hmax, double *h, int *kflag);
  
#ifdef FORTRANNOUNDER
/* Fotran functions without underscore */
#ifdef FORTRANUPP
/* Fotran functions without underscore  & UPPERCASE letters */
#define BVPSOL_ BVPSOL
#define DIFEX1_ DIFEX1
#else
/* Fotran functions without underscore  & lowercase letters */
#define BVPSOL_ bvpsol
#define DIFEX1_ difex1
#endif
#else
/* Fortran functions with underscore */
#ifdef FORTRANUPP
/* Fortran functions with underscore & UPPERCASE letters */
#else
/* Fortran functions with underscore & lowercase letters */
#define BVPSOL_ bvpsol_
#define DIFEX1_ difex1_
#endif
#endif

extern void BVPSOL_ (BVPRightSide f,
  BVPBoundaryCond bc, BVPODESolver ivpsol,
  int *n, int *m, double *t, double *x, double *eps,
  int *iopt, int *info, int *irw, double *rw,
  int *iiw, int *iw);
  
extern void DIFEX1_ (int *n, BVPRightSide f,
  double *t, double *y, double *tend, 
  double *TOL, double *hmax, double *h, int *kflag);

struct ParameterGlobal
{ /* globale Variablen usw. */
  int funcCallMethod; /* Methode, um Matlab-Funktionen aufzurufen */
};
typedef struct ParameterGlobal SParameterGlobal;

struct ParameterOptions
{ /* Parameter f�r Options */
  const mxArray *opt;      /* Optionen */
  int optCreated;          /* Flag, ob Optionen selbst erzeugt */
};
typedef struct ParameterOptions SParameterOptions;

struct ParameterRightSide
{ /* Parameter f�r rechte Seite f */
  char *rightSideFcn;           /* Funktionsname f�r rechte Seite */
  const mxArray *rightSideFcnH; /* Funktionshandle oder inline-function f�r rightSide */
  mxArray *tArg;                /* Zum Aufruf von rightSideFcn: t */
  mxArray *xArg;                /* Zum Aufruf von rightSideFcn: x */
};
typedef struct ParameterRightSide SParameterRightSide;

struct ParameterBoundary
{ /* Parameter f�r Randbedingungen */
  char *boundaryFcn;            /* Funktionsname f�r Randbed. */
  const mxArray *boundaryFcnH;  /* Funktionshandle oder inline-function f�r boundary */
  mxArray *xaArg;               /* Zum Aufruf von boundaryFcn: xa */
  mxArray *xbArg;               /* Zum Aufruf von boundaryFcn: xb */
};
typedef struct ParameterBoundary SParameterBoundary;

struct ParameterODEsolver
{ /* Parameter f�r AWP-L�ser */
  char *odesolFcn;           /* Funktionsname f�r AWP-L�ser */
  const mxArray *odesolFcnH; /* Funktionshandle oder inline-function f�r ODE-Solver */
                             /* Zum Aufruf von odesolFcn: */
  mxArray *rightSideArg;     /* Name der rechten Seite als mxArray */
  mxArray *tArg;             /* Zeitvektor t */
  mxArray *xArg;             /* Startwert x */
  mxArray *optArg;           /* struct mit Optionen */
  double *optRelTol;         /* Hilfspointer f�r optArg */
  double *optAbsTol;         /* Hilfspointer f�r optArg */
  double *optInitialStep;    /* Hilfspointer f�r optArg */
  double *optMaxStep;        /* Hilfspointer f�r optArg */
};
typedef struct ParameterODEsolver SParameterODEsolver;

struct ParameterBVPSOL
{ /* Parameter f�r bvpsol */
  int nodenumber;          /* Anzahl der shooting nodes */
  double* shootingnodes;   /* Knoten f�r Mehrzielmethode */
  int d;                   /* Systemdimension: n in BVPSOL */
  double* xdata;           /* Daten bei shooting nodes */
  double EPS;              /* rel. Toleranz */
  int* IOPT;               /* Options-Array f�r BVPSOL */
  int NRW;                 /* Gr��e von RW */
  double* RW;              /* real workspace */
  int NIW;                 /* Gr��e von IW */
  int* IW;                 /* integer workspace */
  int INFO;                /* R�ckgabe f�r Status von BVPSOL */
};
typedef struct ParameterBVPSOL SParameterBVPSOL;

#endif

