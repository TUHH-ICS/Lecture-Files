% [X,f,results] = mnpso(fun,lb,ub,varargin)
%
% mnpso - Modified dynamic Neighborhood Particle Swarm Optimization, which
% is also the explanation of the acronym.
%
% This file is based on the work done by Jie Yang, described in
% DIPL-138: 'Calculation of Pareto-Fronts by Particle Swarm Optimization',
% ITM, University of Stuttgart, October 2009
%
% Input arguments, required
% fun ........... Cell array of function handles for the criterion
%                 functions, if only one is given, this is expected to
%                 return the vector of all function values for all
%                 particles
% lb ............ Vector of lower boundary values. The dimensions are being
%                 derived from the dimensions of the boundaries. Therefore,
%                 at least one set of boundary values is essential.
% ub ............ Vector of upper boundary values
% 
% If no input arguments are specified, a short example is called and its
% function call given.
% 
% Optional input arguments {Standard values}
% equalityconstraints ......Cell array of function handles for equality
%                           constraints, short: 'eqs', {}
% functionparameters ...... Parameters to be passed to the criterion
%                           functions, then these functions are expected to
%                           return two values: criterion values and possibly
%                           updated functionparameters {{}}
%                           E.g.: f = myfunc(f) or [f,pars]=myfunc(f,pars)
% improvementcontrol ...... Abort when no improvement is made anymore. As
%                           this option depends strongly on many problem
%                           specific values, a good setting can not be
%                           prescribed. If you want to use it, please have
%                           a look at the option 'minimalimprovement',
%                           which sets the threshold for this option
%                           {'none'}:
%     none ................ Off
%     absolute ............ Absolute improvement, specified as improvement
%                           per particle, short: 'abs'
%     relative ............ Relative to previous improvement value,
%                           short: 'rel'
% inequalityconstraints ... Cell array of function handles for inequality
%                           constraints, short: 'iqs', {}
% initialconditions ....... Initial positions, otherwise spread randomly,
%                           passed together with matrix of initial
%                           positions, e.g. of a previous run
%                           short: 'initcons', {}
% keepfigures ............. Keep figures of previous optimizations {false}
% maxiter ................. Maximal number of iterations, total number of
%                           all runs of inner loop {1000}
% maxiterloop ............. Calculate current penalty factors 
%                           every ..-th iteration of the inner loop when
%                           returning to the outer loop {200}
% minimalimprovement ...... Minimum improvement for option
%                           'improvementcontrol', short: 'minimprovement'
%                           {1e-6}
% neighborsize ............ Size of neighborhood, number of particles to be
%                           considered, short: 'neighbors','nneighbors' {8}
% nparticles .............. Number of particles in the optimization {200}
% optimizationparameters .. Weighting factors for the particle swarm
%                           optimization: (w, C1, C2, C3), 
%                           C3 is optional to spread the points
%                           short: 'optipars', {[0.6 1.4 1.6 0.1]}
% options ................. Options data structure, as returned in
%                           results.par. Only non-empty entries are
%                           respected {}
% parameterstruct ......... Complete parameter structure of a previous run
%                           is given, short: 'parstruct','param','par' {}
% penaltyfactor ........... Value for the penalty factors, either scalar
%                           for all or as a vector for each constraint,
%                           short: 'penalty' {1e4}
% penaltymax .............. Upper limit for the penalty factors, helps
%                           avoiding numerical problems {1e12}
% toleq ................... Tolerance for equality constraints: E_g {1e-4}
% tolineq ................. Tolerance for inequality constraints: E_h
%                           {1e-4}
% verbose ................. Select the verbose mode (values from 0 to 7)
%                           Effects usually stack, meaning when verbose=3
%                           you get the effects of 0<verbose<=3. {0}
%                           0 ...... nothing
%                           >= 1 ... text status information
%                           >= 2 ... plot of the final result, (X and f)
%                           >= 3 ... plot of the initial configuration
%                           >= 4 ... plot configuration every 10th
%                                    iteration, feature does not stack
%                           >= 5 ... plot in each iteration
%                           >= 6 ... store results in each step
%                           >= 7 ... plot to illustrate redistribution
% vmax .................... Maximal velocity, otherwise might grow imense
%                           by penalty factors {[]}
%%%% METHODS, here some different algorithms can be chosen:
% neighborhoodmethod ...... Use either the archive method ('archive') or
%                           the manipulative method ('manipulative') to
%                           obtain all pareto optimal solution
%       'archive' ......... As soon as a dominating solution is found it is
%                           entered in the archive
%       'manipulative' .... Compare the solutions elementwise
%                           {'archive'}
% defineneighborhood ...... Use either the distance method 
%                           ('distance'/'difference') or the area/product
%                           method ('area'/'product') to determine a
%                           neighborhood for each particle. This is used to
%                           calculate the current best solution of the
%                           swarm/neighborhood. {'distance'}
%       'distance' ........ Neighborhood is defined by all particles
%                           withing a distance, differences of values are
%                           calculated
%       'area' ............ Neighborhood is defined by all particles for
%                           which the product of differences is small
%                           enough resulting in something like areas.
% boundarycondition ....... Method to treat violating boundary conditions
%                           ('reflective'/'soft'/'intermediate')
%                           {'intermediate'}
%       'reflective' ...... The coordinate which would violate a boundary
%                           is reset to its previous value
%       'soft' ............ Set the coordinate which would violate a
%                           boundary to the min/max allowable value
%       'intermediate' .... A trespassing particle may move half the
%                           distance to the boundary
% redistribute ............ Improve found pareto optima by redistributing
%                           particles 'spread'/'fill'/'none'
%                           short: 'distributepareto' {'fill'}
%       'none' ............ Nothing is done, results are kept
%       'spread' .......... The particles are pushed apart, which is
%                           controlled by the parameter C3, see
%                           'optimizationparameters'
%       'fill' ............ Additional parameters are introduced to cover
%                           holes
%
% Output arguments
% X ............. Parameter combinations / particles in parameter space
%                 with size(X) = [nparticles, length(lb)]
% f ............. Corresponding function values of the criterion function,
%                 with size(f) = [nparticles, ndimensions]
% results ....... Structure containing results, initial configurations and
%                 all options.
%
% Example: mnpso;
% 
% Subfunctions contained in this file:
% 1.1) mnpsoStep
% 2.1) mnpsoEvaluateF
% 3.1) defineNeighborhood_area
% 3.2) defineNeighborhood_distance
% 4.1) bestInNeighborhood_archive
% 4.2) bestInNeighborhood_manipulative
% 5.1) stopButtonCallback
% 6.1) updatePenaltyfactors
% 7.1) evalboundary_reflective
% 7.2) evalboundary_soft
% 7.3) evalboundary_intermediate
% 8.1) smoothParetoLine_spread
% 8.2) smoothParetoLine_fill
% 9.1) mnpsoPlotOptiState
% 10.1) mnpsoIncludedExample
%
% See also: mnpso>mnpsoStep, mnpso>mnpsoEvaluateF,
% mnpso>defineNeighborhood_area, mnpso>defineNeighborhood_distance,
% mnpso>bestInNeighborhood_archive, mnpso>bestInNeighborhood_manipulative,
% mnpso>stopButtonCallback, mnpso>updatePenaltyfactors,
% mnpso>evalboundary_reflective, mnpso>evalboundary_soft,
% mnpso>evalboundary_intermediate, mnpso>smoothParetoLine_spread,
% mnpso>smoothParetoLine_fill, mnpso>mnpsoPlotOptiState,
% mnpso>mnpsoIncludedExample
%
% Written by: Thomas Kurz, First Appearance: 11.08.2010
%  Copyright (c) ITM University of Stuttgart, http://www.itm.uni-stuttgart.de
%
