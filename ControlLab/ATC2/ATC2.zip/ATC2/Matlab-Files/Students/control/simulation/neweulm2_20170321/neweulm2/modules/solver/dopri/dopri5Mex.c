/*
 * DOP853MEX-Interface by C. Ludwig
 * Version:  $Id: dopri5Mex.c 411 2007-10-15 13:35:18Z luchr $ */
#define DOPRI5MexVersion "15. Oct. 2007"
/*
 * English:
 *   Questions, requests, problems, notes, 
 *   remarks and bugs to
 *  Ludwig_C@gmx.de
 * 
 * German:
 *   Fragen, W�nsche, Probleme, Anregungen, 
 *   Anmerkungen, Bemerkungen und Bugs an
 *  Ludwig_C@gmx.de
 */
#include <math.h>
#include "mex.h"
#include "string.h"
#include "options.h"
#include "dopri5Mex.h"

#include "dopriMex.c"

