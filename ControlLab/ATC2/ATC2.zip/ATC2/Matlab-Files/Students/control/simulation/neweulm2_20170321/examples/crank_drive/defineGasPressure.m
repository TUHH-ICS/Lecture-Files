function res_ = defineGasPressure(epsilon_max,pmax)
% defineGasPressure - definition of state-depending user-defined gas
% pressure acting on the pistons of a four-stroke engine starting with the 
% top dead centre, and the combustion takes place short after the top 
% dead center

formulationWay = 'onepart';
p0 = 101325; 
kappa = 1.4;
p2 = p0 * epsilon_max^kappa-p0;

if strcmpi(formulationWay,'partwise')
    res_ = zeros(1,2000);

    % processSection: first stoke
    
    % 2 - 5
    % -----
    load('pCurve25.mat')
    cs_angle25 = 0:1/(length(pCurve25)-1):1;
    scaleStart = p2/pCurve25(1);

    [val id]=max(pCurve25);
    scaleMax=pmax/pCurve25(id);
    scaleEnd = p0/pCurve25(end);
    scale=[scaleStart:(scaleMax-scaleStart)/(id-1):scaleMax,scaleMax:(scaleEnd-scaleMax)/(length(pCurve25)-id):scaleEnd];
    for i_=1:length(pCurve25)
        p25(i_) = scale(i_)*pCurve25(i_);
    end
    clear scale
    res_(0:500) = interp1(cs_angle25,p25,0:1/500:1);

    % processSection: second stoke
    % 5 - 6
    % -----
    cs_angle56 = 0:1/(10-1):1;
    p56 = p0*ones(1,length(cs_angle56));
    res_(500:1000) = interp1(cs_angle56,p56,0:1/500:1);

    % 6 - 7
    % -----
    cs_angle61 = 0:1/(10-1):1;
    p61 = p0*ones(1,length(cs_angle56));
    res_(1000:1500) = interp1(cs_angle61,p61,0:1/500:1);
    
    % 1 - 2
    % -----
    load('pCurve12.mat')
    cs_angle12 = 0:1/(length(pCurve12)-1):1;
    scaleStart = p0/pCurve12(1);
    scaleEnd = p2/pCurve12(end);
    scale=scaleStart:(scaleEnd-scaleStart)/(length(pCurve12)-1):scaleEnd;
    for i_=1:length(pCurve12)
        p12(i_) = scale(i_)*pCurve12(i_);
    end
    clear scale
    res_(1500:2000) = interp1(cs_angle12,p12,0:1/(500-1):1);
else
    load('gasPressure.mat')
    scaleStart = p2/gasPressure(1);
    [val ix]=max(gasPressure);
    scaleMax= pmax/gasPressure(ix);
    scaleEnd = p2/gasPressure(end);
    scale(1:ix)=[scaleStart:(scaleMax-scaleStart)/(ix-1):scaleMax];
    scale(ix:length(gasPressure))=[scaleMax:(scaleEnd-scaleMax)/(length(gasPressure)-ix):scaleEnd];
    for i_=1:length(gasPressure)
        res_(i_)=scale(i_)*gasPressure(i_);
    end
end

