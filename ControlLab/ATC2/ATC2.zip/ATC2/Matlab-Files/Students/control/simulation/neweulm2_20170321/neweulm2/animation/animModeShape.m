% animModeShape - animate modes-th eigenmode
%
%  Optional parameters {default value}:
%
% Amplitude ......... Number to scale the Amplitude of mode shapes or array
%                     to scale each indivudal mode shape
% Animate ........... Start the animation after the evaluation of the state
%                     vectors. This option is useful when the actual
%                     animation shall be performed in another software
%                     {true}
% FramesPerPeriod ... Number of frames per period {40}
% Modeshape ......... Integer or integer array of mode numbers which mode
%                     shapes supposed to be animated {1}
% TimeDependence..... Is to be set true if the mode shape should be
%                     displayed over time {false}
% ModalSuperposition  Is to be set true is the mode modes shapes should be 
%                     superimposed {false}
% RecordAvi ......... With this option the animation will be stored as a
%                     .avi file. The desired filename should be passed as
%                     an argument. This option disables the calculation
%                     of an optimal step size as an optimal stepsize for
%                     the .avi file cannot be determined so easily
%                     {'myMovie.avi'}
% Result ............ Result of modal analysis {sys.results.modal}
% Repetitions ....... Number of repetitions {3}
% Stride ............ Real time factor. If a value smaller than 1 is
%                     passed, slow motion is produced, e.g. 0.5 is half
%                     the velocity. For all values larger than 1 the
%                     animation runs faster, while 1 results in the
%                     original velocity. This setting is stored in the
%                     data structure under sys.settings.graphics.{1/100}
% useFitCanvas ...... Use fitCanvas to adjust the visible area {true}
% CheckVarargin ..... An advanced feature to avoid errors if invalid
%                     parameters are passed. This is only if you know
%                     exactly what you are doing. {true}
% 
%  Return arguments:
% Case 1: One argument
% result.t_ ...... Time vector of this animation, chainsaw like. If only
%                     one return argument is specified, a data structure is given.
%       .y_ ...... Vector of generalized coordinates for this animation
% Case 2: Two arguments
% t_ ............. Time vector of this animation, chainsaw like. If only
%                     one return argument is specified, a data structure is given.
% y_ ............. Vector of generalized coordinates for this animation
%
%  Example:
%   animModeShape('Result',sys.results.modal,'Modeshape',2);
%   result = animModeShape('Result',sys.results.modal,'Modeshape',2,'Amplitude', 0.5);
%
%  See also: 
% freqResPlot, freqResonse, calcEqMotLin, eqm_lin_ssinout,
% modalAnalysis, showModeShape, animTimeInt, plotTrajectories
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
