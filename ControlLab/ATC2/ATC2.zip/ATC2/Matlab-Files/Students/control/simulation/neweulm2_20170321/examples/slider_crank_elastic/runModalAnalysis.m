%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                   %
%                         runModalAnalysis                          %
%                                                                   %
%    modal analysis and presentation of the natural/eigen modes     %
%                                                                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% modal analysis

fprintf(1,'running a modal analysis ...');
sys.results.modal = modalAnalysis(0);
fprintf(1,' ok!\n');


% presentation of the natural modes / Eigen modes

fprintf(1,'presenting eigen modes ...');

showModeShape(sys.results.modal,[1:sys.counters.genCoord], ...
    'Amplitude',0.5, ...
    'ShowRefPos','on', ...
    'RefPosTransparency',0.3)

fprintf(1,' ok!\n');
