% [psi, gradpsi] = optiCritTimeIntAdj(p_in)
% Calculates the criterion value and if necessary the gradient with the
% adjoint variable method. This is one step in the optimization process.
% This method requires an integration of the system equations of motion and
% an additional time integration in opposite time direction of the adjoint
% variable equations. This second integration uses the options at
% sys.settings.opt.spec.intOpts, whereas the system equations use those at
% sys.settings.timeInt.intOpts. It may be interesting to solve the system
% equations of motion with tighter tolerances to improve a smooth solution
% as basis for the evaluation of the adjoint variable equations.
%
% The criterion is of the form
% psi = G1(t1,y1,Dy1) + int _{t0} ^{t1} {F(t,y,Dy) dt}
% where the time t is in [t0,t1] and y1=y(t1), Dy1=Dy(t1). The functions G1
% and F may contain symbolic expressions or references to kinematic
% expressions of the multibody system.
%
% The adjoint variable method is a semi-analytical method. The adjoint
% variables are comparable to Lagrange multipliers to ensure correct
% values. The additional set of adjoint variable equations has 2*sys.counters.genCoord
% equations of first order. Therefore the interesting part is that the
% number of equations is independent of the number of design variables.
% 
% Incoming variables
% p_in ...... Vector of current design variables p. This function uses
%             scaled parameter values for the optimization in the range
%             [-1 <= p_ <= 1]. This may look strange but improves the
%             results, especially if the design variables are in a
%             different order of magnitude. The actual interval is given by
%             [sys.settings.opt.constr.lb, sys.settings.opt.constr.ub]
% Outgoing variables
% psi ....... Value of criterion function
% gradpsi ... Gradient of criterion function, only evaluated if nargout==2
%
% See also: newOpt, optiCritTimeIntDir, matricesGradientTimeInt,
%   OptiCalcInitCon, writeFinalCond, writeOptiAdjoint, writeOptiDirect,
%   writePsiTimeInt, optiCritTimeIntFinite
%
% First appearance: 01.12.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
