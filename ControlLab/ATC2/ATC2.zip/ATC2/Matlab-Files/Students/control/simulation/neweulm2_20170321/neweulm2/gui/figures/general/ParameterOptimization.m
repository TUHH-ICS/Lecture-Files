% PARAMETEROPTIMIZATION M-file for ParameterOptimization.fig
%      PARAMETEROPTIMIZATION, by itself, creates a new
%      PARAMETEROPTIMIZATION or raises the existing singleton*.
%
%      H = PARAMETEROPTIMIZATION returns the handle to a new
%      PARAMETEROPTIMIZATION or the handle to the existing singleton*.
%
%      PARAMETEROPTIMIZATION('CALLBACK',hObject,eventData,handles,...)
%      calls the local function named CALLBACK in PARAMETEROPTIMIZATION.M
%      with the given input arguments.
%
%      PARAMETEROPTIMIZATION('Property','Value',...) creates a new
%      PARAMETEROPTIMIZATION or raises the existing singleton*.  Starting
%      from the left, property value pairs are applied to the GUI before
%      ParameterOptimization_OpeningFunction gets called.  An unrecognized
%      property name or invalid value makes property application stop.  All
%      inputs are passed to ParameterOptimization_OpeningFcn via varargin.
%
% Graphical user interface to start a parameter optimization of the system.
% This function is an interface to the function newOpt. If you are
% working to change this GUI, please note the different panels in use to
% handle the different sets of options.
% 
% For more information, please open the corresponding window and click on
% the help button, labeled with a question mark "?".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
%
% First appearance: 15.05.2008
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
