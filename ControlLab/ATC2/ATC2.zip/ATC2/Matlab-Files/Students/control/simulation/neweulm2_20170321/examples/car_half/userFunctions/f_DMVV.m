function DMVV = f_DMVV(t,varargin)

DMVV = 0;
