% SaveSession(varargin) - Store complete Neweulm2 session to disk
% 
%  Syntax:
%> saveSession('mySystem_today');
%
%  Description:
% Saves the system structure and the created files to a specified folder
% and creates a routine for restoring the results afterwards. 
% 
%  Optional parameters:
% myName_ ........ String defining the name of the saved files
%                  {[sys.model.id,date]}
%
%  First appearance: 16.02.2012
%
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
