function startSysDef(funcMode_)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% startSysDef(funcMode_)                                             %
%                                                                    %
% Programm to build a multi-body-system-model                        %
% The model presented here is a model of a car in a planar motion.   %
% Therefore it is reasonable to model only half the car as seen from %
% the side. In this model, a prescribed motion is implemented, which %
% causes the car to ride over a speed bump, starting at t=0.         %
% The force elements use nonlinear stiffness and damping laws.       %
%                                                                    %
% The definition is in the file sysDef.m                             %
% After this file has run, the system is fully available in symbolic %
% form, the numerical values for constants have been set and an      %
% animation window with graphic representations has been created.    %
% Then you have several possibilities as to what you want to do with %
% this model:                                                        %
% - runTimeInt performs a time integration                           %
% - runModalAnalysis calculates Eigenmodes and displays them         %
%                                                                    %
% Of the files, which are called from here, the following are        %
% model specific. This means that you are kindly asked to adjust     %
% them to your need or copy them to start modelling a new system.    %
% - sysDef.m contains the system definition                          %
% - setUserVar.m assigns numerical values to constants. If called,   %
%   overwrites any values set in sysDef.m                            %
% - defineGraphics.m define graphic representations in the animation %
%   window                                                           %
%                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Input argument funcMode_:
% Select what shall be modeled/simulated:
% ==0 ... Model only the system
% >=1 ... Perform a time integration
% ==2 ... Linearize the system by replacing all constants by values
% >=3 ... Linearize the system in minimal form
% ==4 ... Modal analysis by function
% ==5 ... Manual modal analysis
% 
% Author:       Dipl.-Ing. Thomas Kurz
%
% e-Mail:       kurz@itm.uni-stuttgart.de
%
% Institute:    Universitaet Stuttgart
%               Institut fuer Technische und Numerische Mechanik
%               Pfaffenwaldring 9
%               70569 Stuttgart
%

%%%%%%%%%%%%%%%%%%%%%%%%
% Extend path variable %
%%%%%%%%%%%%%%%%%%%%%%%%

run('../addpathNeweulm2');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Preparations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Initialize workspace
clear global; 
close all;
global sys;

% Handle optional input arguments
if(nargin == 0)
    funcMode_ = 4; % Select what and how shall be calculated
end
useAnimation_ = true; % Flag whether to animate the motion
myStack_ = dbstack;
if(length(myStack_) > 1 && strcmp(myStack_(2).name,'n2CTest_car_half'))
    % Automatic test, no animation
    useAnimation_ = false;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% System defintion, setting up of equations
sysDef; 
calcEqMotNonLin;

% Evaluate all absolute velocities
names_ = fieldnames(sys.model.frame);
for h_ = 1: length(names_)
    getAbsoluteKinematics('v','ISYS',names_{h_});
end

writeMbsNonLin;
setUserVar;

if(useAnimation_)
    % Graphics
    createAnimationWindow;
    defineGraphics;
    updateGeo(0,zeros(sys.counters.genCoord,1));
    axis([-2.3 2.3 -2 2 0 1.6]);
    view(0, 0);
end

if(funcMode_ > 0)
    runTimeInt;
end

%% Linearization
if(funcMode_ == 2)
    % Replace parameters by numerical values, except interesting ones
    whiteList_ = {}; % {'cmhx','cmhz','cmvx','cmvz'};
    fprintf('\nReplacing symbolic expressions by numerical values ... ');
    sys.tmp.eqm = sys.dynamics.nonlinear.generic;
    sys.dynamics.nonlinear.generic = symStruct2num(sys.dynamics.nonlinear.generic, whiteList_);
    fprintf('ok!\n');

    % linearization around zeros
    calcEqMotLin;
    sys.dynamics.nonlinear.generic = sys.tmp.eqm;
    sys.tmp.eqm = []; % Reset data
    writeMbsLin;
elseif(funcMode_ > 2)
    % linearization around zeros
    sys.settings.equation.simplify = 2; % This runs only without too many simplifications
    calcEqMotLin('formulation','minimal');
    writeMbsLin;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Modal analysis
if(funcMode_ == 4)
    % calculate Eigenvalues and vectors
    sys.parameters.data.useLiftOff = false; % Avoid lift-off of tires
    modalAnalysis;
    % In the report, the absolute values of the eigenvectors have been
    % given for reference, scaled, so the maximal entry in each vector is 1
    Phi = abs(sys.results.modal.Phi(:,1:2:end));
    for h_=1:8;
        Phi(:,h_)=Phi(:,h_)/max(Phi(:,h_));
    end
elseif(funcMode_ == 5)
    sys.parameters.data.useLiftOff = false; % Avoid lift-off of tires
    % Manual eigenvalue analysis
    M_ = eqm_lin_M(0);
    P_ = eqm_lin_P(0);
    Q_ = eqm_lin_Q(0);

    [X_,lambda_] = polyeig(Q_,P_,M_);
    delta_ = abs(real(lambda_(1:2:end)));
    omega_ = imag(lambda_(1:2:end));
    X_ = X_(:, 1:2:end);
    f_ = omega_.'/(2*pi);

    Xabs = abs(X_);
    D_ = zeros(1,8);
    for h_ = 1:8
        % Rescale the eigenvectors, so the largest value is 1
        Xabs(:,h_) = Xabs(:,h_) / max(Xabs(:,h_));
        D_(h_) = delta_(h_) / sqrt(omega_(h_)^2 + delta_(h_)^2);
        % is equal to
        % D_(h_) = abs(real(lambda_(2*h_))) / abs(lambda_(2*h_));
    end

    sys.results.modal.X = X_;
    sys.results.modal.lambda = lambda_;
    sys.results.modal.f = f_;
    sys.results.modal.D = D_;
end

fprintf(1,'\nSaving System ...');
save 'sys.mat' sys;
fprintf(1,' ok!\n');

fprintf('\n\nFinished\n');
% END OF FILE
