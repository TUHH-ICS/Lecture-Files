% sysDef
% System definition Trolley
% 

% Create basic data structure
newSys('Id','Trolley', 'Name','Trolley');

% Parameters
newConstant('L1',3)
newConstant('m1',5)
newConstant('h1',3)
newConstant('L2',2)
newConstant('m2',2)
newConstant('F0',1)
newConstant('omega',2)
newTimeDependent('F','F0*sin(omega*t)')
newConstant('k',0.1)
newConstant('d',0.1)

newGenCoord('y1','alpha2');

% Trolley
newBody('Id','Body1','Name','Trolley', ...
    'RelPos','[0;y1;0]', ...
    'CgPos','[0;L1;0]', ...
    'Mass','m2','Inertia',zeros(3));

newFrame('Id','support',  'RefSys','Body1', 'RelPos','[0;2*L1;0]');
newFrame('Id','support2', 'RefSys','Body1', 'RelPos','[0;L1;h1]');

newBody('Id','Body2','Name','Pendulum', ...
    'RefSys','support2', ...
    'RelPos','[0;0;0]', 'RelRot','[alpha2;0;0]', ...
    'CgPos','[0;0;-L2]', ...
    'Mass','m2','Inertia',zeros(3));

newForceElem('Id','springDamper','Name','Spring-Damper-combination', ...
    'frame1','support','frame2','Body2_cg','Type','SpringDampPtp', ...
    'Stiffness','k','Damping','d');
newForceElem('Id','appliedForce','Name','Applied Force F', ...
    'frame1','Body1','frame2','ISYS','Type','General', ...
    'ForceLaw','[0;F;0;0;0;0]');

%% System in-/out
newInput('Id','appliedForce','Var','F');

newOutput('Id','appliedForce','Var','F','group','control');
newOutput('Id','Body1_y','Var','Body1.r(2)','group','kinematic');
newOutput('Id','Body2_y','Var','Body2.r(2)','group','kinematic');
newOutput('Id','genCoord_y1','Var','y1','group','genCoords');
newOutput('Id','genCoord_alpha2','Var','alpha2','group','genCoords');

% END OF sysDef
 