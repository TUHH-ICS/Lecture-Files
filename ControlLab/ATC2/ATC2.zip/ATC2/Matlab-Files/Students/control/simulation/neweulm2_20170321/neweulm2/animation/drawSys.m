% drawSys - Create graphic objects for the visualization of the system
%
%  Description:
% Deletes existing representations of coordinate systems and replaces them
% by new ones by calling framePlot
%
%  Input arguments:
% framelist ... list of coordinate systems for which representations are
%               created {fieldnames(sys.model.frame)}
% 
%  See also:
% initGraphics, framePlot, createAnimationWindow
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
