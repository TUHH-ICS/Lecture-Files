% varargout = EditBody(varargin)
% EditBody M-file for EditBody.fig
%      EditBody, by itself, creates a new EditBody or raises the existing
%      singleton*.
%
%      H = EditBody returns the handle to a new EditBody or the handle to
%      the existing singleton*.
%
%      EditBody('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in EditBody.M with the given input arguments.
%
%      EditBody('Property','Value',...) creates a new EditBody or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before EditBody_OpeningFunction gets called.  An
%      unrecognized property text_name or invalid value makes property application
%      stop.  All inputs are passed to EditBody_OpeningFcn via varargin.
%
% Graphical user interface to define or edit bodies. The type of a body can
% only be selected at its initial definition. This usually doesn't create
% any problems, as the different types have very few things in common
% anyway.
% 
% For more information, please open the corresponding window and click on
% the help button, labeled with a question mark "?".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
%
% First appearance: 01.07.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
