% [sxint, resStruct] = deval_wrap(sol,xint,varargin)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Wrapper function for the deval command to interpolate between calculated
% data points from an integration.
% This wrapper function allows to use it not only for solutions of the
% ode-solver family, but also for other solvers. If the data structure
% contains additional result fields, they are interpolated as well.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Author:       Thomas Kurz
%
% e-Mail:       kurz@itm.uni-stuttgart.de
%
% Institute:    Universitaet Stuttgart
%               Institut fuer Technische und Numerische Mechanik
%               Pfaffenwaldring 9
%               70597 Stuttgart
%
% Incoming parameters
% sol ......... Structure returned by the solver
% xint ........ Is a point or vector of points at which you want the
%               solution
% varargin .... Optional parameters, explained below
% 
% Optional parameters, given pairwise {standard values}
% AllFields ... Logical if all fields shall be interpolated, otherwise only
%               'y' is interpolated {true}
% Fields ...... Cell array of field names which shall be interpolated {'y'}
% StructOnly .. Logical whether only the data structure shall be returned.
%               Usually, this is the second return value {false}
%
% Return parameters
% sxint ....... Solutions calculated. If nothing is specified, the
%               interpolated y-vector. If a certain field was specified,
%               return its interpolated values
% resStruct ... If the data structure contains more fields with the same
%               number of columns, this function can interpolate them as
%               well. resStruct has a structure similar to sol, with the
%               time x, all interpolated fields and the current filename as
%               solver.
%
% First appearance: 01.08.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
