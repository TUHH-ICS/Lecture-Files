% varargout = neweulm2(varargin)
% neweulm2 M-file for neweulm2.fig
%      neweulm2, by itself, creates a new neweulm2 or raises the existing
%      singleton*.
%
%      H = neweulm2 returns the handle to a new neweulm2 or the handle to
%      the existing singleton*.
%
%      neweulm2('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in neweulm2.M with the given input arguments.
%
%      neweulm2('Property','Value',...) creates a new neweulm2 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before neweulm2_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to neweulm2_OpeningFcn via varargin.
%
% Main menu of the graphical user interface of neweulm2. From this all
% functions of the GUI can be called.
% 
% For more information, please open the corresponding window and click on
% the help button, labeled with a question mark "?".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
%
% First appearance: 01.07.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
