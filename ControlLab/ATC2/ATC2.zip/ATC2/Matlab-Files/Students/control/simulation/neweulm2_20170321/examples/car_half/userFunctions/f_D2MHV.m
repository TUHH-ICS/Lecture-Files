function D2MHV = f_D2MHV(t,varargin)

D2MHV = 0;
