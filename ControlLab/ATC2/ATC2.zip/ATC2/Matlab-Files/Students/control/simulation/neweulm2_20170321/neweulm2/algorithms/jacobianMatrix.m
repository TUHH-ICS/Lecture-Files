% jacobianMatrix - Jacobian Matrix of a symbolic vector
%
% vec       symbolic Vector
% vars      Parameters with respect to which to differentiate
%
% res       Result
%
% Optional parameters, given pairwise
%
% isTensor..............Logical: true/{false}
%                       If the output is supposed to be a third order tensor, set
%                       true, otherwise {false}.
% Substitute............Numerical/Symbolic: Array with size of vars
%                       If the substitution of the given result should be done in
%                       here, pass a vector containing the set values. If there is 
%                       no flag passed, the substitution will not be done
% AdditionalVars........Symbolic:
%                       Array containing additional variables that get
%                       substituted with 'AdditionalSetPoints'.
% AdditionalSetPoints...Numerical/Symbolic: Array with size of AdditionalVars
%                       Matched setpoints to 'AdditionalVars'
%
% Two cases:
% res(g,k) = diff(vec(g), vars(k))
% res(g,h,k) = diff(vec(g,h), vars(k))
%
% Anotation:
% To differentiate elementwise is much faster than using the jacobian
% command of the Matlab Symbolic Toolbox
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
