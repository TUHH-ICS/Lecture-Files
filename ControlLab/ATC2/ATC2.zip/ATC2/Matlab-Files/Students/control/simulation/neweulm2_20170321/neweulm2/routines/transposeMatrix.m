% transposedMatrix = transposeMatrix(matrix)
% transposeMatrix - In case of vectorial abbreviations, calling Matlab's 
% transpose function yields unexpected results. Therefore, this function 
% should be used to transpose matrices.
%
% matrix ............... Matrix that is supposed be transposed
%
% transposedMatrix ..... Transposed matrix
%
% See also: mapleSubs
%
% First appearance: 18.12.2013
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
