#ifndef NEWEULSIMULATION_H
#define NEWEULSIMULATION_H

#include <hdf5.h>
#include <string.h>
#include <stdlib.h>
#include <fstream>

class neweulSimulation
{
public:
    neweulSimulation(const char *fileName);
	~neweulSimulation();
	double* timeVec;
    double* genCoords;
	double stepSize;
	int numOfSamples;
    int numGenCoords;
	int counter;

};

#endif // NEWEULSIMULATION_H

