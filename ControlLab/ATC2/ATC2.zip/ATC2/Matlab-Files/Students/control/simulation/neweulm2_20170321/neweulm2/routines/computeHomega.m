% h_omega = computeHomega(body,omega,y_elast,Dy_elast)
% Compute the forces collected in the vector h_omega, which result e.g.
% from a frame of reference of an elastic body which is not located in the
% center of gravity.
% 
% Input arguments:
% body ....... ID of the body under consideration
% omega ...... Vector of the angular velocity of the frame of reference
% y_elast .... Symbolic vector of the elastic degrees of freedom of this
%              body
% Dy_elast ... Symbolic vector of the derivatives wrt. time of the elastic
%              degrees of freedom of this body
% 
% Return arguments:
% h_omega .... Force vector
%
% See also: calcFlexForces, calcEqMotNonLin, elastMassMatrix
% 
% First appearance: 18.05.2011 
%                   (As individual function, was a subfunction before)
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
