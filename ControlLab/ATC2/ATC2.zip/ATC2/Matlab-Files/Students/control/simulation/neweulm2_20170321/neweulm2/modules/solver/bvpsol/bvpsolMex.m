% English:
% ========
% BVPSOLMEX: Interface for BVPSOL
% [x,stats] = bvpsolMex(f,bc,odesol,snodes,start,opt,ODEopt)
%
% Input:
%   f       right side: either the name of a function or a 
%           function handle or an inline function; must be declared as 
%             function dx=f(t,x)
%               t : current time (Scalar)
%               x : current position ( (d,1) double vector)
%               dx: (d,1) double-Vektor
%   bc      boundary conditions: either the name of a function or a
%           function handle or in inline function; must be declared as
%             function r = Boundary (xa,xb) 
%               xa: boundary value at start position ( (d,1) double-Vektor)
%               xb: boundary value at end position ( (d,1) double-Vektor)
%               r : residual
%   odesol  ODE solver:
%           if empty, i.e. [], the built-in ODE solver (difex1) is used;
%           otherwise: the name of a function or a function handle (or
%           an inline function) to be used as solver; must be declared as 
%             function [tG,xG,stats,taupred] = odesol (f,t,x,opt)
%               f       : right side
%               t       : (1,2) double vector with start- and end-value 
%               x       : position at start( (d,1) double vector)
%               opt     : struct with ODEopt (cf. ODEopt and details)
%               tG      : evaluated t nodes (is ignored)
%               xG      : solution at nodes in tG (only the last ROW will be
%                         used)
%               stats   : statistics; if stats(1)<0 Error and interruption
%               taupred : next predicted step size
%           Remark: That's the way Dopri, Radau, Odex, ... are called.
%                   Hence they can be used immediately here.
%   snodes  row vector with shooting nodes (needs at least to components)
%   start   start values ( (d,length(snodes)) double matrix) 
%   opt     optional struct with options: see below
%   ODEopt  optional struct with options for the ODE solver
%             is only allowed (and usefull) if odesol is not empty and
%             an external solver is used. Then this options
%             will be passed (cf. details).
% 
% Output:
%   x       soltions at snodes ( (d,length(snodes)) double matrix)
%   stats   >0: Number of iterations
%           <0: Error with
%              -1 : if SolutionMethod=0: Iteration stops at stationary point
%                   if SolutionMethod=1: Gaussian elimination failed due to
%                   singular Jacobian
%              -2 : iteration stops after MaxIter
%              -3 : ODE solver failed to complete the trajectory computation
%              -4 : Gauss Newton method failed to converge
%              -5 : given initial values inconsistent with separable linear
%                   boundary conditions
%              -6 : if SolutionMethod=0: iterative refinement faild to converge
%                   if SolutionMethod=1: termination since multiple shooting
%                   condition of Jacobian is too bad
%              -7 : RelTol bigger than 1e-2
%              -8 : condensing algorithm for linear block system fails, use
%                   global linear solver, i.e. change SoltionMethod 
%              -9 : Sparse linear solver failed, possible workspace is too small
%             -10 : Real or integer work-space exhausted
%             -11 : rank reduction failed; resulting rank is zero
%
% Options:
% (in round braces: defaults)
% [in square brackets: parameter name in BVPSOL]
%
% If a option is needed and not found in the opt struct (or even
% the opt struct is missing), then the default-value in braces
% are used.
%
%  * RelTol (1e-6) [EPS]
%      required relative precision of solution
%  * MaxIter (30) [IOPT(1)]
%      maximum permitted number of iteration steps
%  * Classification (2) [IOPT(2)]
%      Boundary value problem
%       0 : linear boundary value problem
%       1 : nonlinear boundary value problem; goot initial data available
%       2 : highly nonlinear boundary value problem; only bad initial data
%           available; small initial damping factor in Gauss Newton method
%       3 : highly nonlinear boundary value problem; only bad initial data
%           available; small initial damping factor in Gauss Newton method;
%           additionally initial rank reduction to separable linear boundary
%           conditions
%  * SolutionMethod (0) [IOPT(3)]
%        0 : local linear solver with condensing algorithm
%        1 : use global sparse linear solver
%
% --- Below are the options for the MEX-File; they do not belong to Radau
%
%  * FuncCallMethod (1)
%      option to indicate, which method to use for calling external functions 
%      (like the right side or the boundary conditions)
%        0 call maxCALLMATLAB direct
%          then ONLY names (strings) can be passed for functions
%        1 use maxCALLMATLAB to call feval
%          then ALSO function handles and inline-functions can be used
%  * OptWarnMiss (0)
%      Flag to warn if option is missing 
%        1 Warn if needed option in opt-struct is missing
%        0 don't warn
%  * OptWarnType (1)
%      Flag to warn if wrong type is found in options 
%        1 warn if a entry with wrong type is found in opt struct
%        0 don't warn
%  * OptWarnSize (1)
%      Flag to warn if option value has wrong size 
%        1 warn if a option value has wrong size 
%        0 don't warn
%
% The opt struct can be generated with odeset, although there are
% some additional entries and some other entries are missing. With
% odeset ONLY the following parameters can be set:
%   RelTol
%
% Details on ODEopt:
%  The built-in ODE solver doesn't support any options. The
%  7th input argument must be empty (or missing).
%  If an external solver is used, then the interface does
%  the following steps: the passed options are (deeply) copied.
%  If the 7th argument was empty or missing a struct is created.
%  The fields RelTol, AbsTol, InitialStep and MaxStep are 
%  added if they aren't already there. Before calling the external
%  ODE solver the values (required by BVPSOL) are written in the
%  RelTol, AbsTol, InitialStep and MexStep fields.
%  
%  IMPORTANT NOTICE (if "f", "bc" or "odesol" are also MEX files)
%     these MEX files must not "garble" the passed mxArrays:
%     the size must not be changed and the memory must not
%     be freed. 
%     Hence: the MEX files have to take care, that the
%     passed mxArrays have the same size and enough memory
%     when returning. The values in the memory(-block)
%     may be overwritten.
%     If  "f", "bc" or "odesol" are m-files MATLAB obeys this
%     restriction automatically.
%
%
%
%
% German:
% =======
% BVPSOLMEX: Interface zu BVPSOL
% [x,stats] = bvpsolMex(f,bc,odesol,snodes,start,opt,ODEopt)
%
% Input:
%   f       Funktionsname oder function handle oder inline function
%           f� rechte Seite mit folgender Form
%             function dx=f(t,x)
%               t : aktueller Zeitpunkt (Skalar)
%               x : aktuelle Position ( (d,1) double-Vektor)
%               dx: Ableitung an (t,x) ( (d,1) double-Vektor)
%   bc      Funktionsname oder function handle oder inline function 
%           f� Randbedingungen (Boundary conditions)
%           mit der Form
%             function r = Boundary (xa,xb) 
%               xa: Wert an der Startposition ( (d,1) double-Vektor)
%               xb: Wert an der Zielposition ( (d,1) double-Vektor)
%               r : Residuum 
%   odesol  entweder leer, also [], dann wird der built-in
%           AWP-L�er (difex1) verwendet oder
%           Funktionsname oder function handle (oder inline function)
%             f� eigenen AWP-L�er der Form
%             function [tG,xG,stats,taupred] = odesol (f,t,x,opt)
%               f       : rechte Seite
%               t       : (1,2) double-Vektor mit Start- und Endzeitpunkt
%               x       : Position zum Startzeitpunkt ( (d,1) double-Vektor)
%               opt     : struct mit ODEopt (vgl. ODEopt und Details)
%               tG      : verwendete Zeitgitter (wird ignoriert)
%               xG      : Positionen an Zeitpunkten tG (nur letzte ZEILE wird 
%                         verwendet, also der Zustand zum Endzeitpunkt)
%               stats   : Statistik-Vektor; bei stats(1)<0 Fehler und Abbruch
%               taupred : neuer Schrittweitenvorschlag
%           Anmerkung: Dies ist die Standardaufrufform von Dopri, Radau, ...
%                      Sie k�nen deshalb direkt angegeben werden.
%   snodes  Zeilenvektor mit St�zstellen (shooting nodes), muss mindestens 
%           2 Werte (Start- und Endwert) enthalten.
%   start   Startwerte ( (d,length(snodes)) double-Matrix) 
%   opt     optionale struct mit Optionen: vgl. Beschreibung unten
%   ODEopt  optionale struct mit Optionen f� den AWP-L�er
%             ist nur sinnvoll, wenn odesol nicht leer ist, also ein
%             externer AWP-L�er verwendet wird. Dann werden diese
%             Optionen zus�zlich �ergeben. (Details unten)
% 
% Output:
%   x       Ergebnisse an snodes ( (d,length(snodes)) double-Matrix)
%   stats   >0: Anzahl der Iterationen
%           <0: Fehler mit
%              -1 : f� SolutionMethod=0: Iteration an station�em Punkt abgebrochen
%                   f� SolutionMethod=1: Gauss'sche Elimination wegen sing. 
%                   Jacobi-Matrix fehlgeschlagen
%              -2 : max. Anzahl der Iterationen erreicht
%              -3 : AWP-L�er hat tEnd nicht erreicht
%              -4 : Gauss-Newton konvergiert nicht
%              -5 : Startwerte inkonsistent mit separierbaren lin. Randbed.
%              -6 : f� SolutionMethod=0: Iterative Verfeinerung nicht konvergent
%                   f� SolutionMethod=1: Abbruch, da Mehrzielbedingung an
%                   die Jacobi-Matrix zu schlecht ist
%              -7 : RelTol gr�er als 1e-2
%              -8 : Condensing-Algorithmus f� Block-System klappt nicht,
%                   andere SolutionMethod probieren!
%              -9 : Sparse L�er fehlschlagen, vielleicht zu wenig Workspace
%             -10 : reeler oder integer Workspace zu klein
%             -11 : Rangreduktion fehlgeschlagen; Rang 0 erhalten
%
% Optionen:
% (in runden Klammern: defaults)
% [in eckigen Klammern: entsprechender Name bei BVPSOL]
%
% Falls eine Option ben�igt wird und nicht in der opt-struct vorhanden ist 
% (oder die opt-struct selbst fehlt), so wird der in Klammern angegebene
% default-Wert verwendet.
%
%  * RelTol (1e-6) [EPS]
%      relative Toleranz 
%  * MaxIter (30) [IOPT(1)]
%      maximale Anzahl der Iterationen
%  * Classification (2) [IOPT(2)]
%      Problemtyp:
%       0 : lineares Randwertproblem
%       1 : nichtlin. Randwertproblem mit guten Anfangsdaten
%       2 : h�hst nichtlin. Randwertproblem mit schlechten
%           Anfangsdaten; kleine anf�gliche Gauss-Newton D�pfung
%       3 : h�hst nichtlin. Randwertproblem mit schlechten
%           Anfangsdaten; kleine anf�gliche Gauss-Newton D�pfung
%           Rangreduktion; separierbare lineare Randbedingungen
%  * SolutionMethod (0) [IOPT(3)]
%      L�ungsmethode
%        0 : lokaler L�er mit condensing
%        1 : globaler sparse L�er
%
% --- Ab jetzt kommen Optionen, die zum MEX-File geh�en,
% --- nicht mehr zu DOPRI.
%
%  * FuncCallMethod (1)
%      gibt an, welche Methode zum Aufruf "externer" Funktionen (z.B.
%      rechte Seite oder Output-Funktion) verwendet werden soll:
%        0 direkt mexCallMATLAB verwenden 
%          dann k�nen NUR Funktionsnamen �ergeben werden
%        1 feval mit mexCALLMATLAB verwenden
%          dann k�nen AUCH Funktions-Handle und Inline-Funktionen
%          �ergeben werden.
%  * OptWarnMiss (1)
%      Warnungsflag bei fehlenden Optionen
%        1 Warnung, wenn in opt-struct eine ben�igte Option fehlt
%        0 keine Warnung
%  * OptWarnType (1)
%      Warnungsflag bei Optionen mit falschem Typ
%        1 Warnung, wenn in opt-struct ein Eintrag den falschen Datentyp hat
%        0 keine Warnung
%  * OptWarnSize (1)
%      Warnungsflag bei Optionen mit falscher Gr�e
%        1 Warnung, wenn in opt-struct ein Eintrag die falsche Gr�e hat
%        0 keine Warnung
%
% opt kann auch mit odeset generiert werden, obwohl dort dann  mehr 
% Felder generiert werden, als ben�igt und die meisten Optionen von hier 
% nicht unterst�zt werden. Also kann man mit odeset NUR einstellen:
%   RelTol
%
% Details zu ODEopt:
%  Der built-in AWP-L�er unterst�zt keine Optionen. Hier darf
%  das 7. Eingabeargument nicht angegeben werden (bzw. muss leer sein).
%  Bei externen AWP-L�ern ist das Verfahren so. Die 
%  �ergebenen Optionen werden kopiert. Die Felder RelTol, AbsTol,
%  InitialStep und MaxStep werden hinzugef�t, falls sie noch nicht
%  vorhanden waren. Beim Aufruf des AWP-L�ers werden die von BVPSOL
%  gew�schten Werte bei den kopierten Optionen in RelTol, AbsTol,
%  InitialStep und MaxStep eingetragen und dann die kopierten Optionen
%  �ergeben. 
%  Falls das 7. Eingabeargument fehlt und ein externer L�er verwendet
%  wird, wird intern eine struct nur mit den Feldern RelTol, AbsTol,
%  InitialStep und MaxStep angelegt und diese dann verwendet.
%
%  WICHTIGE Anmerkung (falls "f","bc" oder "odesol" auch MEX-Files sind)
%     diese MEX-Files d�fen die �ergebenen mxArrays nicht "verst�meln": 
%     die Gr�e darf nicht ver�dert werden und auch der Speicherplatz 
%     darf nicht freigegeben werden. Also: es muss  sichergestellet sein, 
%     dass die �ergebenen mxArrays am Ende wieder diesselbe Gr�e und 
%     ausreichend Speicher haben. Der Speicher selbst darf nat�lich zu 
%     rechenzwecken �erschrieben werden.
%     Bei m-Files muss man darauf keine R�ksicht nehmen, denn da achtet 
%     MATLAB automatisch darauf.
