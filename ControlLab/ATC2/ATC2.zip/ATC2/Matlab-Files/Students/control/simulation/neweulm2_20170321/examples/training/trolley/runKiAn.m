function runKiAn
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                   %
%                             runKian                               %
%                                                                   %
%                   Do a kinematic analysis                         %
%                                                                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global sys

% functions for generalized coordinates
setfun('y1','0.5*sin(1/10*pi*t)','alpha2','0.5*cos(1/10*pi*t)');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initial values
% When initial conditions are specified, a constant is added to the
% functions specified above. Then the value at the initial configuration is
% equal to the initial condition and after that is changed according to the
% functions above. In the case of kinematic loops, consistent initial
% conditions are ensured. If exactly the functions above are to be used,
% set the initial conditions to be empty.
%
% No initial conditions
y0 = [];
% Zeros
% y0 = zeros(sys.counters.genCoord,1);
% Use the values from runTimeInt
% y0 = sys.settings.timeInt.y0;
% Use different values
% y0(1) = 0;
% y0(2) = 0.01;
% y0(3) = 0.001;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Time interval
% Use the values from runTimeInt
% t0 = sys.settings.timeInt.time(1); % Start time t0
% t1 = sys.settings.timeInt.time(end); % End time t1
% Use different values
t0 = 0;
t1 = 10;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% stepsize for the time
stepsize = 0.1;

% evaluating the equations
sys.results.kinematic = kinematicAnalysis('y0',y0,'stepsize',stepsize,'t0',t0,'tend',t1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Updating the plot of trajectories
plotTrajectories('','Result',sys.results.kinematic);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% animating kinematik analysis
animTimeInt(sys.results.kinematic,'Stride',0.8);

