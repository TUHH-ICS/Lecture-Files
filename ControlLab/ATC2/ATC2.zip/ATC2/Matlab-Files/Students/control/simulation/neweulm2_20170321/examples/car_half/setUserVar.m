% Set numerical values for all parameters for the half-car-model
%

%     General data (1...10)
sys.parameters.data.g      =      9.81;  % = vdat( 1)  % Gravitational constant [m/s^2]
% Vehicle velocity vf, this value is only used for the animation. The
% actual excitation is implemented using hard-coded values. It can be
% controlled using the obstacle height z
sys.parameters.data.vf     = 60/3.6;     % = vdat( 2)  % Vehicle speed [m/s] = 60 km/h
% sys.parameters.data.bmph   =      0.2;   % = vdat( 3)  % Amplitude obstacle
% sys.parameters.data.bmps   =      2;     % = vdat( 4)  % Start of obstacle
% sys.parameters.data.bmpl   =     10;     % = vdat( 5)  % Length of obstacle
% sys.parameters.data.psdrd  =      0;     % = vdat( 6)  % Spectral density of road [m^3]
% sys.parameters.data.dtsmth =      0;     % = vdat( 7)  % Window width of smoothing function[s]
% sys.parameters.data.tendrd =      0;     % = vdat( 8)  % Time of reducing the excitation [s]
%
%     Mass geometry (11...20)
sys.parameters.data.mcar   =   1150;     % = vdat(11)  % Mass of the car chassis [kg]
sys.parameters.data.icar   =   1500;     % = vdat(12)  % Inertia of chassis [kgm^2]
sys.parameters.data.mfa    =     90;     % = vdat(13)  % Mass front axle [kg]
sys.parameters.data.mra    =     80;     % = vdat(14)  % Mass rear axle [kg]
sys.parameters.data.ira    =      1.5;   % = vdat(15)  % Inertia of rear axle [kgm^2]
sys.parameters.data.md     =     60;     % = vdat(16)  % Mass driver [kg]
sys.parameters.data.me     =    200;     % = vdat(17)  % Mass engine/gears [kg]
sys.parameters.data.ie     =      8;     % = vdat(18)  % Inertia of engine/gears [kgm^2]
%
%     Longitudinal distances (21...40)  [m]
sys.parameters.data.af     =      1.3;   % = vdat(21)  % CG Chassis --> Center of front axle
sys.parameters.data.ar     =      1.3;   % = vdat(22)  % CG Chassis --> Center of rear axle
sys.parameters.data.ag     =      0.8;   % = vdat(23)  % CG Chassis --> Rotational center support of rear axle
sys.parameters.data.sh     =      0.45;  % = vdat(24)  % Rot. center support of rear axle --> CG rear axle
sys.parameters.data.ad     =      0.05;  % = vdat(25)  % CG Chassis --> CG Driver
sys.parameters.data.ae     =      1.7;   % = vdat(26)  % CG Chassis --> CG Engine
sys.parameters.data.aef    =      0.15;  % = vdat(27)  % CG Engine --> Engine support front
sys.parameters.data.aer    =      0.15;  % = vdat(28)  % CG Engine --> Engine support rear
%
%     Vertical distances (41...60) [m]
sys.parameters.data.r0     =      0.315; % = vdat(41)  % Undeformed tire radius
sys.parameters.data.ht     =      0.2;   % = vdat(42)  % Wheel center --> CG Chassis
sys.parameters.data.hd     =      0.35;  % = vdat(43)  % CG Chassis --> CG Driver
sys.parameters.data.he     =      0.05;  % = vdat(44)  % CG Chassis --> CG Engine
sys.parameters.data.hef    =      0.1;   % = vdat(45)  % CG Engine --> Engine support front
sys.parameters.data.her    =      0.1;   % = vdat(46)  % CG Engine --> Engine support rear
%
%     Tires (61...70) [m]
sys.parameters.data.ctf    = 220000;     % = vdat(61)  % Tire stiffness front [N/m]
sys.parameters.data.dtf    =    200;     % = vdat(62)  % Tire damping front [N/(m/s)]
sys.parameters.data.ctr    = 200000;     % = vdat(63)  % Tire stiffness rear [N/m]
sys.parameters.data.dtr    =    180;     % = vdat(64)  % Tire damping rear [N/(m/s)]
%
%     Tire support front (71...80) [m]
sys.parameters.data.f0f    =   4100;     % = vdat(71)  % Spring nominal force [N]
sys.parameters.data.cf     =  25000;     % = vdat(72)  % Spring stiffness [N/m]
sys.parameters.data.xa_mnsf=     -0.08;  % = vdat(73)  % Travel: Tension progression starts [m]
sys.parameters.data.xd_mnsf=     -0.095; % = vdat(74)  % Travel: Tension stiffness is double [m]
sys.parameters.data.xa_plsf=      0.06;  % = vdat(75)  % Travel: Compression progression starts [m]
sys.parameters.data.xd_plsf=      0.1;   % = vdat(76)  % Travel: Comp. stiffness is double [m]
sys.parameters.data.df     =   3000;     % = vdat(77)  % Damping [N/(m/s)]
sys.parameters.data.dpcf   =      2.5;   % = vdat(78)  % Nonlinear compression [1/(m/s)]
sys.parameters.data.dprf   =      1.5;   % = vdat(79)  % Nonlinear tension [1/(m/s)]
%
%     Tire support rear (81...100) [m]
sys.parameters.data.f0r    =   4400;     % = vdat(81)  % Spring nominal force [N]
sys.parameters.data.cr     =  75000;     % = vdat(82)  % Spring stiffness [N/m]
sys.parameters.data.xa_mnsr=     -0.04;  % = vdat(83)  % Travel: Tension progression starts [m]
sys.parameters.data.xd_mnsr=     -0.045; % = vdat(84)  % Travel: Tension stiffness is double [m]
sys.parameters.data.xa_plsr=      0.03;  % = vdat(85)  % Travel: Compression progression starts [m]
sys.parameters.data.xd_plsr=      0.06;  % = vdat(86)  % Travel: Comp. stiffness is double [m]

sys.parameters.data.faprbx =      0.325; % = vdat(87)  % Force application point, rear bottom, longitudinal [m]
sys.parameters.data.faprbz =      0.025; % = vdat(88)  % Force application point, rear bottom, vertical [m]
sys.parameters.data.faprtx =      0.3;   % = vdat(89)  % Force application point, rear top, longitudinal [m]
sys.parameters.data.faprtz =      0.3;   % = vdat(90)  % Force application point, rear top, vertical [m]
sys.parameters.data.daprbx =      0.525; % = vdat(91)  % Damper application point, rear bottom, longitudinal [m]
sys.parameters.data.daprbz =     -0.05;  % = vdat(92)  % Damper application point, rear bottom, vertical [m]
sys.parameters.data.daprtx =      0.5;   % = vdat(93)  % Damper application point, rear top, longitudinal [m]
sys.parameters.data.daprtz =      0.4;   % = vdat(94)  % Damper application point, rear top, vertical [m]
sys.parameters.data.dr     =   2750;     % = vdat(95)  % Damping [N/(m/s)]
sys.parameters.data.dpcr   =      2.5;   % = vdat(96)  % Nonlinear compression [1/(m/s)]
sys.parameters.data.dprr   =      1.5;   % = vdat(97)  % Nonlinear tension [1/(m/s)]
%
%     Seat support (101...110)
sys.parameters.data.f0d    =    588.6;   % = vdat(101)  % Nominal force [N]
sys.parameters.data.cd     =   6000;     % = vdat(102)  % Stiffness [N/m]
sys.parameters.data.dd     =    800;     % = vdat(103)  % Damping [N/(m/s)]
%
%
%     Engine support, front longitudinal (111...120)
sys.parameters.data.cefx   =  80000;     % = vdat(111)  % Stiffness [N/m]
sys.parameters.data.xd_efx =      0.018; % = vdat(112)  % Travel+-: Stiffness is double [m]
sys.parameters.data.defx   =   1200;     % = vdat(113)  % Damping [N/(m/s)]
%
%     Engine support, front vertical (121...130)
sys.parameters.data.cefz   = 250000;     % = vdat(121)  % Stiffness [N/m]
sys.parameters.data.xd_efz =      0.015; % = vdat(122)  % Travel+-: Stiffness is double [m]
sys.parameters.data.defz   =   1000;     % = vdat(123)  % Damping [N/(m/s)]
%
%     Engine support, rear longitudinal (131...140)
sys.parameters.data.cerx   =  90000;     % = vdat(131)  % Stiffness [N/m]
sys.parameters.data.xd_erx =      0.02;  % = vdat(132)  % Travel+-: Stiffness is double [m]
sys.parameters.data.derx   =   1000;     % = vdat(133)  % Damping [N/(m/s)]
%
%     Engine support, rear vertical (141...150)
sys.parameters.data.cerz   = 200000;     % = vdat(141)  % Stiffness [N/m]
sys.parameters.data.xd_erz =      0.018; % = vdat(142)  % Travel+-: Stiffness is double [m]
sys.parameters.data.derz   =   1500;     % = vdat(143)  % Damping [N/(m/s)]

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Additional values
sys.parameters.data.l0r = sqrt( (sys.parameters.data.faprbx-sys.parameters.data.faprtx)^2 ...
    + (sys.parameters.data.faprbz-sys.parameters.data.faprtz)^2); % See IB-40, P.33
% For the animation, the vehicle can be displayed with a constant velocity
% sys.parameters.data.vf = 50/3; % [m/s] corresponds to 60 km/h, see above

% Road excitation:
%   front: u(t) = z*sin(c*t)
%   rear:  v(t) = z*sin(c*t+excitation_phase)
% sys.parameters.data.z                = 0;       % Amplitude
sys.parameters.data.z                = 0.2;       % Amplitude
sys.parameters.data.c                =   10/3*pi; % Frequency
sys.parameters.data.excitation_phase = -13/25*pi; % Phase angle between front and rear axle

% Set values for linearization, position
sys.parameters.data.zc_s   = -0.0182;
sys.parameters.data.bc_s   =  0.0024;
sys.parameters.data.zf_s   =  0.0006;
sys.parameters.data.br_s   = -0.0017;
sys.parameters.data.zd_s   =  0;
sys.parameters.data.xe_s   = -0.0003;
sys.parameters.data.ze_s   = -0.0042;
sys.parameters.data.be_s   = -0.0030;
% Useful vectoral formulation
% y0 = [-0.0182; 0.0024; 0.0006; -0.0017; 0; -0.0003; -0.0042; -0.0030];
sys.settings.timeInt.y0 = [-0.0182; 0.0024; 0.0006; -0.0017; 0; -0.0003; -0.0042; -0.0030];
% Set values for linearization, Velocities/Accelerations = 0
sys.parameters.data.Dzc_s  = 0;
sys.parameters.data.D2zc_s = 0;
sys.parameters.data.Dbc_s  = 0;
sys.parameters.data.D2bc_s = 0;
sys.parameters.data.Dzf_s  = 0;
sys.parameters.data.D2zf_s = 0;
sys.parameters.data.Dbr_s  = 0;
sys.parameters.data.D2br_s = 0;
sys.parameters.data.Dzd_s  = 0;
sys.parameters.data.D2zd_s = 0;
sys.parameters.data.Dxe_s  = 0;
sys.parameters.data.D2xe_s = 0;
sys.parameters.data.Dze_s  = 0;
sys.parameters.data.D2ze_s = 0;
sys.parameters.data.Dbe_s  = 0;
sys.parameters.data.D2be_s = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% System flag, decides if the tires can lift off the street or not
% This is especially helpful if the system is to be linearized
sys.parameters.data.useLiftOff = true;
% sys.parameters.data.useLiftOff = false;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% System flag, show a waitbar during integration
sys.settings.timeInt.display.type = 'waitbar';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% END OF FILE
