function allTimes = compareAll
% Compare all types of the inverse slider_crank model

%% preparations
clear all; close all;

% Shall the figures be saved?
saveFigs_ = false;

fileName_ = ['ergebnisVergleich_',datestr(date,'yymmdd'),'.mat'];
if(exist(fileName_,'file') ~= 0)
    delete(fileName_);
end

% Run simulations
gMax_ = 8;%14; % Check in sysDef_reversed, which is the maximum number
for g_ = 1:gMax_
    fprintf('\nSimulation %d of %d\n',g_,gMax_);
    [worked_,myTime,sys] = startSysDef_reversed(g_,fileName_);
    myTime.name = sys.name;
    myTime.sys = sys;
    allTimes(g_) = myTime;
    if(~worked_) % There was a problem, e.g. model does not exist
        break;
    end
end

clear('sys','g_','gMax_');
fprintf('\nFinished simulation of all systems!\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Compare results
load(fileName_);
% close all;

%% Find names of all simulated systems
fprintf('\nEvaluating comparable results ... ');
% allVars_ = { ...
%     'sys_analytical_reference_yind_gamma1_1', ...
%     'sys_explicit_Mconst_yind_x_2', ...
%     'sys_explicit_Mconst_yind_alpha1_3', ...
%     'sys_explicit_Mconst_yind_beta1_4', ...
%     'sys_kane_yind_x_5', ...
%     'sys_kane_yind_alpha1_6', ...
%     'sys_kane_yind_beta1_7', ...
%     'sys_svd_yind_x_8', ...
%     'sys_svd_yind_alpha1_9', ...
%     'sys_svd_yind_beta1_10', ...
%     'sys_qr_yind_x_11', ...
%     'sys_qr_yind_alpha1_12', ...
%     'sys_qr_yind_beta1_13' ...
%     };
allVars_ = convertString({allTimes(:).name},'prefix','sys_');

%% Produce figures
% #########################################################################
%% Differences for the reverse modeled system
eval(['sys=',allVars_{1},';']); %#ok<UNRCH>
tRef=sys.results.comp.x;
gamma1Ref  = sys.results.comp.y(1,:);
firstCoordRef  = zeros(size(gamma1Ref)); % x
secondCoordRef = zeros(size(gamma1Ref)); % alpha1
thirdCoordRef  = zeros(size(gamma1Ref)); % beta1
firstDiff  = zeros(length(allVars_)-1, length(firstCoordRef));
secondDiff = zeros(length(allVars_)-1, length(firstCoordRef));
thirdDiff  = zeros(length(allVars_)-1, length(firstCoordRef));
% Set up the legend
legendText_ = allVars_(2:end);
% Combine all solutions
allSolutions = cell(length(legendText_),1);
allTmax_ = zeros(length(legendText_),1);
for h_ = 1:length(allSolutions)
    allTmax_(h_) = eval([legendText_{h_},'.results.comp.x(end)']);
    allSolutions{h_} = eval([legendText_{h_},'.results.comp.out']);
end
% Format the legend
legendText_ = strrep(legendText_, 'ydep_', 'ydep=');
legendText_ = strrep(legendText_, 'yind_', 'yind=');
legendText_ = strrep(legendText_, '_', ' ');

% Calculate reference values and differences
% lcrank = sys.userVar.data.lcrank;
% lrod   = sys.userVar.data.lrod;

for g_ = 1:length(firstCoordRef)
%     gamma1 = gamma1Ref(g_);
%     % Analytical reference solution
%     secondCoordRef(g_) = asin(lcrank/lrod*sin(gamma1)); % alpha1
%     firstCoordRef(g_)  = lcrank*cos(gamma1)+lrod*cos(secondCoordRef(g_)); % x
%     thirdCoordRef(g_)  = gamma1 + secondCoordRef(g_); % beta1
    firstCoordRef(g_)  = sys_S01_analytical_reference_yind_gamma1.results.comp.out(1,g_); % alpha1
    secondCoordRef(g_) = sys_S01_analytical_reference_yind_gamma1.results.comp.out(2,g_); % x
    thirdCoordRef(g_)  = sys_S01_analytical_reference_yind_gamma1.results.comp.out(3,g_); % beta1

    % Calculate differences
    for h_ = 1:length(allSolutions)
        if(allTmax_(h_) >= tRef(g_))
            firstDiff(h_,g_)  = allSolutions{h_}(1,g_) -  firstCoordRef(g_); % alpha1
            secondDiff(h_,g_) = allSolutions{h_}(2,g_) - secondCoordRef(g_); % x
            thirdDiff(h_,g_)  = allSolutions{h_}(3,g_) -  thirdCoordRef(g_); % beta1
        end
    end
end
%% Plotting
fprintf('ok!\nPlotting ... ');
saveFigs_ = (exist('saveFigs_','var')~=0) && saveFigs_;

% Both differences in one figure
figure; plot(tRef,firstDiff, tRef,secondDiff, tRef, thirdDiff); grid on;
hold on; plot(allTmax_,firstDiff(:,end),'o', allTmax_,secondDiff(:,end),'o', allTmax_,thirdDiff(:,end),'o'); 
title('Differences to analytical solution'); set(gcf,'Name','differences');
legend([convertString(legendText_,'suffix',' x'), convertString(legendText_,'suffix',' alpha1'), convertString(legendText_,'suffix',' beta1')]);
if(saveFigs_); saveas(gcf,'allDifferences.fig'); end

% Separately
figure; plot(tRef,firstDiff); grid on;
hold on; plot(allTmax_,firstDiff(:,end),'o'); 
title('Differences of x to analytical solution'); set(gcf,'Name','x differences');
legend(legendText_);
if(saveFigs_); saveas(gcf,'differencesCoordX.fig'); end

figure; plot(tRef,secondDiff); grid on;
hold on; plot(allTmax_,secondDiff(:,end),'o'); 
title('Differences of alpha1 to analytical solution'); set(gcf,'Name','alpha1 differences');
legend(legendText_);
if(saveFigs_); saveas(gcf,'differencesCoordAlpha1.fig'); end

figure; plot(tRef,thirdDiff); grid on;
hold on; plot(allTmax_,thirdDiff(:,end),'o'); 
title('Differences of beta1 to analytical solution'); set(gcf,'Name','beta1 differences');
legend(legendText_);
if(saveFigs_); saveas(gcf,'differencesCoordBeta1.fig'); end

% Plotting states of all simulations
for g_ = 1:3
    figure;
    plotData = zeros(length(allSolutions)+1, length(tRef));
    plotData(1, :) = sys_S01_analytical_reference_yind_gamma1.results.comp.out(g_,:);
    for h_ = 1:length(allSolutions)
        plotData(h_+1, 1:length(allSolutions{h_}(g_,:))) = allSolutions{h_}(g_,:);
    end
    plot(tRef, plotData); grid on;
    title([sys.vectors.out.control{g_},' values']); legend([{'Analytical solution'}, legendText_]);
    set(gcf,'Name',[sys.vectors.out.control{g_},' values']);
end

fprintf('ok!\n');
fprintf('\n\nFinished creation of figures\n');

for g_=1:8; fprintf('\n%s\t%4.2f\t%3.2f\t%d', allTimes(g_).name, allTimes(g_).tModel, allTimes(g_).timeInt, allTimes(g_).reachedEnd); end; fprintf('\n');

% END OF FILE

