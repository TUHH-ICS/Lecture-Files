% newBody(sidFile) - Load standard input data from various file formats.
% 
%  Syntax:
%>   loadSID(sidFile);
% 
%  Description:
% This function is used to define a new rigid or flexible body. Next to the
% inertia properties, which are passed as the symbolic values 'm' and 'I' in 
% case of a rigid body or in form of a SID file in case of a flexible body,
% the kinematics of the body's frames can be defined.
%
%  Mandatory inputs:
% sidFile ......... File containing the standard input data
%
% 
%  See also: 
% newBody
%
% First appearance: 03.04.2014
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
