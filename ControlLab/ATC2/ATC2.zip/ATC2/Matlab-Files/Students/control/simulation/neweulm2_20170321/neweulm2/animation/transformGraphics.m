% transformGraphics - rotate and move a graphic object.
%
%  Description:
% Rotate and move a graphic object. This is a static
% change, relative to its governing coordinate system.
%
%  Mandatory input arguments:
%
% h ... object handle
%
%  Optional parameters {default value}:
%
% Translation .................. Translation as 1x3 double vector {[0,0,0]}
% RotationAngles ............... Kardan angles, defined as 1x3 double
%                                vector {[0,0,0]}
% RotationMatrix ............... Define rotation with rotation matrix {eye(3)}
% RotationOrigin ............... Change rotation origin, defined as 1x3
%                                double vector {[0 0 0]}
%
% See also: 
% drawArrow3d, drawCube, drawLine, drawRotBody, drawSphere,
% drawSTL, updateGeo, transformGraphics>transform
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
