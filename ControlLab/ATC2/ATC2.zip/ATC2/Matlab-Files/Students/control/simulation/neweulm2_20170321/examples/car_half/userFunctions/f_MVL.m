function res_ = f_MVL(t,y_,varargin)
% res_ = f_MVL(t,y_,varargin)
% f_MVL - Definition of user-defined variable MVL
% For a better template, please call the appropriate function
% newUserVarTvar for time dependent parameters
% newUserVarYvar for state dependent parameters

global sys;

if(nargin==1 && ischar(t) && strcmp(t,'linearization'))
	% Case IV: Call was f_...('linearization')
	% Return symbolic expression to calculate the linearization
	% Necessary for all parameters appearing in the equations of motion to linearize!
	res_ = sym('cefx*(1+(xe+aef*cos(be)-hef*sin(be)-aef)^2/xd_efx^2)');
	return;
end

% constant user-defined variables

xde = sys.parameters.data.xd_efx;
c = sys.parameters.data.cefx;

% relative vector
% ksys1 = str2func('KARVL_r');
ksys1 = str2func('CAREF_r');
ksys2 = str2func('EF_r');
SDirdef = CAREF_S(t,y_);

r_ = transpose(SDirdef)*(ksys2(t,y_) - ksys1(t,y_));

% state dependent user defined functions
x = r_(1);
res_ = springParam(x, c, 0, -xde, 0, xde);

