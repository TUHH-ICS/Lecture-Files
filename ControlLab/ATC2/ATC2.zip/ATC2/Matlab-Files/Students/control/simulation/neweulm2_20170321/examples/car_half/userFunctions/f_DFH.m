function res_ = f_DFH(t,y_,varargin)

res_ = 0; % Default return value
