% S = quat2rotmat(w, x, y, z)
% QUAT2ROTMAT - Calculate rotation matrix from unit quaterion q = w+ix+jy+kz
%
% Input arguments
% w,x,y,z ........ Unit quaternion q = w+ix+jy+kz, 1 = w^2+x^2+y^2+z^2 
%                  (for four input arguments)
% q .............. Unit quaternion q = [w; x; y; z] (for one input argument)
%
% Return argument
% S ....... Rotation matrix
%
% See also: rotmat2kardan
%
% First appearance: 28.12.2013
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
