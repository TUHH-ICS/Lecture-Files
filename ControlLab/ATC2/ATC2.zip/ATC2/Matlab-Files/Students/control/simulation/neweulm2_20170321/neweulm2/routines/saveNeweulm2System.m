% saveNeweulm2System(filename,filepath,IncludeResults_,autosave_)
%
% Function to save a system for neweulm2
% Saves the structure 'sys' and if available the structure 'gui' in the
% file named 'filename' in the folder denoted by filepath. In addition to
% this the animation window is saved as '[filename(1:end-3),'.fig']' in the
% same location.
% As a default the standard dialog to select a file for saving is openend,
% but this function can also be called to save to a preselected file, whose
% properties are passed as arguments. If nothing is passed the system id
% with the current date is proposed as filename.
%
% Input arguments, all optional, {default value}:
% filename .......... Name of file, containing the filetag, e.g. .mat
%                     {"System-ID"_date.mat}
% filepath .......... Absolute path of the file filename {pwd}
% IncludeResults_ ... Include simulation results in the stored structure.
%                     This is an option because these results may require a
%                     lot of space but could be easily reproduced. {true}
% autosave_ ......... Flag if this function has been called to perform an
%                     auto-save. Then no printouts and no folder changes
%                     are made. {true}
%
% See also: load_neweulm2_System
%
% First appearance: 01.07.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
