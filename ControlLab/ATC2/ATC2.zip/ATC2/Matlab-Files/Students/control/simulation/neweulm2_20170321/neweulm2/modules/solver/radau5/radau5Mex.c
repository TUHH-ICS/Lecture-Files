/*
 * RADAU5MEX-Interface von C. Ludwig
 * Version: $Id: radau5Mex.c 717 2009-08-18 10:02:04Z luchr $ */
#define RADAU5MexVersion "18. Aug. 2009"
/*
 * 
 * Fragen, W�nsche, Probleme, Anregungen, 
 * Anmerkungen, Bemerkungen und Bugs an
 *  Ludwig_C@gmx.de
 */
#include <math.h>
#include "mex.h"
#include "string.h"
#include "options.h"
#include "radau5Mex.h"

static SOptionSettings optSet;
static SParameterIO paramIO;
static SParameterGlobal paramGlobal;
static SParameterRadau paramRadau;
static SParameterRightSide paramRightSide;
static SParameterMassmatrix paramMassmatrix;
static SParameterJacobimatrix paramJacobimatrix;
static SParameterOutput paramOutput;

static SRadauDense radauDense;
static char isInnerCall=(char)0;

void RadauMASFullFunc (int*, double*, int*, double*, int*);
void RadauMASFullLRFunc (int*, double*, int*, double*, int*);
void RadauMASBandedMatrixFunc (int*, double*, int*, double*, int*);
void RadauMASBandedCellFunc (int*, double*, int*, double*, int*);
void RadauMASBandedLRMatrixFunc (int*, double*, int*, double*, int*);
void RadauMASBandedLRCellFunc (int*, double*, int*, double*, int*); 

void RadauJACFullFunc (int*, double*,double*, double*, int*, double*, int*);
void RadauJACFullLFunc (int*, double*,double*, double*, int*, double*, int*);
void RadauJACBandedFunc (int*, double*,double*, double*, int*, double*, int*);
void RadauJACBandedLFunc (int*, double*,double*, double*, int*, double*, int*); 

static char ismxArrayString (const mxArray *arr) {
  if (arr==NULL) return (char)0;
  if (mxIsChar(arr)) return (char)1;
  return (char)0;
}

static char ismxArrayFunction (const mxArray *arr) {
  if (arr==NULL) return (char)0;
  return (mxGetClassID(arr)==mxFUNCTION_CLASS)?(char)1:(char)0;
}

static char ismxArrayInline (const mxArray *arr) {
  if (arr==NULL) return (char)0;
  return (strcmp(mxGetClassName(arr),"inline")==0)?(char)1:(char)0;
}


static void clearList (PListElement current) {
  PListElement next;
  
  while (current!=NULL) {
    next=current->next;
    if (current->values!=NULL)
      {mxFree(current->values);current->values=NULL;}
    mxFree(current);
    current=next;
  }
}

static void initVars (void) {
  /* IO parameters */
  paramIO.opt=NULL;paramIO.optCreated=0;  

  /* Option settings */
  optSet.warnMiss=0;optSet.warnType=1;optSet.warnSize=1;   
  
  /* global parameters */
  paramGlobal.tPointer=NULL;
  isInnerCall=(char)0;
  
  /* parameters for Radau */
  paramRadau.xStart=NULL;
  paramRadau.RTOL=NULL;paramRadau.ATOL=NULL;
  paramRadau.WORK=NULL;paramRadau.IWORK=NULL;
  paramRadau.RPAR=NULL;paramRadau.IPAR=NULL;
  
  /* parameters for rightside */
  paramRightSide.rightSideFcn=NULL;
  paramRightSide.rightSideFcnH=NULL;
  paramRightSide.tArg=NULL;paramRightSide.xArg=NULL;
  
  /* parameters for mass */
  paramMassmatrix.radauMASFunc=NULL;
  
  /* parameters for jacobi */
  paramJacobimatrix.jacFcn=NULL;
  paramJacobimatrix.jacFcnH=NULL;
  paramJacobimatrix.tArg=NULL;paramJacobimatrix.xArg=NULL;
  paramJacobimatrix.radauJACFunc=NULL;
  
  /* output parameters */
  paramOutput.txList.values=NULL;
  paramOutput.txList.next=NULL;
  paramOutput.lastTXElement=&paramOutput.txList;
  paramOutput.numberOfElements=0;
  paramOutput.outputFcn=NULL;
  paramOutput.outputFcnH=NULL;
  paramOutput.tArg=NULL;paramOutput.xArg=NULL;paramOutput.emptyArg=NULL;
  paramOutput.toldArg=NULL;
}

static void doneVars (void) {
  /* IO parameters */
  if ((paramIO.optCreated) && (paramIO.opt!=NULL)) 
    {mxDestroyArray((mxArray*)paramIO.opt);paramIO.opt=NULL;}    
  
  /* global parameters */
  /* tPointer darf auf keinen Fall */
  /* freigegeben werden, er geh�rt dem Aufrufer */
    
  /* parameters for Radau */
  if (paramRadau.xStart!=NULL)
    {mxFree(paramRadau.xStart);paramRadau.xStart=NULL;}
  if (paramRadau.RTOL!=NULL)
    {mxFree(paramRadau.RTOL);paramRadau.RTOL=NULL;}
  if (paramRadau.ATOL!=NULL)
    {mxFree(paramRadau.ATOL);paramRadau.ATOL=NULL;}
  if (paramRadau.WORK!=NULL)
    {mxFree(paramRadau.WORK);paramRadau.WORK=NULL;}
  if (paramRadau.IWORK!=NULL)
    {mxFree(paramRadau.IWORK);paramRadau.IWORK=NULL;}
  if (paramRadau.RPAR!=NULL)
    {mxFree(paramRadau.RPAR);paramRadau.RPAR=NULL;}
  if (paramRadau.IPAR!=NULL)
    {mxFree(paramRadau.IPAR);paramRadau.IPAR=NULL;}
    
  /* parameters for right side */
  if (paramRightSide.rightSideFcn!=NULL)
    {mxFree(paramRightSide.rightSideFcn);paramRightSide.rightSideFcn=NULL;}
  paramRightSide.rightSideFcnH=NULL; /* geh�rt Aufrufer => nicht freigeben */
  if (paramRightSide.tArg!=NULL)
    {mxDestroyArray(paramRightSide.tArg);paramRightSide.tArg=NULL;}
  if (paramRightSide.xArg!=NULL)
    {mxDestroyArray(paramRightSide.xArg);paramRightSide.xArg=NULL;}
  
  /* parameters for jacobi */
  if (paramJacobimatrix.jacFcn!=NULL)
    {mxFree(paramJacobimatrix.jacFcn);paramJacobimatrix.jacFcn=NULL;}
  paramJacobimatrix.jacFcnH=NULL; /* geh�rt Aufrufer => nicht freigeben */
  if (paramJacobimatrix.tArg!=NULL)
    {mxDestroyArray(paramJacobimatrix.tArg);paramJacobimatrix.tArg=NULL;}
  if (paramJacobimatrix.xArg!=NULL)
    {mxDestroyArray(paramJacobimatrix.xArg);paramJacobimatrix.xArg=NULL;}
  
  /* output parameters */
  clearList(paramOutput.txList.next);paramOutput.txList.next=NULL;
  if (paramOutput.outputFcn!=NULL)
    {mxFree(paramOutput.outputFcn);paramOutput.outputFcn=NULL;}
  paramOutput.outputFcnH=NULL; /* geh�rt Aufrufer => nicht freigeben */
  if (paramOutput.tArg!=NULL)
    {mxDestroyArray(paramOutput.tArg);paramOutput.tArg=NULL;}
  if (paramOutput.xArg!=NULL)
    {mxDestroyArray(paramOutput.xArg);paramOutput.xArg=NULL;}
  if (paramOutput.emptyArg!=NULL)
    {mxDestroyArray(paramOutput.emptyArg);paramOutput.emptyArg=NULL;}
  if (paramOutput.toldArg!=NULL) 
    {mxDestroyArray(paramOutput.toldArg);paramOutput.toldArg=NULL;}
}

static void stopMexFunctionImpl (int errNo,
  int i1, int i2, int i3, int i4, int i5, double d1, char doneFlag) {
  char *msg;
  
  isInnerCall=(char)0;
  mexPrintf("Error (%i) [Version: %s]:\n",errNo,RADAU5MexVersion);
  mexPrintf("Fehler (%i) [Version: %s]:\n",errNo,RADAU5MexVersion);
  switch (errNo) {
    #include "errors.c"
    default: msg="unknown error number (Unbekannte Fehlernummer)";break;
  }
  
  if (doneFlag) {doneVars();}
  mexErrMsgTxt(msg);
}

static void stopMexFunction (int errNo,
  int i1, int i2, int i3, int i4, int i5, double d1) {

  stopMexFunctionImpl(errNo,i1,i2,i3,i4,i5,d1,(char)1);
}

static void addTXtoList (double t, double *x) {
  double* dpointer;
  PListElement target;
  
  target=(PListElement)mxMalloc(sizeof(SListElement));
  target->next=NULL;paramOutput.lastTXElement->next=target;
  paramOutput.lastTXElement=target;paramOutput.numberOfElements++;
  target->values=(double*)mxMalloc((paramGlobal.d+1)*sizeof(double));
  dpointer=target->values;
  *dpointer=t;dpointer++;
  memcpy(dpointer,x,paramGlobal.d*sizeof(double));
}

static void checkNumberOfArgs (int nlhs, int nrhs) {
  if ((nlhs<2) || (nlhs>4)) stopMexFunction(1,nlhs,0,0,0,0,0);    
    
  if ((nrhs!=3) && (nrhs!=4)) stopMexFunction(2,nrhs,0,0,0,0,0);
}

static void processArgs (int nrhs, const mxArray* prhs[])
{
  int buflen;
  double *dpointer;
  
  /* 1st arg: right side */
  if (ismxArrayString(prhs[0])) {
    if ((mxGetNumberOfDimensions(prhs[0])!=2) || (mxGetM(prhs[0])!=1))
      stopMexFunction(4,mxGetNumberOfDimensions(prhs[0]),mxGetM(prhs[0]),0,0,0,0);  
    buflen=mxGetN(prhs[0])*sizeof(mxChar)+1;
    paramRightSide.rightSideFcn=(char*)mxMalloc(buflen);
    mxGetString(prhs[0],paramRightSide.rightSideFcn,buflen);
    paramRightSide.rightSideFcnH=prhs[0]; 
  } else 
  if ( (ismxArrayFunction(prhs[0])) || (ismxArrayInline(prhs[0])) ) {
    if ((mxGetNumberOfDimensions(prhs[0])!=2) || (mxGetM(prhs[0])!=1) ||
        (mxGetN(prhs[0])!=1))
      stopMexFunction(21,mxGetNumberOfDimensions(prhs[0]),
                      mxGetM(prhs[0]),mxGetN(prhs[0]),0,0,0);
    paramRightSide.rightSideFcn=NULL; /* kein String */
    paramRightSide.rightSideFcnH=prhs[0];
  } else {
    stopMexFunction(3,0,0,0,0,0,0);
  }

  /* 2nd arg: row-vector containing time-values */
  if (!mxIsDouble(prhs[1])) stopMexFunction(5,0,0,0,0,0,0);
  if ((mxGetNumberOfDimensions(prhs[1])!=2) || (mxGetM(prhs[1])!=1))
    stopMexFunction(6,mxGetNumberOfDimensions(prhs[1]),mxGetM(prhs[1]),0,0,0,0);
  paramGlobal.tLength=mxGetN(prhs[1]);
  if (paramGlobal.tLength<2) stopMexFunction(7,0,0,0,0,0,0);
  if (paramGlobal.tLength>2) {
    paramRadau.denseFlag=1; 
  } else {
    paramRadau.denseFlag=0;
  }
  dpointer=mxGetPr(prhs[1]);paramGlobal.tPointer=dpointer;
  paramRadau.tStart=dpointer[0];
  paramRadau.tEnd=dpointer[paramGlobal.tLength-1];
  if (paramRadau.tStart==paramRadau.tEnd) stopMexFunction(12,0,0,0,0,0,0);
  paramGlobal.direction=(paramRadau.tEnd-paramRadau.tStart)>0?1.0:-1.0;
  for (buflen=1; buflen<paramGlobal.tLength; buflen++,dpointer++)
    if (paramGlobal.direction*(dpointer[0]-dpointer[1])>0)
      stopMexFunction(14,paramGlobal.direction,0,0,0,0,0);        
  
  /* 3rd arg: start vector */
  if (!mxIsDouble(prhs[2])) stopMexFunction(8,0,0,0,0,0,0);
  if ((mxGetNumberOfDimensions(prhs[2])!=2) || (mxGetN(prhs[2])!=1))
    stopMexFunction(9,mxGetNumberOfDimensions(prhs[2]),mxGetN(prhs[2]),0,0,0,0);
  paramGlobal.d=mxGetM(prhs[2]);
  if (paramGlobal.d<1) stopMexFunction(10,0,0,0,0,0,0);
  dpointer=mxGetPr(prhs[2]);
  paramRadau.xStart=(double*)mxMalloc(paramGlobal.d*sizeof(double));
  memcpy(paramRadau.xStart,dpointer,paramGlobal.d*sizeof(double));
  /* little remark: A COPY of the startvector is made, because
     it will be passed to Fortran code. To be sure, that
     it will not be changed there, a copy will be passed.
     x0 belongs to the caller and it is not allowed 
     (due to Matlab-Contract) to change it. */
  /* kleine Anmerkung: der Startvektor wird KOPIERT, da er an den 
     Fortran code weitergegeben wird. Um ganz sicher zu gehen,
     dass er nicht ver�ndert wird, wird eine Kopie �bergeben.
     x0 geh�rt ja dem Aufrufer und darf nach Matlab-Konvention
     nicht ver�ndert werden. */
  
  /* 4th arg: struct with options */
  if (nrhs==4) {
    if (!mxIsStruct(prhs[3])) stopMexFunction(11,0,0,0,0,0,0);
    paramIO.opt=prhs[3];paramIO.optCreated=0;
  } else {
    paramIO.opt=mxCreateStructMatrix(1,1,0,NULL);
    paramIO.optCreated=1;
  }
}

static void extractOptionSettings (void) {
  optSet.warnMiss=opt_getIntFromOpt(paramIO.opt,&optSet,OPT_WARNMISS,0);
  optSet.warnType=opt_getIntFromOpt(paramIO.opt,&optSet,OPT_WARNTYPE,1);
  optSet.warnSize=opt_getIntFromOpt(paramIO.opt,&optSet,OPT_WARNSIZE,1);
}

static void extractHandTOLs (void) {
  int m1,n1,m2,n2,res1,res2;
  int takeScalar;
  
  paramRadau.h=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_INITIALSS,1e-6);
  
  res1=opt_getSizeOfOptField(paramIO.opt,OPT_RTOL,&m1,&n1);
  res2=opt_getSizeOfOptField(paramIO.opt,OPT_ATOL,&m2,&n2);
  
  takeScalar=0;
  if (((res1!=0) || (res2!=0)) ||
      ((res1==0) && (m1==1)) ||
      ((res2==0) && (m2==1))) {
    takeScalar=1; 
  } else {
    if ((n1!=1) || (n2!=1)) takeScalar=1;
    if (m1!=m2) takeScalar=1;
    if (m1!=paramGlobal.d) takeScalar=1;
  }

  if (takeScalar) {
    paramRadau.RTOL=(double*)mxMalloc(1*sizeof(double));
    paramRadau.ATOL=(double*)mxMalloc(1*sizeof(double));
    *paramRadau.RTOL=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_RTOL,1e-3);
    *paramRadau.ATOL=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_ATOL,1e-6);
    paramRadau.ITOL=0;
  } else {
    paramRadau.RTOL=(double*)mxMalloc(paramGlobal.d*sizeof(double));
    paramRadau.ATOL=(double*)mxMalloc(paramGlobal.d*sizeof(double));
    opt_getDoubleVectorFromOpt(paramIO.opt,&optSet,OPT_RTOL,
      paramGlobal.d,1,paramRadau.RTOL);
    opt_getDoubleVectorFromOpt(paramIO.opt,&optSet,OPT_ATOL,
      paramGlobal.d,1,paramRadau.ATOL);
    paramRadau.ITOL=1;
  }
}

static void extractOutput (void) {
  mxArray *arr;

  if (paramRadau.denseFlag) {
    paramOutput.includeGrid=opt_getIntFromOpt(paramIO.opt,&optSet,
      OPT_IGPIDO,0);
  }

  paramOutput.outputFcnH=NULL;paramOutput.outputFcn=NULL;
  arr=mxGetField(paramIO.opt,0,OPT_OUTPUTFUNCTION);
  if ((arr!=NULL) && (!mxIsEmpty(arr))) {
    if ( (ismxArrayFunction(arr)) || (ismxArrayInline(arr)) ) {
      if ((mxGetNumberOfDimensions(arr)!=2) || (mxGetM(arr)!=1) ||
          (mxGetN(arr)!=1))
        stopMexFunction(401,mxGetNumberOfDimensions(arr),
                        mxGetM(arr),mxGetN(arr),0,0,0);
      paramOutput.outputFcnH=arr;
    } else {
      paramOutput.outputFcn=opt_getStringFromOpt(paramIO.opt,&optSet,
        OPT_OUTPUTFUNCTION,NULL);
      if (paramOutput.outputFcn!=NULL) {
        if (strlen(paramOutput.outputFcn)==0) {
          mxFree(paramOutput.outputFcn);paramOutput.outputFcn=NULL;
        } else {
          paramOutput.outputFcnH=arr;
        }
      }
    }
  }
  
  paramOutput.outputCallMode=1;
  if ((paramOutput.outputFcnH!=NULL) && (paramRadau.denseFlag)) {
    paramOutput.outputCallMode=opt_getIntFromOpt(paramIO.opt,&optSet,
      OPT_OUTPUTCALLMODE,1);
    if ((paramOutput.outputCallMode<1) || (paramOutput.outputCallMode>3))
      paramOutput.outputCallMode=1;
  }
}

static void extractGlobalOptions (void) {
  paramGlobal.funcCallMethod=opt_getIntFromOpt(paramIO.opt,&optSet,
    OPT_FUNCCALLMETHOD,1);
  switch (paramGlobal.funcCallMethod) {
    case 0: /* use maxCallMATLAB direct */
      if (paramRightSide.rightSideFcn==NULL) stopMexFunction(22,0,0,0,0,0,0);
      if ((paramOutput.outputFcnH!=NULL) && (paramOutput.outputFcn==NULL))
        stopMexFunction(23,0,0,0,0,0,0);
      if ((paramJacobimatrix.jacFcnH!=NULL) && 
          (paramJacobimatrix.jacFcn==NULL)) 
        stopMexFunction(24,0,0,0,0,0,0);
      break;
    case 1: /* use mexCallMATLAB to call feval */
      break;
    default:
      stopMexFunction(25,0,0,0,0,0,0);
      break;
  }
}

static void extractOptionsPart1 (void) {
  extractOptionSettings();
  extractHandTOLs();
  extractOutput();  
  /* extractGlobalOptions sp�ter; erst wenn Jacobi-Param eingelesen */
}

static void extractMassMatrix (void) {
  mxArray *mField;
  int m,n,m1,len;
  
  mField=mxGetField(paramIO.opt,0,OPT_MASSMATRIX);
  m1=paramRadau.IWORK[9-1];
  
  if ((mField==NULL) || (mxIsEmpty(mField))) {
    /* Massenmatrix=Id */
    paramMassmatrix.IMAS=0;paramMassmatrix.MLMAS=0;
    paramMassmatrix.radauMASFunc=NULL;
    return;
  }
  
  if (paramRadau.IWORK[1-1]!=0) stopMexFunction(18,0,0,0,0,0,0);
  paramMassmatrix.IMAS=1; 
  paramMassmatrix.MLMAS=opt_getIntFromOpt(paramIO.opt,&optSet,
    OPT_MASSLBAND,paramGlobal.d-m1);
  paramMassmatrix.MUMAS=opt_getIntFromOpt(paramIO.opt,&optSet,
    OPT_MASSUBAND,paramGlobal.d-m1);   
  if ((paramMassmatrix.MLMAS<0) || (paramMassmatrix.MUMAS<0) || 
      (paramMassmatrix.MLMAS>paramGlobal.d-m1) ||
      (paramMassmatrix.MUMAS>paramGlobal.d-m1))
    stopMexFunction(110,0,0,0,0,0,0);
    
  if (paramMassmatrix.MLMAS==paramGlobal.d-m1) { 
    /* Massmatrix is full or fullbutlowerright */
    if (!mxIsDouble(mField)) stopMexFunction(101,paramGlobal.d,m1,0,0,0,0);      
    if (mxGetNumberOfDimensions(mField)!=2) stopMexFunction(102,0,0,0,0,0,0);
    m=mxGetM(mField);n=mxGetN(mField);
    if (m!=n) stopMexFunction(103,m,n,0,0,0,0);
    if (m!=paramGlobal.d-m1) stopMexFunction(104,m,m1,0,0,0,0);
    if (m1>0)
      paramMassmatrix.radauMASFunc=RadauMASFullLRFunc; else
      paramMassmatrix.radauMASFunc=RadauMASFullFunc;
  } else { 
    /* Massmatrix is banded or bandedbutlowerright */
    if ((!mxIsDouble(mField)) && (!mxIsCell(mField)))      
      stopMexFunction(105,paramMassmatrix.MLMAS,m1,0,0,0,0);
    if (m1==0) { 
      /* Massmatrix is banded */
      if (mxIsDouble(mField)) {
        len=1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS;
        if ((mxGetNumberOfDimensions(mField)!=2) ||
            ((int)mxGetM(mField)!=(int)len) || ((int)mxGetN(mField)!=(int)paramGlobal.d))
          stopMexFunction(106,mxGetM(mField),mxGetN(mField),0,0,0,0);            
        paramMassmatrix.radauMASFunc=RadauMASBandedMatrixFunc;
      }
      if (mxIsCell(mField)) {
        len=1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS;
        if ((mxGetNumberOfDimensions(mField)!=2) ||
            ((int)mxGetM(mField)!=1) || ((int)mxGetN(mField)!=len))
          stopMexFunction(107,mxGetM(mField),mxGetN(mField),0,0,0,0);
        paramMassmatrix.radauMASFunc=RadauMASBandedCellFunc;
      }      
    } else { 
      /* Massmatrix is bandedbutlowerright */
      if (mxIsDouble(mField)) {
        len=1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS;
        if ((mxGetNumberOfDimensions(mField)!=2) ||
            ((int)mxGetM(mField)!=len) || ((int)mxGetN(mField)!=paramGlobal.d-m1))
          stopMexFunction(108,mxGetM(mField),mxGetN(mField),0,0,0,0);
        paramMassmatrix.radauMASFunc=RadauMASBandedLRMatrixFunc;
      }
      if (mxIsCell(mField)) {
        len=1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS;
        if ((mxGetNumberOfDimensions(mField)!=2) ||
            ((int)mxGetM(mField)!=1) || ((int)mxGetN(mField)!=len))          
          stopMexFunction(109,mxGetM(mField),mxGetN(mField),0,0,0,0);
        paramMassmatrix.radauMASFunc=RadauMASBandedLRCellFunc;
      }
    }
  }
}

static void extractJacobiMatrix (void) {
  int m1,m2;
  int buflen;
  mxArray *arr;

  paramJacobimatrix.jacFcnH=NULL;
  paramJacobimatrix.jacFcn=NULL;

  arr=mxGetField(paramIO.opt,0,OPT_JACOBIMATRIX);
  if ((arr!=NULL) && (!mxIsEmpty(arr))) {
    if (ismxArrayString(arr)) {
      if ((mxGetNumberOfDimensions(arr)!=2) || (mxGetM(arr)!=1)) 
        stopMexFunction(225,mxGetNumberOfDimensions(arr),mxGetM(arr),0,0,0,0);
      buflen=mxGetN(arr)*sizeof(mxChar)+1;
      paramJacobimatrix.jacFcn=(char*)mxMalloc(buflen);
      mxGetString(arr,paramJacobimatrix.jacFcn,buflen);
      paramJacobimatrix.jacFcnH=arr;
    } else
    if ( (ismxArrayFunction(arr)) || (ismxArrayInline(arr)) ) {
      if ((mxGetNumberOfDimensions(arr)!=2) || (mxGetM(arr)!=1) ||
          (mxGetN(arr)!=1)) 
        stopMexFunction(226,mxGetNumberOfDimensions(arr),mxGetM(arr),mxGetN(arr),0,0,0);
      paramJacobimatrix.jacFcn=NULL; /* kein String */
      paramJacobimatrix.jacFcnH=arr;
    } else {
      stopMexFunction(227,0,0,0,0,0,0);
    }
  }

  m1=paramRadau.IWORK[9-1];m2=paramRadau.IWORK[10-1];
  
  paramJacobimatrix.IJAC=(paramJacobimatrix.jacFcnH==NULL)?0:1; /*changed jacFcn to jacFcnH, M. Burkhardt*/
  paramJacobimatrix.MLJAC=opt_getIntFromOpt(paramIO.opt,&optSet,
    OPT_JACOBILBAND,paramGlobal.d-m1);
  paramJacobimatrix.MUJAC=opt_getIntFromOpt(paramIO.opt,&optSet,
    OPT_JACOBIUBAND,0);
  
  if ((paramJacobimatrix.MLJAC<0) ||
      (paramJacobimatrix.MUJAC<0) || 
      (paramJacobimatrix.MLJAC>paramGlobal.d-m1) ||
      (paramJacobimatrix.MUJAC>paramGlobal.d-m1))
    stopMexFunction(201,paramGlobal.d,m1,0,0,0,0);  
  
  if (m1>0) {
    if (paramRadau.IWORK[1-1]!=0) stopMexFunction(19,0,0,0,0,0,0);
    if (paramJacobimatrix.MLJAC==paramGlobal.d-m1) {
      paramJacobimatrix.radauJACFunc=RadauJACFullLFunc; 
    } else {      
      if (m1+m2!=paramGlobal.d) stopMexFunction(202,0,0,0,0,0,0);
      if ((paramJacobimatrix.MLJAC>m2) || (paramJacobimatrix.MUJAC>m2))      
        stopMexFunction(203,0,0,0,0,0,0);
      paramJacobimatrix.radauJACFunc=RadauJACBandedLFunc;
    }
  } else {
    if (paramJacobimatrix.MLJAC==paramGlobal.d-m1) {
      paramJacobimatrix.radauJACFunc=RadauJACFullFunc; 
    } else {
      if (paramRadau.IWORK[1-1]!=0) stopMexFunction(20,0,0,0,0,0,0);
      paramJacobimatrix.radauJACFunc=RadauJACBandedFunc;
    }
  }      
}

static void extractOptionsPart2 (void) {
  extractMassMatrix();
  extractJacobiMatrix();
  if (paramMassmatrix.MLMAS>paramJacobimatrix.MLJAC)
    stopMexFunction(16,paramMassmatrix.MLMAS,paramJacobimatrix.MLJAC,0,0,0,0);
  extractGlobalOptions();
}

static void prepareIWORKArray (void) {
  int i,d,m1,m2;

  d=paramGlobal.d;  
  paramRadau.IOUT=1;
  
  /* IWORK */
  paramRadau.LIWORK=3*d+20;
  paramRadau.IWORK=(int*)mxMalloc(paramRadau.LIWORK*sizeof(int));
  
  /* Std-Values */
  for (i=1-1; i<=20-1; i++) paramRadau.IWORK[i]=0;
  
  i=opt_getIntFromOpt(paramIO.opt,&optSet,OPT_TRANSJTOH,0);
  if ((i!=0) && (i!=1)) stopMexFunction(502,i,0,0,0,0,0);
  paramRadau.IWORK[1-1]=i;
    
  i=opt_getIntFromOpt(paramIO.opt,&optSet,OPT_MAXSTEPS,100000);
  if (i<=0) stopMexFunction(503,i,0,0,0,0,0);
  paramRadau.IWORK[2-1]=i;
  
  i=opt_getIntFromOpt(paramIO.opt,&optSet,OPT_MAXNEWTONITER,7);
  if (i<=0) stopMexFunction(504,i,0,0,0,0,0);
  paramRadau.IWORK[3-1]=i;  
    
  i=opt_getIntFromOpt(paramIO.opt,&optSet,OPT_NEWTONSTARTSWITCH,0);
  paramRadau.IWORK[4-1]=i;
  
  i=opt_getIntFromOpt(paramIO.opt,&optSet,OPT_DIMOFIND1VAR,d);
  if ((i<=0) || (i>d)) stopMexFunction(505,i,0,0,0,0,0);
  paramRadau.IWORK[5-1]=i;
  
  i=opt_getIntFromOpt(paramIO.opt,&optSet,OPT_DIMOFIND2VAR,0);
  if (i<0) stopMexFunction(506,i,0,0,0,0,0);
  paramRadau.IWORK[6-1]=i;
  
  i=opt_getIntFromOpt(paramIO.opt,&optSet,OPT_DIMOFIND3VAR,0);
  if (i<0) stopMexFunction(507,i,0,0,0,0,0);
  paramRadau.IWORK[7-1]=i;
  
  i=opt_getIntFromOpt(paramIO.opt,&optSet,OPT_STEPSIZESTRATEGY,1);
  if ((i!=1) && (i!=2)) stopMexFunction(508,i,0,0,0,0,0);
  paramRadau.IWORK[8-1]=i;
  
  m1=opt_getIntFromOpt(paramIO.opt,&optSet,OPT_M1,0);
  m2=opt_getIntFromOpt(paramIO.opt,&optSet,OPT_M2,0);
  if ((m1<0) || (m2<0)) stopMexFunction(509,m1,m2,0,0,0,0);
  if (m1+m2>d) stopMexFunction(510,0,0,0,0,0,0);
  if (((m1==0) && (m2!=0)) || ((m1!=0) && (m2==0)))
    stopMexFunction(511,m1,m2,0,0,0,0);
  if (m2!=0) {
    if (m1%m2!=0) stopMexFunction(512,m1,m2,0,0,0,0);
    paramRadau.mm=m1/m2;
  }
  paramRadau.IWORK[9-1]=m1;
  paramRadau.IWORK[10-1]=m2;
}

static void prepareWORKArray (void) {
  int i,ljac,lmas,le,d,m1;
  double dValue,help;
  
  d=paramGlobal.d;m1=paramRadau.IWORK[9-1];
  if (m1>0) { 
    /* mit Spezialstruktur */
    /* ljac */
    if (paramJacobimatrix.MLJAC==d-m1) {
      ljac=d-m1; 
    } else {
      ljac=1+paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC;
    }
      
    /* lmas */
    if (paramMassmatrix.IMAS==0) {
      lmas=0; 
    } else {
      if (paramMassmatrix.MLMAS==d-m1) {
        lmas=d-m1; 
      } else {
        lmas=1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS;
      }
    }
    
    /* le */
    if (paramJacobimatrix.MLJAC==d-m1) {
      le=d; 
    } else {
      le=1+2*paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC;
    }
    
    paramRadau.LWORK=d*(ljac+12)+(d-m1)*(lmas+3*le)+20;
    paramRadau.WORK=(double*)mxMalloc(paramRadau.LWORK*sizeof(double));
  } else { 
    /* keine Spezialstruktur */
    /* ljac */
    if (paramJacobimatrix.MLJAC==d) {
      ljac=d; 
    } else {
      ljac=1+paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC;
    }
      
    /* lmas */
    if (paramMassmatrix.IMAS==0) {
      lmas=0; 
    } else {
      if (paramMassmatrix.MLMAS==d) {
        lmas=d; 
      } else {
        lmas=1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS;
      }
    }
    
    /* le */
    if (paramJacobimatrix.MLJAC==d) {
      le=d; 
    } else {
      le=1+2*paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC;
    }
    
    paramRadau.LWORK=d*(ljac+lmas+3*le+12)+20;
    paramRadau.WORK=(double*)mxMalloc(paramRadau.LWORK*sizeof(double));
  } 
  
  /* std-Values */
  for (i=1-1; i<=20-1; i++) paramRadau.WORK[i]=0.0;
  
  dValue=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_EPS,1.0e-16);
  if (!((dValue>1e-19) && (dValue<1.0))) stopMexFunction(513,0,0,0,0,0,dValue);
  paramRadau.WORK[1-1]=dValue;
  
  dValue=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_RHO,0.9);
  if (!(dValue>0)) stopMexFunction(514,0,0,0,0,0,dValue);
  paramRadau.WORK[2-1]=dValue;
  
  dValue=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_JACRECOMPFACTOR,0.001);
  paramRadau.WORK[3-1]=dValue;  
    
  help=paramRadau.WORK[1-1]/paramRadau.RTOL[1-1];  
  dValue=sqrt(paramRadau.RTOL[1-1]);  
  if (dValue>0.03) dValue=0.03;
  if (10.0*help>dValue) dValue=10.0*help;
  dValue=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_NEWTONSTOPCRIT,dValue);
  if (!(dValue>help)) stopMexFunction(516,0,0,0,0,0,dValue);
  paramRadau.WORK[4-1]=dValue;
    
  dValue=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_FREEZESSLEFT,1.0);
  if (!((dValue<=1.0) && (dValue>=0.0))) stopMexFunction(517,0,0,0,0,0,dValue);
  paramRadau.WORK[5-1]=dValue;
  
  dValue=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_FREEZESSRIGHT,1.2);
  if (!(dValue>=1.0)) stopMexFunction(518,0,0,0,0,0,dValue);
  paramRadau.WORK[6-1]=dValue;
  
  dValue=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_MAXSS,
    paramRadau.tEnd-paramRadau.tStart);
  if (!(dValue!=0.0)) stopMexFunction(519,0,0,0,0,0,dValue);
  paramRadau.WORK[7-1]=dValue;
  
  dValue=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_SSMINSEL,0.2);
  if (!((dValue<=1.0) && (dValue>0.0))) stopMexFunction(520,0,0,0,0,0,dValue);
  paramRadau.WORK[8-1]=dValue;
  
  dValue=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_SSMAXSEL,8.0);  
  if (!(dValue>=1.0)) stopMexFunction(521,0,0,0,0,0,dValue);
  paramRadau.WORK[9-1]=dValue;
}

static void prepareHelpMxArrays (void) {
  int d;

  d=paramGlobal.d;
  
  paramRightSide.tArg=mxCreateDoubleMatrix(1,1,mxREAL);
  paramRightSide.xArg=mxCreateDoubleMatrix(d,1,mxREAL);
  
  if ((paramOutput.outputFcnH!=NULL) || (paramRadau.denseFlag)) {
    paramOutput.tArg=mxCreateDoubleMatrix(1,1,mxREAL);
    paramOutput.xArg=mxCreateDoubleMatrix(paramGlobal.d,1,mxREAL);    
    paramOutput.emptyArg=mxCreateDoubleMatrix(1,0,mxREAL);
    paramOutput.toldArg=mxCreateDoubleMatrix(1,1,mxREAL);
  }
  
  if (paramJacobimatrix.IJAC!=0) {
    paramJacobimatrix.tArg=mxCreateDoubleMatrix(1,1,mxREAL);
    paramJacobimatrix.xArg=mxCreateDoubleMatrix(d,1,mxREAL);  
  }
}

static int callOutputFcn (int reason, double tOld, double t, double *x, int doCopy) {
  int doPoint,erg,offset;
  double *dpointer;
  mxArray* rhs[5];
  mxArray* lhs[1];
    
  if (paramOutput.outputFcnH==NULL) return 0;
  doPoint=0;lhs[0]=NULL;erg=0;
  switch (reason) {
    case 1: /* Init-Fall */
      offset=0;
      switch (paramGlobal.funcCallMethod) {
        case 0: break;
        case 1:
          rhs[offset++]=(mxArray*)paramOutput.outputFcnH;
          break;
        default: stopMexFunction(1002,0,0,0,0,0,0);break;
      }
      rhs[offset]=mxCreateDoubleMatrix(1,2,mxREAL);
      dpointer=mxGetPr(rhs[offset]);
      *dpointer=paramRadau.tStart;dpointer++;
      *dpointer=paramRadau.tEnd;
      offset++;
      
      rhs[offset]=mxCreateDoubleMatrix(paramGlobal.d,1,mxREAL);
      memcpy(mxGetPr(rhs[offset]),paramRadau.xStart,paramGlobal.d*sizeof(double));        
      offset++;

      rhs[offset++]=mxCreateString("init");

      switch (paramGlobal.funcCallMethod) {
        case 0:
          mexCallMATLAB(0,lhs,offset,rhs,paramOutput.outputFcn);
          while (--offset>=0) {mxDestroyArray(rhs[offset]);}
          break;
        case 1:
          mexCallMATLAB(0,lhs,offset,rhs,"feval");
          while (--offset>=1) {mxDestroyArray(rhs[offset]);}
          break;
        default: stopMexFunction(1002,0,0,0,0,0,0);break;
      }
      break;
    case 2: /* Done-Fall */
      offset=0;
      switch (paramGlobal.funcCallMethod) {
        case 0: break;
        case 1:
          rhs[offset++]=(mxArray*)paramOutput.outputFcnH;
          break;
        default: stopMexFunction(1002,0,0,0,0,0,0);break;
      }
      rhs[offset++]=mxCreateDoubleMatrix(0,0,mxREAL);
      rhs[offset++]=mxCreateDoubleMatrix(0,0,mxREAL);
      rhs[offset++]=mxCreateString("done");
      
      switch (paramGlobal.funcCallMethod) {
        case 0:
          mexCallMATLAB(0,lhs,offset,rhs,paramOutput.outputFcn);
          while (--offset>=0) {mxDestroyArray(rhs[offset]);}
          break;
        case 1:
          mexCallMATLAB(0,lhs,offset,rhs,"feval");
          while (--offset>=1) {mxDestroyArray(rhs[offset]);}
          break;
        default: stopMexFunction(1002,0,0,0,0,0,0);break;
      }
      break;
    case 3: /* Neuer Grid-Punkt */
      if ((paramRadau.denseFlag) && (paramOutput.outputCallMode==1)) break;
      doPoint=1;
      break;
    case 4: /* Neuer dense-Punkt */
      if ((paramRadau.denseFlag) && (paramOutput.outputCallMode==2)) break;
      doPoint=1;
      break;
    case 5: /* Neuer dense und Grid-Punkt */
      doPoint=1;
      break;
    default: stopMexFunction(1001,0,0,0,0,0,0);
  }
  
  if (doPoint) {
    *mxGetPr(paramOutput.tArg)=t;
    *mxGetPr(paramOutput.toldArg)=tOld;
    if (doCopy)
      memcpy(mxGetPr(paramOutput.xArg),x,paramGlobal.d*sizeof(double));

    offset=0;
    switch (paramGlobal.funcCallMethod) {
      case 0: break;
      case 1:
        rhs[offset++]=(mxArray*)paramOutput.outputFcnH;
        break;
      default: stopMexFunction(1002,0,0,0,0,0,0);break;
    }
    rhs[offset++]=paramOutput.tArg;rhs[offset++]=paramOutput.xArg;
    rhs[offset++]=paramOutput.emptyArg;
    rhs[offset++]=paramOutput.toldArg;
    
    switch (paramGlobal.funcCallMethod) {
      case 0:
        mexCallMATLAB(1,lhs,offset,rhs,paramOutput.outputFcn);
        break;
      case 1:
        mexCallMATLAB(1,lhs,offset,rhs,"feval");
        break;
      default: stopMexFunction(1002,0,0,0,0,0,0);break;
    }

    if (lhs[0]==NULL) {
      erg=0; 
    } else {
      erg=mxGetScalar(lhs[0]);
      mxDestroyArray(lhs[0]);
    }
  }

  return erg;
}

void RadauRightSideFunc (int *n, double *t,
  double *x, double *f,double *rpar, int *ipar) {
  int i,d,m1,m2,offset;
  mxArray *rhs[3];
  mxArray *lhs[1];
  (void) rpar;
  (void) ipar;
  d=*n;lhs[0]=NULL;

  /* Call by value */
  /* Use always the SAME Matlab tArg and xArg */
  /* IMPORTANT NOTICE (if the right side is also a MEX-File)
     the right side must not "garble" the passed mxArrays:
     the size must not be changed and the memory must not
     be freed. 
     Hence: the right side has to take care, that the
     passed mxArrays have the same size and enough memory
     when returning. The values in the memory(-block)
     may be overwritten.
     If the right side is an m-file MATLAB obeys this
     restriction automatically. */
  /* WICHTIGE Anmerkung (falls rechte Seite auch MEX-File ist)
     die rechte Seite darf die �bergebenen mxArrays nicht
     "verst�mmeln": die Gr��e darf nicht ver�ndert werden
     und auch der Speicherplatz darf nicht freigegeben werden.
     Also: die rechte Seite muss sicherstellen, dass die
     �bergebenen mxArrays am Ende wieder diesselbe Gr��e
     und ausreichend Speicher haben. Der Speicher selbst
     darf nat�rlich zu rechenzwecken �berschrieben werden.
     Bei m-Files achtet MATLAB automatisch darauf.
  */
  offset=0;
  switch (paramGlobal.funcCallMethod) {
    case 0: break;
    case 1:
      rhs[offset++]=(mxArray*)paramRightSide.rightSideFcnH;
      break;
    default: stopMexFunction(1002,0,0,0,0,0,0);
  }
  rhs[offset]=paramRightSide.tArg;*mxGetPr(rhs[offset])= *t;
  offset++;

  rhs[offset]=paramRightSide.xArg;
  memcpy(mxGetPr(rhs[offset]),x,d*sizeof(double));
  offset++;   
  
  switch (paramGlobal.funcCallMethod) {
    case 0:
      mexCallMATLAB(1,lhs,offset,rhs,paramRightSide.rightSideFcn);
      break;
    case 1:
      mexCallMATLAB(1,lhs,offset,rhs,"feval");
      break;
    default: stopMexFunction(1002,0,0,0,0,0,0);break;
  }
  
  /* check return values */
  if (lhs[0]==NULL) stopMexFunction(301,0,0,0,0,0,0);
  if ((!mxIsDouble(lhs[0])) || (mxGetNumberOfDimensions(lhs[0])!=2))
    stopMexFunction(302,0,0,0,0,0,0);
  m1=paramRadau.IWORK[9-1];m2=paramRadau.IWORK[10-1];
  if (m1==0) { 
    /* keine Spezialstruktur */
    if (!((((int)mxGetM(lhs[0])==d) && ((int)mxGetN(lhs[0])==1)) ||
          (((int)mxGetM(lhs[0])==1) && ((int)mxGetN(lhs[0])==d))))
      stopMexFunction(303,(int)mxGetM(lhs[0]),(int)mxGetN(lhs[0]),0,0,0,0);
    
    /* copy back */
    memcpy(f,mxGetPr(lhs[0]),d*sizeof(double));
  } else { 
    /* mit Spezialstruktur */
    if (!((((int)mxGetM(lhs[0])==d-m1) && ((int)mxGetN(lhs[0])==1)) ||
          (((int)mxGetM(lhs[0])==1) && ((int)mxGetN(lhs[0])==d-m1))))
      stopMexFunction(304,mxGetM(lhs[0]),mxGetN(lhs[0]),0,0,0,0);  
      
    /* Spezialstruktur eintragen: */
    for (i=0; i<m1; i++,f++) *f=x[i+m2];
    
    /* der Rest */
    memcpy(f,mxGetPr(lhs[0]),(d-m1)*sizeof(double));
  }
  
  /* free memory */
  mxDestroyArray(lhs[0]);  
}

void RadauSoloutFunc (int *nr, double *told,
  double *t, double *x, double *cont, int *lrc, 
  int *n,	
  double *rpar, int *ipar, int *irtrn) {
  int i,erg;
  double *dpointer;
  double tdense;
  int alreadySaved;
  (void) n;
  (void) rpar;
  (void) ipar;
  
  if (*nr==1) paramOutput.tPos=0;
  
  erg=0;
  if (paramRadau.denseFlag) {
    radauDense.cont=cont;radauDense.lrc=lrc;
    isInnerCall=(char)1;
    alreadySaved=0;
    while (1) {
      if (paramOutput.tPos>=paramGlobal.tLength) break;
      tdense=paramGlobal.tPointer[paramOutput.tPos];
      if (tdense==*t) {
        addTXtoList(*t,x);paramOutput.tPos++;
        alreadySaved=1;
        erg=callOutputFcn(5,*told,*t,x,1);if ((erg!=0) && (erg!=1)) erg=0;
        if (erg==1) {erg=-1;break;} /* Stop, NOW */
        continue;
      }
      if (paramGlobal.direction*(tdense-(*t))>0) break;
      
      dpointer=mxGetPr(paramOutput.xArg);
      
      for (i=1; i<=paramGlobal.d; i++,dpointer++)
        *dpointer=CONTR5_ (&i,&tdense,cont,lrc);
        
      dpointer=mxGetPr(paramOutput.xArg);
      addTXtoList(tdense,dpointer);
      erg=callOutputFcn(4,*told,tdense,dpointer,0);if ((erg!=0) && (erg!=1)) erg=0;
      if (erg==1) {erg=-1;break;} /* Stop, NOW */
      
      paramOutput.tPos++;
    }
    if (!alreadySaved) {
      if (paramOutput.includeGrid) addTXtoList(*t,x);
      erg=callOutputFcn(3,*told,*t,x,1);if ((erg!=0) && (erg!=1)) erg=0;
      if (erg==1) {erg=-1;} /* Stop, NOW */
    }
    isInnerCall=(char)0;
    radauDense.cont=NULL;radauDense.lrc=NULL;
  } else {
    addTXtoList(*t,x);
    erg=callOutputFcn(3,*told,*t,x,1);if ((erg!=0) && (erg!=1)) erg=0;
    if (erg==1) {erg=-1;} /* Stop, NOW */
  }
  
  *irtrn=erg;
}
void RadauMASFullFunc (int *n, double *am,
  int *lmas, double *rpar, int *ipar) {
  int d;
  
  d=paramGlobal.d;
  
  (void) n;
  (void) rpar;
  (void) ipar;
  (void) lmas;

  mxAssert(paramRadau.IWORK[9-1]==0,"internal error: RadauMASFullFunc: m1!=0");
  mxAssert(*lmas==d,"internal error: RadauMASFullFunc: unexpected lmas");

  /* durch extractMassMatrix wurde schon Typ/Dimension/Gr��e �berpr�ft */
  memcpy(am,mxGetPr(mxGetField(paramIO.opt,0,OPT_MASSMATRIX)),
    d*d*sizeof(double));
}

void RadauMASFullLRFunc (int *n, double *am,
  int *lmas, double *rpar, int *ipar) {
  int d,m1,len;
  
  d=paramGlobal.d;m1=paramRadau.IWORK[9-1];len=d-m1;
  (void) n;
  (void) rpar;
  (void) ipar;
  (void) lmas;
  
  mxAssert(m1!=0,"internal error: RadauMASFullLRFunc: m1==0");
  mxAssert(*lmas==len,"internal error: RadauMASFullLRFunc: unexpected lmas");
  
  /* durch extractMassMatrix wurde schon Typ/Dimension/Gr��e �berpr�ft */
  memcpy(am,mxGetPr(mxGetField(paramIO.opt,0,OPT_MASSMATRIX)),
    len*len*sizeof(double));
}

void RadauMASBandedMatrixFunc (int *n, double *am,
  int *lmas, double *rpar, int *ipar) {
  int d,len;
  mxArray *mField;
  (void) n;
  (void) rpar;
  (void) ipar;
  (void) lmas;
  
  d=paramGlobal.d;len=1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS;
  mxAssert(paramRadau.IWORK[9-1]==0,"internal error: RadauMASBandedMatrixFunc: m1!=0");
  mxAssert(len==*lmas,"internal error: RadauMASBandedMatrixFunc: enexpected lmas");
    
  mField=mxGetField(paramIO.opt,0,OPT_MASSMATRIX);
  /* durch extractMassMatrix wurde schon Typ/Dimension/Gr��e �berpr�ft */
  memcpy(am,mxGetPr(mField),len*d*sizeof(double));
}

void RadauMASBandedCellFunc (int *n, double *am,
  int *lmas, double *rpar, int *ipar) {
  int i,j,len;
  double *dpointer;
  
  mxArray *mField,*cellField;
  
  (void) n;
  (void) rpar;
  (void) ipar;
  
  len=1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS;
  
  mxAssert(paramRadau.IWORK[9-1]==0,"internal error: RadauMASBandedCellFunc: m1!=0");
  mxAssert(len==*lmas,"internal error: RadauMASBandedCellFunc: unexpected lmas");
  
  mField=mxGetField(paramIO.opt,0,OPT_MASSMATRIX);
  /* durch extractMassMatrix wurde schon Typ/Dimension/Gr��e des cells 
     �berpr�ft, NCIHT aber der Typ/Dimension/Gr��e der cell-Eintr�ge */
     
  for (i=paramMassmatrix.MUMAS; i>=-paramMassmatrix.MLMAS; i--) {
    /* ACHTUNG: cells beginnen bei 0 mit der Indizierung */
    cellField=mxGetCell(mField,paramMassmatrix.MUMAS-i); 
    len=paramGlobal.d-abs(i);
    if ((cellField==NULL) || (!mxIsDouble(cellField)) || 
        (mxGetNumberOfDimensions(cellField)!=2))
      stopMexFunction(111,paramMassmatrix.MUMAS-i+1,0,0,0,0,0);
    if (((int)mxGetM(cellField)!=1) || ((int)mxGetN(cellField)!=len))
      stopMexFunction(112,paramMassmatrix.MUMAS-i+1,
        mxGetM(cellField),mxGetN(cellField),len,0,0);
    dpointer=mxGetPr(cellField);
    for (j=0; j<len; j++,dpointer++)
      am[paramMassmatrix.MUMAS+(j+(i>0?i:0))*(*lmas)-i]= *dpointer;
  }  
}

void RadauMASBandedLRMatrixFunc (int *n, double *am,
  int *lmas, double *rpar, int *ipar) {
  int d,m1,len;
  mxArray *mField;
  
  (void) n;
  (void) rpar;
  (void) ipar;
  
  d=paramGlobal.d;
  len=1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS;
  m1=paramRadau.IWORK[9-1];
  
  mxAssert(m1!=0,"internal error: RadauMASBandedMatrixFunc: m1==0");
  mxAssert(len==*lmas,"internal error: RadauMASBandedMatrixFunc: unexpected lmas");
    
  mField=mxGetField(paramIO.opt,0,OPT_MASSMATRIX);
  /* durch extractMassMatrix wurde schon Typ/Dimension/Gr��e �berpr�ft */
  
  memcpy(am,mxGetPr(mField),len*(d-m1)*sizeof(double));  
}

void RadauMASBandedLRCellFunc (int *n, double *am,
  int *lmas, double *rpar, int *ipar) {
  int i,j,m1,len;
  double *dpointer;
  mxArray *mField,*cellField;
  
  (void) n;
  (void) rpar;
  (void) ipar;
  
  len=1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS;
  m1=paramRadau.IWORK[9-1];
  
  mxAssert(m1!=0,"internal error: RadauMASBandedLRCellFunc: m1==0");
  mxAssert(len==*lmas,"internal error: RadauMASBandedCellFunc: unexpected lmas");
  
  mField=mxGetField(paramIO.opt,0,OPT_MASSMATRIX);
  /* durch extractMassMatrix wurde schon Typ/Dimension/Gr��e des cells 
     �berpr�ft, NCIHT aber der Typ/Dimension/Gr��e der cell-Eintr�ge */
     
  for (i=paramMassmatrix.MUMAS; i>=-paramMassmatrix.MLMAS; i--) {
    /* ACHTUNG: cells beginnen bei 0 mit der Indizierung */
    cellField=mxGetCell(mField,paramMassmatrix.MUMAS-i); 
    len=paramGlobal.d-m1-abs(i);
    if ((cellField==NULL) || (!mxIsDouble(cellField)) || 
        (mxGetNumberOfDimensions(cellField)!=2))
      stopMexFunction(113,paramMassmatrix.MUMAS-i+1,0,0,0,0,0);
    if (((int)mxGetM(cellField)!=1) || ((int)mxGetN(cellField)!=len))
      stopMexFunction(114,paramMassmatrix.MUMAS-i+1,
        mxGetM(cellField),mxGetN(cellField),len,0,0);
    dpointer=mxGetPr(cellField);
    for (j=0; j<len; j++,dpointer++)
      am[paramMassmatrix.MUMAS+(j+(i>0?i:0))*(*lmas)-i]= *dpointer;
  }  
}

void RadauJACFullFunc (int *n, double *t,
  double *x, double *dfy, int *ldfy, double *rpar, int *ipar) {
  int d,offset;
  mxArray *rhs[3],*lhs[1];

  (void) n;
  (void) rpar;
  (void) ipar;
  (void) ldfy;
  
  d=paramGlobal.d;lhs[0]=NULL;  
  
  mxAssert(paramRadau.IWORK[9-1]==0,"internal error: RadauJACFullFunc: m1!=0");
  mxAssert(*ldfy==d,"internal error: RadauJACFullFunc: unexpected ldfy");      
  
  /* Call by value */
  offset=0;
  switch (paramGlobal.funcCallMethod) {
    case 0: break;
    case 1:
      rhs[offset++]=(mxArray*)paramJacobimatrix.jacFcnH;
      break;
    default: stopMexFunction(1002,0,0,0,0,0,0);
  }
  rhs[offset]=paramJacobimatrix.tArg;
  *mxGetPr(rhs[offset])=*t;
  offset++;

  rhs[offset]=paramJacobimatrix.xArg;
  memcpy(mxGetPr(rhs[offset]),x,d*sizeof(double));
  offset++;
  
  /* Call User's jac function */
  switch (paramGlobal.funcCallMethod) {
    case 0:
      mexCallMATLAB(1,lhs,offset,rhs,paramJacobimatrix.jacFcn);
      break;
    case 1:
      mexCallMATLAB(1,lhs,offset,rhs,"feval");
      break;
    default: stopMexFunction(1002,0,0,0,0,0,0);
  }
  
  /* check return value */
  if (lhs[0]==NULL) stopMexFunction(204,0,0,0,0,0,0);
  if ((!mxIsDouble(lhs[0])) || (mxGetNumberOfDimensions(lhs[0])!=2))
    stopMexFunction(205,0,0,0,0,0,0);
  if (((int)mxGetM(lhs[0])!=d) || ((int)mxGetN(lhs[0])!=d))
    stopMexFunction(206,mxGetM(lhs[0]),mxGetN(lhs[0]),0,0,0,0);
  
  /* copy back */
  memcpy(dfy,mxGetPr(lhs[0]),d*d*sizeof(double));
  
  /* free memory */
  mxDestroyArray(lhs[0]);
}

void RadauJACFullLFunc (int *n, double *t,
  double *x, double *dfy, int *ldfy, double *rpar, int *ipar) {
  int d,m1,len,offset;
  mxArray *rhs[3],*lhs[1];
  (void) n;
  (void) rpar;
  (void) ipar;
  (void) ldfy;
  d=paramGlobal.d;m1=paramRadau.IWORK[9-1];lhs[0]=NULL;  
  len=d-m1;
  mxAssert(m1!=0,"internal error: RadauJACFullLFunc: m1==0");
  mxAssert(*ldfy==len,"internal error: RadauJACFullLFunc: unexpected ldfy");
    
  /* Call by value */
  offset=0;
  switch (paramGlobal.funcCallMethod) {
    case 0: break;
    case 1:
      rhs[offset++]=(mxArray*)paramJacobimatrix.jacFcnH;
      break;
    default: stopMexFunction(1002,0,0,0,0,0,0);
  }
  rhs[offset]=paramJacobimatrix.tArg;*mxGetPr(rhs[offset])=*t;
  offset++;

  rhs[offset]=paramJacobimatrix.xArg;
  memcpy(mxGetPr(rhs[offset]),x,d*sizeof(double));
  offset++;
  
  /* Call User's jac function */
  switch (paramGlobal.funcCallMethod) {
    case 0:
      mexCallMATLAB(1,lhs,offset,rhs,paramJacobimatrix.jacFcn);
      break;
    case 1:
      mexCallMATLAB(1,lhs,offset,rhs,"feval");
      break;
    default: stopMexFunction(1002,0,0,0,0,0,0);
  }
  
  /* check return value */
  if (lhs[0]==NULL) stopMexFunction(204,0,0,0,0,0,0);
  if ((!mxIsDouble(lhs[0])) || (mxGetNumberOfDimensions(lhs[0])!=2))
    stopMexFunction(207,0,0,0,0,0,0);
  if (((int)mxGetM(lhs[0])!=len) || ((int)mxGetN(lhs[0])!=paramGlobal.d))
    stopMexFunction(208,mxGetM(lhs[0]),mxGetN(lhs[0]),0,0,0,0);

  /* copy back */
  memcpy(dfy,mxGetPr(lhs[0]),len*paramGlobal.d*sizeof(double));
  
  /* free memory */
  mxDestroyArray(lhs[0]);
}

void RadauJACBandedFunc (int *n, double *t,
  double *x, double *dfy, int *ldfy, double *rpar, int *ipar) {
  int i,j,d,len,offset;
  double *dpointer;
  mxArray *rhs[3],*lhs[1];
  mxArray *cellField;
  (void) n;
  (void) rpar;
  (void) ipar;
  d=paramGlobal.d;lhs[0]=NULL;  
  len=paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC+1;
  mxAssert(paramRadau.IWORK[9-1]==0,"internal error: RadauJACBandedFunc: m1!=0");
  mxAssert(*ldfy==len,"internal error: RadauJACBandedFunc: unexpected ldfy");  
  
  /* Call by value */
  offset=0;
  switch (paramGlobal.funcCallMethod) {
    case 0: break;
    case 1:
      rhs[offset++]=(mxArray*)paramJacobimatrix.jacFcnH;
      break;
    default: stopMexFunction(1002,0,0,0,0,0,0);
  }
  rhs[offset]=paramJacobimatrix.tArg;
  
  *mxGetPr(rhs[offset])=*t;
  offset++;

  rhs[offset]=paramJacobimatrix.xArg;
  memcpy(mxGetPr(rhs[offset]),x,d*sizeof(double));
  offset++;
  
  /* Call User's jac function */
  switch (paramGlobal.funcCallMethod) {
    case 0:
      mexCallMATLAB(1,lhs,offset,rhs,paramJacobimatrix.jacFcn);
      break;
    case 1:
      mexCallMATLAB(1,lhs,offset,rhs,"feval");
      break;
    default: stopMexFunction(1002,0,0,0,0,0,0);
  }
  
  /* check return value */
  if (lhs[0]==NULL) stopMexFunction(204,0,0,0,0,0,0);
  if ((!mxIsCell(lhs[0])) && (!mxIsDouble(lhs[0])))
    stopMexFunction(209,0,0,0,0,0,0);
  if (mxIsCell(lhs[0])) {
    if (mxGetNumberOfDimensions(lhs[0])!=2) stopMexFunction(224,0,0,0,0,0,0);
    if (((int)mxGetM(lhs[0])!=1) || ((int)mxGetN(lhs[0])!=len))
      stopMexFunction(210,mxGetM(lhs[0]),mxGetN(lhs[0]),0,0,0,0);
    for (i=paramJacobimatrix.MUJAC; i>=-paramJacobimatrix.MLJAC; i--) {
      /* ACHTUNG: cells beginnen bei 0 mit der Indizierung */
      cellField=mxGetCell(lhs[0],paramJacobimatrix.MUJAC-i); 
      len=paramGlobal.d-abs(i);
      if ((cellField==NULL) || (!mxIsDouble(cellField)) || 
          (mxGetNumberOfDimensions(cellField)!=2))
        stopMexFunction(211,paramJacobimatrix.MUJAC-i+1,0,0,0,0,0);
      if (((int)mxGetM(cellField)!=1) || ((int)mxGetN(cellField)!=len))
        stopMexFunction(212,paramJacobimatrix.MUJAC-i+1,len,
        mxGetM(cellField),mxGetN(cellField),0,0);
      dpointer=mxGetPr(cellField);
      for (j=0; j<len; j++,dpointer++)
        dfy[paramJacobimatrix.MUJAC+(j+(i>0?i:0))*(*ldfy)-i]= *dpointer;
    }
  }
  if (mxIsDouble(lhs[0])) {
    if (mxGetNumberOfDimensions(lhs[0])!=2) stopMexFunction(213,0,0,0,0,0,0);
    if (((int)mxGetM(lhs[0])!=len) || ((int)mxGetN(lhs[0])!=d))
      stopMexFunction(214,mxGetM(lhs[0]),mxGetN(lhs[0]),0,0,0,0);
    memcpy(dfy,mxGetPr(lhs[0]),len*d*sizeof(double));
  }
    
  /* free memory */
  mxDestroyArray(lhs[0]);
}

void RadauJACBandedLFunc (int *n, double *t,
  double *x, double *dfy, int *ldfy, double *rpar, int *ipar) {
  int i,j,k,d,m2,len,offset;
  double *dpointer;
  mxArray *rhs[3],*lhs[1];
  mxArray *cellField,*innerField;
  (void) n;
  (void) rpar;
  (void) ipar;
  d=paramGlobal.d;lhs[0]=NULL;
  m2=paramRadau.IWORK[10-1];
  len=paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC+1;
  mxAssert(paramRadau.IWORK[9-1]!=0,"internal error: RadauJACBandedLFunc: m1==0");
  mxAssert(*ldfy==len,"internal error: RadauJACBandedLFunc: unexpected ldfy");
  
  /* Call by value */
  offset=0;
  switch (paramGlobal.funcCallMethod) {
    case 0: break;
    case 1:
      rhs[offset++]=(mxArray*)paramJacobimatrix.jacFcnH;
      break;
    default: stopMexFunction(1002,0,0,0,0,0,0);
  }
  rhs[offset]=paramJacobimatrix.tArg;*mxGetPr(rhs[offset])=*t;
  offset++;

  rhs[offset]=paramJacobimatrix.xArg;
  memcpy(mxGetPr(rhs[offset]),x,d*sizeof(double));
  offset++;
  
  /* Call User's jac function */
  switch (paramGlobal.funcCallMethod) {
    case 0:
      mexCallMATLAB(1,lhs,offset,rhs,paramJacobimatrix.jacFcn);
      break;
    case 1:
      mexCallMATLAB(1,lhs,offset,rhs,"feval");
      break;
    default: stopMexFunction(1002,0,0,0,0,0,0);
  }
  
  /* check return value */
  if (lhs[0]==NULL) stopMexFunction(204,0,0,0,0,0,0);
  if ((!mxIsCell(lhs[0])) || (mxGetNumberOfDimensions(lhs[0])!=2))
    stopMexFunction(215,0,0,0,0,0,0);
  if (((int)mxGetM(lhs[0])!=1) || ((int)mxGetN(lhs[0])!=paramRadau.mm+1))
    stopMexFunction(216,mxGetM(lhs[0]),mxGetN(lhs[0]),0,0,0,0);
  for (k=0; k<paramRadau.mm+1; k++) { 
    /* Schleife �ber alle Teilmatrizen */
    cellField=mxGetCell(lhs[0],k);
    if (cellField==NULL) stopMexFunction(217,k,0,0,0,0,0);
    if ((!mxIsDouble(cellField)) && (!mxIsCell(cellField)))
      stopMexFunction(218,k,0,0,0,0,0);
    if (mxGetNumberOfDimensions(cellField)!=2) 
      stopMexFunction(219,k,0,0,0,0,0);
    if (mxIsDouble(cellField)) { 
      /* diese banded Teilmatrix wird als Matrix �bergeben */
      if (((int)mxGetM(cellField)!=len) || ((int)mxGetN(cellField)!=m2))
        stopMexFunction(220,k,mxGetM(cellField),mxGetN(cellField),0,0,0);
      memcpy(dfy+(k*(*ldfy)*m2),mxGetPr(cellField),len*m2*sizeof(double));
    }
    if (mxIsCell(cellField)) { 
      /* diese banded Teilmatrix wird als cell �bergeben */
      if (((int)mxGetM(cellField)!=1) || ((int)mxGetN(cellField)!=len))
        stopMexFunction(221,k,mxGetM(cellField),mxGetN(cellField),0,0,0);
      for (i=paramJacobimatrix.MUJAC; i>=-paramJacobimatrix.MLJAC; i--) { 
        /* Schleife �ber alle diag-Vektoren */
        innerField=mxGetCell(cellField,paramJacobimatrix.MUJAC-i);
        if ((innerField==NULL) || (!mxIsDouble(innerField)) ||
            (mxGetNumberOfDimensions(innerField)!=2))
          stopMexFunction(222,k,paramJacobimatrix.MUJAC-i+1,0,0,0,0);
        len=m2-abs(i);
        if (((int)mxGetM(innerField)!=1) || ((int)mxGetN(innerField)!=len))
          stopMexFunction(223,k,paramJacobimatrix.MUJAC-i+1,len,
          mxGetM(innerField),mxGetN(innerField),0);
        dpointer=mxGetPr(innerField);
        for (j=0; j<len; j++,dpointer++)
          dfy[k*(*ldfy)*m2+paramJacobimatrix.MUJAC+(j+(i>0?i:0))*(*ldfy)-i]= *dpointer;
      }
    }
  }
  
  /* free memory */
  mxDestroyArray(lhs[0]);
}

static void createTXArrays (mxArray* plhs[]) {
  int i,d,count,n;
  PListElement current;
  double *tPointer, *xPointer, *vPointer;
  
  d=paramGlobal.d;n=paramOutput.numberOfElements;
  plhs[0]=mxCreateDoubleMatrix(n,1,mxREAL);
  plhs[1]=mxCreateDoubleMatrix(n,d,mxREAL);
  
  tPointer=mxGetPr(plhs[0]);
  xPointer=mxGetPr(plhs[1]);
  
  current=paramOutput.txList.next;
  count=0;
  while (current!=NULL) {
    vPointer=current->values;
    *tPointer= *vPointer; tPointer++; vPointer++;
    for (i=0; i<d; i++,vPointer++) xPointer[count+i*n]= *vPointer;
    
    current=current->next;count++;
  }
}

static void createStatVector (mxArray* plhs[]) {
  int i;
  double *dpointer;
  
  plhs[2]=mxCreateDoubleMatrix(1,8,mxREAL);
  dpointer=mxGetPr(plhs[2]);
  
  *dpointer=paramRadau.IDID;dpointer++;
  for (i=14-1; i<=20-1; i++) {
    *dpointer=paramRadau.IWORK[i];dpointer++;
  }
}

static void createHPred (mxArray* plhs[]) {
  plhs[3]=mxCreateDoubleMatrix(1,1,mxREAL);
  
  *mxGetPr(plhs[3])=paramRadau.h;
}

static void createOutput (int nlhs, mxArray* plhs[]) {
  createTXArrays(plhs);
  
  if (nlhs>=3) createStatVector(plhs);
  if (nlhs>=4) createHPred(plhs);
}

static void doInnerCall (int nlhs, mxArray *plhs[],
                         int nrhs, const mxArray *prhs[]) {
  /* So jetzt wird es trickreich: Wenn wir jetzt
       stopMexFunction(...);
     aufrufen, so ist das f�r Matlab t�dlich!
     Begr�ndung:
     Schauen wir uns jetzt einmal den Stack in diesem Moment an:
       radau5Mex (InnerCall)
       Matlab m-file
       dopridMex (NormalCall)
       Matlab (bsp. Command-Line)
     Wenn ich jetzt stopMexFunction mache, dann wird ALLES
     von dopriMex aufger�umt und dann mexErrMsgTxt aufgerufen.
     Matlab will jetzt gepfelgt den kompletten Stack von oben
     nach unten abarbeiten und den Speicher aufr�umen. Aber 
     da w�ren wir ja schon schneller gewesen, so dass Matlab
     auf dem Stack ung�ltige Speicherhandles findet ... und sich
     damit verabschiedet!! 
     Deshalb beenden wir uns jetzt, OHNE unseren Speicher 
     aufzur�umen. Damit verlassen wir uns darauf, dass Matlab
     unseren ganzen Sch... aufr�umt! Dies sollte problemlos funktionieren,
     aber ich habe mich noch NIE auf sowas verlassen, bis jetzt ... */

  int i;
  double t;
  double *dpointer;
  const mxArray *tArg;
  mxArray *xArg;

  if ((nlhs!=1) || (nrhs!=1)) stopMexFunctionImpl(601,0,0,0,0,0,0.0,(char)0);
  
  tArg=prhs[0];
  if ((tArg==NULL) || (mxIsEmpty(tArg))) 
    stopMexFunctionImpl(602,0,0,0,0,0,0.0,(char)0);
  if (!mxIsDouble(tArg) || (mxIsSparse(tArg)) ||
     (mxGetNumberOfDimensions(tArg)!=2) ||
     (mxGetM(tArg)!=1) || (mxGetN(tArg)!=1))
    stopMexFunctionImpl(603,0,0,0,0,0,0.0,(char)0);
  t= *mxGetPr(tArg);

  xArg=mxCreateDoubleMatrix(1,paramGlobal.d,mxREAL);
  dpointer=mxGetPr(xArg);
  for (i=1; i<=paramGlobal.d; i++,dpointer++) {
    *dpointer= CONTR5_ (&i,&t,radauDense.cont,radauDense.lrc);
  }
  plhs[0]=xArg;
}

void mexFunction (int nlhs, mxArray* plhs[],
                  int nrhs, const mxArray* prhs[]) {
  /* check for inner call during Solout routine */
  if (isInnerCall && (nrhs==1)) {doInnerCall(nlhs,plhs,nrhs,prhs);return;}
  initVars();
  
  checkNumberOfArgs(nlhs,nrhs);
  processArgs(nrhs,prhs);
  
  extractOptionsPart1();  
  prepareIWORKArray();
  extractOptionsPart2();
  prepareWORKArray();
  prepareHelpMxArrays();

  callOutputFcn(1,0.0,0.0,NULL,0);
  RADAU5_(&paramGlobal.d,&RadauRightSideFunc,
    &paramRadau.tStart,paramRadau.xStart,&paramRadau.tEnd,&paramRadau.h,
    paramRadau.RTOL,paramRadau.ATOL,&paramRadau.ITOL,
    paramJacobimatrix.radauJACFunc,&paramJacobimatrix.IJAC,
    &paramJacobimatrix.MLJAC,&paramJacobimatrix.MUJAC,
    paramMassmatrix.radauMASFunc,&paramMassmatrix.IMAS,
    &paramMassmatrix.MLMAS,&paramMassmatrix.MUMAS,
    &RadauSoloutFunc,&paramRadau.IOUT,
    paramRadau.WORK,&paramRadau.LWORK,
    paramRadau.IWORK,&paramRadau.LIWORK,
    paramRadau.RPAR,paramRadau.IPAR,&paramRadau.IDID);
  callOutputFcn(2,0.0,0.0,NULL,0);
  
  createOutput(nlhs,plhs);
  
  doneVars();
}
