% function varargout = getVersionNeweulm2
% Function to enter the version of Neweul-M2, its release date and the
% current date into the data structure at sys.settings.version.
% This helps should there be any problems with old models.
%
% Return values:
% version ........ If a return value is specified, return the version,
%                  otherwise insert data into the system structure with the
%                  following fields under: sys.settings.version:
% versionFirst ... Version of neweul of the first run of this model
% version ........ Version number of Neweul-M2
% versionTime .... Date when this version was released
% versionSHA1 .... SHA1 hash key of this version out of GIT version control
% evalTime ....... Time when this function was called
% isMupad ........ Has the Mupad symbolic engine been used
%
% First appearance: 09.08.2010
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
