% writeSetValDef(fid,varargin)
% writeSetValDef - With the introduction of state dependent parameters for
% the definition of force elements, some problems occured. To evaluate a
% value for these parameters the describing equations have to be evaluated
% at the set values for the linearization. But in the files for numerical
% evaluation of the vectors and matrices of the linearized equations of
% motion these values are not always available, and even if they are, they
% are not defined in a vector form. Therefore this function initializes the
% vector of set values, which in this context is called 'y_' so it can be
% passed to the functions evaluating the values of state dependent
% parameters.
% 
% Function call is comparable to writeHelpVarDef.m:
% writeSetValDef(fid,SymbolicParameter)
% fid ................. File identifier
% SymbolicParameter ... Parameter, for which the file is created
% 
% See also: writeGencoordDef, writeHelpvarDef
%
% First appearance: 30.05.2008
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
