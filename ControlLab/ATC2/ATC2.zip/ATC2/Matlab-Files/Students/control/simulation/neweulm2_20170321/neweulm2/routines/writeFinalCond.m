% writeFinalCond - This function creates an output function if necessary
% This can be caused be a final condition, defined in
% sys.settings.timeInt.finalCond or by an option to display results or the
% progress during the time integration, which is set in
% sys.settings.timeInt.display
%
% See also: timeInt, runSensAn, runSysOpt
%
% First appearance: 01.12.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
