function res_ = f_D2RV(t,y_,varargin)

res_ = 0; % Default return value
