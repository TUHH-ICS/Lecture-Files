function v = f_v(t)
% f_v - definition of time-depending user-defined variable v
% Rear axle

global sys;



% constant user-defined variables

c = sys.parameters.data.c;
excitation_phase = sys.parameters.data.excitation_phase;
z = sys.parameters.data.z;


% time dependent user-defined variables

v = zeros(1,1);

if(0.1560 < t && t < 0.7560)
    v(1) = 0.5*z*(1-cos(c*t+excitation_phase));
end