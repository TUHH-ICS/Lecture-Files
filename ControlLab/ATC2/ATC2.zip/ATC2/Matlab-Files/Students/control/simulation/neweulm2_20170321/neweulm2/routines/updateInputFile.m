% res = updateInputFile(filename)
% Function to update input files to new file names and new data structure.
% This is necessary due to a change in July 2012, where the data structure
% and some filenames have been rearranged. If no filename is given, all
% files in the current folder are used, if the file 'startSysDef.m' is
% present. Otherwise, this function assumes that the current folder does
% not contain Neweul-M2 input files. However, you can still specify the
% files to be converted manually
% 
% Input arguments
% filename .... Filename of the file to be converted, if none given, all
%               files are used
%
% First appearance: 15.08.2012
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
