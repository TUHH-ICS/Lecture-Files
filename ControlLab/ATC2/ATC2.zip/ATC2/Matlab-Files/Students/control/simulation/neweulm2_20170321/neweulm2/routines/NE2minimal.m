% NE2minimal - Set up the equations of motion in minimal form. If
% abbreviations are used, this requires first to replace them by their
% respective values.
% 
% Input arguments
% Cells ....... Specify whether the return values of Jg, qa, ... shall
%               remain cell arrays or if they shall be stacked as symbolic
%               arrays {true}
% minimal ..... Logical parameter whether the equations in minimal form
%               shall be calculated. If not, only the abbreviations are
%               removed {true}
% replaceAll .. Replace all abbreviations by their values, even the scalar
%               ones {false}
% store ....... Store the results in the system data structure, here only
%               the Newton-Euler expressions are considered. Minimal
%               expressions are always stored in sys.dynamics.nonlinear.minimal {false}
%
% See also: calcEqMotNonLin, writeMbsNonLin
%
% First appearance: 01.07.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
