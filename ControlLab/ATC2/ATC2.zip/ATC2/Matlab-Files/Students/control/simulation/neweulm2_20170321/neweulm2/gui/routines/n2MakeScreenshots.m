% res_ = neweulm2MakeScreenshots(varargin)
% neweulm2MakeScreenshots - Model the system in the current directory and
% run all available simulations. After this, open the GUI and make a
% screenshot of every available GUI. These pictures are saved in a folder
% called screenshots in the current folder.
%
% Optional input arguments {standard value}
% Commands ...... Used modeling commands
%       {{'startSysDef','runTimeInt','runKiAn','runModalAnalysis'}
% FileName ...... When the option 'OnlyOne' is used, you can specify the
%                 filename {}
% FilePath ...... When the option 'OnlyOne' is used, you can specify the
%                 path to the file {'screenshots/'}
% FileType ...... Image file type {'png'}
% OnlyOne ....... If only one screenshot shall be made, please pass the
%                 figure handle {}
% useElement .... Show GUIs for modeling element specific things {true}
% useGeneral .... Show GUIs for general settings {true}
% useGraphics ... Show GUI for graphic objects {true}
% useModeling ... Logical of whether to use the modeling commands {true}
% useResult ..... Logical wheter to use the results for some plots {true}
%
% Return arguments
% res_ .......... If everything went well, true is returned
%
% Example: 
%   n2MakeScreenshots
%   n2MakeScreenshots('useModeling',true, 'useGeneral',true, ...
%       'useElements',true, 'useGraphics',true, 'useResults',true);
%
% First appearance: 02.09.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
