function res_ = f_RV(t,y_,varargin)
% res_ = f_RV(t,y_,varargin)
% f_RV - definition of state-depending user-defined variable RV
% Positions, velocities, ... of coordinate systems can be calculated by
% calling the functions in 'sysFunctions', e.g. body1_r

global sys;

Dy_ = zeros(sys.counters.genCoord,1); % Default value for derivatives
% Treat optional input arguments
if(length(varargin) == 1)
	% Call was f_RV(t,y_,Dy_)
	% Generalized velocities have been passed
	Dy_ = varargin{1};
elseif(nargin==1 && ischar(t) && strcmp(t,'linearization'))
	% Case IV: Call was f_...('linearization')
	% Return symbolic expression to calculate the linearization
	% Necessary for all parameters appearing in the equations of motion to linearize!
    symRoadF_S = getAbsoluteKinematics('S','RoadF','ISYS');
    symRoadF_r = getAbsoluteKinematics('r','ISYS','RoadF');
    symRoadF_v = getAbsoluteKinematics('v','ISYS','RoadF');
    symRoadF_o = getAbsoluteKinematics('omega','ISYS','RoadF');
    symFA_r    = getAbsoluteKinematics('r','ISYS','FA');
    symFA_v    = getAbsoluteKinematics('v','ISYS','FA');
    r_ = transpose(symRoadF_S)*(symFA_r-symRoadF_r);
    r_ = mapleSimplify(r_,'combine');
    v_ = transpose(symRoadF_S)*(symFA_v-symRoadF_v);
    Dphi_Dirdef_ = transpose(symRoadF_S)*symRoadF_o;
    v_ = v_ - cross(Dphi_Dirdef_,r_);
    v_ = mapleSimplify(v_(3),'combine');
    x_ = r_(3)-sym('r0');
    c_ = sym('ctf');
    d_ = sym('dtf');
    res_ = mapleSimplify(c_*x_+d_*v_);
	return;
end

% Force law of the front tire
% Parameters
r0 = sys.parameters.data.r0; % Nominal length
ctf = sys.parameters.data.ctf; % Stiffness
dtf = sys.parameters.data.dtf; % Damping

% Calculate the positions of the two coordinate systems involved
FAr = FA_r(t,y_);
RoadFr = RoadF_r(t,y_);

% distance in z-direction, without nominal length
r = FAr(3) - RoadFr(3) - r0;

% Calculate the velocities of the two coordinate systems involved
FAv = FA_v(t,y_,Dy_);
RoadFv = RoadF_v(t,y_,Dy_);
% Relative velocity in z-direction
v = FAv(3) - RoadFv(3);

% Calculate force
res_ = ctf * r + dtf * v;

% Respect lifting off of the tire, therefore: force < 0
if(sys.parameters.data.useLiftOff)
    res_ = min(res_, 0);
end
