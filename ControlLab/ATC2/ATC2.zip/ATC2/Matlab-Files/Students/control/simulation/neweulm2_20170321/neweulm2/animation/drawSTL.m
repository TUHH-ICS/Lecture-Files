% drawSTL - include graphical representation of a body stored in a STL-file
% 
%  Description:
% This code is to import CAD (CT) data in stl format (ASCII) 
% and register into original CT Frame. This function requires the file
% cad2mat.m to read the cad data from a file to Matlab.
%
%
%  Input arguments:
% filename ... Filename of exported CAD data, {required}
% c  ......... Offset vector c= [cx, cy, cz], {[0 0 0]}
%              this parameter may contain symbolic constants of Neweul-M2
% dx,dy,dz ... Scale factors in three dimensions, {1}
%              this parameter may contain symbolic constants of Neweul-M2
% fcolor ..... A three-element RGB vector or one of the MATLAB
%              predefined names, specifying a single color for faces
%              {[0 0 1]}
% ecolor ..... Edgecolor in the same format {[0 0 1]}
% 
%  Optional arguments, given pairwise:
% Tag ............. Set Tag property, for identification {'STL_1'}
% FaceColor ....... Color of the faces {'none'}
% EdgeColor ....... Color of the edges {'none'}
% Color ........... Set face and edgecolor to the same, overwrites color
%                   specified before
% FaceAlpha ....... Transparency of the faces {1}
% EdgeAlpha ....... Transparency of the edges {1}
% Frame ........... Specify the coordinate system of Neweul-M2 to attach
%                   this shape to. Otherwise you would have to call
%                   addGraphics manually {[]}
% CheckVarargin ... An advanced feature to avoid errors if invalid
%                   parameters are passed. This is only if you know
%                   exactly what you are doing. {true}
%
%  Return parameters:
% h .......... Handle to the graphic object
% 
%  See also: 
% drawArrow3d, drawCube, drawElasticBeam, drawLine, drawRotBody,
% drawSphere, drawSpring, cad2mat
%
% First appearance: 09.04.2009
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
