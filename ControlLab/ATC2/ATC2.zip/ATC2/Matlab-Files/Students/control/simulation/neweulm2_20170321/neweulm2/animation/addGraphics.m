% addGraphics - Attach graphic object(s) to hgtransform group
% 
%  Description:
% Attach graphic object(s) to hgtransform group of a
% coordinate system. The coordinate system has to be perviously defined,
% but if the animation window has been closed it will not pose problems.
% Then the information is just introduced into the system data structure.
%
%  Input arguments:
% frame ......... Coordinate system
% objHandle ..... Graphics handle(s)
% createEntry ... Boolean variable to decide if an entry to the data
%                 structure shall be made. {true}
% 
%  See also:
% drawArrow3d, drawCube, drawLine, drawRotBody, drawSphere, drawSTL
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
