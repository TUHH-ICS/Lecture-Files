% [result] = freqAnim(t,in,amp_in, freq,varargin)
%
% Input arguments
% t		time
% in		System input
% amp_in	value of input
% freq		frequency at which response shall be calculated
%
% Return values
% result 	structur containing the frequency response
% 	phi	frequency response
% 	ref.y	reference point / linearization point
% 	f0	evaluation frequency
%
% Optional input arguments, should be specified in pairs, {default values}
% 'inits' ................ {true}|false -> initSys
% 'startanim' ............. true|{false} -> start anim
% 'framesPerPeriod'	    frames per period
%
% Example function calls:
% [result ye_ t_] = freqAnim(t,in,2e-2, 2e3,'amplitude',1,'startanim',true);
% numerical linearization
% [result ye_ t_] = freqAnim(t,in,2e-2, 2e3,'amplitude',1,'startanim',true,'numlin',true);
