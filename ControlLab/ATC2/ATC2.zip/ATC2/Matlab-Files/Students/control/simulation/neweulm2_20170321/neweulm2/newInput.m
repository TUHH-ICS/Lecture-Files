% newInput(varargin) - Create new system input
% 
%  Syntax:
%> newInput;
%> newInput('Property', value, ...);
% 
%  Description:
% You can specify any time dependent parameter to be a system input. 
% It is a priori not known from a given time dependent parameter u(t) if
% the parameter u itself or one of its first two time derivatives Du or D2u
% appears in the equations of motion. Therefore calcEqMotNonLin.m as a
% default checks for all occurences and includes all found derivatives in
% the input vector. You can check this vector in sys.vectors.in and if
% something went wrong, suppress this automatic selection in
% calcEqMotNonLin by an option. Please type 'help calcEqMotNonLin' for more
% information. Then all three values are kept, looking like
% [u; Du; D2u; v; Dv; D2v; ...]
% This would cause the input matrix, usually called B to be larger than
% some people would expect.
%
%  Optional parameters, given pairwise:
% Id .............. Input identifier {'SYSIN_1'}
% Name ............ Name of the system input {'Input Number 1'}
% Var ............. Variable, which is used an input {}
% Group ........... Define input group id {control}                  
% newGroup ........ This option can be used to define new groups {}
%
%  See also: newBody, newForceElem, newGenCoord, newFrame, newConstraint, newSys,
%   newOutput, newConstant, newTimeDependent, newStateDependent, newVolume,
%   calcEqMotNonLin
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
