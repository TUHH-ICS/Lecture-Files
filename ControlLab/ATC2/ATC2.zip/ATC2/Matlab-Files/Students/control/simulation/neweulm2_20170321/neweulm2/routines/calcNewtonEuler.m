% calcNewtonEuler - Function to set up the local and global mass matrices
% and to evaluate the generalized Coriolis, centrifugal, gyroscopic and
% gravitational forces.
%
% See also: elastMassmatrix
