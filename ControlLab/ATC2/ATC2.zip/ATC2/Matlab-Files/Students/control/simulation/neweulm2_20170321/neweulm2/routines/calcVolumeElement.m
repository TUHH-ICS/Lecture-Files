% calcVolumeElement 
% calculate forces of general elements stored under sys.model.other
