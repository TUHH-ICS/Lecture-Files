% newSys - Create new System. This includes a new structure, setting up of
% the workspace, ...
% 
%  Syntax:
%> newSys
%> newSys('Property', value, ...);
%     
%  Description:
% Initialize the Neweul-M2 system structure sys and define settings.
% 
%
%  Optional parameters, given pairwise:
% Id .................. System identifier {'MBS'}
% Name ................ Name of the System {'Multibody System'}
% Gravity ............. Gravity vector {'[0 0 -g]'}
%
% Abbreviations ....... Numerical value to specify, whether abbreviations
%                       shall be used for the relative kinematic
%                       expressions of elastic bodies. This makes smaller
%                       expressions and sometimes improves evaluation
%                       speed. Values from 0 to 2 are accepted, where 0
%                       means no abbreviations are introduced. For 1 only
%                       scalar abbreviations are used, while 2 means to use
%                       abbreviations for all expressions. A value of 2
%                       allows the user to exchange the .mat or .SID_FILE
%                       of an elastic body, without recalculating the
%                       equations {1}
% Angles .............. Specify angular defintion, either 'kardan','euler'
%                       or in the future 'quaternion' {'kardan'}
% CodeOptimize ........ Boolean, deciding whether a a runtime optimization of the code
%                       is performed or not. {false}
% CalcReactionForces .. Boolean to specify whether reaction forces are
%                       to be calculated or not {false}
% ConstraintIndex ..... For systems with kinematic loops the index of the
%                       system of equations of motion can be specified. For
%                       the formulation 'ode' index is set to 0, for the
%                       other two options, an index between 1 and 3 is
%                       available. {1}
% EquationType ........ For systems with kinematic loops, some
%                       different formulations for the equations of motion
%                       are available. They are clearly
%                       visible in the file 'constraint_equations.m'.
%                       Formulations with special explanations:
%       'partition' characterizes the method to use separation of generalized
%           coordinates to eliminate the constraint equations.
%       'svd' characterizes the method to use singular value decompostion 
%           to eliminate the constraint equations.
%       'qr' characterizes the method to use QR decompostion 
%           to eliminate the constraint equations.
%       'track' is a stabilized QR decomposition related to Baumgarte
%                       Possibilities: 'explicit_Mconst',
%                       'partialexplicit', 'partition', 'track',
%                       'ggl', 'svd', 'qr' {'explicit_Mconst'}
% Formulation ......... Specify which part is to be done symbolically.
%                       Possibilities are: 'minimal', 'newtonEuler',
%                       'recursive','recursiveMinimal','hamilton'. 
%                       For newtonEuler the premultiplication
%                       of the global Jacobian matrix is done numerically
%                       instead of symbolically as in minimal. {'newtonEuler'}
% FrameOfReference .... Currently this is a duplicate parameter, belonging
%                       to the kinematics-option. One day, we will be able
%                       to specify which coordinate system to use for the
%                       description of the equations. Possibilities:
%                       'body', 'ISYS' {'body'}
% SortGenCoords ....... Bool defining if the vector of the generalized coordinates
%                       is supossed to be sorted. {true}
% Kinematics .......... Calculate the kinematics in absolute or relative
%                       coordinates 'abs' or {'rel'}
% MassSymmetric ....... Logical: true/false {true}
% MassMatrixInverse ... Invert the matrix numerically or symbolically.
%                       For the evaluation of the state space form, the
%                       backslash \ operator is used, which is more
%                       efficient. This only corresponds to what is done in
%                       eqm_nonlin_Minv.m. Only available in absolute
%                       kinematics mode. {'num'} or 'sym'
% OutType ............. Type to use for the status updates, see
%                       'n2StatusOutput' for more information {'CMD'}
% OutHandle ........... Handle to use for the status updates, see
%                       'n2StatusOutput' for more information {1}
% PermuteMassMatrix ... Decide, whether the mass matrix is supposed to be
%                       permuted to minimize the fill-in during
%                       decomposition {false}
% ReactionRefSys ...... Specify the DirDef for the reaction forces. If set
%                       to 'reference', then the frame of reference of each
%                       body is used, otherwise the inertial frame 'ISYS'
%                       is used to describe the vectors {'reference'}
% SeparateInputs ...... Boolean determining if the input matrices
%                       should be computed or not {true}  
% 
%  Return value:
% varargout ........... If one is specified, the system data structure,
%                       identical to the global data structure sys is
%                       returned. Therefore the output variable is not
%                       necessary, as the global variable sys is available
%                       in the workspace after this function has been
%                       called.
%
%  Example:
%> newSys('Id', 'myFirstSys', 'Gravity', '[0; 0; -g]', 'Simplify', 3);
%
%  See also: newBody, newForceElem, newGenCoord, newFrame, newConstraint,
%   newInput, newOutput, newConstant, newTimeDependent, newStateDependent,
%   newVolume, calcEqMotNonLin
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
