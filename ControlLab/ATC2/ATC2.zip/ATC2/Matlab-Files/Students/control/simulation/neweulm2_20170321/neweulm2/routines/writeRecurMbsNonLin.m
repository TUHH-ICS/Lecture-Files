% writeMbsNonLinRecur(varargin) - Create files for numerical evaluation
%
%  Syntax:
%   writeRecurMbsNonLin
%   writeRecurMbsNonLin('Property', value, ...);
%
%  Describtion:
% Creates a Matlab function m-file 
% (eqm_nonlin_ss.m) for the numerical evaluation of values of the 
% nonlinear equations of motion and kinematic values. In addition the file
% absolutePositions is created to evaluate position vectors and rotation
% matrices
%
%  Optional parameters {default value}:
% OnlyPositions ........ Writes only function to calculate the absolute
%                        position of bodies. {false} 
% Formulation .......... Determines the formulation of the calculation its
%                        possible to choose between 'recursive' and 
%                        'recursiveMinimal' {'recursive'}.
%
%  Subfunctions contained in this file:
% - writeKinRecur
% - writeReplaceAbbrev
% - writeJacobianRecMinAbs
% - writeJacobianRecMinRel
% - writeAbsPosRecur
% - writeAbsPosFrame
% - writeAbsPosRecurOutput
% - writeAbsPosFrameOutput
% - writeAppFor
% - writeForcesFelem
% - writeForcesFelem_file
% - writeCalcC
% - writeCalcb
% - writeRecurBack
% - writeRecurBack_file
% - writeRecurForward2
% - writeConstraintEquationsRecMin
% - writeCalcKinConEq
% - writeCalcKin_jac_of_con_left
% - writeCalcKin_jac_of_con
% - writeCalcKin_eqc_velocities
% - writeCalcKin_eqc_accelerations
% - writeCalcKin_eq_of_con_1
% - writeCalcKin_eq_of_con_2
% - writeCalcKin_eq_of_con_3
% 
% 
%  See also: 
% calcEqMotNonLin, calcEqMotLin, writeMbsNonLin, writeMbsLin,
% writeMbsNonLinRecur>writeKinRecur, writeMbsNonLinRecur>writeReplaceAbbrev,
% writeMbsNonLinRecur>writeJacobianRecMinAbs,
% writeMbsNonLinRecur>writeJacobianRecMinRel,
% writeMbsNonLinRecur>writeAbsPosRecur, writeMbsNonLinRecur>writeAbsPosFrame, 
% writeMbsNonLinRecur>writeAbsPosRecurOutput,
% writeMbsNonLinRecur>writeAbsPosFrameOutput, writeMbsNonLinRecur>writeAppFor,
% writeMbsNonLinRecur>writeForcesFelem, writeMbsNonLinRecur>writeForcesFelem_file,
% writeMbsNonLinRecur>writeCalcC, writeMbsNonLinRecur>writeCalcb, 
% writeMbsNonLinRecur>writeRecurBack, writeMbsNonLinRecur>writeRecurBack_file,
% writeMbsNonLinRecur>writeRecurForward2,
% writeMbsNonLinRecur>writeConstraintEquationsRecMin,
% writeMbsNonLinRecur>writeCalcKinConEq,
% writeMbsNonLinRecur>writeCalcKin_jac_of_con,
% writeMbsNonLinRecur>writeCalcKin_eqc_velocities,
% writeMbsNonLinRecur>writeCalcKin_eqc_accelerations,
% writeMbsNonLinRecur>writeCalcKin_eq_of_con_1,
% writeMbsNonLinRecur>writeCalcKin_eq_of_con_2,
% writeMbsNonLinRecur>writeCalcKin_eq_of_con_3
%
%  First appearance:
%   18.04.2011
%
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
