% SYSTEMINOUT MATLAB code for SystemInOut.fig
%      SYSTEMINOUT, by itself, creates a new SYSTEMINOUT or raises the existing
%      singleton*.
%
%      H = SYSTEMINOUT returns the handle to a new SYSTEMINOUT or the handle to
%      the existing singleton*.
%
%      SYSTEMINOUT('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SYSTEMINOUT.M with the given input arguments.
%
%      SYSTEMINOUT('Property','Value',...) creates a new SYSTEMINOUT or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before SystemInOut_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to SystemInOut_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
