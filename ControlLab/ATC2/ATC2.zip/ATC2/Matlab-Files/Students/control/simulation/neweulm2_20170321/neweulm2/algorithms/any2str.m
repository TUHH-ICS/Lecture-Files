% any2str - Converts any given expression to a printable string
%
% Syntax:
%> res = any2str(expression)
%
% Description:
% Converts any given expression to a printable string.
% The main focus is to be able to display the properties no matter which
% input data type is used. It is not made for reevaluation of the resulting
% expressions. In most cases this will work, but some cases are known to
% result in easily readable expressions, which cannot be directly
% evaluated. For numerical values an investigation is performed, whether
% the expression can be described using commands like zeros, ones, eye,
% diag and linspace. Numerical arrays have to be 2D arrays, with the
% exception of those created with zeros and ones, they support up to 3D
% arrays.
%
% This function does not change any expressions. The only exception, where
% some small change of values might occur is when the linspace command is
% inserted. Then the values need to be linearly spaced within a certain
% tolerance.
%
% See also: num2str, mat2str, func2str
%
% First appearance: 11.03.2008
%
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
