function plotResults
% plotResults - Plot energies, position and velocity of the first node

global sys;

load W_kin
load W_pot

t      = sys.results.timeInt.x; 
output = sys.results.timeInt.outControl;

figure(2)
set(2,'Name',sprintf('Position and velocity of pin 1'));
subplot(2,1,1);
plot(t,output(1,:),'k');
xlabel('t[s]');
ylabel('x_1[m]');
axis([0 10 -1.1 1.1]);
grid on;
title('Position in x-direction');
subplot(2,1,2);
plot(t,output(2,:),'k');
title('Velocity in x-direction');
xlabel('t[s]');
ylabel('dx_1[m/s]');
grid on;
axis([0 10 -8 2.5]);

figure(3)
set(3,'Name',sprintf('Kinetic and potential energy of System'));
subplot(2,1,1);
plot(t,W_kin,'k');
axis([0 10 0 72]);
grid on;
title('Kinetic energy of System');
xlabel('t[s]');
ylabel('W_{kin}[J]');
subplot(2,1,2);
plot(t,W_pot,'k');
grid on;
axis([0 10 -72 0]);
title('Potential energy of System');
xlabel('t[s]');
ylabel('W_{pot}[J]');

figure(4)
set(4,'Name',sprintf('Energy of System'));
plot(t,W_pot+W_kin-(W_kin(1)+W_pot(1)),'k');
grid on;
title('Energy of System');
xlabel('t[s]');
ylabel('W[J]');

