% tensor_out = twoSideDivide(matrix, tensor_in)
% twoSideDivide - This function provides a routine that performs a left
% side and a right side multiplication of a three-dimensional array with an
% inverted matrix. This routine can be used to compute the partial
% derivative of an inverted matrix without inverting the matrix
% symbolically.
%
% Input arguments:
% matrix ....... Square matrix suppossed to inverted
% tensor_in .... Three-dimensional array ( stack of matrices tensor_in(i) )
%
% Output arguments:
% tensor_out ... Three-dimensional array containing a stack of matrices 
%                tensor_out(i) = matrix^(-1)*tensor_in(i)*matrix^(-1);
% 
% See also: tensorTranspose, tensorMultiplication, leftSideDivide
%
% First appearance: 03.10.2010
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
