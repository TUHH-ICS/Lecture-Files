% stop = optiOutputFreqRes(p_, optimValues, state)
% Output function for the optimization using the frequency response curve /
% transfer function. This function plots a transfer function after each
% iteration and at the very beginning and end of the optimization.
% Independent of a selection of only a certain number of evaluation points,
% this function plots all evaluated points. The initial and final
% configuration are highlighted in different colors and line widths.
% 
% Input arguments
% p_ ............ Values of the design parameters. These values are scaled
%                 using the properties stored under sys.settings.opt.
%                 Therefore p_ will only take values in the interval
%                 [-1,1]. The used settings are:
%               - sys.settings.opt.constr.lb representing the lower bound
%               - sys.settings.opt.constr.ub representing the upper bound
% optimValues ... This setting is ignored.
% state ......... Specifies the state of the optimization algorithm. Has
%                 the values
%               - 'interrupt': Somewhere in the middle of the calculation
%               - 'iter': Finished an optimization step
%               - 'init': At the beginning of the optimization
%               - 'done': At the very end of the optimization
% 
% Return arguments
% stop .......... Value to quit an optimization. As this function is only
%                 for visualization, this is always false, meaning to
%                 continue the optimization.
%
% See also: newOpt, optiCritFreqRes, optiOutputGeneral
%
% First appearance: 16.08.2012
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
