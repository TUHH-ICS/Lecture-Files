% cur = getKinematics(y,Dy,expr,varargin)
% getKinematics - Calculate the kinematic values of the symbolic expression
% 'expr' and pass the struct 'cur' containing all needed values. This
% function is not nessary for all cases.
%
% See also: absoluteKinematics, calcEqMotNonLin, expandTimeVars,
%   jacobianMatrix, kardan2rotmat, rotmat2kardan
%
% First appearance: 14.03.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
