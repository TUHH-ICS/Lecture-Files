function defineGraphics
% Define graphical objects for the system 'Oscillator'

global sys;

% Define cubes for the bodies
for k_=1:sys.counters.body
    h = drawCube([0 0 0], 0.2, 0.2, 0.2, 'blue');
    addGraphics(['M',num2str(k_)],h);
end

% Build wall
h = drawCube([0 0 0], 0.2, 0.8, 0.8, 'blue');
    addGraphics('W1',h);

% Draw spring between bodies
for k_=1:sys.counters.body-1
    drawSpring(['M',num2str(k_)],['M',num2str(k_+1)],['Spring_',num2str(k_)],'Color',[1 0 0],'NumWinding',8,'Diameter',0.08,'LineWidth',0.6);
end

% Draw spring between last body and wall
drawSpring(['M',num2str(sys.counters.body)],'W1',['Spring_',num2str(sys.counters.body)],'Color',[1 0 0],'NumWinding',8,'Diameter',0.08,'LineWidth',0.6);
