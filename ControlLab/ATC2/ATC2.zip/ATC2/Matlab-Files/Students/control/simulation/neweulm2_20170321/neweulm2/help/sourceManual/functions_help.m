%% Functions Reference
% UI-functions of the _Neweul-M2_ toolbox sorted by categories
%
% <html><hr></html>
%
%%
% <html><hr></html>
%
%
%% Preparations
% * <addpathNeweulm2.html |addpathNeweulm2|> - adjust the search path for Neweul-M2
%
%% System definition
% * <declareDependent.html |declareDependent|> - declare a generalized coordinate to be dependent
% * <declareDependentInitCond.html |declareDependentInitCond|> - declare a generalized coordinate to be dependent concerning implicit initial conditions
% * <declareIndependent.html |declareIndependent|> - declare a generalized coordinate to be independent
% * <declareIndependentInitCond.html |declareIndependentInitCond|> - declare a generalized coordinate to be independent concerning implicit initial conditions
% * <fullModelRun.html |fullModelRun|> - set up the system in the current folder and run all prepared simulations
% * <modifyBody.html |modifyBody|> - modify properties of an existing body
% * <modifyConstant.html |modifyConstant|> - modify constants
% * <modifyFrame.html |modifyFrame|> - modify properties of an existing frame
% * <newBody.html |newBody|> - define a new body, rigid or elastic
% * <newConstant.html |newConstant|> - declare a constant parameter, optionally setting the value at the same time
% * <newConstraint.html |newConstraint|> - define an algebraic constraint equation
% * <newForceElem.html |newForceElem|> - define a force element for applied forces
% * <newFrame.html |newFrame|> - define a new massless frame
% * <newGenCoord.html |newGenCoord|> - declare a generalized coordinate
% * <newImplicitInitCond.html |newImplicitInitCond|> - specify an implicit initial condition
% * <newInput.html |newInput|> - define a new system input
% * <newOpt.html |newOpt|> - specify or start an optimization or sensitivity analysis
% * <newOutput.html |newOutput|> - define a new system output
% * <newPeriodic.html |newPeriodic|> - declare a periodic parameter
% * <newRandomSignal.html |newRandomSignal|> - declare a normal distribution
% * <newSmoothTransition.html |newSmoothTransition|> - declare a sufficiently smooth transition
% * <newStateDependent.html |newStateDependent|> - declare a state dependent parameter
% * <newSys.html |newSys|> - initialize a new multibody system and the corresponding data structure
% * <newTimeData.html |newTimeData|> - introduce a time history based on set points and interpolation
% * <newTimeDependent.html |newTimeDependent|> - declare a time dependent parameter
% * <newVolume.html |newVolume|> - define a volume element using pressure
%
%% Equations setup
% * <calcEqMotLin.html |calcEqMotLin|> - symbolically linearize the equations of motion
% * <calcEqMotNonLin.html |calcEqMotNonLin|> - set up the kinematics and the equations of motion
% * <calcReacForce.html |calcReacForce|> - calculate the reaction forces
% * <replaceSymbolicValues.html |replaceSymbolicValues|> - replace symbolical values
% * <scriptCalcEqMotNonLin.html |scriptCalcEqMotNonLin|> - script to incorporate user-defined functions in the workflow, here in calcEqMotNonLin
% * <scriptWriteMbsNonLin.html |scriptWriteMbsNonLin|> - script to incorporate user-defined functions in the workflow, here in writeMbsNonLin
% * <writeMbsLin.html |writeMbsLin|> - write the files for the linearized equations of motion
% * <writeMbsNonLin.html |writeMbsNonLin|> - write the files for the nonlinear equations of motion and the kinematics
%
%% Simulation and evaluation
% * <calcNomLength.html |calcNomLength|> - calculate nominal lengths of springs to match a given static equilibrium
% * <calcNumericalLinearization.html |calcNumericalLinearization|> - evaluate the numerical linearization at a given configuration
% * <evalForces.html |evalForces|> - evaluate forces, applied or reaction
% * <freqResponse.html |freqResponse|> - calculate the frequency response
% * <kinematicAnalysis.html |kinematicAnalysis|> - perform a kinematic analysis, prescribing values for generalized coordinates
% * <modalAnalysis.html |modalAnalysis|> - calculate eigenvectors and eigenvalues
% * <setfun.html |setfun|> - specify functions for a kinematic analysis
% * <staticEquilibrium.html |staticEquilibrium|> - numerically calculate a static equilibrium
% * <timeInt.html |timeInt|> - perform a numerical time integration
%
%% Animation
% * <addGraphics.html |addGraphics|> - add graphical objects to frame
% * <animFreqResponse.html |animFreqResponse|> - animate frequency response
% * <animModeShape.html |animModeShape|> - animate mode shapes
% * <animTimeInt.html |animTimeInt|> - animate time integration
% * <createAnimationWindow.html |createAnimationWindow|> - create animation window
% * <createSubplots.html |createSubplots|> - create subplots in the animation window
% * <drawArrow3d.html |drawArrow3d|> - draw a 3-dimensional arrow
% * <drawCube.html |drawCube|> - draw a cube
% * <drawElasticBeam.html |drawElasticBeam|> - draw a elastic body
% * <drawLine.html |drawLine|> - draw a line between frames
% * <drawMesh.html |drawMesh|> - draw the mesh of an elastic body
% * <drawRotBody.html |drawRotBody|> - draw a rotational-symmetric body
% * <drawSphere.html |drawSphere|> - draw a sphere
% * <drawSpring.html |drawSpring|> - draw a spring
% * <drawSTL.html |drawSTL|> - draw a object stored in a STL-container
% * <drawSys.html |drawSys|> - redraw graphical representation of the system
% * <fitCanvas.html |fitCanvas|> - adjust visible area with respect to simulation results
% * <framePlot.html |framePlot|> - create graphical representation of a frame
% * <freqResPlot.html |freqResPlot|> - plot frequency response plot
% * <initGraphics.html |initGraphics|> - initial graphical representation
% * <n2CaptureScene.html |n2CaptureScene|> - capture the current view setting
% * <plotStandardResults.html |plotStandardResults|> - plot states, outputs, constraints, ...
% * <plotTimeSteps.html |plotTimeSteps|> - plot different configurations
% * <plotTrajectories.html |plotTrajectories|> - add the trajectories of a frame to the animation window
% * <setVisibility.html |setVisibility|> - set visibility properties of graphic objects
% * <showModeShape.html |showModeShape|> - plot mode shapes
% * <transformGraphics.html |transformGraphics|> - perform rotations and translations of graphical objects
% * <updateGeo.html |updateGeo|> - update graphical objects
%
%% Export
% * <compileMatlabCode.html |compileMatlabCode|> - compile created C code
% * <createSimulinkLibrary.html |createSimulinkLibrary|> - create Simulink library
% * <exportEqMot.html |exportEqMot|> - export the equations of motion to be independent of the system data structure
% * <exportSystem2C.html |exportSystem2C|> - export the equations of motion to C
%
%% General functions
% * <printSystemInformation.html |printSystemInformation|> - print some general information on the system, very useful for debugging
% * <saveSession.html |saveSession|> - save the system with all settings and files
% * <LICENSE.html |LICENSE|> - Unknown file
% * <ReadMe_Examples.html |ReadMe_Examples|> - Unknown file
% * <WikiDoublePendulum.html |WikiDoublePendulum|> - Unknown file
% * <WikiElasticDoublePendulum.html |WikiElasticDoublePendulum|> - Unknown file
% * <WikiGeneralPreparations.html |WikiGeneralPreparations|> - Unknown file
% * <WikiSinglePendulum.html |WikiSinglePendulum|> - Unknown file
% * <WikiSliderCrank.html |WikiSliderCrank|> - Unknown file
% * <aa2rotmat.html |aa2rotmat|> - Unknown file
% * <ab2rotmat.html |ab2rotmat|> - Unknown file
% * <animContact.html |animContact|> - Unknown file
% * <animGenCoords.html |animGenCoords|> - Unknown file
% * <arctan2.html |arctan2|> - Unknown file
% * <calcConstraint.html |calcConstraint|> - Unknown file
% * <calcConstraintDynamics.html |calcConstraintDynamics|> - Unknown file
% * <calcConstraintKinematics.html |calcConstraintKinematics|> - Unknown file
% * <calcDynamicsGeneric.html |calcDynamicsGeneric|> - Unknown file
% * <calcDynamicsMinimal.html |calcDynamicsMinimal|> - Unknown file
% * <calcEnergy.html |calcEnergy|> - Unknown file
% * <calcEqmLin.html |calcEqmLin|> - Unknown file
% * <calcEqmNonlin.html |calcEqmNonlin|> - Unknown file
% * <calcForceFelem.html |calcForceFelem|> - Unknown file
% * <calcForceInertia.html |calcForceInertia|> - Unknown file
% * <calcForceReaction.html |calcForceReaction|> - Unknown file
% * <calcForceVector.html |calcForceVector|> - Unknown file
% * <calcInitConditions.html |calcInitConditions|> - Unknown file
% * <calcInput.html |calcInput|> - Unknown file
% * <calcKinematics.html |calcKinematics|> - Unknown file
% * <calcKinematicsAbsolute.html |calcKinematicsAbsolute|> - Unknown file
% * <calcKinematicsRelative.html |calcKinematicsRelative|> - Unknown file
% * <calcMassMatrix.html |calcMassMatrix|> - Unknown file
% * <calcNewtonEuler.html |calcNewtonEuler|> - Unknown file
% * <calcOutput.html |calcOutput|> - Unknown file
% * <calcOutputOld.html |calcOutputOld|> - Unknown file
% * <calcVolumeElement.html |calcVolumeElement|> - Unknown file
% * <cheatSheet.html |cheatSheet|> - Unknown file
% * <checkSettingStructure.html |checkSettingStructure|> - Unknown file
% * <colorStr2RGB.html |colorStr2RGB|> - Unknown file
% * <convertInertia.html |convertInertia|> - Unknown file
% * <coriolisSum.html |coriolisSum|> - Unknown file
% * <createAnimationWindow_new.html |createAnimationWindow_new|> - Unknown file
% * <csgn.html |csgn|> - Unknown file
% * <defAbbreviationFelem.html |defAbbreviationFelem|> - Unknown file
% * <defForceFelem.html |defForceFelem|> - Unknown file
% * <defGenCoord.html |defGenCoord|> - Unknown file
% * <defParameter.html |defParameter|> - Unknown file
% * <drawBodies.html |drawBodies|> - Unknown file
% * <drawFrame.html |drawFrame|> - Unknown file
% * <drawTrajectories.html |drawTrajectories|> - Unknown file
% * <drawTriangle.html |drawTriangle|> - Unknown file
% * <evalDiffResult.html |evalDiffResult|> - Unknown file
% * <evalDiffResult_recur.html |evalDiffResult_recur|> - Unknown file
% * <evalElastBody_Mq.html |evalElastBody_Mq|> - Unknown file
% * <evalElastBody_he.html |evalElastBody_he|> - Unknown file
% * <evalElastBody_ho.html |evalElastBody_ho|> - Unknown file
% * <evalElastBody_qa.html |evalElastBody_qa|> - Unknown file
% * <evalEnergy.html |evalEnergy|> - Unknown file
% * <evalEnergyNum.html |evalEnergyNum|> - Unknown file
% * <evalForcesContact.html |evalForcesContact|> - Unknown file
% * <evalKinematics.html |evalKinematics|> - Unknown file
% * <evalOutputGroups.html |evalOutputGroups|> - Unknown file
% * <evalPostprocessing.html |evalPostprocessing|> - Unknown file
% * <exampleVtkExport.html |exampleVtkExport|> - Unknown file
% * <expandTimeVars.html |expandTimeVars|> - Unknown file
% * <f_coulomb.html |f_coulomb|> - Unknown file
% * <f_lugreStat.html |f_lugreStat|> - Unknown file
% * <fastinterp1.html |fastinterp1|> - Unknown file
% * <finDiffs.html |finDiffs|> - Unknown file
% * <findroot.html |findroot|> - Unknown file
% * <function_help.html |function_help|> - Unknown file
% * <getHandleForceLaw.html |getHandleForceLaw|> - Unknown file
% * <getHandleOdeAux.html |getHandleOdeAux|> - Unknown file
% * <getHandleRelKin.html |getHandleRelKin|> - Unknown file
% * <getScene.html |getScene|> - Unknown file
% * <gettingStarted.html |gettingStarted|> - Unknown file
% * <getting_started.html |getting_started|> - Unknown file
% * <initSettingsDefault.html |initSettingsDefault|> - Unknown file
% * <initSettingsGlobal.html |initSettingsGlobal|> - Unknown file
% * <initSettingsLocal.html |initSettingsLocal|> - Unknown file
% * <initStructSys.html |initStructSys|> - Unknown file
% * <initStructure.html |initStructure|> - Unknown file
% * <jacobianMatrix.html |jacobianMatrix|> - Unknown file
% * <kardan2rotmat.html |kardan2rotmat|> - Unknown file
% * <link_neweulm2.html |link_neweulm2|> - Unknown file
% * <matrixTranspose.html |matrixTranspose|> - Unknown file
% * <models.html |models|> - Unknown file
% * <modifyConstraint.html |modifyConstraint|> - Unknown file
% * <modifyForceElement.html |modifyForceElement|> - Unknown file
% * <modifyInput.html |modifyInput|> - Unknown file
% * <modifyLookUpTable.html |modifyLookUpTable|> - Unknown file
% * <modifyOutput.html |modifyOutput|> - Unknown file
% * <modifyParameter.html |modifyParameter|> - Unknown file
% * <modifySignal.html |modifySignal|> - Unknown file
% * <modifySwitch.html |modifySwitch|> - Unknown file
% * <newAuxiliarySet.html |newAuxiliarySet|> - Unknown file
% * <newContact.html |newContact|> - Unknown file
% * <newContactSurface.html |newContactSurface|> - Unknown file
% * <newFriction.html |newFriction|> - Unknown file
% * <newInitCond.html |newInitCond|> - Unknown file
% * <newLookUpTable.html |newLookUpTable|> - Unknown file
% * <newSetPoint.html |newSetPoint|> - Unknown file
% * <newSwitch.html |newSwitch|> - Unknown file
% * <neweulm2_main.html |neweulm2_main|> - Unknown file
% * <numericalLinearization.html |numericalLinearization|> - Unknown file
% * <plotFreqRes.html |plotFreqRes|> - Unknown file
% * <postTimeInt.html |postTimeInt|> - Unknown file
% * <postTimeInt_example.html |postTimeInt_example|> - Unknown file
% * <qrGivens.html |qrGivens|> - Unknown file
% * <quat2rotmat.html |quat2rotmat|> - Unknown file
% * <rotmat2aa.html |rotmat2aa|> - Unknown file
% * <rotmat2kardan.html |rotmat2kardan|> - Unknown file
% * <rotmat2quat.html |rotmat2quat|> - Unknown file
% * <scaleForceContact.html |scaleForceContact|> - Unknown file
% * <setView.html |setView|> - Unknown file
% * <signum.html |signum|> - Unknown file
% * <sym2num.html |sym2num|> - Unknown file
% * <sysDef_balls.html |sysDef_balls|> - Unknown file
% * <sysDef_car.html |sysDef_car|> - Unknown file
% * <sysDef_carHalf.html |sysDef_carHalf|> - Unknown file
% * <sysDef_chain.html |sysDef_chain|> - Unknown file
% * <sysDef_crankDrive.html |sysDef_crankDrive|> - Unknown file
% * <sysDef_cube.html |sysDef_cube|> - Unknown file
% * <sysDef_devx6.html |sysDef_devx6|> - Unknown file
% * <sysDef_devx6pod.html |sysDef_devx6pod|> - Unknown file
% * <sysDef_doubleFourBarMechanism.html |sysDef_doubleFourBarMechanism|> - Unknown file
% * <sysDef_doublePendulum.html |sysDef_doublePendulum|> - Unknown file
% * <sysDef_elasticPendulum.html |sysDef_elasticPendulum|> - Unknown file
% * <sysDef_elasticSliderCrank.html |sysDef_elasticSliderCrank|> - Unknown file
% * <sysDef_felemNonholonomic.html |sysDef_felemNonholonomic|> - Unknown file
% * <sysDef_forceElements.html |sysDef_forceElements|> - Unknown file
% * <sysDef_friction.html |sysDef_friction|> - Unknown file
% * <sysDef_garageDoor.html |sysDef_garageDoor|> - Unknown file
% * <sysDef_lensTriplet.html |sysDef_lensTriplet|> - Unknown file
% * <sysDef_linkage.html |sysDef_linkage|> - Unknown file
% * <sysDef_mariotteLeibnizPendulum.html |sysDef_mariotteLeibnizPendulum|> - Unknown file
% * <sysDef_multipleFourBarMechanism.html |sysDef_multipleFourBarMechanism|> - Unknown file
% * <sysDef_muscle1.html |sysDef_muscle1|> - Unknown file
% * <sysDef_muscle2.html |sysDef_muscle2|> - Unknown file
% * <sysDef_oscillator.html |sysDef_oscillator|> - Unknown file
% * <sysDef_padOnDisc.html |sysDef_padOnDisc|> - Unknown file
% * <sysDef_rotatingArm.html |sysDef_rotatingArm|> - Unknown file
% * <sysDef_rotatingArmMod.html |sysDef_rotatingArmMod|> - Unknown file
% * <sysDef_rotationSpring.html |sysDef_rotationSpring|> - Unknown file
% * <sysDef_sliderCrank.html |sysDef_sliderCrank|> - Unknown file
% * <sysDef_solarSystem.html |sysDef_solarSystem|> - Unknown file
% * <sysDef_spatialRigidSliderCrank.html |sysDef_spatialRigidSliderCrank|> - Unknown file
% * <sysDef_testForceElements.html |sysDef_testForceElements|> - Unknown file
% * <sysDef_testKinematics.html |sysDef_testKinematics|> - Unknown file
% * <sysDef_wheelLoader.html |sysDef_wheelLoader|> - Unknown file
% * <tensorMultiplication.html |tensorMultiplication|> - Unknown file
% * <tensorTranspose.html |tensorTranspose|> - Unknown file
% * <tipsAndTricks.html |tipsAndTricks|> - Unknown file
% * <twoSideDivide.html |twoSideDivide|> - Unknown file
% * <unifiedRepresentation.html |unifiedRepresentation|> - Unknown file
% * <updateFrames.html |updateFrames|> - Unknown file
% * <vec2skew.html |vec2skew|> - Unknown file
% * <vecs2rotmat.html |vecs2rotmat|> - Unknown file
% * <writeAnglesForceElementsC.html |writeAnglesForceElementsC|> - Unknown file
% * <writeAuxDynamics.html |writeAuxDynamics|> - Unknown file
% * <writeCalcForceReactionC.html |writeCalcForceReactionC|> - Unknown file
% * <writeCloseFile.html |writeCloseFile|> - Unknown file
% * <writeConstraint.html |writeConstraint|> - Unknown file
% * <writeConstraintC.html |writeConstraintC|> - Unknown file
% * <writeDataFile.html |writeDataFile|> - Unknown file
% * <writeDynamics.html |writeDynamics|> - Unknown file
% * <writeDynamicsMinimal.html |writeDynamicsMinimal|> - Unknown file
% * <writeEnergy.html |writeEnergy|> - Unknown file
% * <writeEnergySimpleContact.html |writeEnergySimpleContact|> - Unknown file
% * <writeEqmC.html |writeEqmC|> - Unknown file
% * <writeEqmLin.html |writeEqmLin|> - Unknown file
% * <writeEqmLin_new.html |writeEqmLin_new|> - Unknown file
% * <writeEqmNonlin.html |writeEqmNonlin|> - Unknown file
% * <writeEqmStandalone.html |writeEqmStandalone|> - Unknown file
% * <writeEquationsOfMotion.html |writeEquationsOfMotion|> - Unknown file
% * <writeEvalBodyElastic.html |writeEvalBodyElastic|> - Unknown file
% * <writeEvalKinematicsAbsolute.html |writeEvalKinematicsAbsolute|> - Unknown file
% * <writeEvalKinematicsRelative.html |writeEvalKinematicsRelative|> - Unknown file
% * <writeFinalCond.html |writeFinalCond|> - Unknown file
% * <writeForceFelem.html |writeForceFelem|> - Unknown file
% * <writeForceFelemC.html |writeForceFelemC|> - Unknown file
% * <writeForceVector.html |writeForceVector|> - Unknown file
% * <writeFunctions.html |writeFunctions|> - Unknown file
% * <writeHeaderFileC.html |writeHeaderFileC|> - Unknown file
% * <writeHelpvarC.html |writeHelpvarC|> - Unknown file
% * <writeIndependentCodeC.html |writeIndependentCodeC|> - Unknown file
% * <writeInitAux.html |writeInitAux|> - Unknown file
% * <writeInputMatrix.html |writeInputMatrix|> - Unknown file
% * <writeKinematicAbbreviationsC.html |writeKinematicAbbreviationsC|> - Unknown file
% * <writeKinematicsC.html |writeKinematicsC|> - Unknown file
% * <writeLinearizationC.html |writeLinearizationC|> - Unknown file
% * <writeLookUpTable.html |writeLookUpTable|> - Unknown file
% * <writeMatlabCodeC.html |writeMatlabCodeC|> - Unknown file
% * <writeOpenSceneGraphC.html |writeOpenSceneGraphC|> - Unknown file
% * <writePasimodoCodeC.html |writePasimodoCodeC|> - Unknown file
% * <writePositionAbsolute.html |writePositionAbsolute|> - Unknown file
% * <writePositionAbsoluteAll.html |writePositionAbsoluteAll|> - Unknown file
% * <writeReplaceAbbrevC.html |writeReplaceAbbrevC|> - Unknown file
% * <writeSfunctionC.html |writeSfunctionC|> - Unknown file
% * <writeSimulinkCodeC.html |writeSimulinkCodeC|> - Unknown file
% * <writeSimulinkLibraryC.html |writeSimulinkLibraryC|> - Unknown file
% * <writeStateDependent.html |writeStateDependent|> - Unknown file
% * <writeStructureC.html |writeStructureC|> - Unknown file
% * <writeSysDef.html |writeSysDef|> - Unknown file
% * <writeTimeDependent.html |writeTimeDependent|> - Unknown file
% * <writeUserDefinedCodeC.html |writeUserDefinedCodeC|> - Unknown file
% * <writeVisualC.html |writeVisualC|> - Unknown file
%
%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2013 ITM University of Stuttgart
%        <tt class="minicdot">&#149;</tt>
%        <a href="http://www.itm.uni-stuttgart.de">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:./LICENSE.html">Terms of Use</a>
%   </p>
% </html>
