% A_ = vec2skew(v_)
% Rearrange the entries of a 3x1 vector v_ into a skew symmetric matrix A_
% in a way so it represents the following multiplication with the arbitrary
% vector x_:
% cross(v_, x_) = A_ * x_
%
% v_ can also be an agglomeration of nq column vectors, and for each of
% them the equation above shall hold true
% cross(v_(:,i), x_) = A_(:,i,:) * x_
%
% First appearance: 01.07.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
