% colorStr2RGB - convert color strings to RGB values
%
%  Description:
% Matlab provides some predefined colors, which should be accepted by many
% other functions for the animation as well. Convert those color strings to
% RGB vectors in the range between 0 and 1. The other way works as well,
% giving a triplet of numbers and receiving a color string. If a numerical
% triplet is given, the closest to the standard colors is used. The color
% option 'none' is always kept at that. However, empty brackets [] are
% always converted to 'none'.
% The parameter ensureNumerical is a logical, which prevents the inverse
% behavior meaning that no matter which input argument, a numerical color
% representation is given.
% 
% Predefined colors are:
% [1 1 0] ... y ... yellow
% [1 0 1] ... m ... magenta
% [0 1 1] ... c ... cyan
% [1 0 0] ... r ... red
% [0 1 0] ... g ... green
% [0 0 1] ... b ... blue
% [1 1 1] ... w ... white
% [0 0 0] ... k ... black
%
%  Input arguments:
% colorStr .......... A string denoting a standard Matlab color type
%                     'help ColorSpec' for more information. Or a numerical
%                     triplet with values between 0 and 1 to invoke the
%                     other direction.
% ensureNumerical ... Optional logical parameter which if true ensures a
%                     numerical representation as return value, standard is
%                     {false}.
%  Return value:
% colorRGB .......... When a string was given, a numerical triplet is
%                     returned, or the other way around. Except if
%                     ensureNumerical is set to true, then always a
%                     numerical return value is given
%
%  See also:
% drawArrow3d, drawCube, drawElasticBeam, drawLine,drawRotBody,
% drawSphere, drawSTL, drawSpring
%
%  First appearance: 23.03.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
