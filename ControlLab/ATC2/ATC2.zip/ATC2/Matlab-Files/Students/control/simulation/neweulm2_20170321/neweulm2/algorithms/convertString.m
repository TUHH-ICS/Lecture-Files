% res_ = convertString(varargin)
% Function to go over an input containing strings and changing them.
% Acceptable inputs:
% - cell arrays
% - symbolic arrays, containing one parameter in each field
% - structures, then the fieldnames are changed
% 
% Possible changes/options to the entries:
% colvect ... Same as the option newSize, just the common case of a column
%             vector, give this only as an option, no second argument
% rowvect ... Same as the option newSize, just the common case of a row
%             vector, give this only as an option, no second argument
% newSize ... Insert the elements into this size, e.g. change from a column
%             to a row vector. Second argument is the size {size()}
% outtype ... Specify the output type, should be one of 'cell','sym','char'
%             The standard is the same as it came in
% prefix .... If a string is passed as prefix, this is inserted before each
%             entry of expr_. The prefix has to be given after this option.
%             {''}
% suffix .... If a string is passed as suffix, this is inserted after each
%             entry of expr_. The suffix has to be given after this option.
%             {''}
% strrep .... This option requests a cell array with two elements as second
%             input value, both being strings. Then occurences of the first
%             element are replaced with the second using the function
%             strrep. E.g.
%             convertString(sym('[a;a+2;a1]'),'strrep',{'a','b'})
%
% First appearance: 16.11.2010
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
