/*
 * BVPSOLMEX-Interface von C. Ludwig
 * Version: $Id: bvpsolMex.c 281 2006-01-11 17:10:24Z luchr $ */
#define BVPSOLMexVersion "11. Jan. 2006"
/*
 * 
 * Fragen, W�nsche, Probleme, Anregungen, 
 * Anmerkungen, Bemerkungen und Bugs an
 *  Ludwig_C@gmx.de
 */
#include <math.h>
#include <string.h>
#include "mex.h"
#include "options.h"
#include "bvpsolMex.h"

/* [x,stats] = bvpsolMex(f,bc,odesol,snodes,startdata,options,ODEoptions) */
/* dx = RightSide (t,x) */
/*  r = Boundary (xa,xb) */
/* [tG,xG,stats,taunext] = odesol (f,t,x,ODEopt) */

static SOptionSettings optSet;
static SParameterOptions paramOpt;
static SParameterGlobal paramGlobal;
static SParameterRightSide paramRightSide;
static SParameterBoundary paramBoundary;
static SParameterODEsolver paramODEsolver;
static SParameterBVPSOL paramBVPSOL;

static char ismxArrayString (const mxArray *arr) {
  if (arr==NULL) return (char)0;
  if (mxIsChar(arr)) return (char)1;
  return (char)0;
}

static char ismxArrayFunction (const mxArray *arr) {
  if (arr==NULL) return (char)0;
  return (mxGetClassID(arr)==mxFUNCTION_CLASS)?(char)1:(char)0;
}

static char ismxArrayInline (const mxArray *arr) {
  if (arr==NULL) return (char)0;
  return (strcmp(mxGetClassName(arr),"inline")==0)?(char)1:(char)0;
}

static void initVars (void) {
  /* Options settings */
  optSet.warnMiss=0;optSet.warnType=1;optSet.warnSize=1;
  
  /* parameters for options */
  paramOpt.opt=NULL; paramOpt.optCreated=0;

  /* global parameters */
  
  /* parameters for rightside */
  paramRightSide.rightSideFcn=NULL;
  paramRightSide.rightSideFcnH=NULL;
  paramRightSide.tArg=NULL;
  paramRightSide.xArg=NULL;
  
  /* parameters for boundary */
  paramBoundary.boundaryFcn=NULL;
  paramBoundary.boundaryFcnH=NULL;
  paramBoundary.xaArg=NULL;
  paramBoundary.xbArg=NULL;
  
  /* parameters for ode solver */
  paramODEsolver.odesolFcn=NULL;
  paramODEsolver.odesolFcnH=NULL;
  paramODEsolver.rightSideArg=NULL;
  paramODEsolver.tArg=NULL;
  paramODEsolver.xArg=NULL;  
  paramODEsolver.optArg=NULL;
  
  /* parameters for BVPSOL */
  paramBVPSOL.shootingnodes=NULL;
  paramBVPSOL.xdata=NULL;
  paramBVPSOL.IOPT=NULL;
  paramBVPSOL.RW=NULL;
  paramBVPSOL.IW=NULL;
}

static void doneVars (void) {
  /* parameters for options */
  if ((paramOpt.optCreated) && (paramOpt.opt!=NULL))
    {mxDestroyArray((mxArray*)paramOpt.opt);paramOpt.opt=NULL;}
  
  /* global parameters */
    
  /* parameters for rightside */
  if (paramRightSide.rightSideFcn!=NULL)
    {mxFree(paramRightSide.rightSideFcn);paramRightSide.rightSideFcn=NULL;}
  paramRightSide.rightSideFcnH=NULL; /* geh�rt Aufrufer => nicht freigeben */
  if (paramRightSide.tArg!=NULL)
    {mxDestroyArray(paramRightSide.tArg);paramRightSide.tArg=NULL;}
  if (paramRightSide.xArg!=NULL)
    {mxDestroyArray(paramRightSide.xArg);paramRightSide.xArg=NULL;}
    
  /* parameters for boundary */
  if (paramBoundary.boundaryFcn!=NULL)
    {mxFree(paramBoundary.boundaryFcn);paramBoundary.boundaryFcn=NULL;}
  paramBoundary.boundaryFcnH=NULL; /* geh�rt Aufrufer => nicht freigeben */
  if (paramBoundary.xaArg!=NULL)
    {mxDestroyArray(paramBoundary.xaArg);paramBoundary.xaArg=NULL;}
  if (paramBoundary.xbArg!=NULL)
    {mxDestroyArray(paramBoundary.xbArg);paramBoundary.xbArg=NULL;}
    
  /* parameters for ode solver */
  if (paramODEsolver.odesolFcn!=NULL)
    {mxFree(paramODEsolver.odesolFcn);paramODEsolver.odesolFcn=NULL;}
  paramODEsolver.odesolFcnH=NULL; /* geh�rt Aufrufer => nicht freigeben */
  if (paramODEsolver.rightSideArg!=NULL)
    {mxDestroyArray(paramODEsolver.rightSideArg);paramODEsolver.rightSideArg=NULL;}
  if (paramODEsolver.tArg!=NULL)
    {mxDestroyArray(paramODEsolver.tArg);paramODEsolver.tArg=NULL;}
  if (paramODEsolver.xArg!=NULL)
    {mxDestroyArray(paramODEsolver.xArg);paramODEsolver.xArg=NULL;}
  if (paramODEsolver.optArg!=NULL)
    {mxDestroyArray(paramODEsolver.optArg);paramODEsolver.optArg=NULL;}
  /* Bereich auf den die Hilfspointer optRelTol, optAbsTol, ... 
     zeigen wurde jetzt schon entsorgt; dieser Speicherberich
     geh�rte ja zum struct-Field optArg */
    
  /* parameters for BVPSOL */
  /* shooting nodes d�rfen NICHT aufger�umt werden, sie geh�ren dem
     Aufrufer!! */
  if (paramBVPSOL.xdata!=NULL)
    {mxFree(paramBVPSOL.xdata);paramBVPSOL.xdata=NULL;}
  if (paramBVPSOL.IOPT!=NULL)
    {mxFree(paramBVPSOL.IOPT);paramBVPSOL.IOPT=NULL;}
  if (paramBVPSOL.RW!=NULL)
    {mxFree(paramBVPSOL.RW);paramBVPSOL.RW=NULL;}
  if (paramBVPSOL.IW!=NULL)
    {mxFree(paramBVPSOL.IW);paramBVPSOL.IW=NULL;}
}

static void stopMexFunction (int errNo,
  int i1, int i2, int i3, int i4, int i5) {
  char *msg;
  
  mexPrintf("Error (%i) [Version: %s]:\n",errNo,BVPSOLMexVersion);
  mexPrintf("Fehler (%i) [Version: %s]:\n",errNo,BVPSOLMexVersion);
  switch (errNo) {
    #include "errors.c"
    default: msg="unknown error number (Unbekannte Fehlernummer)";break;
  }
  
  doneVars();
  mexErrMsgTxt(msg);
}

static void checkNumberOfArgs (int nlhs, int nrhs) {
  if ((nlhs!=1) && (nlhs!=2)) stopMexFunction(1,nlhs,0,0,0,0);
  
  if ((nrhs!=5) && (nrhs!=6) && (nrhs!=7)) 
    stopMexFunction(2,nrhs,0,0,0,0);
}

static void processArgs (int nrhs, const mxArray* prhs[]) {
  int m,n,buflen;
  double *dpointer;
  
  /* 1st arg: right side */
  if (ismxArrayString(prhs[0])) {
    if ((mxGetNumberOfDimensions(prhs[0])!=2) || (mxGetM(prhs[0])!=1))
      stopMexFunction(4,mxGetNumberOfDimensions(prhs[0]),mxGetM(prhs[0]),0,0,0);
    buflen=mxGetN(prhs[0])*sizeof(mxChar)+1;
    paramRightSide.rightSideFcn=mxMalloc(buflen);
    mxGetString(prhs[0],paramRightSide.rightSideFcn,buflen);
    paramRightSide.rightSideFcnH=prhs[0];
  } else 
  if ( (ismxArrayFunction(prhs[0])) || (ismxArrayInline(prhs[0])) ) {
    if ((mxGetNumberOfDimensions(prhs[0])!=2) || (mxGetM(prhs[0])!=1) ||
        (mxGetN(prhs[0])!=1))
      stopMexFunction(21,mxGetNumberOfDimensions(prhs[0]),
                      mxGetM(prhs[0]),mxGetN(prhs[0]),0,0);
    paramRightSide.rightSideFcn=NULL; /* kein String */
    paramRightSide.rightSideFcnH=prhs[0];
  } else {
    stopMexFunction(3,0,0,0,0,0);
  }
  
  /* 2nd arg: boundary */
  if (ismxArrayString(prhs[1])) {
    if ((mxGetNumberOfDimensions(prhs[1])!=2) || (mxGetM(prhs[1])!=1))
      stopMexFunction(6,mxGetNumberOfDimensions(prhs[1]),mxGetM(prhs[1]),0,0,0);
    buflen=mxGetN(prhs[1])*sizeof(mxChar)+1;
    paramBoundary.boundaryFcn=mxMalloc(buflen);
    mxGetString(prhs[1],paramBoundary.boundaryFcn,buflen);
    paramBoundary.boundaryFcnH=prhs[1];
  }  else
  if ( (ismxArrayFunction(prhs[1])) || (ismxArrayInline(prhs[1])) ) {
    if ((mxGetNumberOfDimensions(prhs[1])!=2) || (mxGetM(prhs[1])!=1) ||
        (mxGetN(prhs[1])!=1))
      stopMexFunction(23,mxGetNumberOfDimensions(prhs[1]),
                      mxGetM(prhs[1]),mxGetN(prhs[1]),0,0);
    paramBoundary.boundaryFcn=NULL; /* kein String */
    paramBoundary.boundaryFcnH=prhs[1];
  } else {
    stopMexFunction(5,0,0,0,0,0);
  }

  /* 3rd arg: ode solver */
  if ( (prhs[2]==NULL) || (mxIsEmpty(prhs[2])) ) {
    /* use built-in difex1 */
    paramODEsolver.odesolFcn=NULL;
    paramODEsolver.odesolFcnH=NULL;
  } else {
    if (ismxArrayString(prhs[2])) {
      if ((mxGetNumberOfDimensions(prhs[2])!=2) || (mxGetM(prhs[2])!=1))
        stopMexFunction(8,mxGetNumberOfDimensions(prhs[2]),mxGetM(prhs[2]),0,0,0);
      buflen=mxGetN(prhs[2])*sizeof(mxChar)+1;
      paramODEsolver.odesolFcn=mxMalloc(buflen);
      mxGetString(prhs[2],paramODEsolver.odesolFcn,buflen);
      paramODEsolver.odesolFcnH=prhs[2];
    } else
    if ( (ismxArrayFunction(prhs[2])) || (ismxArrayInline(prhs[2])) ) {
      if ((mxGetNumberOfDimensions(prhs[2])!=2) || (mxGetM(prhs[2])!=1) ||
          (mxGetN(prhs[2])!=1))
        stopMexFunction(25,mxGetNumberOfDimensions(prhs[2]),
                        mxGetM(prhs[2]),mxGetN(prhs[2]),0,0);
      paramODEsolver.odesolFcn=NULL; /* kein String */
      paramODEsolver.odesolFcnH=prhs[2];
    } else {
      stopMexFunction(7,0,0,0,0,0);
    }
  }
  
  /* 4th arg: double vector */
  if (!mxIsDouble(prhs[3])) stopMexFunction(9,0,0,0,0,0);
  if (mxGetNumberOfDimensions(prhs[3])!=2) stopMexFunction(10,0,0,0,0,0);
  m=mxGetM(prhs[3]);n=mxGetN(prhs[3]);
  if ((m=1) && (m!=1)) stopMexFunction(11,m,n,0,0,0);
  if (m>n) paramBVPSOL.nodenumber=m; else paramBVPSOL.nodenumber=n;
  if (paramBVPSOL.nodenumber<2) stopMexFunction(12,paramBVPSOL.nodenumber,0,0,0,0);
  paramBVPSOL.shootingnodes=mxGetPr(prhs[3]);
  dpointer=paramBVPSOL.shootingnodes;
  for (m=1; m<paramBVPSOL.nodenumber; m++, dpointer++)
    if ((*dpointer)>=(*(dpointer+1))) stopMexFunction(13,0,0,0,0,0);

  /* 5th arg: double matrix */
  if (!mxIsDouble(prhs[4])) stopMexFunction(14,0,0,0,0,0);
  if (mxGetNumberOfDimensions(prhs[4])!=2) stopMexFunction(15,0,0,0,0,0);
  m=mxGetM(prhs[4]);n=mxGetN(prhs[4]);
  if (n!=paramBVPSOL.nodenumber) 
    stopMexFunction(16,paramBVPSOL.nodenumber,m,n,0,0);
  paramBVPSOL.d=m;
  /* diese Daten m�ssen kopiert werden, da sie an BVPSOL weitergegeben
     werden und dort ver�ndert werden! Nach Matlab-Kontrakt d�rfen aber
     Eingabeargumente nicht ver�ndert werden!! */
  paramBVPSOL.xdata=mxMalloc(m*n*sizeof(double));
  memcpy(paramBVPSOL.xdata,mxGetPr(prhs[4]),m*n*sizeof(double));
  
  /* 6th arg: struct mit BVPSOL options*/
  if ( (nrhs<6) || (mxIsEmpty(prhs[5])) ) {
    paramOpt.opt=mxCreateStructMatrix(1,1,0,NULL);
    paramOpt.optCreated=1;
  } else { 
    paramOpt.optCreated=0;
    if (!mxIsStruct(prhs[5])) stopMexFunction(17,0,0,0,0,0);
    paramOpt.opt=prhs[5];
  }
  
  /* 7th arg: struct mit ODE options */
  if ( (nrhs<7) || (mxIsEmpty(prhs[6])) ) {
    paramODEsolver.optArg=mxCreateStructMatrix(1,1,0,NULL);    
  } else {
    if (!mxIsStruct(prhs[6])) stopMexFunction(18,0,0,0,0,0);
    /* wir machen ein deep copy, DENN wir wollen vielleicht
       einige Felder �ndern: RelTol, AbsTol, ... 
       Oder wir f�gen die Felder ein, falls sie nicht vorhanden
       sind, aber auf jeden Fall wird die struct ver�ndert */
    paramODEsolver.optArg=mxDuplicateArray(prhs[6]);
    if ( (paramODEsolver.odesolFcn==NULL) && (paramODEsolver.odesolFcnH==NULL) ) 
      stopMexFunction(19,0,0,0,0,0);
  }
  
  /* consist check */
  if ( (paramBVPSOL.d>51) && 
       (paramODEsolver.odesolFcn==NULL) && (paramODEsolver.odesolFcnH==NULL) )
    stopMexFunction(501,0,0,0,0,0);
}

static void extractOptionSettings (void) {
  optSet.warnMiss=opt_getIntFromOpt(paramOpt.opt,&optSet,OPT_WARNMISS,0);
  optSet.warnType=opt_getIntFromOpt(paramOpt.opt,&optSet,OPT_WARNTYPE,1);
  optSet.warnSize=opt_getIntFromOpt(paramOpt.opt,&optSet,OPT_WARNSIZE,1);
}

static void extractIOPT (void) {
  int i;

  i=opt_getIntFromOpt(paramOpt.opt,&optSet,OPT_MAXITER,30);
  paramBVPSOL.IOPT[1-1]=i;
  if (i<1) stopMexFunction(101,i,0,0,0,0);
  
  i=opt_getIntFromOpt(paramOpt.opt,&optSet,OPT_CLASS,2);
  if ((i<0) || (i>3)) stopMexFunction(102,i,0,0,0,0);
  paramBVPSOL.IOPT[2-1]=i;

  i=opt_getIntFromOpt(paramOpt.opt,&optSet,OPT_SOLMETHOD,0);
  if ((i!=0) && (i!=1)) stopMexFunction(103,i,0,0,0,0);
  paramBVPSOL.IOPT[3-1]=i;

  /* BVPSOL soll gleich gar nicht versuchen, irgendetwas zu schreiben,
     denn es funktioniert ja in MATLAB sowieso nicht */
  paramBVPSOL.IOPT[4-1]=-1;
  paramBVPSOL.IOPT[5-1]=0; /* Output unit ist egal, vgl. oben */
}

static void extractTOL (void) {
  double d;
  
  d=opt_getDoubleFromOpt(paramOpt.opt,&optSet,OPT_RELTOL,1e-6);
  paramBVPSOL.EPS=d;
  if (!(d>0)) stopMexFunction(104,0,0,0,0,0);    
}

static void extractGlobalOptions (void) {
  paramGlobal.funcCallMethod=opt_getIntFromOpt(paramOpt.opt,&optSet,
    OPT_FUNCCALLMETHOD,1);
  switch (paramGlobal.funcCallMethod) {
    case 0: /* use mexCallMATLAB direct */
      if (paramRightSide.rightSideFcn==NULL) stopMexFunction(22,0,0,0,0,0);
      if (paramBoundary.boundaryFcn==NULL) stopMexFunction(24,0,0,0,0,0);
      if (paramODEsolver.odesolFcn==NULL) stopMexFunction(26,0,0,0,0,0);
      break;
    case 1: /* use mexCallMATLAB to call feval */
      break;
    default:
      stopMexFunction(20,0,0,0,0,0); 
      break;
  }
}

static void extractOptions (void) {
  extractOptionSettings();
  extractIOPT();
  extractTOL();
  extractGlobalOptions();
}

static void prepareIOPTArray (void) {
  paramBVPSOL.IOPT=mxMalloc(5*sizeof(int));
}

static void prepareRealWorkspace (void) {
  int n,m;
 
  n=paramBVPSOL.d;m=paramBVPSOL.nodenumber;

  if (paramBVPSOL.IOPT[3-1]==0) {
    paramBVPSOL.NRW=n*n*(m+5)+10*m*n+10*n+m;
  } else {
    /* Formel aus Fortran-Source bestimmt, NICHT aus Doku */
    paramBVPSOL.NRW=3*n*n*m+3*n*n+14*n*m+2*n+m-1;
  }
  paramBVPSOL.RW=mxMalloc(paramBVPSOL.NRW*sizeof(double));
}

static void prepareIntegerWorkspace (void) {
  int m,n,nz,licnq,lirnq,lisnq,h1,h2;
  
  n=paramBVPSOL.d;m=paramBVPSOL.nodenumber;
  if (paramBVPSOL.IOPT[3-1]==0) {
    paramBVPSOL.NIW=2*n*n+4*n;
  } else {
    nz = n*n*(m+1)+n*(m-1);
    licnq = 2*nz;
    h1 = (int)(ceil(1.5*(double)nz));
    h2 = nz+4*m*n;
    if (h2>h1) lirnq=h2; else lirnq=h1;
    if (licnq<lirnq) lirnq=licnq;
    lisnq=licnq+lirnq;
    /* paramBVPSOL.NIW=2*n*n*(m+1)+2*n*(m-1)+16*n*m+3*n+2*n*n+lisnq; */
    paramBVPSOL.NIW=2*n*n+3*n+16*m*n+2*nz+lisnq;
  }
  paramBVPSOL.IW=mxMalloc(paramBVPSOL.NIW*sizeof(int));
}

static void prepareIOMemory (void)
{
  /* Speicher f�r mxArrays, die den User-supplied
     Funktionen �bergeben werden. Dieser Speicher
     wird immer wieder verwendet. */
  int i,d;
  int numberOfOptFields=4;
  const char* optFields[] = {"RelTol","AbsTol","InitialStep","MaxStep"};
  
  d=paramBVPSOL.d;
  
  /* paramRightSide */
  paramRightSide.tArg=mxCreateDoubleMatrix(1,1,mxREAL);
  paramRightSide.xArg=mxCreateDoubleMatrix(d,1,mxREAL);
  
  /* paramBoundary */
  paramBoundary.xaArg=mxCreateDoubleMatrix(d,1,mxREAL);
  paramBoundary.xbArg=mxCreateDoubleMatrix(d,1,mxREAL);
  
  /* paramODEsolver */
  /* nur n�tig, wenn externer AWP-L�ser angegeben */
  if ( (paramODEsolver.odesolFcn!=NULL) || (paramODEsolver.odesolFcnH!=NULL) ) {
    switch (paramGlobal.funcCallMethod) {
      case 0:
        paramODEsolver.rightSideArg=mxCreateString(paramRightSide.rightSideFcn);
        break;
      case 1:
        /* Kopie anfertigen, denn rightSideArg wird freigegeben */
        paramODEsolver.rightSideArg=mxDuplicateArray(paramRightSide.rightSideFcnH);
        break;
      default: stopMexFunction(1002,0,0,0,0,0);break;
    }
    paramODEsolver.tArg=mxCreateDoubleMatrix(1,2,mxREAL);
    paramODEsolver.xArg=mxCreateDoubleMatrix(d,1,mxREAL);
    /* Test, ob die Felder, die wir unbedingt brauchen, auch da sind.
       Wenn nicht f�gen wir sie in die struct ein. */
    for (i=0; i<numberOfOptFields; i++) {
      if (mxGetField(paramODEsolver.optArg,0,optFields[i])==NULL) {
        mxAddField(paramODEsolver.optArg,optFields[i]);
      }
      mxSetField(paramODEsolver.optArg,0,optFields[i],
        mxCreateDoubleMatrix(1,1,mxREAL));      
    }
    /* So jetzt haben wir mindestens RelTol,AbsTol,InitialStep,MaxStep 
       mit (1,1) double-Matrix als Feld */
    paramODEsolver.optRelTol=mxGetPr(mxGetField(paramODEsolver.optArg,0,optFields[0]));
    paramODEsolver.optAbsTol=mxGetPr(mxGetField(paramODEsolver.optArg,0,optFields[1]));
    paramODEsolver.optInitialStep=mxGetPr(mxGetField(paramODEsolver.optArg,0,optFields[2]));
    paramODEsolver.optMaxStep=mxGetPr(mxGetField(paramODEsolver.optArg,0,optFields[3]));
  }
}

void BVPRightSideFunc (int *dim, double *t, double *x, double *dx) {
  int d,m,n;
  mxArray *rhs[3];
  mxArray *lhs[1];
  
  d=*dim;lhs[0]=NULL;

  /* Call by value */
  /* Use always the SAME Matlab tArg and xArg */
  /* IMPORTANT NOTICE (if the right side is also a MEX-File)
     the right side must not "garble" the passed mxArrays:
     the size must not be changed and the memory must not
     be freed. 
     Hence: the right side has to take care, that the
     passed mxArrays have the same size and enough memory
     when returning. The values in the memory(-block)
     may be overwritten.
     If the right side is an m-file MATLAB obeys this
     restriction automatically. */
  /* WICHTIGE Anmerkung (falls rechte Seite auch MEX-File ist)
     die rechte Seite darf die �bergebenen mxArrays nicht
     "verst�mmeln": die Gr��e darf nicht ver�ndert werden
     und auch der Speicherplatz darf nicht freigegeben werden.
     Also: die rechte Seite muss sicherstellen, dass die
     �bergebenen mxArrays am Ende wieder diesselbe Gr��e
     und ausreichend Speicher haben. Der Speicher selbst
     darf nat�rlich zu rechenzwecken �berschrieben werden.
     Bei m-Files achtet MATLAB automatisch darauf.
  */
  *mxGetPr(paramRightSide.tArg)= *t;
  memcpy(mxGetPr(paramRightSide.xArg),x,d*sizeof(double));
  switch (paramGlobal.funcCallMethod) {
    case 0:
      rhs[0]=paramRightSide.tArg;
      rhs[1]=paramRightSide.xArg;

      /* Call User's right side */
      mexCallMATLAB(1,lhs,2,rhs,paramRightSide.rightSideFcn);
      break;
    case 1:
      rhs[0]=(mxArray*)paramRightSide.rightSideFcnH;
      rhs[1]=paramRightSide.tArg;
      rhs[2]=paramRightSide.xArg;

      /* Call User's right side */
      mexCallMATLAB(1,lhs,3,rhs,"feval");
      break;
    default: stopMexFunction(1002,0,0,0,0,0);break;
  }
    
  /* check return values */
  if (lhs[0]==NULL) stopMexFunction(201,0,0,0,0,0);
  if ((!mxIsDouble(lhs[0])) || (mxGetNumberOfDimensions(lhs[0])!=2))
    stopMexFunction(202,0,0,0,0,0);
  m=mxGetM(lhs[0]);n=mxGetN(lhs[0]);
  if (!(((m==d) && (n==1)) || ((m==1) && (n==d))))
      stopMexFunction(203,m,n,0,0,0);    
      
  /* copy back */
  memcpy(dx,mxGetPr(lhs[0]),d*sizeof(double));
  
  /* free memory */
  mxDestroyArray(lhs[0]);    
}

void BVPBoundaryCondFunc (double *xa, double *xb, double *r) {
  int d,m,n;
  mxArray *rhs[3];
  mxArray *lhs[1];
    
  d=paramBVPSOL.d;lhs[0]=NULL;
  
  /* Call by value */
  /* Use always the SAME Matlab xaArg and xbArg */
  /* Bemerkung vgl.: BVPRightSideFunc */
  memcpy(mxGetPr(paramBoundary.xaArg),xa,d*sizeof(double));
  memcpy(mxGetPr(paramBoundary.xbArg),xb,d*sizeof(double));
  switch (paramGlobal.funcCallMethod) {
    case 0:
      rhs[0]=paramBoundary.xaArg;
      rhs[1]=paramBoundary.xbArg;

      /* Call User's boundary function */
      mexCallMATLAB(1,lhs,2,rhs,paramBoundary.boundaryFcn);
      break;
    case 1:
      rhs[0]=(mxArray*)paramBoundary.boundaryFcnH;
      rhs[1]=paramBoundary.xaArg;
      rhs[2]=paramBoundary.xbArg;

      /* Call User's boundary function */
      mexCallMATLAB(1,lhs,3,rhs,"feval");
      break;
    default: stopMexFunction(1002,0,0,0,0,0);break;
  }
  
  /* check return values */
  if (lhs[0]==NULL) stopMexFunction(301,0,0,0,0,0);
  if ((!mxIsDouble(lhs[0])) || (mxGetNumberOfDimensions(lhs[0])!=2))
    stopMexFunction(302,0,0,0,0,0);
  m=mxGetM(lhs[0]);n=mxGetN(lhs[0]);
  if (!(((m==d) && (n==1)) || ((m==1) && (n==d))))
    stopMexFunction(303,m,n,0,0,0);
    
  /* copy back */
  memcpy(r,mxGetPr(lhs[0]),d*sizeof(double));
  
  /* free memory */
  mxDestroyArray(lhs[0]);  
}

void BVPODESolverFunc (int *dim,
  BVPRightSide f, double *t, double *y, double *tend,
  double *TOL, double *hmax, double *h, int *kflag) {
  int d,i,m,n,offset;
  mxArray *rhs[5];
  mxArray *lhs[4];
  double *numbers;
  
  d=paramBVPSOL.d;
  lhs[0]=NULL;lhs[1]=NULL;lhs[2]=NULL;lhs[3]=NULL;
  
  /* Call by value */
  /* Use always the SAME Matlab memory for all input args */
  /* Bemerkung vgl.: BVPRightSideFunc */
  offset=0;
  switch (paramGlobal.funcCallMethod) {
    case 0:
      break;
    case 1:
      rhs[offset++]=(mxArray*)paramODEsolver.odesolFcnH;
      break;
    default: stopMexFunction(1002,0,0,0,0,0);break;
  }
  rhs[offset++]=paramODEsolver.rightSideArg;
  rhs[offset++]=paramODEsolver.tArg;
  rhs[offset++]=paramODEsolver.xArg;
  rhs[offset++]=paramODEsolver.optArg;

  numbers=mxGetPr(paramODEsolver.tArg);numbers[0]= *t; numbers[1]= *tend; 
  memcpy(mxGetPr(paramODEsolver.xArg),y,d*sizeof(double));
  *paramODEsolver.optRelTol = *TOL;
  *paramODEsolver.optAbsTol = *TOL;
  *paramODEsolver.optInitialStep = *h;
  *paramODEsolver.optMaxStep = *hmax;
  
  switch (paramGlobal.funcCallMethod) {
    case 0:
      /* Call Users's ODE solver */
      mexCallMATLAB(4,lhs,offset,rhs,paramODEsolver.odesolFcn);
      break;
    case 1:
      /* Call Users's ODE solver */
      mexCallMATLAB(4,lhs,offset,rhs,"feval");
      break;
    default: stopMexFunction(1002,0,0,0,0,0);break;
  }
  
  /* check return values */
  /* 1st return: tGitter */
  if (lhs[0]==NULL) stopMexFunction(401,1,0,0,0,0);
  /* Rest von 1st Arg ist egal */
  
  /* 2nd return: xGitter */
  if (lhs[1]==NULL) stopMexFunction(401,2,0,0,0,0);
  if ((!mxIsDouble(lhs[1])) || (mxGetNumberOfDimensions(lhs[1])!=2))
    stopMexFunction(404,0,0,0,0,0);
  m=mxGetM(lhs[1]);n=mxGetN(lhs[1]);
  if ((n!=d) || (m<=0)) stopMexFunction(405,m,n,0,0,0);
  
  /* 3rd return: stats */
  if (lhs[2]==NULL) stopMexFunction(401,3,0,0,0,0);
  if ( (!mxIsDouble(lhs[2])) || (mxGetNumberOfDimensions(lhs[2])!=2) ||
       (mxIsEmpty(lhs[2])) )
    stopMexFunction(406,0,0,0,0,0);
  m=mxGetM(lhs[2]);n=mxGetN(lhs[2]);
  if ( (m!=1) && (n!=1) ) stopMexFunction(406,0,0,0,0,0);
  
  /* 4th return: taunext */
  if (lhs[3]==NULL) stopMexFunction(401,4,0,0,0,0);
  if ((!mxIsDouble(lhs[3])) || (mxGetNumberOfDimensions(lhs[3])!=2))
    stopMexFunction(408,0,0,0,0,0);
  m=mxGetM(lhs[3]);n=mxGetN(lhs[3]);
  if ((m!=1) || (n!=1)) stopMexFunction(408,0,0,0,0,0);
  
  /* copy back */
  m=mxGetM(lhs[1]);n=mxGetN(lhs[1]);numbers=mxGetPr(lhs[1])+m-1;
  for (i=0; i<d; i++,y++,numbers+=m) {
    *y = *numbers;
  }
  
  *h = *mxGetPr(lhs[3]);
  *kflag = (int)(*mxGetPr(lhs[2]));
  
  /* free memory */
  mxDestroyArray(lhs[3]);mxDestroyArray(lhs[2]);
  mxDestroyArray(lhs[1]);mxDestroyArray(lhs[0]);
}

static void createReturnValues (int nlhs, mxArray* plhs[]) {
  /* xdata */
  plhs[0]=mxCreateDoubleMatrix(paramBVPSOL.d,
    paramBVPSOL.nodenumber,mxREAL);
    
  memcpy(mxGetPr(plhs[0]),paramBVPSOL.xdata,
    paramBVPSOL.d*paramBVPSOL.nodenumber*sizeof(double));
   
  /* info */
  if (nlhs>1) {
    plhs[1]=mxCreateDoubleMatrix(1,1,mxREAL);
    *mxGetPr(plhs[1])=paramBVPSOL.INFO;
  }
}

void mexFunction (int nlhs, mxArray* plhs[],
                  int nrhs, const mxArray* prhs[]) {
  BVPODESolver odeSolver;
  
  initVars();
  
  checkNumberOfArgs(nlhs,nrhs);
  processArgs(nrhs,prhs);
  
  prepareIOPTArray();  
  extractOptions();
  prepareRealWorkspace();
  prepareIntegerWorkspace();
  prepareIOMemory();
  
  if ( (paramODEsolver.odesolFcn==NULL) && (paramODEsolver.odesolFcnH==NULL) ) {
    odeSolver=&DIFEX1_; 
  } else {
    odeSolver=&BVPODESolverFunc;
  }
  
  BVPSOL_(&BVPRightSideFunc,&BVPBoundaryCondFunc,
    odeSolver,&paramBVPSOL.d,&paramBVPSOL.nodenumber,
    paramBVPSOL.shootingnodes,paramBVPSOL.xdata,
    &paramBVPSOL.EPS,paramBVPSOL.IOPT,&paramBVPSOL.INFO,
    &paramBVPSOL.NRW,paramBVPSOL.RW,
    &paramBVPSOL.NIW,paramBVPSOL.IW);
      
  if (paramBVPSOL.INFO==-10) stopMexFunction(1001,0,0,0,0,0);  
  
  createReturnValues(nlhs,plhs);
  
  doneVars();
}
