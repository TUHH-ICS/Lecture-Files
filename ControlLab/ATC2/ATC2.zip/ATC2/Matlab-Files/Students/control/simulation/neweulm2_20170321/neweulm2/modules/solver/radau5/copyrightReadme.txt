This algorithm was downlowded from:
http://www-m3.ma.tum.de/Software/ODEHome

The following has been copied from the homepage mentioned above:

Copyright Notice
This software is provided for non-commercial use only. See the license conditions and the warranty conditions.

Copyright © Christian Ludwig

License
The use of ODE Mexfiles is hereby granted free of charge for an unlimited time, provided the following rules are accepted and applied:

   1. You may use or modify this code for your own non commercial and non violent purposes.
   2. The code may not be re-distributed without the consent of the authors.
   3. The copyright notice and statement of authorship must appear in all copies.
   4. You accept the warranty conditions (see WARRANTY).
   5. In case you intend to use the code commercially, we oblige you to sign an according licence agreement with the authors. 

Warranty
This code has been tested up to a certain level. Defects and weaknesses, which may be included in the code, do not establish any warranties by the authors.

The authors do not make any warranty, express or implied, or assume any liability or responsibility for the use, acquisition or application of this software. 
