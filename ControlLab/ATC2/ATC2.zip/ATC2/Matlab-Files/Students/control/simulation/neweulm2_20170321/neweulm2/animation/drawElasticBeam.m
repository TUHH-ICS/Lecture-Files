% drawElasticBeam - create graphical representation of an elastic body
%
%  Description:
% This function was written mainly to animate flexible shapes like elastic
% bodies. These bodies are based on an existing line element around which a
% cross section is drawn. At each point of the line, one crosssection is
% drawn and oriented orthogonal to the line. Therefore the resolution is
% usually determined by the line. This element does not represent torsion.
% 
%  Input arguments:
% lineID ... Id of the line element, which has been created with the
%            command drawLine
%
%  Optional input arguments, given pairwise:
% Color .......... Surface Color {[1 0 0]}
% CrossSection ... The crosssection can be specified as a nx3 matrix
%                  containing points in the yz-plane. To get closed shapes,
%                  the first and last point should be identical. As a
%                  standard a quadratic shape with sidelength 0.2 is used.
%                  {0.2*[0 -1 -1; 0 1 -1; 0 1 1; 0 -1 1; 0 -1 -1]}
%                  this parameter may contain symbolic constants of
%                  Neweul-M2
% FaceAlpha ...... Alpha value of the faces to make them translucent {1}
% FaceColor ...... Color of the faces as RGB value or 'none' for only
%                  wireframes {[0.7 0 0]}
% EdgeAlpha ...... Alpha value of the edges to make them translucent {1}
% EdgeColor ...... Color of the edges as RGB value or 'none' {[1 0 0]}
% NumPoints ...... The number of points along the line can be specified,
%                  however the default value is recomended, which uses the
%                  resolution of the line {[]}
% SideLengths .... When a rectangular crosssection with non-standard
%                  sidelengths shall be used. For a two element vector, the
%                  first element is used for the y-axis, the second element
%                  for the z-axis. If only one value is given, the
%                  crosssection is quadratic {0.2}
%                  this parameter may contain symbolic constants of
%                  Neweul-M2
% Radius ......... This option requires one numerical value specifying the
%                  radius of a circular shape.
%                  this parameter may contain symbolic constants of
%                  Neweul-M2
% Tag ............ For identification the Tag property can be specified
%                  {['elasticShape_',lineID]}
% Triangle ....... Similar to the option 'SideLengths', this create a
%                  triangle with equal sides, axissymetric to the z-axis.
%                  If one parameter is given, the triangle is scaled, if
%                  two parameters are given, the scale y- and z-direction,
%                  keeping the symmetry {1}
%                  this parameter may contain symbolic constants of
%                  Neweul-M2
% 
%  Return argument:
% objHandle ...... Graphics handle to the hgtransform object, being the
%                  parent of this shape
%
%  See also:
% drawArrow3d, drawCube, drawLine, drawRotBody, drawSphere,
% drawSTL, drawSpring
% 
%  Example:
% drawElasticBeam('myLineId')
%
% First appearance: 20.01.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
