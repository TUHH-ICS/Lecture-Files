%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                   %
%                         runModalAnalysis                          %
%                                                                   %
% fuehre Modalanalyse durch und stelle Eigenformen dar              %
%                                                                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% fuehre Modalanalyse durch

fprintf(1,'fuehre Modalanalyse durch ...');
sys.results.modalAnalysis = modalAnalysis(0);
fprintf(1,' ok!\n');


% Darstellung der Eigenformen

fprintf(1,'stelle Eigenmoden dar ...');

amp = 0.5*ones(sys.counters.genCoord,1);

for j = 1:sys.counters.genCoord % Schleife ueber alle Freiheitsgrade
    
    showModeShape(sys.results.modalAnalysis,j, ...
              'Amplitude',amp(j), ...
              'ShowRefPos','on', ...
              'RefPosTransparency',0.3 ...
              );
    
end;

fprintf(1,' ok!\n');
