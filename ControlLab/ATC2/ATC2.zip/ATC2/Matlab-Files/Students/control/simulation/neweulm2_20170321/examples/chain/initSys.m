%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                    %
% Program to initialize a modell                                     %
%                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Author:       Dipl.-Ing. Thomas Kurz
%
% e-Mail:       kurz@itm.uni-stuttgart.de
%
% Institute:    Universitaet Stuttgart
%               Institut fuer Technische und Numerische Mechanik
%               Pfaffenwaldring 9
%               70569 Stuttgart
%

%%%%%%%%%%%%%%%%%%%%%%%%
% Extend path variable %
%%%%%%%%%%%%%%%%%%%%%%%%
% If you did not call 'startneweulm2.m' before this, then please enter here
% the path to the folder containing neweulm2. Otherwise just skip this.
% For the local version, you can set mypath_ = '../../neweulm2';
% For the server version, please enter the full path.
mypath_ = '../../neweulm2'; % Local version
% mypath_ = '/home/itm/itmsw/neweulm2/currentVersion/neweulm2'; % ITM Server version

% Check if path is already available, then use the available routines
if(exist('initGraphics.m','file') ~= 2)
    % Recursively add all subdirectories of neweulm2
    addpath(genpath(mypath_));
end
% Add temporary folders
addpath('./sysFunctions');
addpath('./userFunctions');

%%%%%%%%%%%%%%%%%%%%%%%%
% Initialize Workspace %
%%%%%%%%%%%%%%%%%%%%%%%%

close all;
clear all;
clear global;

%%%%%%%%%%%%%%
% load Model %
%%%%%%%%%%%%%%

global sys;
fprintf(1,'Loading Model ...');
load('sys.mat');
fprintf(1,' ok!\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define user defined parameters %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fprintf(1,'Defining Auxiliary Variables ...');
setUserVar;
fprintf(1,' ok!\n');

%%%%%%%%%%%%%%%%%%%%%%%%
% initialize Animation %
%%%%%%%%%%%%%%%%%%%%%%%%

% fprintf(1,'Initializing the Animation ...');
% createAnimationWindow;

% Add shapes in the plot window
% defineGraphics;

% Update the plot window
% updateGeo(0,zeros(sys.counters.genCoord,1));

% define Visible area
% axis equal;
% xlim([-0.4 0.4]);
% ylim([-0.4 0.4]);
% zlim([-0.4 0.4]);
% view(30,18);

% set visibility properties
% setVisibility('on');

% fprintf(1,' ok!\n');

%%%%%%%%%%%%%%%%%%%
% save the System %
%%%%%%%%%%%%%%%%%%%

fprintf(1,'\nSaving System ...');
save 'sys.mat' sys;
fprintf(1,' ok!\n');
