% res_ = cell2sym(expr_,varargin)
% cell2sym - Convert the cell array containing strings to a symbolic array
% with the same sizes, containing similar symbolic expressions. Here
% similar is used because prefixes and suffixes can be inserted with this
% function as well.
% 
% Input arguments
% expr_ ...... Cell array to be converted to a symbolic array
%
% Optional input arguments in argument/value pairs:
% size .......... Specification of the size of the new symbolic array.
%                 {size(expr_)} The user can use one of the following
%                 formats:
%   isnumeric ... If newSize_ is a numerical value, it is used to specify
%                 the size, then res_ is initialized with
%                 res_=zeros(newSize_)
%   rowvect ..... res_ is a row vector with newSize_=[1,numel(expr_)]
%   colvect ..... res_ is a column vector with newSize_=[numel(expr_),1]
%
% prefix ........ If a string is passed as prefix, this is inserted before
%                 each entry of expr_. {''}
% suffix ........ If a string is passed as suffix, this is inserted after
%                 each entry of expr_. {''}
% returncell .... As this function has proven to be quite usefull, this
%                 additional option allows to add pre- or suffixes even
%                 when returning a cell array. This option returns a cell
%                 array, but otherwise does the same as before. As this is
%                 meant to be used for pre-/suffixes, all entries are
%                 converted to be strings. {false}
% strrep ........ This option requests a cell array with two elements as
%                 second input value, both being strings. Then occurences
%                 of the first element are replaced with the second using
%                 the function strrep. E.g.
%                 convertString(sym('[a;a+2;a1]'),'strrep',{'a','b'})
% 
% Example
%   res_ = cell2sym({'x','y','z'},'size','colvect','Prefix','D');
%
% First appearance: 26.05.2010
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
