% [ye_, t_] = animoscil(results,n,varargin)
