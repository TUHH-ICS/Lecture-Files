function u = f_u(t)
% f_u - definition of time-depending user-defined variable u
% Front axle

global sys;



% constant user-defined variables

c = sys.parameters.data.c;
z = sys.parameters.data.z;


% time dependent user-defined variables

u = zeros(1,1);

if(0 < t && t < 0.6)
    u(1) = 0.5*z*(1-cos(c*t));
end
