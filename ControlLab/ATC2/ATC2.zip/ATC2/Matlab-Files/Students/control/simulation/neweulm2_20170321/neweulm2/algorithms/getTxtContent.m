% res = getTxtContent(hObject, varargin)
% Function which gets the String of the text-field hObject and returns it
% in the required Type, e.g. numeric. If the String is empty, the default
% value is returned and entered in the text-field hObject. If nothing is
% specified this is a zero. Options have to be passed in pairs, e.g:
% getTxtContent(hObject, 'type','numeric', 'default','nothing entered')
%
% replace get(hObject,'String') by getTxtContent(hObject);
% replace str2num(get(hObject,'String')) by getTxtContent(hObject, 'type','numeric');
% 
% Examples:
% With full options the structure is:
%   getTxtContent(hObject,'type','varname','default','test1');
% Only numerical values
%   getTxtContent(hObject,'type','numeric','default',1);
% Only positive (larger than zero) numerical values
%   getTxtContent(hObject,'type','positivenonzero','default',1);
% 
% Input arguments
% hObject ..... Handle to the object, from which the String property shall
%               be read.
% Optional arguments in pairwise manner, {default values}
% allowVector ..... As a standard, only scalar expressions are expected.
%                   Using this option, the user may use ',' to separate the
%                   elements {false}
% default ......... The default value to be returned if nothing or the
%                   wrong data type is entered. The user has to ensure
%                   that his default value is of the proper type and
%                   value! {'0'}
% type ............ Defining the data type which the return value shall have.
%                   If nothing is specified, {'string'} is assumed.
%                   Possibilities are:
%   filename .......... A filename is expected. May contain a path and a
%                       file extension, however, the filename should be a
%                       valid variable name using 'isvarname()'
%   nonzero ........... The input is not allowed to be equal to zero. But
%                       otherwise either a numerical or symbolical
%                       expression is valid.
%   numeric ........... Only data which does not cause [] to be returned
%                       from 'str2num()' is valid. str2num is used instead
%                       of str2double as it accepts 'pi'.
%   positiveNumeric ... Like 'numeric' but the result is always positive,
%                       in the meaning of 'abs()'. Therefore a zero is a
%                       valid return value.
%   positiveNonZero ... Numerical return values like 'positiveNumeric',
%                       but always larger than zero.
%   string ............ Only character arrays are valid, meaning it is
%                       just checked whether the user entered any string.
%   symbolic .......... Input is tried to be interpreted as a symbolic
%                       expression with the 'sym()' function.
%   varname ........... Input should be a valid variable name
% CheckVarargin ... An advanced feature to avoid errors if invalid
%                   parameters are passed. This is only if you know
%                   exactly what you are doing. {true}
%
% First appearance: 11.03.2008
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
