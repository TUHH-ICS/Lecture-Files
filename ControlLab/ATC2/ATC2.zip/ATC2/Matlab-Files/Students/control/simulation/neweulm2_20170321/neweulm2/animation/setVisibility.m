% setVisibility - Set visibility properties of graphic objects
%
%  Optional Parameters to be passed in pairs {default value}:
% Body ............ ID of the body under consideration, e.g. 'BODY_1', will
%                   influence all coordinate systems and surface objects
%                   associated with this body
% Tag ............. Tag of graphic object, e.g. 'Sphere_1'
% Type ............ Type: ['Text','Frame','Shape']
% CheckVarargin ... An advanced feature to avoid errors if invalid
%                   parameters are passed. This is only if you know
%                   exactly what you are doing. {true}
%
%  Function calls:
% setVisibility('on'); % Switches everything on
% setVisibility('off','Type','Text'); % Disables the text
% setVisibility('off','Body','BODY_1'); % Makes 'BODY_1' invisible
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
