%getAbbreviations - Fill up sys.parameters.data
