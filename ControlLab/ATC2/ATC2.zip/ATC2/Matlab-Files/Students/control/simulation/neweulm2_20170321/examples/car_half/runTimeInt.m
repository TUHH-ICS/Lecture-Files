function runTimeInt
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function runTimeInt                                               %
%                                                                   %
%                             runTimeInt                            %
%                                                                   %
% Perform a time integration of the nonlinear equations of motion   %
% and start an animation of the results                             %
%                                                                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global sys;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initialize all values and parameters for the time integration

% Time Intervall [t0, t1] for the numerical integration
timeInterval = [-2 4];

% Initial values for the integration, for both position and velocity of all
% generalized coordinates, at t = timeInterval(1);
% Attention!! Do not exceed system dimension

% If the following parameter is set to true, the static equilibrium will be
% calculated and the specified initial conditions added to these values
measureFromEquilibrium = false;

% Initialization
% y0  = zeros(sys.counters.genCoord,1); % For the generalized coordinates on position level
Dy0 = zeros(sys.counters.genCoord,1); % For the generalized coordinates on velocity level

y0 = [-0.0182; 0.0024; 0.0006; -0.0017; 0; -0.0003; -0.0042; -0.0030];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ensure that system dimension is not exceeded
y0  = y0(1:sys.counters.genCoord);
Dy0 = Dy0(1:sys.counters.genCoord);
% Calculation of the static equilibrium, if requested
if(sys.counters.constraint == 0 && measureFromEquilibrium)
    % Evaluate static equilibrium and add initial conditions
    % Attention! All time dependent functions are evaluated at t = t0 !
    fprintf(1,'Calculating Static Equilibrium ...\n');
    ye = staticEquilibrium(timeInterval, zeros(sys.counters.genCoord,1));
    sys.results.statEq = ye;
    updateGeo(0,ye); % Update animation window
    fprintf(1,'ok!\n');
    % Adjust initial values
    y0 = ye + y0;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Choose the integration algorithm, leave empty for standard choice
% There are several integration algorithms available, Matlab offers
% ode45, ode15s, ode23, ode113, ode23s, ode23t, ode23tb
% Other choices usually provided by Neweul-M2 are:
% ode1, ode1s, ode2, ode3, ode4, ode5, radauMex, dop853Mex
%
% Recommended choices are, if available:
% Systems with tree structure:       ode45, dop853Mex
% Systems with constraint equations: ode15s, radauMex
integrator = [];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Integration options and tolerances
sys.settings.timeInt.intOpts = odeset;
% Refine the tolerances
sys.settings.timeInt.intOpts.AbsTol=1e-8;
sys.settings.timeInt.intOpts.RelTol=1e-5;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Activate a measure to follow the progress of the integration
sys.settings.timeInt.display.type = 'waitbar';
% sys.settings.timeInt.display.type = 'odeplot';
% sys.settings.timeInt.display.type = 'animation';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Check if everything has been set and is available
if(sys.parameters.data.mcar == 0)
    setUserVar;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Time integration
fprintf(1,'Integrating the System over Time ...');
sys.results.timeInt = timeInt(y0, Dy0, 'time', timeInterval, 'integrator', integrator);
fprintf(1,' ok!\n');

if(isempty(sys.graphics.axes) || ~ishandle(sys.graphics.axes))
    % No animation window available, quit without animation
    return;
else
    % Animation window exists, start animation
    if(~isfield(sys.graphics,'surfaces') || isempty(sys.graphics.surfaces))
        % If shapes haven't been defined yet, do it now
        defineGraphics;
    end
    % Preparations for the animation
    axis([-2.3 2.3 -2 2 0 1.6]); view(0, 0);
    % Plot trajectories
    plotTrajectories('RoadR');
    plotTrajectories('RoadF','Color',[1 0 0]);
    % Adjust visible area
    fitCanvas('equal','CenterCS','Anim','allowance',0.3);

    figure(sys.graphics.fig); % Pull window to foreground
    animTimeInt(sys.results.timeInt,'CenterCS','Anim');
end
% END OF FILE

