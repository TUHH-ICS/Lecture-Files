function D2MVV = f_D2MVV(t,varargin)

D2MVV = 0;
