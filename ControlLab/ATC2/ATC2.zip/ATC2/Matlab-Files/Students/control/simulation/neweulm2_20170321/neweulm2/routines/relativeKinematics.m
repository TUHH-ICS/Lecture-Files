% relativeKinematics(y,Dy,D2y,Yvars_,Yvars_D_,frame,minorAdjustment_)
% 
% relativeKinematics - Calculate the relative kinematic values of
% coordinate systems recursively. After every call, this function calls
% itself to calculate the kinematics of all 'Children'.
% This function is the replacement of calcKin, which consisted of several
% subfunctions for different cases and always calculated relative and
% absolute values. Now the absolute kinematic values are calculated by
% absoluteKinematics.
% 
% Inputs:  
% y             generalized coordinates
% Dy            generalized velocities
% D2y           generalized acclerations
% Yvars_        state-dependent parmaters
% Yvars_D_      directional derivatives of all state-dependent parameters
% frame         coordinate system to calculate the kinematics of
%
% All values calculated by this function are stored under
% sys.kinematics(idx_).relative and are described in the respective frame of
% reference.
% 
% Subfunctions in this file:
% - calcKinRel
% - calcKinRelNode
% - calcKinRelJointSys
% 
% See also: absoluteKinematics, calcEqMotNonLin, expandTimeVars,
%   jacobianMatrix, kardan2rotmat, rotmat2kardan,
%   relativeKinematics>calcKinRelNode,
%   relativeKinematics>calcKinRelJointSys, relativeKinematics>calcKinRel
%
% First appearance: 14.03.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
