/* description of errors, included in seulexMex.c */
/* m�gliche Fehler, werden in seulexMex.c included */

/* general Errors */
/* allgemeine Fehler */
case 1:
  mexPrintf("English: \n");
  mexPrintf("Only 2,3 or 4 output arguments are possible, but %i were requested.\n",i1);
  mexPrintf("German: \n");
  mexPrintf("Es werden 2,3 oder 4 Ausgabeargumente unterst�tzt. Verlangt wurden\n");
  mexPrintf("aber %i Ausgabeargumente.\n",i1);
  msg="Invalid number of output arguments (Ung�ltige Anzahl von Ausgabeargumenten)";break;
case 2:
  mexPrintf("English: \n");
  mexPrintf("Only 3 or 4 input arguments are possible, but %i were passed.\n",i1);
  mexPrintf("German: \n");
  mexPrintf("Es werden 3 oder 4 Eingabeargumente unterst�tzt. Es wurden aber\n");
  mexPrintf("%i Argumente �bergeben.\n",i1);
  msg="Invalid number of input arguments (Ung�ltige Anzahl von Eingabeargumenten)";break;
case 3:
  mexPrintf("English: \n");
  mexPrintf("1st argument has to be a string (function name), a function handle\n");
  mexPrintf("or an inline function.\n");
  mexPrintf("German: \n");
  mexPrintf("1. Argument muss ein String (Funktionsname), ein Funktions-Handle\n");
  mexPrintf("oder eine inline-Funktion sein.\n");
  msg="1. Arg: Function (String,handle,inline) expected";break;
case 4:
  mexPrintf("English: \n");
  mexPrintf("1st argument has characters, but needs to be ONE string. ");
  if (i1!=2) 
    mexPrintf("Not a 0-, 1- or >=3-dimensional thing.");
  else
    if (i2!=1) mexPrintf("Not a matrix containing strings.");
  mexPrintf("\n");
  mexPrintf("German: \n");
  mexPrintf("1. Argument enth�lt Zeichen, muss aber EIN String sein. ");
  if (i1!=2) 
    mexPrintf("Kein 0-,1- oder >=3-dimensionales Gebilde."); 
  else
    if (i2!=1) mexPrintf("Keine Matrix aus Strings.");
  mexPrintf("\n");
  msg="1. Arg: only ONE string expected (nur EIN String erwartet)";break;
case 5:
  mexPrintf("English: \n");
  mexPrintf("2nd argument has to be a double row vector.\n");
  mexPrintf("German: \n");
  mexPrintf("2. Argument muss ein double-Zeilenvektor sein.\n");
  msg="2. Arg: double row vector expected (double-Vektor erwartet)";break;
case 6:
  mexPrintf("English: \n");
  mexPrintf("2nd argument has to be a double row vector. ");
  if (i1!=2) 
    mexPrintf("Not a 0-, 1- or >=3-dimensional thing.");
  else
    if (i2!=1) mexPrintf("Not a double matrix");
  mexPrintf("\n");
  mexPrintf("German: \n");
  mexPrintf("2. Argument muss ein double-Vektor sein. ");
  if (i1!=2)
    mexPrintf("Kein 0-,1- oder >=3-dimensionales Gebilde."); 
  else
    if (i2!=1) mexPrintf("Keine double-Matrix.");
  mexPrintf("\n");
  msg="2. Arg: (1,k) double vector expected ((1,k) double-Vektor erwartet)";break;
case 7:
  mexPrintf("English: \n");
  mexPrintf("2nd argument has to be a double vector with at least 2 components.\n");
  mexPrintf("The length of the vector found is %i.\n",paramGlobal.tLength);
  mexPrintf("German: \n");
  mexPrintf("2. Argument muss double-Vektor mit mindestens der\n");
  mexPrintf("L�nge 2 sein. Der �bergebene Vektor hat L�nge %i.\n",
    paramGlobal.tLength);
  msg="2. Arg: (1,k) double vector (k>=2) expected ((1,k) double-Vektor (k>=2) erwartet)";break;
case 8:
  mexPrintf("English: \n");
  mexPrintf("3rd argument has to be a double column vector.\n");
  mexPrintf("German: \n");
  mexPrintf("3. Argument muss ein double-Spaltenvektor sein.\n");
  msg="3. Arg: double vector expected (double-Vektor erwartet)";break;
case 9:
  mexPrintf("English: \n");
  mexPrintf("3rd argument has to be a double column vector.\n");
  if (i1!=2) 
    mexPrintf("Not a 0-, 1- or >=3-dimensional thing.");
  else
    if (i2!=1) mexPrintf("Not a double matrix");
  mexPrintf("\n");
  mexPrintf("German: \n");
  mexPrintf("3. Argument muss ein double-Spaltenvektor sein. ");
  if (i1!=2)
    mexPrintf("Kein 0-,1- oder >=3-dimensionales Gebilde."); 
  else
    if (i2!=1) mexPrintf("Keine double-Matrix.");
  mexPrintf("\n");
  msg="3. Arg: (d,1) double vector expected ((d,1) double-Vektor erwartet)";break;
case 10:
  mexPrintf("English: \n");
  mexPrintf("3rd argument has to be a double column vector with at least one component.\n");
  mexPrintf("The length of the vector found was %i.\n",paramGlobal.d);
  mexPrintf("German: \n");
  mexPrintf("3. Argument muss ein double-Spaltenvektor mit mindestens\n");
  mexPrintf("der L�nge 1 sein. Der �bergebene Vektor hat L�nge %i.\n",paramGlobal.d);
  msg="3. Arg: (d,1) double vector (d>=1) expected ((d,1) double-Vektor (d>=1) erwartet)";break;    
case 11:
  mexPrintf("English: \n");
  mexPrintf("4th argument has to be a struct.\n");
  mexPrintf("German: \n");
  mexPrintf("4. Argument muss eine struct sein.\n");
  msg="4. Arg: struct expected (struct erwartet)";break;
case 12:
  mexPrintf("English: \n");
  mexPrintf("Concerning option '%s':\n",OPT_ISAUTONOMOUS);
  mexPrintf("Valid values for '%s' are 0 or 1.\n",OPT_ISAUTONOMOUS);
  mexPrintf("But I found '%s'=%i.\n",OPT_ISAUTONOMOUS,i1);
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_ISAUTONOMOUS);
  mexPrintf("G�ltige Werte f�r '%s' sind 0 oder 1.\n",OPT_ISAUTONOMOUS);
  mexPrintf("Gefunden wurde aber '%s'=%i.\n",OPT_ISAUTONOMOUS,i1);
  msg="invalid autonomous flag (ung�ltige Angabe, ob System autonom)";break;
case 14:
  mexPrintf("English: \n");
  mexPrintf("2nd argument has to be ordered.\n");
  if (i1>0)
    mexPrintf("Because of %f=tStart<tEnd=%f, the 2nd argument has to be ascending.\n",
      paramSeulex.tStart,paramSeulex.tEnd);
  else
    mexPrintf("Because of %f=tStart>tEnd=%f, the 2nd argument has to be descending.\n",
      paramSeulex.tStart,paramSeulex.tEnd);
  mexPrintf("German: \n");
  mexPrintf("2. Argument muss sortiert sein.\n");
  if (i1>0)
    mexPrintf("Da %f=tStart<tEnd=%f ist, muss das zweite Argument steigend\n",
     paramSeulex.tStart,paramSeulex.tEnd); 
  else    
    mexPrintf("Da %f=tStart>tEnd=%f ist, muss das zweite Argument fallend\n",
     paramSeulex.tStart,paramSeulex.tEnd); 
  mexPrintf("sortiert sein.\n");
  msg="2. Arg: has to be ordered (muss sortiert sein)";break;
case 15:
  mexPrintf("English: \n");
  mexPrintf("Concering Options '%s' and '%s':\n",OPT_MASSMATRIX,OPT_TRANSJTOH);
  mexPrintf("Transformation of the Jacobian to Hessenberg form is not supported\n");
  mexPrintf("for implicit systems.\n");
  mexPrintf("German: \n");
  mexPrintf("Zu den Optionen '%s' und '%s':\n",OPT_MASSMATRIX,OPT_TRANSJTOH);
  mexPrintf("Die Transformation der Jacobimatrix auf Hessenberggestalt\n");
  mexPrintf("wird nicht bei impliziten Systeme unterst�tzt.\n");
  msg="Jacobian transformation to Hessenberg for implicit systems not possible (Hessenbergtransformation der Jacobischen bei impliziten System nicht m�glich)";break;
case 16:
  mexPrintf("English: \n");
  mexPrintf("Concerning option '%s' and '%s':\n",OPT_M1,OPT_TRANSJTOH);
  mexPrintf("Transformation of the Jacobian to Hessenberg form is not supported\n");
  mexPrintf("for systems with special structure ('%s'>0).\n",OPT_M1);
  mexPrintf("German: \n");
  mexPrintf("Zu den Optionen '%s' und '%s':\n",OPT_M1,OPT_TRANSJTOH);
  mexPrintf("Die Transformation der Jacobimatrix auf Hessenberggestalt\n");
  mexPrintf("wird nicht bei Systemen mit Spezialstruktur ('%s'>0) unterst�tzt.\n",OPT_M1);
  msg="Hessenbergtransformation not supported if system has special structure (Hessenbergtransformation bei Systemen mit Spezialstruktur)";break;
case 17:
  mexPrintf("English: \n");
  mexPrintf("Concerning option '%s' and '%s':\n",OPT_JACOBILBAND,OPT_TRANSJTOH);
  mexPrintf("Transformation of the Jacobian to Hessenberg form is not supported\n");
  mexPrintf("for systems with band structure.\n");
  mexPrintf("German: \n");
  mexPrintf("Zu den Optionen '%s' und '%s':\n",OPT_JACOBILBAND,OPT_TRANSJTOH);
  mexPrintf("Die Transformation der Jacobimatrix auf Hessenberggestalt\n");
  mexPrintf("wird nicht bei Jacobimatrizen mit Bandstruktur unterst�tzt.\n");
  msg="Hessenbergtransformation of the Jacobian not supported for banded Jacobians (Hessenbergtransformation bei Jacobimatrizen mit Bandstruktur)";break;
case 18:
  mexPrintf("English: \n");
  mexPrintf("Concerning option '%s' and '%s':\n",OPT_MASSLBAND,OPT_JACOBILBAND);
  mexPrintf("Requirement: '%s'<='%s'.\n",OPT_MASSLBAND,OPT_JACOBILBAND);
  mexPrintf("But I found: '%s'=%i and '%s'=%i.\n",OPT_MASSLBAND,i1,OPT_JACOBILBAND,i2);
  mexPrintf("German: \n");
  mexPrintf("Zu den Optionen '%s' und '%s':\n",OPT_MASSLBAND,OPT_JACOBILBAND);
  mexPrintf("Es muss gelten: '%s'<='%s'.\n",OPT_MASSLBAND,OPT_JACOBILBAND);
  mexPrintf("Gefunden wurde: '%s'=%i und '%s'=%i\n",OPT_MASSLBAND,i1,OPT_JACOBILBAND,i2);
  msg="MLMAS > MLJAC";break;
case 19:
  mexPrintf("English: \n");
  mexPrintf("1st argument contained inline-funcs or function handles, but I need only ONE. ");
  if (i1!=2) 
    mexPrintf("Not a 0-, 1- or >=3-dimensional thing.");
  else
    if ((i2!=1) || (i3!=1)) 
      mexPrintf("Not a matrix containing inline-funcs or function handles.");
  mexPrintf("\n");
  mexPrintf("German: \n");
  mexPrintf("1. Argument enth�lt zwar Inline-Funktionen oder Funktions-Handles, aber");
  mexPrintf("ben�tigt wird nur EIN Handle oder EINE Inline-Funktion. ");
  if (i1!=2) 
    mexPrintf("Kein 0-,1- oder >=3-dimensionales Gebilde."); 
  else
    if ((i2!=1) || (i3!=1)) 
      mexPrintf("Keine Matrix mit Inline-Funktionen oder Funktions-Handles .");
  mexPrintf("\n");
  msg="1. Arg: only ONE function expected (nur EINE Funktion erwartet)";break;
case 20:
  mexPrintf("English: \n");
  mexPrintf("3rd arg: start- and end-time are the same.\n");
  mexPrintf("German: \n");
  mexPrintf("3. Argument: Start- und Endzeitpunkt d�rfen nicht\n");
  mexPrintf("�bereinstimmen!\n");
  msg="3. Arg: tStart==tEnd";break;  
case 21:
  mexPrintf("English: \n");
  mexPrintf("Concering Option '%s':\n",OPT_FUNCCALLMETHOD);
  mexPrintf("Requirement: '%s'==0 or '%s'==1\n",OPT_FUNCCALLMETHOD,OPT_FUNCCALLMETHOD);
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_FUNCCALLMETHOD);
  mexPrintf("Es muss gelten: '%s'==0 or '%s'==1\n",OPT_FUNCCALLMETHOD,OPT_FUNCCALLMETHOD);
  msg="Invalid call method (ung�ltige Methode f�r Funktionsaufruf)";break;
case 22:
  mexPrintf("English: \n");
  mexPrintf("Concering Option '%s':\n",OPT_FUNCCALLMETHOD);
  mexPrintf("'%s'==0 was chosen. Hence all Matlab-functions must be given as string.\n",
    OPT_FUNCCALLMETHOD);
  mexPrintf("But the rightSide was not a string.\n");
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_FUNCCALLMETHOD);
  mexPrintf("Es wurde '%s'==0 gew�hlt. Also m�ssen alle Matlab-Funktionen als String angegeben werden.\n",
    OPT_FUNCCALLMETHOD);
  mexPrintf("Aber die rechte Seite war kein String mit Funktionsname.\n");
  msg="CallMethod 0 => all Matlab-Funcs must be given as Strings (Bei Aufrufmethode 0: m�ssen Funktionsnamen �bergeben werden)";break;
case 23:
  mexPrintf("English: \n");
  mexPrintf("Concering Option '%s':\n",OPT_FUNCCALLMETHOD);
  mexPrintf("'%s'==0 was chosen. Hence the all Matlab-functions must be given as string.\n",
    OPT_FUNCCALLMETHOD);
  mexPrintf("But the Output Function was not a string.\n");
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_FUNCCALLMETHOD);
  mexPrintf("Es wurde '%s'==0 gew�hlt. Also m�ssen alle Matlab-Funktionen als String angegeben werden.\n",
    OPT_FUNCCALLMETHOD);
  mexPrintf("Aber die Output Funktion war kein String mit Funktionsname.\n");
  msg="CallMethod 0 => all Matlab-Funcs must be given as Strings (Bei Aufrufmethode 0: m�ssen Funktionsnamen �bergeben werden)";break;
case 24:
  mexPrintf("English: \n");
  mexPrintf("Concering Option '%s':\n",OPT_FUNCCALLMETHOD);
  mexPrintf("'%s'==0 was chosen. Hence the all Matlab-functions must be given as string.\n",
    OPT_FUNCCALLMETHOD);
  mexPrintf("But the Jacobimatrix Function was not a string.\n");
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_FUNCCALLMETHOD);
  mexPrintf("Es wurde '%s'==0 gew�hlt. Also m�ssen alle Matlab-Funktionen als String angegeben werden.\n",
    OPT_FUNCCALLMETHOD);
  mexPrintf("Aber die Jacobimatrix Funktion war kein String mit Funktionsname.\n");
  msg="CallMethod 0 => all Matlab-Funcs must be given as Strings (Bei Aufrufmethode 0: m�ssen Funktionsnamen �bergeben werden)";break;

/* errors concerning the massmatrix */
/* Fehler im Zusammenhang mit der Massenmatrix */
case 101:
  mexPrintf("English: \n");
  mexPrintf("Concerning Option '%s':\n",OPT_MASSMATRIX);
  if (i2==0) {
    mexPrintf("The system has dimension d=%i. Because of\n",i1);
    mexPrintf("'%s'=d=%i the massmatrix is full (not banded).\n",OPT_MASSLBAND,i1);
    mexPrintf("Hence in '%s' this double-matrix is expected.\n",OPT_MASSMATRIX);
  } else {
    mexPrintf("The system has dimension d=%i and we have '%s'=%i.\n",i1,OPT_M1,i2);
    mexPrintf("Because of '%s'=d-'%s'=%i the lower right\n",OPT_MASSLBAND,OPT_M1,i1-i2);
    mexPrintf("(d-'%s',d-'%s')=(%i,%i) block of the massmatrix is full (not banded)",
      OPT_M1,OPT_M1,i1-i2,i1-i2);
    mexPrintf("Hence in '%s' this block is expected.\n",OPT_MASSMATRIX);
  }
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_MASSMATRIX);
  if (i2==0) {
    mexPrintf("Die Systemdimension ist d=%i. Da aber\n",i1);
    mexPrintf("'%s'=d=%i ist, ist die Massenmatrix vollbesetzt.\n",OPT_MASSLBAND,i1);
    mexPrintf("Deshalb wird in '%s' diese double-Matrix erwartet.\n",OPT_MASSMATRIX);
  } else {
    mexPrintf("Die Systemdimension ist d=%i und es ist '%s'=%i.\n",i1,OPT_M1,i2);
    mexPrintf("Da nun '%s'=d-'%s'=%i ist, ist der rechte untere\n",
      OPT_MASSLBAND,OPT_M1,i1-i2);
    mexPrintf("(d-'%s',d-'%s')=(%i,%i)-Block der Massenmatrix vollbesetzt.\n",
      OPT_M1,OPT_M1,i1-i2,i1-i2);
    mexPrintf("Deshalb wird in '%s' dieser unter Block\n",OPT_MASSMATRIX);
    mexPrintf("erwartet.\n");
  }
  msg="Massmatrix has to be double-matrix (Massenmatrix muss double-Matrix sein)";break;
case 102:
  mexPrintf("English: \n");
  mexPrintf("Concerning Option '%s':\n",OPT_MASSMATRIX);
  mexPrintf("I expected a double-matrix, not a 0-, 1- or >=3-dimensional thing.\n");
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_MASSMATRIX);
  mexPrintf("Es wird eine double-Matrix erwartet. ");
  mexPrintf("Kein 0-,1- oder >=3-dimensionales Gebilde.\n");
  msg="Massmatrix must be 2-dimensional (Massenmatrix muss 2-dimensional sein)";break;
case 103:
  mexPrintf("English: \n");
  mexPrintf("Concerning Option '%s':\n",OPT_MASSMATRIX);
  mexPrintf("A quadratic double-matrix is expected.\n");
  mexPrintf("But I found a (%i,%i)-matrix.\n",i1,i2);
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_MASSMATRIX);
  mexPrintf("Es wird eine quadratische double-Matrix erwartet.\n");
  mexPrintf("Gefunden wurde aber eine (%i,%i)-Matrix.\n",i1,i2);
  msg="Massmatrix must be quadratic (Massenmatrix muss quadratisch sein)";break;
case 104:
  mexPrintf("English: \n");
  mexPrintf("Concerning Option '%s':\n",OPT_MASSMATRIX);
  if (i2==0) {
    mexPrintf("The system has dimension d=%i. Because of\n",paramGlobal.d);
    mexPrintf("'%s'=d=%i the massmatrix is full (not banded).\n",OPT_MASSLBAND,
      paramGlobal.d);
    mexPrintf("Hence in '%s' this double-matrix is expected.\n",OPT_MASSMATRIX);
  } else {
    mexPrintf("The system has dimension d=%i and we have '%s'=%i.\n",
      paramGlobal.d,OPT_M1,i2);
    mexPrintf("Because of '%s'=d-'%s'=%i the lower right\n",OPT_MASSLBAND,OPT_M1,
      paramGlobal.d-i2);
    mexPrintf("(d-'%s',d-'%s')=(%i,%i) black of the massmatrix is full (not banded)",
      OPT_M1,OPT_M1,paramGlobal.d-i2,paramGlobal.d-i2);
    mexPrintf("Hence in '%s' this Block is expected.\n",OPT_MASSMATRIX);
  }
  mexPrintf("I found a (%i,%i)-Matrix.\n",i1,i1);
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_MASSMATRIX);
  if (i2==0) {
    mexPrintf("Die Systemdimension ist d=%i. Da aber\n",paramGlobal.d);
    mexPrintf("'%s'=d=%i ist, ist die Massenmatrix vollbesetzt.\n",OPT_MASSLBAND,
      paramGlobal.d);
    mexPrintf("Deshalb wird in '%s' diese double-Matrix erwartet.\n",OPT_MASSMATRIX);
  } else {
    mexPrintf("Die Systemdimension ist d=%i und es ist '%s'=%i.\n",
      paramGlobal.d,OPT_M1,i2);
    mexPrintf("Da nun '%s'=d-'%s'=%i ist, ist der rechte untere\n",OPT_MASSLBAND,OPT_M1,
      paramGlobal.d-i2);
    mexPrintf("(d-'%s',d-'%s')=(%i,%i)-Block der Massenmatrix vollbesetzt.\n",
      OPT_M1,OPT_M1,paramGlobal.d-i2,paramGlobal.d-i2);
    mexPrintf("Deshalb wird in '%s' dieser unter Block\n",OPT_MASSMATRIX);
    mexPrintf("erwartet.\n");
  }
  mexPrintf("Die gefundene Matrix war eine (%i,%i)-Matrix.\n",i1,i1);
  msg="Massmatrix has to be a (d-m1,d-m1) Matrix (Massenmatrix muss eine (d-m1,d-m1) Matrix sein)";break;
case 105:
  mexPrintf("English: \n");
  mexPrintf("Concerning Option '%s':\n",OPT_MASSMATRIX);
  if (i2==0) {
    mexPrintf("The system has dimension d=%i. Because of\n",paramGlobal.d);
    mexPrintf("%i='%s'!=d=%i the massmatrix is banded.\n",i1,OPT_MASSLBAND,paramGlobal.d);
    mexPrintf("Hence a cell or a double-matrix (containing the bands) is expected.\n");
  } else {
    mexPrintf("The system has dimension d=%i and we have '%s'=%i.\n",
      paramGlobal.d,OPT_M1,i2);
    mexPrintf("Because of %i='%s'!=d=%i the lower right\n",
      i1,OPT_MASSLBAND,paramGlobal.d);
    mexPrintf("(d-'%s',d-'%s')=(%i,%i) block is banded.\n",
      OPT_M1,OPT_M1,paramGlobal.d-i2,paramGlobal.d-i2);
    mexPrintf("Hence a cell or a double-matrix (containing the bands for this block)\n");
    mexPrintf("is expected.\n");
  }
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_MASSMATRIX);
  if (i2==0) {
    mexPrintf("Die Systemdimension ist d=%i. Da aber\n",paramGlobal.d);
    mexPrintf("%i='%s'!=d=%i ist, hat die Massenmatrix\n",i1,OPT_MASSLBAND,paramGlobal.d);
    mexPrintf("Bandstruktur. Deshalb wird entweder eine cell oder eine\n");
    mexPrintf("double-Matrix erwartet, die die Eintr�ge der B�nder enthalten.\n");
  } else {
    mexPrintf("Die Systemdimension ist d=%i und es ist '%s'=%i.\n",
      paramGlobal.d,OPT_M1,i2);
    mexPrintf("Da nun %i='%s'!=d=%i ist, hat der rechte untere\n",i1,
      OPT_MASSLBAND,paramGlobal.d);
    mexPrintf("(d-'%s',d-'%s')=(%i,%i) Block Bandstruktur.\n",
      OPT_M1,OPT_M1,paramGlobal.d-i2,paramGlobal.d-i2);
    mexPrintf("Deshalb wird entweder eine cell oder eine double-Matrix\n");
    mexPrintf("erwartet, die die Eintr�ge der B�nder dieses Blocks enthalten.\n");
  }
  msg="Massmatrix: double-matrix or cell expected (Massenmatrix: double-Matrix oder cell erwartet)";break;
case 106:
  mexPrintf("English: \n");
  mexPrintf("Concerning Option '%s':\n",OPT_MASSMATRIX);
  mexPrintf("The system has dimension d=%i. Because of\n",paramGlobal.d);
  mexPrintf("%i='%s'!=d=%i the massmatrix is banded.\n",
    paramMassmatrix.MLMAS,OPT_MASSLBAND,paramGlobal.d);
  mexPrintf("I found a double-matrix and I expected it containing the bands.\n");
  mexPrintf("Hence I expected a (1+'%s'+'%s',d)=(%i,%i) matrix.\n",
    OPT_MASSLBAND,OPT_MASSUBAND,1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS,
    paramGlobal.d);
  mexPrintf("But I found a (%i,%i) matrix.\n",i1,i2);
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_MASSMATRIX);
  mexPrintf("Die Systemdimension ist d=%i. Da aber\n",paramGlobal.d);
  mexPrintf("%i='%s'!=d=%i ist, hat die Massenmatrix\n",
    paramMassmatrix.MLMAS,OPT_MASSLBAND,paramGlobal.d);
  mexPrintf("Bandstruktur. Deshalb wird erwartet, dass die gefundene\n");
  mexPrintf("double-Matrix die Eintr�ge der B�nder enth�lt. Es wird also eine\n");
  mexPrintf("(1+'%s'+'%s',d)=(%i,%i) Matrix erwartet.\n",
    OPT_MASSLBAND,OPT_MASSUBAND,1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS,
    paramGlobal.d);
  mexPrintf("Gefunden wurde aber eine (%i,%i) Matrix.\n",i1,i2);      
  msg="Massmatrix: double-matrix with unexpected size (Massenmatrix: double-Matrix mit unerwarteter Gr��e)";break;
case 107:
  mexPrintf("English: \n");
  mexPrintf("Concerning Option '%s':\n",OPT_MASSMATRIX);
  mexPrintf("The system has dimension d=%i. Because of\n",paramGlobal.d);
  mexPrintf("%i='%s'!=d=%i the massmatrix is banded.\n",
    paramMassmatrix.MLMAS,OPT_MASSLBAND,paramGlobal.d);
  mexPrintf("I found a cell and I expected it containing the bands.\n");
  mexPrintf("Hence I expected a (1,1+'%s'+'%s')=(1,%i) cell.\n",
    OPT_MASSLBAND,OPT_MASSUBAND,1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS);
  mexPrintf("But I found a (%i,%i) cell.\n",i1,i2);
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_MASSMATRIX);
  mexPrintf("Die Systemdimension ist d=%i. Da aber\n",paramGlobal.d);
  mexPrintf("%i='%s'!=d=%i ist, hat die Massenmatrix\n",
    paramMassmatrix.MLMAS,OPT_MASSLBAND,paramGlobal.d);
  mexPrintf("Bandstruktur. Deshalb wird erwartet, dass die gefundene\n");
  mexPrintf("cell die Eintr�ge der B�nder enth�lt. Es wird also eine\n");
  mexPrintf("(1,1+'%s'+'%s')=(1,%i) cell erwartet.\n",
    OPT_MASSLBAND,OPT_MASSUBAND,1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS);
  mexPrintf("Gefunden wurde aber eine (%i,%i) cell.\n",i1,i2);            
  msg="Massmatrix: cell with unexpected size (Massenmatrix: cell mit unerwarteter Gr��e)";break;
case 108:
  mexPrintf("English: \n");
  mexPrintf("Concerning Option '%s':\n",OPT_MASSMATRIX);
  mexPrintf("The system has dimension d=%i and we have '%s'=%i.\n",
    paramGlobal.d,OPT_M1,paramSeulex.IWORK[9-1]);
  mexPrintf("Because of %i='%s'!=d-m1=%i the lower right\n",
    paramMassmatrix.MLMAS,OPT_MASSLBAND,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("(d-'%s',d-'%s')=(%i,%i) block is banded.\n",OPT_M1,OPT_M1,
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("I found a double-matrix and I expected it containing the bands.\n");
  mexPrintf("Hence I expected a (1+'%s'+'%s',d-'%s') matrix.\n",
    OPT_MASSLBAND,OPT_MASSUBAND,OPT_M1,1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS,
    paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("But I found a (%i,%i) matrix.\n",i1,i2);
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_MASSMATRIX);
  mexPrintf("Die Systemdimension ist d=%i und es ist '%s'=%i.\n",
    paramGlobal.d,OPT_M1,paramSeulex.IWORK[9-1]);
  mexPrintf("Da aber %i='%s'!=d-m1=%i ist, hat der rechte untere\n",
    paramMassmatrix.MLMAS,OPT_MASSLBAND,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("(d-'%s',d-'%s')=(%i,%i)-Block Bandstruktur. Deshalb wird\n",OPT_M1,OPT_M1,
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("erwartet, dass die gefundene double-Matrix die Eintr�ge\n");
  mexPrintf("der B�nder f�r diesen Block enth�lt. Es wird also eine\n");
  mexPrintf("(1+'%s'+'%s',d-'%s')=(%i,%i) Matrix erwartet.\n",
    OPT_MASSLBAND,OPT_MASSUBAND,OPT_M1,1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS,
    paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("Gefunden wurde aber eine (%i,%i) Matrix.\n",i1,i2);
  msg="Massmatrix: double-matrix with unexpected size (Massenmatrix: double-Matrix mit unerwarteter Gr��e)";break;
case 109:
  mexPrintf("English: \n");
  mexPrintf("Concerning Option '%s':\n",OPT_MASSMATRIX);
  mexPrintf("The system has dimension d=%i and we have '%s'=%i.\n",
    paramGlobal.d,OPT_M1,paramSeulex.IWORK[9-1]);
  mexPrintf("Because of %i='%s'!=d-m1=%i the lower right\n",
    paramMassmatrix.MLMAS,OPT_MASSLBAND,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("(d-'%s',d-'%s')=(%i,%i) block is banded.\n",OPT_M1,OPT_M1,
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("I found a cell and I excpected it containing the bands.\n");
  mexPrintf("Hence I excpected a (1,1+'%s'+'%s')=(1,%i) cell.\n",
    OPT_MASSLBAND,OPT_MASSUBAND,1+paramMassmatrix.MLMAS,paramMassmatrix.MUMAS);
  mexPrintf("But I found a (%i,%i) cell.\n",i1,i2);
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_MASSMATRIX);
  mexPrintf("Die Systemdimension ist d=%i und es ist m1=%i.\n",
    paramGlobal.d,paramSeulex.IWORK[9-1]);
  mexPrintf("Da aber %i='%s'!=d-m1=%i ist, hat der rechte untere\n",
    paramMassmatrix.MLMAS,OPT_MASSLBAND,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("(d-m1,d-m1)=(%i,%i)-Block Bandstruktur. Deshalb wird\n",
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("erwartet, dass die gefundene cell die Eintr�ge der B�nder\n");
  mexPrintf("f�r diesen Block enth�lt. Es wird also eine\n");
  mexPrintf("(1,1+'%s'+'%s')=(1,%i) cell erwartet.\n",
    OPT_MASSLBAND,OPT_MASSUBAND,1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS);
  mexPrintf("Gefunden wurde aber eine (%i,%i) cell.\n",i1,i2);      
  msg="Massmatrix: cell with unexpected size (Massenmatrix: cell mit unerwarteter Gr��e)";break;
case 110:
  mexPrintf("English: \n");
  mexPrintf("Concerning Options '%s' and '%s':\n",OPT_MASSLBAND,OPT_MASSUBAND);
  mexPrintf("Requirements:\n");
  mexPrintf("0<='%s'<=d-m1=%i and\n",OPT_MASSLBAND,i1-i2);
  mexPrintf("0<='%s'<=d-m1=%i\n",OPT_MASSUBAND,i1-i2);
  mexPrintf("But I found '%s'=%i and '%s'=%i.\n",
    OPT_MASSLBAND,paramMassmatrix.MLMAS,OPT_MASSUBAND,paramMassmatrix.MUMAS);
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s' bzw. '%s':\n",OPT_MASSLBAND,OPT_MASSUBAND);
  mexPrintf("Es muss gelten:\n");
  mexPrintf("0<='%s'<=d-m1=%i und\n",OPT_MASSLBAND,i1-i2);
  mexPrintf("0<='%s'<=d-m1=%i\n",OPT_MASSUBAND,i1-i2);
  mexPrintf("Gefunden wurde aber '%s'=%i und '%s'=%i.\n",
    OPT_MASSLBAND,paramMassmatrix.MLMAS,OPT_MASSUBAND,paramMassmatrix.MUMAS);
  msg="Massmatrix: impossible values for bandwidth (Massenmatrix: unm�gliche Werte f�r Bandbreite)";break;
case 111:
  mexPrintf("English: \n");
  mexPrintf("Concerning options '%s','%s' and '%s':\n",
    OPT_MASSMATRIX,OPT_MASSLBAND,OPT_MASSUBAND);
  mexPrintf("The system has dimension d=%i.\n",paramGlobal.d);
  mexPrintf("Because of %i='%s'!=d=%i the mass matrix is banded.\n",
    paramMassmatrix.MLMAS,OPT_MASSLBAND,paramGlobal.d);
  mexPrintf("'%s' is a cell. In every cell entry I expect\n",OPT_MASSMATRIX);
  mexPrintf("a double-Vector. But the entry %i ist not\n",i1);
  mexPrintf("double-vector.\n");
  mexPrintf("German: \n");
  mexPrintf("Zu den Optionen '%s','%s' und '%s':\n",
    OPT_MASSMATRIX,OPT_MASSLBAND,OPT_MASSUBAND);
  mexPrintf("Die Systemdimension ist d=%i.\n",paramGlobal.d);
  mexPrintf("Da aber %i='%s'!=d=%i ist, hat die Massenmatrix\n",
    paramMassmatrix.MLMAS,OPT_MASSLBAND,paramGlobal.d);
  mexPrintf("Bandstruktur.\n");
  mexPrintf("'%s' ist eine cell. Es wird erwartet, dass jeder cell-Eintrag\n",
    OPT_MASSMATRIX);
  mexPrintf("einen double-Vektor enth�lt. Aber der Eintrag %i ist\n",i1);
  mexPrintf("kein double-Vektor.\n");        
  msg="Massmatrix: cell entry is not a double-vector (Massenmatrix: ein cell-Eintrag ist kein double-Vektor)";break;
case 112:
  mexPrintf("English: \n");
  mexPrintf("Concerning options '%s','%s' and '%s':\n",
    OPT_MASSMATRIX,OPT_MASSLBAND,OPT_MASSUBAND);
  mexPrintf("The system has dimension d=%i.\n",paramGlobal.d);
  mexPrintf("Because of %i='%s'!=d=%i the mass matrix is banded.\n",
    paramMassmatrix.MLMAS,OPT_MASSLBAND,paramGlobal.d);
  mexPrintf("'%s' is a cell. In every cell entry I expect\n",OPT_MASSMATRIX);
  mexPrintf("a double-Vector. In the entry %i I expect a\n",i1);
  mexPrintf("(1,%i) double-vector.\n",i4);
  mexPrintf("But I found a (%i,%i) double-Vector.\n",i2,i3);
  mexPrintf("German: \n");
  mexPrintf("Zu den Optionen '%s','%s' und '%s':\n",
    OPT_MASSMATRIX,OPT_MASSLBAND,OPT_MASSUBAND);
  mexPrintf("Die Systemdimension ist d=%i.\n",paramGlobal.d);
  mexPrintf("Da aber %i='%s'!=d=%i ist, hat die Massenmatrix\n",
    paramMassmatrix.MLMAS,OPT_MASSLBAND,paramGlobal.d);
  mexPrintf("Bandstruktur.\n");
  mexPrintf("'%s' ist eine cell. Es wird erwartet, dass jeder cell-Eintrag\n",
    OPT_MASSMATRIX);
  mexPrintf("einen double-Vektor enth�lt. Der Eintrag %i\n",i1);
  mexPrintf("hat die Gr��e (%i,%i); erwartet wurde aber (1,%i).\n",
    i2,i3,i4);    
  msg="Massmatrix: cell entry has vector with wrong length (Massenmatrix: ein cell-Eintrag hat Vektor mit falscher L�nge)";break;
case 113:
  mexPrintf("English: \n");
  mexPrintf("Concerning options '%s','%s' and '%s':\n",
    OPT_MASSMATRIX,OPT_MASSLBAND,OPT_MASSUBAND);
  mexPrintf("The system has dimension d=%i and we have '%s'=%i.\n",
    paramGlobal.d,OPT_M1,paramSeulex.IWORK[9-1]);
  mexPrintf("Because of %i='%s'!=d-'%s'=%i the lower right\n",
    paramMassmatrix.MLMAS,OPT_MASSLBAND,OPT_M1,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("(d-'%s',d-'%s')=(%i,%i) block is banded.\n",OPT_M1,OPT_M1,
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("'%s' is a cell. For every entry in this cell I expect a double-vector,\n",
    OPT_MASSMATRIX);
  mexPrintf("but entry %i is not a double-vector.\n",i1);
  mexPrintf("German: \n");
  mexPrintf("Zu den Optionen '%s','%s' und '%s':\n",
    OPT_MASSMATRIX,OPT_MASSLBAND,OPT_MASSUBAND);
  mexPrintf("Die Systemdimension ist d=%i und es ist '%s'=%i.\n",
    paramGlobal.d,OPT_M1,paramSeulex.IWORK[9-1]);
  mexPrintf("Da aber %i='%s'!=d-'%s'=%i ist, hat der rechte untere\n",
    paramMassmatrix.MLMAS,OPT_MASSLBAND,OPT_M1,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("(d-'%s',d-'%s')=(%i,%i)-Block Bandstruktur.\n",OPT_M1,OPT_M1,
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("'%s' ist eine cell. Es wird erwartet, dass jeder cell-Eintrag\n",
    OPT_MASSMATRIX);
  mexPrintf("einen double-Vektor enth�lt. Aber der Eintrag %i ist\n",i1);
  mexPrintf("kein double-Vektor.\n");            
  msg="Massmatrix: one cell entry is not a double-vector (Massenmatrix: ein cell-Eintrag ist kein double-Vektor)";break;
case 114:
  mexPrintf("English: \n");
  mexPrintf("Concerning options '%s','%s' and '%s':\n",
    OPT_MASSMATRIX,OPT_MASSLBAND,OPT_MASSUBAND);
  mexPrintf("The system has dimension d=%i and we have '%s'=%i.\n",
    paramGlobal.d,OPT_M1,paramSeulex.IWORK[9-1]);
  mexPrintf("Because of %i='%s'!=d-'%s'=%i the lower right\n",
    paramMassmatrix.MLMAS,OPT_MASSLBAND,OPT_M1,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("(d-'%s',d-'%s')=(%i,%i) block is banded.\n",OPT_M1,OPT_M1,
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("'%s' is a cell. For every entry in this cell I expect a double-vector.\n",
    OPT_MASSMATRIX);
  mexPrintf("In the entry %i I expect a (1,%i) double-vector.\n",i1,i4);
  mexPrintf("But I found a (%i,%i) double-vector.\n",i2,i3);
  mexPrintf("German: \n");
  mexPrintf("Zu den Optionen '%s','%s' und '%s':\n",
    OPT_MASSMATRIX,OPT_MASSLBAND,OPT_MASSUBAND);
  mexPrintf("Die Systemdimension ist d=%i und es ist m1=%i.\n",
    paramGlobal.d,paramSeulex.IWORK[9-1]);
  mexPrintf("Da aber %i='%s'!=d-'%s'=%i ist, hat der rechte untere\n",
    paramMassmatrix.MLMAS,OPT_MASSLBAND,OPT_M1,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("(d-'%s',d-'%s')=(%i,%i)-Block Bandstruktur.\n",OPT_M1,OPT_M1,
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("'%s' ist eine cell. Es wird erwartet, dass jeder cell-Eintrag\n",
    OPT_MASSMATRIX);
  mexPrintf("einen double-Vektor enth�lt. Der Eintrag %i\n",i1);
  mexPrintf("hat die Gr��e (%i,%i); erwartet wurde aber (1,%i).\n",
    i2,i3,i4);    
  msg="Massmatrix: one cell entry has vector with wrong length (Massenmatrix: ein cell-Eintrag hat Vektor mit falscher L�nge)";break;
  
/* errors concerning the jacobian */
/* Fehler im Zusammenhang mit der Jacobimatrix */
case 201: 
  mexPrintf("English: \n");
  mexPrintf("Concerning options '%s' and '%s':\n",OPT_JACOBILBAND,OPT_JACOBIUBAND);
  mexPrintf("Requirements:\n");
  mexPrintf("0<='%s'<=d-'%s'=%i and\n",OPT_JACOBILBAND,OPT_M1,i1-i2);
  mexPrintf("0<='%s'<=d-'%s'=%i\n",OPT_JACOBIUBAND,OPT_M1,i1-i2);
  mexPrintf("But I found '%s'=%i and '%s'=%i.\n",
    OPT_JACOBILBAND,paramJacobimatrix.MLJAC,
    OPT_JACOBIUBAND,paramJacobimatrix.MUJAC);
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s' bzw. '%s':\n",OPT_JACOBILBAND,OPT_JACOBIUBAND);
  mexPrintf("Es muss nat�rlich gelten:\n");
  mexPrintf("0<='%s'<=d-'%s'=%i und\n",OPT_JACOBILBAND,OPT_M1,i1-i2);
  mexPrintf("0<='%s'<=d-'%s'=%i\n",OPT_JACOBIUBAND,OPT_M1,i1-i2);
  mexPrintf("Gefunden wurde aber '%s'=%i und '%s'=%i.\n",
    OPT_JACOBILBAND,paramJacobimatrix.MLJAC,
    OPT_JACOBIUBAND,paramJacobimatrix.MUJAC);
  msg="Jacobimatrix: invalid values for bandwidth (unm�gliche Werte f�r Bandwidth)";break;
case 202:
  mexPrintf("English: \n");
  mexPrintf("Concerning options '%s','%s' and '%s','%s':\n",
    OPT_JACOBILBAND,OPT_JACOBIUBAND,OPT_M1,OPT_M2);
  mexPrintf("We have '%s'=%i>0 and %i='%s'!=d-'%s'=%i.\n",
    OPT_M1,paramSeulex.IWORK[9-1],paramJacobimatrix.MLJAC,OPT_JACOBILBAND,
    OPT_M1,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("In such cases band structures are only supported if\n");
  mexPrintf("'%s'+'%s'=d.\n",OPT_M1,OPT_M2);
  mexPrintf("German: \n");
  mexPrintf("Zu den Optionen '%s','%s' und '%s','%s':\n",
    OPT_JACOBILBAND,OPT_JACOBIUBAND,OPT_M1,OPT_M2);
  mexPrintf("Es ist '%s'=%i>0 und %i='%s'!=d-'%s'=%i.\n",OPT_M1,
    paramSeulex.IWORK[9-1],paramJacobimatrix.MLJAC,OPT_JACOBILBAND,OPT_M1,
    paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("In einem solchen Fall werden Bandstrukturen nur\n");
  mexPrintf("f�r '%s'+'%s'=d unterst�tzt.\n",OPT_M1,OPT_M2);
  msg="Jacobimatrix: Bandstructure for m1>0 only supported if m1+m2=d (Bandstruktur bei m1>0 werden nur f�r m1+m2=d unterst�tzt)";
  break;
case 203:
  mexPrintf("English: \n");
  mexPrintf("Concerning options '%s','%s' and '%s','%s':\n",
    OPT_JACOBILBAND,OPT_JACOBIUBAND,OPT_M1,OPT_M2);
  mexPrintf("We have '%s'=%i>0 and %i='%s'!=d-'%s'=%i.\n",
    OPT_M1,paramSeulex.IWORK[9-1],paramJacobimatrix.MLJAC,OPT_JACOBILBAND,
    OPT_M1,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("Because we have '%s'+'%s'=d the nontrivial\n",OPT_M1,OPT_M2);
  mexPrintf("(d-'%s',d)=(%i,%i) lower block of the jacobian\n",OPT_M1,
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d);
  mexPrintf("is devided into mm+1=%i subblocks ('%s'=mm*'%s')\n",
    paramSeulex.mm+1,OPT_M1,OPT_M2);
  mexPrintf("with size ('%s','%s')=(%i,%i).\n",OPT_M2,OPT_M2,
    paramSeulex.IWORK[10-1],paramSeulex.IWORK[10-1]);
  mexPrintf("The options '%s' and '%s' are related to each these subblocks.\n",
    OPT_JACOBILBAND,OPT_JACOBIUBAND);
  mexPrintf("Hence there is the requirement: 0<='%s','%s'<='%s'=%i.\n", 
    OPT_JACOBILBAND,OPT_JACOBIUBAND,OPT_M2,paramSeulex.IWORK[10-1]);
  mexPrintf("German: \n");
  mexPrintf("Zu den Optionen '%s','%s' und '%s','%s':\n",
    OPT_JACOBILBAND,OPT_JACOBIUBAND,OPT_M1,OPT_M2);
  mexPrintf("Es ist '%s'=%i>0 und %i='%s'!=d-'%s'=%i.\n",OPT_M1,
    paramSeulex.IWORK[9-1],paramJacobimatrix.MLJAC,OPT_JACOBILBAND,OPT_M1,
    paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("Au�erdem ist '%s'+'%s'=d. Dann wird der nichttrivale Teil\n",OPT_M1,OPT_M2);
  mexPrintf("der Jacobimatrix, das ist der (d-'%s',d)=(%i,%i) Block,\n",OPT_M1,
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d);
  mexPrintf("in mm+1=%i Bl�cke ('%s'=mm*'%s') der Gr��e ('%s','%s')=(%i,%i) aufgeteilt.\n",
    paramSeulex.mm+1,OPT_M1,OPT_M2,OPT_M2,OPT_M2,
    paramSeulex.IWORK[10-1],paramSeulex.IWORK[10-1]);
  mexPrintf("Die Optionen '%s' und '%s' werden nun f�r\n",
    OPT_JACOBILBAND,OPT_JACOBIUBAND);
  mexPrintf("jeden dieser Teilbl�cke angewendet, folglich muss\n");
  mexPrintf("0<='%s','%s'<='%s'=%i gelten.\n",
    OPT_JACOBILBAND,OPT_JACOBIUBAND,OPT_M2,paramSeulex.IWORK[10-1]);      
  msg="Banded Jacobian with m1>0 and m1+m2=d; bandwidth<=m2 expected (Jacobimatrizen mit Bandstruktur bei m1>0 mit m1+m2=d: Bandwidth<=m2 erwartet)";
  break;
case 204:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the jacobian.\n");
  mexPrintf("No return values found.\n");
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der Jacobifunktion.\n");
  mexPrintf("Habe keine R�ckgabe erhalten.\n");
  msg="Jacobian: no return values (Jacobifunktion ohne R�ckgabe)";break;
case 205:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the jacobian.\n");
  mexPrintf("The system has dimension d=%i. Because of\n",paramGlobal.d);
  mexPrintf("'%s'=d the jacobian is full (not banded).\n",OPT_JACOBILBAND);
  mexPrintf("Hence I expect a full matrix, but I didn't found a double-matrix.\n");
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der Jacobifunktion.\n");
  mexPrintf("Die Systemdimension ist d=%i. Au�erdem ist\n",paramGlobal.d);
  mexPrintf("'%s'=d, also die Jacobimatrix vollbesetzt.\n",OPT_JACOBILBAND);
  mexPrintf("Deshalb wird als R�ckgabe diese vollbesetzte Matrix erwartet.\n");
  mexPrintf("Die R�ckgabe war keine double-Matrix.\n");
  msg="Jacobian: didn't return double-matrix (R�ckgabe der Jacobifunktion keine double-Matrix)";break;
case 206:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the jacobian.\n");
  mexPrintf("The system has dimension d=%i. Because of\n",paramGlobal.d);
  mexPrintf("'%s'=d the jacobian is full (not banded).\n",OPT_JACOBILBAND);
  mexPrintf("Hence I expect a full matrix, but I found a (%i,%i) matrix.\n",i1,i2);
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der Jacobifunktion.\n");
  mexPrintf("Die Systemdimension ist d=%i. Au�erdem ist\n",paramGlobal.d);
  mexPrintf("'%s'=d, also die Jacobimatrix vollbesetzt.\n",OPT_JACOBILBAND);
  mexPrintf("Deshalb wird als R�ckgabe diese vollbesetzte Matrix erwartet.\n");
  mexPrintf("Die zur�ckgegebene Matrix ist aber eine (%i,%i) Matrix.\n",i1,i2);    
  msg="Jacobian: didn't return a (d,d)-matrix (R�ckagabe der Jacobifunktion keine (d,d)-Matrix)";break;
case 207:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the jacobian.\n");
  mexPrintf("The system has dimension d=%i and we have '%s'=%i.\n",
    paramGlobal.d,OPT_M1,paramSeulex.IWORK[9-1]);
  mexPrintf("Because of '%s'=d-1 the nontrivial (d-'%s',d)=(%i,%i)\n",
    OPT_JACOBILBAND,OPT_M1,paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d);
  mexPrintf("lower block of the jacobian is full (not banded).\n");
  mexPrintf("Hence I expect a full matrix, but I didn't find a double-matrix.\n");
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der Jacobifunktion.\n");
  mexPrintf("Die Systemdimension ist d=%i und '%s'=%i.\n",
    paramGlobal.d,OPT_M1,paramSeulex.IWORK[9-1]);
  mexPrintf("Wegen '%s'=d-m1, ist der nichttriviale Teil der\n",OPT_JACOBILBAND);
  mexPrintf("Jacobimatrix, das ist der untere (d-'%s',d)=(%i,%i) Block,\n",
    OPT_M1,paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d);
  mexPrintf("vollbesetzt. Deshalb wird als R�ckgabe diese vollbesetzte\n");
  mexPrintf("Matrix erwartet. Die R�ckgabe war keine double-Matrix.\n");      
  msg="Jacobian: dind't return double-matrix (R�ckgabe der Jacobifunktion keine double-Matrix)";break;
case 208:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the jacobian.\n");
  mexPrintf("The system has dimension d=%i and we have '%s'=%i.\n",
    paramGlobal.d,OPT_M1,paramSeulex.IWORK[9-1]);
  mexPrintf("Because of '%s'=d-1 the nontrivial (d-'%s',d)=(%i,%i)\n",
    OPT_JACOBILBAND,OPT_M1,paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d);
  mexPrintf("lower block of the jacobian is full (not banded).\n");
  mexPrintf("Hence I expect a full matrix, but I found a (%i,%i) matrix.\n",i1,i2);
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der Jacobifunktion.\n");
  mexPrintf("Die Systemdimension ist d=%i und '%s'=%i.\n",
    paramGlobal.d,OPT_M1,paramSeulex.IWORK[9-1]);
  mexPrintf("Wegen '%s'=d-'%s', ist der nichttriviale Teil der\n",OPT_JACOBILBAND,OPT_M1);
  mexPrintf("Jacobimatrix, das ist der untere (d-'%s',d)=(%i,%i) Block,\n",OPT_M1,
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d);
  mexPrintf("vollbesetzt. Deshalb wird als R�ckgabe diese vollbesetzte\n");
  mexPrintf("Matrix erwartet.\n");      
  mexPrintf("Die R�ckgabe war aber eine (%i,%i) Matrix.\n",i1,i2);    
  msg="Jacobian: didn't find (d-m1,d) matrix (R�ckgabe der Jacobifunktion keine (d-m1,d)-Matrix)";break;
case 209:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the jacobian.\n");
  mexPrintf("The system has dimension d=%i. Because of\n",paramGlobal.d);
  mexPrintf("%i='%s'!=d the jacobian is banded.\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND);
  mexPrintf("Hence I expect the jacobian function to return a cell or a matrix\n");
  mexPrintf("with the entries for the bands. But I didn't find a cell or a matrix.\n");
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der Jacobifunktion.\n");
  mexPrintf("Die Systemdimension ist d=%i. Wegen\n",paramGlobal.d);
  mexPrintf("%i='%s'!=d, hat die Jacobimatrix Bandstruktur.\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND);  
  mexPrintf("Deshalb wird als R�ckgabe der Jacobifunktion entweder\n");
  mexPrintf("eine cell oder eine double-Matrix erwartet, die die\n");
  mexPrintf("Eintr�ge der B�nder enthalten.\n");
  msg="Jacobian didn't return cell or matrix: R�ckgabe der Jacobifunktion muss cell-Vektor oder Matrix sein)";break;
case 210:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the jacobian.\n");
  mexPrintf("The system has dimension d=%i. Because of\n",paramGlobal.d);
  mexPrintf("%i='%s'!=d the jacobian is banded.\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND);
  mexPrintf("The Jacobian returned a cell. I expected a\n");
  mexPrintf("(1,1+'%s'+'%s') cell. But I found a (%i,%i) cell.\n",
    OPT_JACOBILBAND,OPT_JACOBIUBAND,i1,i2);
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der Jacobifunktion.\n");
  mexPrintf("Die Systemdimension ist d=%i. Wegen\n",paramGlobal.d);
  mexPrintf("%i='%s'!=d, hat die Jacobimatrix Bandstruktur.\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND);  
  mexPrintf("Die Jacobifunktion hat eine cell zur�ckgeliefert.\n");    
  mexPrintf("Es wurde eine (1,1+'%s'+'%s') cell erwartet.\n",
    OPT_JACOBILBAND,OPT_JACOBIUBAND);
  mexPrintf("Zur�ckgeliefert wurde aber eine (%i,%i) cell.\n",i1,i2);
  msg="Jacobian returned cell with unexpected size (R�ckgabe der Jacobifunktion: cell mit unerwarteter Gr��e)";break;
case 211:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the jacobian.\n");
  mexPrintf("The system has dimension d=%i. Because of\n",paramGlobal.d);
  mexPrintf("%i='%s'!=d the jacobian is banded.\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND);
  mexPrintf("The Jacobian returned a cell. Every entry has to be a double-vector.\n");
  mexPrintf("But the entry %i is not a double-vector.\n",i1);
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der Jacobifunktion.\n");
  mexPrintf("Die Systemdimension ist d=%i. Wegen\n",paramGlobal.d);
  mexPrintf("%i='%s'!=d, hat die Jacobimatrix Bandstruktur.\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND);  
  mexPrintf("Die Jacobifunktion hat eine cell zur�ckgeliefert.\n");    
  mexPrintf("Jeder cell-Eintrag muss jetzt ein double-Vektor sein.\n");
  mexPrintf("Der Eintrag %i ist aber kein double-Vektor.\n",i1);  
  msg="Jacobian: cell entry is not double-vector (R�ckgabe der Jacobifunktion: cell-Eintrag ist kein double-Vektor)";break;
case 212:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the jacobian.\n");
  mexPrintf("The system has dimension d=%i. Because of\n",paramGlobal.d);
  mexPrintf("%i='%s'!=d the jacobian is banded.\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND);
  mexPrintf("The Jacobian returned a cell. The entry %i has the wrong size.\n",i1);
  mexPrintf("I expect a (1,%i) double-vector, but I found a (%i,%i) matrix.\n",
    i2,i3,i4);
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der Jacobifunktion.\n");
  mexPrintf("Die Systemdimension ist d=%i. Wegen\n",paramGlobal.d);
  mexPrintf("%i='%s'!=d, hat die Jacobimatrix Bandstruktur.\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND);  
  mexPrintf("Die Jacobifunktion hat eine cell zur�ckgeliefert.\n");    
  mexPrintf("Der Eintrag %i ist die falsche Gr��e.\n",i1);
  mexPrintf("Erwartet wurde ein (1,%i) double-Vektor,\n",i2);
  mexPrintf("gefunden wurde aber eine (%i,%i) Matrix.\n",i3,i4);
  msg="Jacobian: cell entry has wrong size (R�ckgabe der Jacobifunktion: ein cell-Eintrag hat falsche L�nge)";break;
case 213:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the jacobian.\n");
  mexPrintf("The system has dimension d=%i. Because of\n",paramGlobal.d);
  mexPrintf("%i='%s'!=d the jacobian is banded.\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND);
  mexPrintf("The jacobian has returned something 0-, 1- or >=3 dimensional thing.\n");
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der Jacobifunktion.\n");
  mexPrintf("Die Systemdimension ist d=%i. Wegen\n",paramGlobal.d);
  mexPrintf("%i='%s'!=d, hat die Jacobimatrix Bandstruktur.\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND);  
  mexPrintf("Die Jacobifunktion hat aber keine Matrix, sondern\n");
  mexPrintf("ein 0-,1- oder >=3-dimensionales Gebilde zur�ckgeliefert.\n");  
  msg="Jacobian: Matrix expected (R�ckgabe der Jacobifunktion muss Matrix sein)";break;
case 214:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the jacobian.\n");
  mexPrintf("The system has dimension d=%i. Because of\n",paramGlobal.d);
  mexPrintf("%i='%s'!=d the jacobian is banded.\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND);
  mexPrintf("The jacobian returned a matrix. I expected a\n");
  mexPrintf("(1+'%s'+'%s',d)=(%i,%i) matrix, but I found a\n",
    OPT_JACOBILBAND,OPT_JACOBIUBAND,
    1+paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC,paramGlobal.d);
  mexPrintf("(%i,%i) matrix.\n",i1,i2);
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der Jacobifunktion.\n");
  mexPrintf("Die Systemdimension ist d=%i. Wegen\n",paramGlobal.d);
  mexPrintf("%i='%s'!=d, hat die Jacobimatrix Bandstruktur.\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND);  
  mexPrintf("Die Jacobifunktion hat eine Matrix zur�ckgegeben. Erwartet\n");
  mexPrintf("wurde eine (1+'%s'+'%s',d)=(%i,%i) Matrix,\n",
    OPT_JACOBILBAND,OPT_JACOBIUBAND,
    1+paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC,paramGlobal.d);
  mexPrintf("Zur�ckgeliefert wurde eine (%i,%i) Matrix\n",i1,i2);  
  msg="Jacobian: Matrix with unexpected size (R�ckgabe der Jacobifunktion: double-Matrix mit unerwarteter Gr��e)";break;
case 215:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the jacobian.\n");
  mexPrintf("The system has dimension d=%i and we have '%s'=%i.\n",
    paramGlobal.d,OPT_M1,paramSeulex.IWORK[9-1]);
  mexPrintf("Because %i='%s'!=d-'%s'=%i the nontrivial lower\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND,OPT_M1,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("(d-'%s',d)=(%i,%i) block is banded.\n",OPT_M1,
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d);
  mexPrintf("This block is divided into mm+1=%i subblocks ('%s'=mm*'%s').\n",
    paramSeulex.mm+1,OPT_M1,OPT_M2);
  mexPrintf("Every subblock is banded. I expect a (1,mm+1) cell containing one entry\n");
  mexPrintf("for each subblock.\n");
  mexPrintf("But the jacobian didn't return such a cell.\n");
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der Jacobifunktion\n.");
  mexPrintf("Die Systemdimension ist d=%i und es ist '%s'=%i.\n",
    paramGlobal.d,OPT_M1,paramSeulex.IWORK[9-1]);
  mexPrintf("Wegen %i='%s'!=d-'%s'=%i, hat der nichttriviale Teil der\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND,OPT_M1,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("Jacobimatrix, das ist der untere (d-'%s',d)=(%i,%i) Block,\n",OPT_M1,
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d);
  mexPrintf("Bandstruktur. Genauer: dieser block wird in mm+1=%i\n",
    paramSeulex.mm+1);
  mexPrintf("Teilbl�cke ('%s'=mm*'%s') eingeteilt. Jeder dieser Teilbl�cke\n",
    OPT_M1,OPT_M2);
  mexPrintf("hat Bandstruktur.\n");
  mexPrintf("Es wird nun eine cell erwartet, in der jeder cell-Eintrag\n");
  mexPrintf("eine solche Teilmatrix beschreibt.\n");
  mexPrintf("Die Jacobifunktion hat aber keine (1,mm+1) cell zur�ckgeliefert.\n");  
  msg="Jacobian: (1,mm+1) cell expected (R�ckgabe der Jacobifunktion: cell-Vektor erwartet)";break;
case 216:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the jacobian.\n");
  mexPrintf("The system has dimension d=%i and we have '%s'=%i.\n",
    paramGlobal.d,OPT_M1,paramSeulex.IWORK[9-1]);
  mexPrintf("Because %i='%s'!=d-'%s'=%i the nontrivial lower\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND,OPT_M1,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("(d-'%s',d)=(%i,%i) block is banded.\n",OPT_M1,
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d);
  mexPrintf("This block is divided into mm+1=%i subblocks ('%s'=mm*'%s').\n",
    paramSeulex.mm+1,OPT_M1,OPT_M2);
  mexPrintf("Every subblock is banded. I expect a (1,mm+1) cell containing one entry\n");
  mexPrintf("for each subblock.\n");
  mexPrintf("But the jacobian didn't return such a cell. I found (%i,%i) cell.\n",i1,i2);
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der Jacobifunktion\n.");
  mexPrintf("Die Systemdimension ist d=%i und es ist '%s'=%i.\n",
    paramGlobal.d,OPT_M1,paramSeulex.IWORK[9-1]);
  mexPrintf("Wegen %i='%s'!=d-'%s'=%i, hat der nichttriviale Teil der\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND,OPT_M1,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("Jacobimatrix, das ist der untere (d-'%s',d)=(%i,%i) Block,\n",OPT_M1,
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d);
  mexPrintf("Bandstruktur. Genauer: dieser block wird in mm+1=%i\n",
    paramSeulex.mm+1);
  mexPrintf("Teilbl�cke ('%s'=mm*'%s') eingeteilt. Jeder dieser Teilbl�cke\n",
    OPT_M1,OPT_M2);
  mexPrintf("hat Bandstruktur.\n");
  mexPrintf("Es wird nun eine cell erwartet, in der jeder cell-Eintrag\n");
  mexPrintf("eine solche Teilmatrix beschreibt.\n");
  mexPrintf("Die Jacobifunktion hat aber keine (1,mm+1) cell zur�ckgeliefert.\n");  
  mexPrintf("Gefunden wurde eine (%i,%i) cell.\n",i1,i2);
  msg="Jacobian: (1,mm+1) cell expected (R�ckgabe der Jacobifunktion: cell-Vektor erwartet)";break;
case 217:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the jacobian.\n");
  mexPrintf("The system has dimension d=%i and we have '%s'=%i.\n",
    paramGlobal.d,OPT_M1,paramSeulex.IWORK[9-1]);
  mexPrintf("Because %i='%s'!=d-'%s'=%i the nontrivial lower\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND,OPT_M1,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("(d-'%s',d)=(%i,%i) block is banded.\n",OPT_M1,
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d);
  mexPrintf("This block is divided into mm+1=%i subblocks ('%s'=mm*'%s').\n",
    paramSeulex.mm+1,OPT_M1,OPT_M2);
  mexPrintf("Every subblock is banded. I expect a (1,mm+1) cell containing one entry\n");
  mexPrintf("for each subblock.\n");
  mexPrintf("But the %i entry of the returned cell is empty.\n",i1);
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der Jacobifunktion\n.");
  mexPrintf("Die Systemdimension ist d=%i und es ist m1=%i\n",
    paramGlobal.d,paramSeulex.IWORK[9-1]);
  mexPrintf("Wegen %i='%s'!=d-m1=%i, hat der nichttriviale Teil der\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("Jacobimatrix, das ist der untere (d-m1,d)=(%i,%i) Block,\n",
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d);
  mexPrintf("Bandstruktur. Genauer: dieser block wird in mm+1=%i\n",
    paramSeulex.mm+1);
  mexPrintf("Teilbl�cke (m1=mm*m2) eingeteilt. Jeder dieser Teilbl�cke\n");
  mexPrintf("hat Bandstruktur.\n");
  mexPrintf("Es wird nun eine cell erwartet, in der jeder cell-Eintrag\n");
  mexPrintf("eine solche Teilmatrix beschreibt.\n");
  mexPrintf("Der Eintrag %i in dieser cell ist aber leer.\n",i1);
  msg="Jacobian: returned cell with empty entry (R�ckgabe der Jacobifunktion: ein cell-Eintrag war leer)";break;
case 218:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the jacobian.\n");
  mexPrintf("The system has dimension d=%i and we have '%s'=%i.\n",
    paramGlobal.d,OPT_M1,paramSeulex.IWORK[9-1]);
  mexPrintf("Because %i='%s'!=d-'%s'=%i the nontrivial lower\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND,OPT_M1,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("(d-'%s',d)=(%i,%i) block is banded.\n",OPT_M1,
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d);
  mexPrintf("This block is divided into mm+1=%i subblocks ('%s'=mm*'%s').\n",
    paramSeulex.mm+1,OPT_M1,OPT_M2);
  mexPrintf("Every subblock is banded. I expect a (1,mm+1) cell containing one entry\n");
  mexPrintf("for each subblock.\n");
  mexPrintf("Every entry (for such a subblock) can be a cell or a double-matrix.\n");
  mexPrintf("But the entry %i is neither a cell nur a double-matrix.\n");
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der Jacobifunktion.\n");
  mexPrintf("Die Systemdimension ist d=%i und es ist m1=%i\n",
    paramGlobal.d,paramSeulex.IWORK[9-1]);
  mexPrintf("Wegen %i='%s'!=d-m1=%i, hat der nichttriviale Teil der\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("Jacobimatrix, das ist der untere (d-m1,d)=(%i,%i) Block,\n",
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d);
  mexPrintf("Bandstruktur. Genauer: dieser block wird in mm+1=%i\n",
    paramSeulex.mm+1);
  mexPrintf("Teilbl�cke (m1=mm*m2) eingeteilt. Jeder dieser Teilbl�cke\n");
  mexPrintf("hat Bandstruktur.\n");
  mexPrintf("Es wird nun eine cell erwartet, in der jeder cell-Eintrag\n");
  mexPrintf("eine solche Teilmatrix beschreibt.\n");
  mexPrintf("Jeder solche cell-Eintrag kann nun seinerseits eine cell\n");
  mexPrintf("oder eine double-Matrix sein.\n");
  mexPrintf("Der Eintrag %i ist aber keines von beidem.\n",i1);
  msg="Jacobian: cell entry is neither cell or double-matrix (R�ckgabe der Jacobifunktion: ein cell-Eintrag mit unerwartetem Typ)";
case 219:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the jacobian.\n");
  mexPrintf("The system has dimension d=%i and we have '%s'=%i.\n",
    paramGlobal.d,OPT_M1,paramSeulex.IWORK[9-1]);
  mexPrintf("Because %i='%s'!=d-'%s'=%i the nontrivial lower\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND,OPT_M1,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("(d-'%s',d)=(%i,%i) block is banded.\n",OPT_M1,
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d);
  mexPrintf("This block is divided into mm+1=%i subblocks ('%s'=mm*'%s').\n",
    paramSeulex.mm+1,OPT_M1,OPT_M2);
  mexPrintf("Every subblock is banded. I expect a (1,mm+1) cell containing one entry\n");
  mexPrintf("for each subblock.\n");
  mexPrintf("Every entry (for such a subblock) can be a cell or a double-matrix.\n");
  mexPrintf("But the entry %i  is a 0, 1- or >=3-dimensional thing.\n",i1);
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der Jacobifunktion.\n");
  mexPrintf("Die Systemdimension ist d=%i und es ist m1=%i\n",
    paramGlobal.d,paramSeulex.IWORK[9-1]);
  mexPrintf("Wegen %i='%s'!=d-m1=%i, hat der nichttriviale Teil der\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("Jacobimatrix, das ist der untere (d-m1,d)=(%i,%i) Block,\n",
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d);
  mexPrintf("Bandstruktur. Genauer: dieser block wird in mm+1=%i\n",
    paramSeulex.mm+1);
  mexPrintf("Teilbl�cke (m1=mm*m2) eingeteilt. Jeder dieser Teilbl�cke\n");
  mexPrintf("hat Bandstruktur.\n");
  mexPrintf("Es wird nun eine cell erwartet, in der jeder cell-Eintrag\n");
  mexPrintf("eine solche Teilmatrix beschreibt.\n");
  mexPrintf("Jeder solche cell-Eintrag kann nun seinerseits eine cell\n");
  mexPrintf("oder eine double-Matrix sein.\n");
  mexPrintf("Der Eintrag %i ist aber ein 0-,1- oder >=3-dimensionales Gebilde.\n",i1);
  msg="Jacobian: cell entry with unexpected dimension (R�ckgabe der Jacobifunktion: ein cell-Eintrag mit unerwarteter Dimension)";
  break;
case 220:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the jacobian.\n");
  mexPrintf("The system has dimension d=%i and we have '%s'=%i.\n",
    paramGlobal.d,OPT_M1,paramSeulex.IWORK[9-1]);
  mexPrintf("Because %i='%s'!=d-'%s'=%i the nontrivial lower\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND,OPT_M1,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("(d-'%s',d)=(%i,%i) block is banded.\n",OPT_M1,
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d);
  mexPrintf("This block is divided into mm+1=%i subblocks ('%s'=mm*'%s').\n",
    paramSeulex.mm+1,OPT_M1,OPT_M2);
  mexPrintf("Every subblock is banded. I expect a (1,mm+1) cell containing one entry\n");
  mexPrintf("for each subblock.\n");
  mexPrintf("Entry %i is a matrix. I expected a (1+'%s'+'%s','%s')=(%i,%i) matrix,\n",
    i1,OPT_JACOBILBAND,OPT_JACOBIUBAND,OPT_M2,
    1+paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC,paramSeulex.IWORK[10-1]);
  mexPrintf("but found a (%i,%i) matrix.\n",i2,i3);
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der Jacobifunktion.\n");
  mexPrintf("Die Systemdimension ist d=%i und es ist m1=%i\n",
    paramGlobal.d,paramSeulex.IWORK[9-1]);
  mexPrintf("Wegen %i='%s'!=d-m1=%i, hat der nichttriviale Teil der\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("Jacobimatrix, das ist der untere (d-m1,d)=(%i,%i) Block,\n",
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d);
  mexPrintf("Bandstruktur. Genauer: dieser block wird in mm+1=%i\n",
    paramSeulex.mm+1);
  mexPrintf("Teilbl�cke (m1=mm*m2) eingeteilt. Jeder dieser Teilbl�cke\n");
  mexPrintf("hat Bandstruktur.\n");
  mexPrintf("Es wird nun eine cell erwartet, in der jeder cell-Eintrag\n");
  mexPrintf("eine solche Teilmatrix beschreibt.\n");
  mexPrintf("Der Eintrag %i ist eine Matrix; erwartet wurde\n",i1);
  mexPrintf("eine (1+'%s'+'%s','%s')=(%i,%i) Matrix.\n",
    OPT_JACOBILBAND,OPT_JACOBIUBAND,OPT_M2,
    1+paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC,paramSeulex.IWORK[10-1]);
  mexPrintf("Die Matrix in Eintrag %i ist aber eine (%i,%i) Matrix.\n",
    i1,i2,i3);
  msg="Jacobian: cell with unexpected matrix size (R�ckgabe der Jacobifunktion: Matrix in cell mit unerwarteter Gr��e)";break;
case 221:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the jacobian.\n");
  mexPrintf("The system has dimension d=%i and we have '%s'=%i.\n",
    paramGlobal.d,OPT_M1,paramSeulex.IWORK[9-1]);
  mexPrintf("Because %i='%s'!=d-'%s'=%i the nontrivial lower\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND,OPT_M1,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("(d-'%s',d)=(%i,%i) block is banded.\n",OPT_M1,
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d);
  mexPrintf("This block is divided into mm+1=%i subblocks ('%s'=mm*'%s').\n",
    paramSeulex.mm+1,OPT_M1,OPT_M2);
  mexPrintf("Every subblock is banded. I expect a (1,mm+1) cell containing one entry\n");
  mexPrintf("for each subblock.\n");
  mexPrintf("Entry %i is a cell. I exepected a (1,1+'%s'+'%s')=(1,%i) cell.\n",
    i1,OPT_JACOBILBAND,OPT_JACOBIUBAND,
    1+paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC);
  mexPrintf("But I found a (%i,%i) cell.\n",i2,i3);
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der Jacobifunktion.\n");
  mexPrintf("Die Systemdimension ist d=%i und es ist m1=%i\n",
    paramGlobal.d,paramSeulex.IWORK[9-1]);
  mexPrintf("Wegen %i='%s'!=d-m1=%i, hat der nichttriviale Teil der\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("Jacobimatrix, das ist der untere (d-m1,d)=(%i,%i) Block,\n",
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d);
  mexPrintf("Bandstruktur. Genauer: dieser block wird in mm+1=%i\n",
    paramSeulex.mm+1);
  mexPrintf("Teilbl�cke (m1=mm*m2) eingeteilt. Jeder dieser Teilbl�cke\n");
  mexPrintf("hat Bandstruktur.\n");
  mexPrintf("Es wird nun eine cell erwartet, in der jeder cell-Eintrag\n");
  mexPrintf("eine solche Teilmatrix beschreibt.\n");
  mexPrintf("Der Eintrag %i ist eine cell; erwartet wurde\n",i1);
  mexPrintf("eine (1,1+'%s'+'%s')=(1,%i) cell.\n",
    OPT_JACOBILBAND,OPT_JACOBIUBAND,
    1+paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC);
  mexPrintf("Die cell in Eintrag %i ist aber eine (%i,%i) cell.\n",i2,i3);
  msg="Jacobian: cell entry cell with wrong size (R�ckgabe der Jacobifunktion: cell in cell mit unerwarteter Gr��e)";break;
case 222:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the jacobian.\n");
  mexPrintf("The system has dimension d=%i and we have '%s'=%i.\n",
    paramGlobal.d,OPT_M1,paramSeulex.IWORK[9-1]);
  mexPrintf("Because %i='%s'!=d-'%s'=%i the nontrivial lower\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND,OPT_M1,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("(d-'%s',d)=(%i,%i) block is banded.\n",OPT_M1,
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d);
  mexPrintf("This block is divided into mm+1=%i subblocks ('%s'=mm*'%s').\n",
    paramSeulex.mm+1,OPT_M1,OPT_M2);
  mexPrintf("Every subblock is banded. I expect a (1,mm+1) cell containing one entry\n");
  mexPrintf("for each subblock.\n");
  mexPrintf("Entry %i is a cell. But the entry %i is not a double vector.\n",i1,i2);
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der Jacobifunktion.\n");
  mexPrintf("Die Systemdimension ist d=%i und es ist m1=%i\n",
    paramGlobal.d,paramSeulex.IWORK[9-1]);
  mexPrintf("Wegen %i='%s'!=d-m1=%i, hat der nichttriviale Teil der\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("Jacobimatrix, das ist der untere (d-m1,d)=(%i,%i) Block,\n",
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d);
  mexPrintf("Bandstruktur. Genauer: dieser block wird in mm+1=%i\n",
    paramSeulex.mm+1);
  mexPrintf("Teilbl�cke (m1=mm*m2) eingeteilt. Jeder dieser Teilbl�cke\n");
  mexPrintf("hat Bandstruktur.\n");
  mexPrintf("Es wird nun eine cell erwartet, in der jeder cell-Eintrag\n");
  mexPrintf("eine solche Teilmatrix beschreibt.\n");
  mexPrintf("Der Eintrag %i ist eine cell. Es geht nun um den Eintrag %i\n",
    i1,i2);
  mexPrintf("in dieser cell. Es handelt sich um keinen double-Vektor.\n");
  msg="Jacobian: cell entry in cell is not a double-vector (R�ckgabe der Jacobifunktion: cell in cell enth�lt Eintrag, der kein Vektor ist)";
  break;
case 223:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the jacobian.\n");
  mexPrintf("The system has dimension d=%i and we have '%s'=%i.\n",
    paramGlobal.d,OPT_M1,paramSeulex.IWORK[9-1]);
  mexPrintf("Because %i='%s'!=d-'%s'=%i the nontrivial lower\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND,OPT_M1,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("(d-'%s',d)=(%i,%i) block is banded.\n",OPT_M1,
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d);
  mexPrintf("This block is divided into mm+1=%i subblocks ('%s'=mm*'%s').\n",
    paramSeulex.mm+1,OPT_M1,OPT_M2);
  mexPrintf("Every subblock is banded. I expect a (1,mm+1) cell containing one entry\n");
  mexPrintf("for each subblock.\n");
  mexPrintf("Entry %i is a cell. Entry %i in this cell is a double vector.\n",i1,i2);
  mexPrintf("I expect a (1,%i) vector but found a (%i,%i) matrix.\n",i3,i4,i5);
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der Jacobifunktion.\n");
  mexPrintf("Die Systemdimension ist d=%i und es ist m1=%i\n",
    paramGlobal.d,paramSeulex.IWORK[9-1]);
  mexPrintf("Wegen %i='%s'!=d-m1=%i, hat der nichttriviale Teil der\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("Jacobimatrix, das ist der untere (d-m1,d)=(%i,%i) Block,\n",
    paramGlobal.d-paramSeulex.IWORK[9-1],paramGlobal.d);
  mexPrintf("Bandstruktur. Genauer: dieser block wird in mm+1=%i\n",
    paramSeulex.mm+1);
  mexPrintf("Teilbl�cke (m1=mm*m2) eingeteilt. Jeder dieser Teilbl�cke\n");
  mexPrintf("hat Bandstruktur.\n");
  mexPrintf("Es wird nun eine cell erwartet, in der jeder cell-Eintrag\n");
  mexPrintf("eine solche Teilmatrix beschreibt.\n");
  mexPrintf("Der Eintrag %i ist eine cell. Es geht nun um den Eintrag %i\n",
    i1,i2);
  mexPrintf("in dieser cell. Er wartet wurde ein (1,%i) Vektor.\n",i3);
  mexPrintf("Gefunden wurde aber eine (%i,%i) Matrix.\n",i4,i5);    
  msg="Jacobian: cell entry in cell has wrong size (R�ckgabe der Jacobifunktion: cell in cell mit Eintrag unerwarteter Gr��e)";
  break;
case 224:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the jacobian.\n");
  mexPrintf("The system has dimension d=%i. Because of\n",paramGlobal.d);
  mexPrintf("%i='%s'!=d the jacobian is banded.\n",
    paramJacobimatrix.MLJAC,OPT_JACOBILBAND);
  mexPrintf("The jacobian has return a cell. I expected the entries for the bands\n");
  mexPrintf("in the cell. But the cell was 0-, 1- or >=3-dimensional.\n");
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der Jacobifunktion.\n");
  mexPrintf("Die Systemdimension ist d=%i. Wegen\n",paramGlobal.d);
  mexPrintf("'%s'!=d, hat die Jacobimatrix Bandstruktur.\n",OPT_JACOBILBAND);  
  mexPrintf("Die Jacobifunktion hat eine cell zur�ckgeliefert.\n");    
  mexPrintf("Leider aber ein 0-,1- oder >=3-dimensionales Gebilde.\n");
  msg="Jacobian return cell with unexpected dimension (R�ckgabe der Jacobifunktion: cell mit unerwarteter Dimension)";break;

case 225:
  mexPrintf("English: \n");
  mexPrintf("Concerning option '%s':\n",OPT_JACOBIMATRIX);
  mexPrintf("Found characters, but expected a string,\n");
  if (i1!=2) 
    mexPrintf("not a 0-, 1- or >=3-dimensional thing.");
  else
    if (i2!=1) mexPrintf("not a matrix containing strings.");
  mexPrintf("\n");
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_JACOBIMATRIX);
  mexPrintf("Habe zwar chars gefunden; habe aber einen String erwartet,\n");
  if (i1!=2) 
    mexPrintf("kein 0-,1- oder >=3-dimensionales Gebilde."); 
  else
    if (i2!=1) mexPrintf("keine Matrix aus Strings.");
  mexPrintf("\n");
  msg="Jacobimatrix: only ONE string expected (nur EIN String erwartet)";break;
  break;
case 226:
  mexPrintf("English: \n");
  mexPrintf("Concerning option '%s':\n",OPT_JACOBIMATRIX);
  mexPrintf("Option contained inline-funcs or function handles, but I need only ONE. ");
  if (i1!=2) 
    mexPrintf("Not a 0-, 1- or >=3-dimensional thing.");
  else
    if ((i2!=1) || (i3!=1)) 
      mexPrintf("Not a matrix containing inline-funcs or function handles.");
  mexPrintf("\n");
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_JACOBIMATRIX);
  mexPrintf("Option enth�lt zwar Inline-Funktionen oder Funktions-Handles, aber");
  mexPrintf("ben�tigt wird nur EIN Handle oder EINE Inline-Funktion. ");
  if (i1!=2) 
    mexPrintf("Kein 0-,1- oder >=3-dimensionales Gebilde."); 
  else
    if ((i2!=1) || (i3!=1)) 
      mexPrintf("Keine Matrix mit Inline-Funktionen oder Funktions-Handles .");
  mexPrintf("\n");
  msg="Jacobimatrix: only ONE function expected (nur EINE Funktion erwartet)";break;
case 227:
  mexPrintf("English: \n");
  mexPrintf("Concerning option '%s':\n",OPT_JACOBIMATRIX);
  mexPrintf("Option has to be a string (function name), a function handle\n");
  mexPrintf("or an inline function.\n");
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_JACOBIMATRIX);
  mexPrintf("Option muss ein String (Funktionsname), ein Funktions-Handle\n");
  mexPrintf("oder eine inline-Funktion sein.\n");
  msg="Jacobimatrix: Function (String,handle,inline) expected";break;
  
/* errors concerning the right side */
/* Fehler im Zusammenhang mit der rechten Seite */
case 301:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the right side.\n");
  mexPrintf("No return values found.\n");
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der rechten Seite.\n");
  mexPrintf("Habe keine R�ckgabe erhalten.\n");
  msg="Right side without return values (Rechte Seite ohne R�ckgabe)";break;
case 302:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the right side.\n");
  mexPrintf("The return value was not a double-vector.\n");
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der rechten Seite.\n");
  mexPrintf("Die R�ckgabe war kein double-Vektor.\n");
  msg="Right side didn't return double vector (R�ckgabe der rechten Seite ist kein double-Vektor)";break;    
case 303:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the right side.\n");
  mexPrintf("The return value was not a (d,1) or (1,d) double-vector.\n");
  mexPrintf("I found a (%i,%i) double-matrix.\n",i1,i2);
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der rechten Seite.\n");
  mexPrintf("Die R�ckgabe war kein (d,1) oder (1,d) double-Vektor.\n");
  mexPrintf("Es wurde eine (%i,%i) double-Matrix zur�ckgegeben.\n",i1,i2);
  msg="Return value of right side was not a (d,1) or (1,d) double vector (R�ckgabe der rechten Seite kein (d,1) oder (1,d) double-Vektor)";break;
case 304:
  mexPrintf("English: \n");
  mexPrintf("Problem calling the right side.\n");
  mexPrintf("We have '%s'=%i!=0. Therefore the problem has special structure.\n",
    OPT_M1,paramSeulex.IWORK[9-1]);
  mexPrintf("Hence the right side has return only\n");
  mexPrintf("the non-trivial Part. I expected a\n");
  mexPrintf("(d-'%s',1)=(%i,1) or a (1,d-'%s')=(1,%i) double-vector.\n",OPT_M1,
    paramGlobal.d-paramSeulex.IWORK[9-1],OPT_M1,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("But I found a (%i,%i) double-matrix.\n",i1,i2);
  mexPrintf("German: \n");
  mexPrintf("Problem beim Aufruf der rechten Seite.\n");
  mexPrintf("Es ist '%s'=%i!=0. Deshalb hat das Problem Spezialstruktur.\n",
    OPT_M1,paramSeulex.IWORK[9-1]);
  mexPrintf("Die rechte Seite muss dann nur noch den\n");
  mexPrintf("nichttrivialen Teil zur�ckliefern. Erwartet wurde\n");
  mexPrintf("ein (d-'%s',1)=(%i,1) oder ein (1,d-'%s')=(1,%i) double-Vektor,\n", OPT_M1,
    paramGlobal.d-paramSeulex.IWORK[9-1],OPT_M1,paramGlobal.d-paramSeulex.IWORK[9-1]);
  mexPrintf("zur�ckgegeben wurde aber eine (%i,%i) double-Matrix.\n",i1,i2);
  msg="R�ckgabe der rechten Seite kein (d-m1,1) oder (1,d-m1) double-Vektor";
  break;

/* Errors concering output options */
/* Fehler im Zusammenhang mit Output Options */
case 401:
  mexPrintf("English: \n");
  mexPrintf("Concering option '%s':\n",OPT_OUTPUTFUNCTION);
  mexPrintf("Option contained inline-funcs or function handles, but I need only ONE. ");
  if (i1!=2) 
    mexPrintf("Not a 0-, 1- or >=3-dimensional thing.");
  else
    if ((i2!=1) || (i3!=1)) 
      mexPrintf("Not a matrix containing inline-funcs or function handles.");
  mexPrintf("\n");
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_OUTPUTFUNCTION);
  mexPrintf("Option enth�lt zwar Inline-Funktionen oder Funktions-Handles, aber");
  mexPrintf("ben�tigt wird nur EIN Handle oder EINE Inline-Funktion. ");
  if (i1!=2) 
    mexPrintf("Kein 0-,1- oder >=3-dimensionales Gebilde."); 
  else
    if ((i2!=1) || (i3!=1)) 
      mexPrintf("Keine Matrix mit Inline-Funktionen oder Funktions-Handles .");
  mexPrintf("\n");
  msg="only ONE function expected (nur EINE Funktion erwartet)";break;

/* errors with WORK-Opt and IWORK-Opt */
/* Fehler mit WORK-Opt und IWORK-Opt */
case 501:
  mexPrintf("English: \n");
  mexPrintf("Concering Option '%s':\n",OPT_MAXEXCOLUMN);
  mexPrintf("Requirement: 3<='%s'.\n",OPT_MAXEXCOLUMN);
  mexPrintf("But I found: '%s'=%i.\n",OPT_MAXEXCOLUMN,paramSeulex.maxExColumn);
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_MAXEXCOLUMN);
  mexPrintf("Es muss gelten: 3<='%s'.\n",OPT_MAXEXCOLUMN);
  mexPrintf("Gefunden wurde aber '%s'=%i.\n",OPT_MAXEXCOLUMN,paramSeulex.maxExColumn);
  msg="invalid maximal columns in tableau for extrapolation (ung�ltige max. Anzahl von Spalten im Extrapolationstableau";break;
case 502:
  mexPrintf("English: \n");
  mexPrintf("Concering Option '%s':\n",OPT_TRANSJTOH);
  mexPrintf("Requirement: 0<='%s'<=1.\n",OPT_TRANSJTOH);
  mexPrintf("But I found: '%s'=%i.\n",OPT_TRANSJTOH,i1);
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_TRANSJTOH);
  mexPrintf("G�ltige Werte f�r '%s' sind 0 oder 1.\n",OPT_TRANSJTOH);
  mexPrintf("Gefunden wurde aber '%s'=%i.\n",OPT_TRANSJTOH,i1);
  msg="invalid JACtoHess transformation flag (ung�ltiges JACtoHess-Transformationsflag)";break;
case 503:
  mexPrintf("English: \n");
  mexPrintf("Concerning Option '%s':\n",OPT_MAXSTEPS);
  mexPrintf("Requirement: 0<'%s'.\n",OPT_MAXSTEPS);
  mexPrintf("But I found '%s'=%i.\n",OPT_MAXSTEPS,i1);
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_MAXSTEPS);
  mexPrintf("Es muss gelten: 0<'%s'.\n",OPT_MAXSTEPS);
  mexPrintf("Gefunden wurde aber '%s'=%i.\n",OPT_MAXSTEPS,i1);
  msg="invalid maximal number of steps (ung�ltige maximale Schrittanzahl)";break;
case 504:
  mexPrintf("English: \n");
  mexPrintf("Concerning Option '%s':\n",OPT_STEPSIZESEQUENCE);
  mexPrintf("Requirement: 1<='%s'<=4.\n",OPT_STEPSIZESEQUENCE);
  mexPrintf("But I found '%s'=%i.\n",OPT_STEPSIZESEQUENCE,i1);
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_STEPSIZESEQUENCE);
  mexPrintf("Es muss gelten: 1<='%s'<=4.\n",OPT_STEPSIZESEQUENCE);
  mexPrintf("Gefunden wurde aber '%s'=%i.\n",OPT_STEPSIZESEQUENCE,i1);
  msg="invalid step size sequence (ung�ltige Angabe bei der Schrittweitenabfolge)";break;
case 505:
  mexPrintf("English: \n");
  mexPrintf("Concerning Option '%s':\n",OPT_OUTPUTLAMBDADENSE);
  mexPrintf("Requirement: 0<='%s'<=1.\n",OPT_OUTPUTLAMBDADENSE);
  mexPrintf("But I found: '%s'=%i.\n",OPT_OUTPUTLAMBDADENSE);
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_OUTPUTLAMBDADENSE);
  mexPrintf("G�ltige Werte f�r '%s' sind 0 oder 1.\n",OPT_OUTPUTLAMBDADENSE);
  mexPrintf("Gefunden wurde aber '%s'=%i.\n",OPT_OUTPUTLAMBDADENSE,i1);
  msg="invalid lambda for dense output (ung�ltiges lambda f�r kont. Ausgabe)";break;
case 506:
  mexPrintf("English: \n");
  mexPrintf("Concerning Options '%s' and '%s':\n",OPT_M1,OPT_M2);
  mexPrintf("Requirement: 0<='%s','%s'.\n",OPT_M1,OPT_M2);
  mexPrintf("But I found '%s'=%i and '%s'=%i.\n",OPT_M1,i1,OPT_M2,i2);
  mexPrintf("German: \n");
  mexPrintf("Zu den Optionen '%s' und '%s':\n",OPT_M1,OPT_M2);
  mexPrintf("Es muss nat�rlich gelten: 0<='%s','%s'\n",OPT_M1,OPT_M2);
  mexPrintf("Gefunden wurde m1=%i und m2=%i.\n",i1,i2);
  msg="m1 and/or m2 negative (m1 und/oder m2 negativ)";break;
case 507:
  mexPrintf("English: \n");
  mexPrintf("Concerning Options '%s' and '%s':\n",OPT_M1,OPT_M2);
  mexPrintf("Requirement: '%s'+'%s'<=d.\n",OPT_M1,OPT_M2);
  mexPrintf("But I found: %i='%s'+'%s'>d=%i.\n",i1+i2,OPT_M1,OPT_M2,paramGlobal.d);
  mexPrintf("German: \n");
  mexPrintf("Zu den Optionen '%s' und '%s':\n",OPT_M1,OPT_M2);
  mexPrintf("Es muss nat�rlich gelten: '%s'+'%s'<=d.\n",OPT_M1,OPT_M2);
  mexPrintf("Gefunden wurde aber %i='%s'+'%s'>d=%i.\n",i1+i2,OPT_M1,OPT_M2,paramGlobal.d);
  msg="m1+m2>d";break;
case 508:
  mexPrintf("English: \n");
  mexPrintf("Concerning Options '%s' and '%s':\n",OPT_M1,OPT_M2);
  mexPrintf("Either '%s' and '%s' are both zero or they are both greater than zero.\n",
    OPT_M1,OPT_M2);
  mexPrintf("But I found: '%s'=%i, '%s'=%i.\n",OPT_M1,i1,OPT_M2,i2);
  mexPrintf("German: \n");
  mexPrintf("Zu den Optionen '%s' und '%s':\n",OPT_M1,OPT_M2);
  mexPrintf("Entweder sind beide 0 oder beide verschieden von 0\n");
  mexPrintf("Gefunden wurde '%s'=%i und '%s'=%i.\n",OPT_M1,i1,OPT_M2,i2);
  msg="either m1,m2 both zero or both are not (entweder m1,m2 beide 0 oder beide nicht)";break;
case 509:
  mexPrintf("English: \n");
  mexPrintf("Concerning Options '%s' and '%s':\n",OPT_M1,OPT_M2);
  mexPrintf("Requirement: There has to exist an mm with\n");
  mexPrintf("%s=mm*%s.\n",OPT_M1,OPT_M2);
  mexPrintf("But I found '%s'=%i and '%s'=%i.\n",OPT_M1,i1,OPT_M2,i2);
  mexPrintf("German: \n");
  mexPrintf("Zu den Optionen '%s' und '%s':\n",OPT_M1,OPT_M2);
  mexPrintf("'%S' muss ein Vielfaches von '%s' sein. Es muss ein\n",OPT_M1,OPT_M2);
  mexPrintf("mm geben, so dass '%s'=mm*'%s' gilt.\n",OPT_M1,OPT_M2);
  mexPrintf("Gefunden wurde '%s'=%i und '%s'=%i.\n",OPT_M1,i1,OPT_M2,i2);
  msg="m1 must be a multiple of m2 (m1 muss ein Vielfaches von m2 sein)";break;
case 510:
  mexPrintf("English: \n");
  mexPrintf("Concerning option '%s':\n",OPT_EPS);
  mexPrintf("Requirement: 0<'%s'<1.\n",OPT_EPS);
  mexPrintf("But I found: '%s'=%e.\n",OPT_EPS,d1);
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_EPS);
  mexPrintf("Es muss gelten: 0<'%s'<1.\n",OPT_EPS);
  mexPrintf("Gefunden wurde aber '%s'=%e.\n",OPT_EPS,d1);
  msg="invalid rounding unit (ung�ltige Maschinengenauigkeit)";break;
case 511:
  mexPrintf("English: \n");
  mexPrintf("Concerning option '%s':\n",OPT_MAXSS);
  mexPrintf("Requirement: '%s'!=0.\n",OPT_MAXSS);
  mexPrintf("But I found: '%s'=%e.\n",OPT_MAXSS,d1);
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_MAXSS);
  mexPrintf("Es muss gelten: '%s'!=0.\n",OPT_MAXSS);
  mexPrintf("Gefunden wurde aber '%s'=%e.\n",OPT_MAXSS,d1);
  msg="invalid maximal stp size (ung�ltige maximale Schrittweite)";break;
case 512:
  mexPrintf("English: \n");
  mexPrintf("Concerning option '%s':\n",OPT_SSSELECTPAR1);
  mexPrintf("Requirement: '%s'>0.\n",OPT_SSSELECTPAR1);
  mexPrintf("But I found: '%s'=%e.\n",OPT_SSSELECTPAR1,d1);
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_SSSELECTPAR1);
  mexPrintf("Es muss gelten: '%s'>0.\n",OPT_SSSELECTPAR1);
  mexPrintf("Gefunden wurde aber '%s'=%e.\n",OPT_SSSELECTPAR1,d1);
  msg="invalid first parameter for step size selection (ung�ltiger erster Schrittweitensteuerungsparameter)";break;
case 513:
  mexPrintf("English: \n");
  mexPrintf("Concerning option '%s':\n",OPT_SSSELECTPAR2);
  mexPrintf("Requirement: '%s'>0.\n",OPT_SSSELECTPAR2);
  mexPrintf("But I found: '%s'=%e.\n",OPT_SSSELECTPAR2,d1);
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_SSSELECTPAR2);
  mexPrintf("Es muss gelten: '%s'>0.\n",OPT_SSSELECTPAR2);
  mexPrintf("Gefunden wurde aber '%s'=%e.\n",OPT_SSSELECTPAR2,d1);
  msg="invalid second parameter for step size selection (ung�ltiger zweiter Schrittweitensteuerungsparameter)";break;
case 514:
  mexPrintf("English: \n");
  mexPrintf("Concerning option '%s':\n",OPT_ORDERDECFRAC);
  mexPrintf("Requirement: '%s'>0.\n",OPT_ORDERDECFRAC);
  mexPrintf("But I found: '%s'=%e.\n",OPT_ORDERDECFRAC,d1);
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_ORDERDECFRAC);
  mexPrintf("Es muss gelten: '%s'>0.\n",OPT_ORDERDECFRAC);
  mexPrintf("Gefunden wurde aber '%s'=%e.\n",OPT_ORDERDECFRAC,d1);
  msg="invalid parameter for order selection (ung�ltiger Faktor f�r Ordnungsreduzierung)";break;
case 515:
  mexPrintf("English: \n");
  mexPrintf("Concerning option '%s':\n",OPT_ORDERINCFRAC);
  mexPrintf("Requirement: '%s'>0.\n",OPT_ORDERINCFRAC);
  mexPrintf("But I found: '%s'=%e.\n",OPT_ORDERINCFRAC,d1);
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_ORDERINCFRAC);
  mexPrintf("Es muss gelten: '%s'>0.\n",OPT_ORDERINCFRAC);
  mexPrintf("Gefunden wurde aber '%s'=%e.\n",OPT_ORDERINCFRAC,d1);
  msg="invalid parameter for order selection (ung�ltiger Faktor f�r Ordnungsreduzierung)";break;
case 516:
  mexPrintf("English: \n");
  mexPrintf("Concerning option '%s':\n",OPT_SSSELECTPAR3);
  mexPrintf("Requirement: '%s'>0.\n",OPT_SSSELECTPAR3);
  mexPrintf("But I found: '%s'=%e.\n",OPT_SSSELECTPAR3,d1);
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_SSSELECTPAR3);
  mexPrintf("Es muss gelten: '%s'>0.\n",OPT_SSSELECTPAR3);
  mexPrintf("Gefunden wurde aber '%s'=%e.\n",OPT_SSSELECTPAR3,d1);
  msg="invalid safety factor for step size control (ung�ltiger Schrittweitensteuerungsparameter)";break;
case 517:
  mexPrintf("English: \n");
  mexPrintf("Concerning option '%s':\n",OPT_RHO);
  mexPrintf("Requirement: '%s'>0.\n",OPT_RHO);
  mexPrintf("But I found: '%s'=%e.\n",OPT_RHO,d1);
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_RHO);
  mexPrintf("Es muss gelten: '%s'>0.\n",OPT_RHO);
  mexPrintf("Gefunden wurde aber '%s'=%e.\n",OPT_RHO,d1);
  msg="invalid safety factor for step size control (ung�ltiger Schrittweitensteuerungsparameter)";break;
case 518:
  mexPrintf("English: \n");
  mexPrintf("Concerning option '%s':\n",OPT_WORKFCN);
  mexPrintf("Requirement: '%s'>0.\n",OPT_WORKFCN);
  mexPrintf("But I found: '%s'=%e.\n",OPT_WORKFCN,d1);
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_WORKFCN);
  mexPrintf("Es muss gelten: '%s'>0.\n",OPT_WORKFCN);
  mexPrintf("Gefunden wurde aber '%s'=%e.\n",OPT_WORKFCN,d1);
  msg="invalid estimated work for right size (ung�ltige Aufwandssch�tzung f�r die rechte Seite)";break;
case 519:
  mexPrintf("English: \n");
  mexPrintf("Concerning option '%s':\n",OPT_WORKJAC);
  mexPrintf("Requirement: '%s'>0.\n",OPT_WORKJAC);
  mexPrintf("But I found: '%s'=%e.\n",OPT_WORKJAC,d1);
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_WORKJAC);
  mexPrintf("Es muss gelten: '%s'>0.\n",OPT_WORKJAC);
  mexPrintf("Gefunden wurde aber '%s'=%e.\n",OPT_WORKJAC,d1);
  msg="invalid estimated work for jacobi function (ung�ltige Aufwandssch�tzung f�r die Jacobimatrix)";break;
case 520:
  mexPrintf("English: \n");
  mexPrintf("Concerning option '%s':\n",OPT_WORKDEC);
  mexPrintf("Requirement: '%s'>0.\n",OPT_WORKDEC);
  mexPrintf("But I found: '%s'=%e.\n",OPT_WORKDEC,d1);
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_WORKDEC);
  mexPrintf("Es muss gelten: '%s'>0.\n",OPT_WORKDEC);
  mexPrintf("Gefunden wurde aber '%s'=%e.\n",OPT_WORKDEC,d1);
  msg="invalid estimated work for decomposition (ung�ltige Aufwandssch�tzung f�r Matrixzerlegung)";break;
case 521:
  mexPrintf("English: \n");
  mexPrintf("Concerning option '%s':\n",OPT_WORKSOL);
  mexPrintf("Requirement: '%s'>0.\n",OPT_WORKSOL);
  mexPrintf("But I found: '%s'=%e.\n",OPT_WORKSOL,d1);
  mexPrintf("German: \n");
  mexPrintf("Zur Option '%s':\n",OPT_WORKSOL);
  mexPrintf("Es muss gelten: '%s'>0.\n",OPT_WORKSOL);
  mexPrintf("Gefunden wurde aber '%s'=%e.\n",OPT_WORKSOL,d1);
  msg="invalid estimated work for forward- backward-substitution (ung�ltige Aufwandssch�tzung f�r Vorw�rts- und R�ckw�rtssubstitution)";break;
  
/* Errors that should never occur */
/* Fehler, die niemals auftreten sollten */
case 1001:
  msg="internal error: callOutputFcn: unknown reason";
  break;
case 1002:
  msg="internal error: unknown funcCallMethod";
  break;
