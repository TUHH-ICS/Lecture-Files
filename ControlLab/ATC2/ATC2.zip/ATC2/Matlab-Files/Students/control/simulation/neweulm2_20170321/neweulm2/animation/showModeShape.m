% showModeShape - Display n-th Eigenmode
%
%  Syntax:
% showModeShape(modalResults,n,varargin);
%
%  Input arguments:
% modalResults .... Results of a modal analysis {sys.results.modal}
% n ............... Index of mode to be displayed, several can be passed as
%                   a vector. It is assumed, that all eigenvalues exist in
%                   complex conjugated pairs and that they are arranged
%                   like that in the results. There exist 2*sys.counters.genCoord
%                   eigenvalues, but n can be maximal sys.counters.genCoord. 
%                   {[1:sys.counters.genCoord]}
%
%  optional Parameters {default values}:
% Amplitude ............ Amplitude {1}
% ShowRefPos ........... Include reference position in animation [on/off]
%                        {off}
% RefPosTransparency ... Transparceny of reference configuration [0..1]
%                        {0.5}
% AdjustFigure ......... Adjust the visible size of the animation window
%                        {true}
% Axes ................. Axes in which the current mode shape shall be
%                        plotted. {If nothing is specified, a new axes is
%                        created.}
% RealOrImaginary ...... The matrix of the eigenvectors can contain real or
%                        complex values. But to display an eigenform only
%                        real values are valid. As the eigenvectors can be
%                        scaled arbitrarily, no single choice is always
%                        good. Therefore the user can decide, whether
%                        either the 'real' or the 'imag' part shall be
%                        used. Other possibilities are the absolute value
%                        'abs' or a sum of 'both' real and imaginary part.
%                        By the theory, the imaginary part should give the
%                        eigenform, while the real part is associated to
%                        the damping. As a standard, the imaginary part is
%                        used, except if by chance (and probably the
%                        numerical evaluation) this is a zero vector, and
%                        the real part is unequal to zero, this is used
%                        instead. {'imag'}
% CheckVarargin ........ An advanced feature to avoid errors if invalid
%                        parameters are passed. This is only if you know
%                        exactly what you are doing. {true}
%
%  Return arguments:
% myFigs ............... Figure handles to the newly created figures
% myAxes ............... Axes handles to the newly created axes
% Positions_ ........... Position vectors of the coordinate systems for the
%                        displayed eigenmodes. 
%                        size(Positions) = [3, length(n), sys.counters.frame]
% 
%  See also:
%  freqResPlot, freqResonse, calcEqMotLin, eqm_lin_ssinout,
%  modalAnalysis, animModeShape, animTimeInt
%
% First appearance: 01.04.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
