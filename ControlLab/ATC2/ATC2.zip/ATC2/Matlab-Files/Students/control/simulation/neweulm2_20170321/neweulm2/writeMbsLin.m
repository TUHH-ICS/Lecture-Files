% writeMbsLin - Create Matlab functions for the numerical evaluation
% 
%  Syntax:
%> writeMbsLin;
%> writeMbsLin(varargin);
%
%  Description:
% This function creates all files needed for the numerical evaluation of
% the linearized equations of motion.
% 
%  Optional Parameters, given pairwise:
% OutType ......... Type to use for the status updates, see
%                   'n2StatusOutput' for more information {'CMD'} 
% OutHandle ....... Handle to use for the status updates, see
%                   'n2StatusOutput' for more information {1}
% MassSymmetric ... Logical: true/false {sys.settings.equation.massSymmetric}
%
%  Example:
%> writeMbsLin('MassSymmetric',true);
%
%  See also: 
%   writeMbsNonLin, calcEqMotNonLin, sym2mcode, writeHelpvarDef,
%   writeGenCoordDef, writeSetValDef.m
%
% First appearance: 01.04.2007
%
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
