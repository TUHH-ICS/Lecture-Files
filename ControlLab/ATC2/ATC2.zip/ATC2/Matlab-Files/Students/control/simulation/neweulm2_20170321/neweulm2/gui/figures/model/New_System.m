% varargout = New_System(varargin)
% New_System M-file for New_System.fig
%      New_System, by itself, creates a new New_System or raises the existing
%      singleton*.
%
%      H = New_System returns the handle to a new New_System or the handle to
%      the existing singleton*.
%
%      New_System('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in New_System.M with the given input arguments.
%
%      New_System('Property','Value',...) creates a new New_System or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before New_System_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to New_System_OpeningFcn via varargin.
%
% Graphical user interface to initialize the system data structure and
% define a new multibody system.
% 
% For more information, please open the corresponding window and click on
% the help button, labeled with a question mark "?".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
%
% First appearance: 01.07.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
