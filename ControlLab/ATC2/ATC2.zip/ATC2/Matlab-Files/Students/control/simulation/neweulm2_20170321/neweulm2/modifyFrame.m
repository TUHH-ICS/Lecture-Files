% modifyFrame - Change selected properties of coordinate system
% 
%  Syntax:
%> modifyFrame;
%> modifyFrame(frameID, 'Property', value, ...);
% 
%  Description: 
%  Input arguments:
% frameID ...... ID of the frame to be changed
% Optional input arguments, given in pairs with the new property
% Caller ...... Internal option, specifying the function from which this
%               file has been called
% ID .......... Specify a new ID
% Name ........ Specify a new Name
% phi ......... Specify a new angular description of the orientation 
% r ........... Specify a new relative position vector
% Recompute ... Logical whether a recomputation of the equations of motion
%               is necessary. Usually, this is determined, however,
%               sometimes it is known before which can avoid unnecessary
%               work
% RefSys ...... Specify a new frame of reference, from which the frame is
%               defined
% Struct ...... Give a data structure of the new frame
%
%  Return values:
% data_ ....... New data substructure of this frame
% flag_ ....... Flag specifying the success and consequences of the
%               function call:
%       -1 .... Some error occured
%        0 .... Successfull run, but equations have to be set up by calling
%               calcEqMotNonLin.
%        1 .... Successfull run, calculation can continue without further
%               adjustment or recomputation
%
%  See also: 
% newFrame, modifyBody
% 
% First appearance: 12.04.2012
%
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
