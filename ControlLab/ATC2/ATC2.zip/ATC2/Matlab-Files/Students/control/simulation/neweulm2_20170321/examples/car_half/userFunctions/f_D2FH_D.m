function res_ = f_D2FH_D(t,y_,varargin)

res_ = 0; % Default return value
