% newTimeData(varargin) - To obtain reproducible results the
% following method is implemented.
% 
%  Syntax: 
%> newTimeData;
%> newTimeData('Property', value, ...);
% 
%  Description:
% In several applications it may be necessary to use precalculated data
% which can be identified over the time t or some state information y.
%
% Examples for this is a precalculated stochastic excitation or a road
% profile exciting a car model. To obtain reproducible results the
% following method is implemented. By using this function, the given values
% are stored under sys.model.other. The user can then define a time or state
% dependent parameter and use the template to interpolate any value between
% the given support points.
%
%  Input, all optional, given pairwise:
% Id .............. Identifier of the volume element {'timeData_1'}
% Name ............ Name of the element {'Time Data 1'}
% Type ............ Type of element {'timeData'}
% x or Time ....... Independent Data to identify the position in dependent
%                   data {linspace(0,10,length(y))}
% y ............... Dependent data, which shall be returned later {[]}
% interpolation ... Method to use to interpolate. This is only inserted in
%                   the template and a preparation for the user's
%                   implementation {'linear'}
% data ............ Field where the user can enter any data associated with
%                   this element {[]}
%
%  See also: 
% newVolume, newTimeDependent
%
% First appearance: 23.12.2010
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
