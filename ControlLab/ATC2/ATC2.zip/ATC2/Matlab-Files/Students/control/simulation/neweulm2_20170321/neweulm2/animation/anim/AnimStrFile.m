% err_ = AnimStrFile(ye_,t_,varargin)
% AnimStrFile - write .str file for an animation with anim/...
% If nothing is specified the movement of all bodies is displayed. For this
% the motions of the primary coordinate systems are exported. Then all
% geometric shapes should be attached to them. 
%
% Input arguments
% ye_ ... 		  generalized Coordinates
% t_  ... 		  time
%
% Optional input arguments, should be specified in pairs, {default values}
% 'Filename' ............ A filename can be specified {[sys.id,'.str']}
% 'CoordinateSystems' ... The coordinate systems whose motion is to be
%                         exported can be specified. 
%                         If 'cg' is passed as value for this option, the
%                         frames in the centers of gravity are exported, if
%                         they exist.
%                         If 'all' is passed as value for this option, all
%                         existing coordinate systems are exported.
%                         An arbitrary list may be specified.
% 'amplitude' ........... ye is multiplied with amplitude
% 'timepershift' ........ define a delta time for anim
% 'repetitions' ......... number of repetitions
% 'force' ............... force matrix
% 'forcek' .............. force coordinate Systems
% 'startanim' ........... false | true
%
% Return values
% err_ .... If an output parameter is specified, any occuring errors are not
%           thrown immediately, but their message passed back.
%
% Function call:
% AnimStrFile(ye_,t_,'CoordinateSystems','cg','startanim',true)
