% fullModelRun(varargin) - Model the system in the current or given directory, then perform all
% available simulations and finish by saving the system data structure to
% sys.mat.
% 
%  Syntax:
%> fullModelRun;
%> fullModelRun(varargin);
% 
%  Description:
% This function provides an option to display all commands using
% the 'echo' command.
%
%  Optional parameters, given pairwise:
% DisplayCommands ..... Logical parameter, if true, the commands being
%                       issued are displayed using the 'echo' command.
%                       {false}
% Folder .............. Model folder to use {pwd}
% startSysDef ......... Specify the file to model the system
%                       {'startSysDef'}
%
%  See also:
% gettingStarted, startSysDef
%
% First appearance: 29.09.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
