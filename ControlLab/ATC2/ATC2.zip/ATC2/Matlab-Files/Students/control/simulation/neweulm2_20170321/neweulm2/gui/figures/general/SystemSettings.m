% SYSTEMSETTINGS M-file for SystemSettings.fig
%      SYSTEMSETTINGS, by itself, creates a new SYSTEMSETTINGS or raises the existing
%      singleton*.
%
%      H = SYSTEMSETTINGS returns the handle to a new SYSTEMSETTINGS or the handle to
%      the existing singleton*.
%
%      SYSTEMSETTINGS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SYSTEMSETTINGS.M with the given input arguments.
%
%      SYSTEMSETTINGS('Property','Value',...) creates a new SYSTEMSETTINGS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before SystemSettings_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to SystemSettings_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
