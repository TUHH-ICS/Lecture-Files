% plotStandardResults - Create often used plots
%
%  Description:
%
% After some simulation has been run, this function can be used to create
% the plots we used most often, namely of states, trajectories or system
% outputs
%
%  Optional parameters {default value}:
%
% Figure ........... For comparison, you can plot results of different
%                    simulations into the same figure(s). Please make sure,
%                    that the correct number of figures is given. If
%                    nothing is specified, new figure(s) are created {[]}
% LegendLocation ... Specify the location of the legend in each axes,
%                    corresponds to the property 'Location' of the legend,
%                    type 'help legend' for more information {'NorthEast'}
% LineStyle ........ Specify the LineStyle property of all curves in the
%                    figure, e.g. draw all curves with dashed lines. Search
%                    ''LineSpec'' in the Matlab Help Browser for more
%                    information. If nothing is specified, the current
%                    standard values are kept {''}
% LineWidth ........ Specify the line width of all new plotted curves. If
%                    nothing is specified, the current standard values are
%                    kept {[]}
% Marker ........... Specify a marker for all new plotted curves.  If
%                    nothing is specified, the current standard values are
%                    kept {[]}
% Name ............. Specify the name of this system, then the created
%                    figures will be called accordingly. This is very
%                    useful for the comparison between different systems or
%                    configurations. If logical true is passed, sys.model.name is
%                    used, for logical false no name is inserted {false}
% Resolution ....... Number of interpolation points to be used for the
%                    plot. This numerical value is passed to linspace() to
%                    calculate the time vector. If the option ''Time'' has
%                    been used as well, this specifies the number of points
%                    in this interval. As a standard, the time vector is
%                    kept from the result. {[]}
% Result ........... Data structure containing the result as returned from
%                    an integration algorithm or timeInt.m.
%                    {sys.results.timeInt}
% Subplots ......... Logical parameter. If set to true, the created plots
%                    don't use separate figures but subplots instead. The
%                    plot of states is split up in several subplots as well
%                    {false}
% Time ............. Time vector if it shall be different from the
%                    integration result. Can be used to specify all
%                    interpolation points or to be combined with the
%                    ''Resolution'' option. As a standard the time interval
%                    and interpolation points are kept from the result.
%                    {[]}
% Type ............. Specify the type of data to be plotted. As a standard,
%                    the Type {'genCoords'} are plotted. Currently the
%                    following possibilities are implemented:
%       - 'constraints': Plot all violations of the position and velocity
%         constraints if this system has such constraints (sys.dynamics.constraints.c_2 /
%         sys.dynamics.constraints.c_3).
%       - 'genCoords': Plot only the position level data of the result
%       - 'lagrangemultiplier': If a system with kinematic loops has been
%         simulated, the Lagrange Multipliers will be plotted
%       - 'inputs': Plot all system inputs stored under sys.model.input.
%         Each substructure representing a group gets its own figure.
%       - 'outputs': Plot all system outputs stored under sys.model.output.
%         Each substructure representing a group gets its own figure.
%       - 'phase': Plots the phase plane, meaning the generalized
%         velocities over the generalized coordinates. Elastic degrees of
%         freedom are not included.
%       - 'positionconstraints': Plot all violations of the position
%         constraints if this system has velocity constraints
%         (sys.dynamics.constraints.c_2).
%       - 'reactionforces': Plot all reaction forces if they are available
%         and have been calculated already.
%       - 'appliedforces': Plot all applied forces if they are available.
%       - 'states': Plot the complete state vectors of the result
%       - 'trajectories': Plot the trajectories of all coordinate systems,
%         evaluated at the states in result
%       - 'velocity': Plot the velocities of all coordinate systems,
%         evaluated at the states in result, in cartesian coordinates
%       - 'velocityconstraints': Plot all violations of the velocity
%         constraints if this system has velocity constraints
%         (sys.dynamics.constraints.c_3).
% Windowstyle ...... Set the 'WindowStyle' property of the figure, either
%                    'normal' or 'docked', if [] is given, nothing is
%                    changed {[]}
%
%  Return Arguments:
%
% fig_ ..... Handles of all figures which have been created
% result ... Data structure containing the result which has been used to
%            create the plots. Depending on the plottype additional fields
%            to the time result.x and states result.y have been created
%
%  Example:
%
% plotStandardResults('type','outputs','Result',sys.results.timeInt);
% See also: timeInt, kinematicAnalysis, deval_wrap
% 
% First appearance: 16.12.2010
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
