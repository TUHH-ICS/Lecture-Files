% exportSystem2C(varargin) - Create ANSI C code for a fast evaluation
%
%  Syntax:
%> exportSystem2C;
%> exportSystem2C('Property', value, ...);
%
%  Description:
% Create ANSI C code used to create different executables
% for Matlab, Simulink, Pasimodo and stand-alone applications. The source
% code can be found in ./cFunctions.
%
%  Optional parameters {default value}:
% 
% CallMatlab .......... Boolean, deciding whether the Matlab function of
%                       time and state dependent variables which are not
%                       defined as symbolic variables shall be included in
%                       the source code or not. {false}
% Compile ............. Boolean, deciding whether the source code shall
%                       be compiled right after creation. {true}
% OutputSampleTime .... Float, defining the sample time of the visual
%                       output. {0.01}
% ExportKinematics .... Determine, whether the the kinematics of all frames
%                       should be exported {false}
% Prefix .............. Determine a prefix for the function and file names
%                       {''}
% Visual .............. Boolean, deciding whether the real-time evaluation
%                       of the vertices of all defined grafical objects
%                       shall be included in the Simulink models. Please
%                       keep in mind that this evaluation is very time
%                       consuming and not really neccessary simulations in
%                       the Neweul-M2 simulation environment. {false}
%
%  Example:
%> exportSystem2C('CallMatlab', true, 'Compile', false);
%
%  See also: 
% compileMatlabCode, createSimulinkLibrary
%
% First appearance:             06.07.2011
%
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
