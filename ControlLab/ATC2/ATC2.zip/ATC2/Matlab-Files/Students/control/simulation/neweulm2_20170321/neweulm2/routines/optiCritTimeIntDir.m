% [psi, gradpsi] = optiCritTimeIntDir(p_in)
% Evaluates all values necessary in an optimization step or calls the
% required subroutines. This Function handles the direct method where the
% System-ODE and the Matrix-ODE are integrated in one equation. If only the
% criterion value is requested, only the equations of motion are
% integrated, using the options under sys.settings.timeInt.intOpts.
%
% The criterion is of the form
% psi = G1(t1,y1,Dy1) + int _{t0} ^{t1} {F(t,y,Dy) dt}
% where the time t is in [t0,t1] and y1=y(t1), Dy1=Dy(t1). The functions G1
% and F may contain symbolic expressions or references to kinematic
% expressions of the multibody system.
%
% The direct method is a semi-analytical method. By symbolically
% differentiating the equations of motion, a second set of differential
% equations is obtained. Here, both sets of equations are integrated
% together. The direct method is usually faster and more precise than
% finite differences. However it has one restriction. The dimension of the
% additional set of equations is sys.counters.genCoord*numel(sys.settings.opt.p), which can
% result in many equations. For an alternative, please have a look at the
% adjoint variable method
%
% Incoming variables
% p_in ...... Vector of current design variables p. This function uses
%             scaled parameter values for the optimization in the range
%             [-1 <= p_ <= 1]. This may look strange but improves the
%             results, especially if the design variables are in a
%             different order of magnitude. The actual interval is given by
%             [sys.settings.opt.constr.lb, sys.settings.opt.constr.ub]
% Outgoing variables
% psi ....... Value of criterion function
% gradpsi ... Gradient of criterion function, only evaluated if nargout==2
%
% See also: newOpt, optiCritTimeIntAdj, matricesGradientTimeInt,
%   OptiCalcInitCon, writeFinalCond, writeOptiAdjoint, writeOptiDirect,
%   writePsiTimeInt, optiCritTimeIntFinite
%
% First appearance: 01.12.2007
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
