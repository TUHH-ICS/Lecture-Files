function Du = f_Du(t)
% f_Du - definition of 1st time-derivative of user-defined variable u

global sys;



% constant user-defined variables

c = sys.parameters.data.c;
z = sys.parameters.data.z;


% time dependent user-defined variables

Du = zeros(1,1);

if(0 < t && t < 0.6)
    Du(1) = 0.5*z*sin(c*t)*c;
end
