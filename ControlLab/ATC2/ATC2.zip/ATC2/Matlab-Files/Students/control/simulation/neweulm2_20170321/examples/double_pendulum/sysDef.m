%% Double Pendulum
% 
% System definition of a double pendulum
% 
%%
% *Neweul-M2 System Struct* 
%
% At first, the structure sys is initialized
%%

% Create basic data structure
newSys('Id', 'DP', ...
    'Name',  'double pendulum');

%%
% *Pendulum 1* 
%
% The first pendulum can rotate about the x- and y-axis of the inertial
% frame. In addition, the joint is actuated with an input x.
%%

% Constant parameters m1, l1, x0 and omega
newConstant('m1', 10, ...
    'l1', 0.1);
newConstant('x0', 0, ...
    'omega', 0.2);

% Time dependent parameters x = x0*cos(omega*t)
newTimeDependent('x', 'x0*cos(omega*t)');

% Generalized coordinates _alpha1_ and _beta1_
newGenCoord('alpha1', 'beta1');

% Body definition
newBody('Id',    'P1', ...
        'Name',  'Pendulum 1', ...
        'RefSys', 'ISYS', ...
        'RelPos', '[x; 0; 0]', ...
        'RelRot', '[alpha1; beta1; 0]', ...
        'CgPos',  '[0; 0; -l1]', ...
        'Mass',   'm1', ...
        'Inertia', sym('m1')/6250*eye(3));

%%
% *Pendulum 2*
%
% The second pendulum is attached to the first one. Similar to the first
% pendulum, it can perform rotations about the x- and y-axis.
%%

% Constant parameters m2 and l2
newConstant('m2', 10, ...
    'l2', 0.2);

% Generalized coordinates alpha2 and beta2
newGenCoord('alpha2', 'beta2');

% Body definition
newBody('Id',     'P2', ...
        'Name',   'Pendulum 2', ...
        'RefSys', 'P1_cg', ...
        'RelPos', '[0; 0; 0]', ...
        'RelRot', '[alpha2; beta2; 0]', ...
        'CgPos',  '[0; 0; -l2]', ...
        'Mass',   'm2', ...
        'Inertia', sym('m2')/6250*eye(3));

%%
% *Force elements*
%
% A spring-damper combination connects the center of gravity of the second
% pendulum with the inertial frame.
%%

% Constant parameters k and c
newConstant('k', 0, ...
    'c', 0);

% Spring damper combination with stiffness k and damping coefficient c
newForceElem('Id',        'FELEM_P2_HOR', ...
             'Name',      'SpringDampCmp', ...
             'Frame1',    'ISYS', ...
             'Frame2',    'P2_cg', ...
             'DirDef',    'ISYS', ...
             'Stiffness', '[k; 0; 0; 0; 0; 0]', ...
             'Damping',   '[c; 0; 0; 0; 0; 0]');

%%
% *System inputs*
%
% The excitation x is used as an input.
%%

% Excitation x as input 'In_x'
newInput('Id',   'In_x', ...
         'Name', 'base point excitation', ...
         'Var',  'x');

%%
% *System outputs*
%
% The x-component of the position vector of the first pendulum's center of
% gravity, the x-component of the force caused by the spring-damper
% combination and the angle _beta2_ are used as outputs. 
%%

% x-component of he position vector of the first pendulum's center of
% gravity as output 'P1_cg_x'
newOutput('Id',  'P1_cg_x', ...
         'Name', 'vertical Position Pendulum 1', ...
         'Var',  'P1_cg.r(1)', ...
         'Type', 'kinematic');

% x-component of the force caused by the spring-damper
% combination as output 'Force_horizontal'
newOutput('Id',  'Force_horizontal', ...
         'Name', 'Force of horizontal force element', ...
         'Var',  'FELEM_P2_HOR(1)', ...
         'Type', 'appliedForce');

% Generalized coordinate beta2 as output 'beta2'
newOutput('Id',  'beta2', ...
         'Name', 'Generalized coordinate beta 2', ...
         'Var',  'beta2', ...
         'Type', 'genCoord');
     
%%
% *Neweul-M2*
%
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
%%