function sysDef(p,formulation,parSet,nDimensions)
% sysDef(p,formulation,parSet)
% sysDef - System definition of a chain with a load at the end. The support
% has a position excitation in the xy-plane, orthogonal to gravity.
%
% Input arguments. {standard value}
% p ............. Number of chain links {25}
% formulation ... Parameters specifying the system formulation. Is passed
%                 to newSys with the option 'formulation', e.g.
%                 'recursive', 'recursiveMinimal' or 'newtonEuler',
%                 {'recursiveMinimal'}
% parSet ........ Select the parameter set for the excitation. For
%                 parSet==1, a circular motion is prescribed, for
%                 parSet==2, the second eigenfrequency is excited. This
%                 eigenfrequency is not evaluated, but is hard coded for
%                 p==25. {2}
% nDimensions ... Number of dimensions. If 2 is given, the chain is a
%                 planar system in the xz-plane. {3}

global sys;

if(nargin == 0 || isempty(p))
    p = 25;
end
if(nargin < 2 || isempty(formulation))
    formulation = 'recursiveMinimal';
end
if(nargin < 4 || isempty(nDimensions))
    nDimensions = 3;
end

sys = newSys('Id','SC', 'Name','Slide with chain and load','Kinematics','rel', ...
    'formulation',formulation,'simplify',3);

% Constant parameters
newConstant('m1',0.1,'m2',2,'l1',0.04,'l2',0.2,'ly',0.1,...
                'Ix1',0.00005,'Iy1',0.00005,'Iz1',0.00005,...
                 'Ix2',0.0133,'Iy2',0.0133,'Iz2',0.0133);

% Timedependent parameters (Slider)
newConstant('xAmp',0.15,'xOmega',2.5);
newTimeDependent('x','xAmp*sin(xOmega*t)');
newInput('var', 'x');
newConstant('yAmp',0.15,'yOmega',2.5);
newTimeDependent('y','yAmp*cos(yOmega*t)');
newInput('var', 'y');

if(nargin < 3 || parSet == 1)
    % Prescribe a circular motion
    sys.parameters.data.xAmp = 0.15;
    sys.parameters.data.xOmega = 2.5;
    sys.parameters.data.yAmp = 0.15;
    sys.parameters.data.yOmega = 2.5;
else
    % Excite the second eigenfrequency (for p=25) in the xz-plane
    sys.parameters.data.xAmp = 0.01;
    sys.parameters.data.xOmega = 9.4775;
    sys.parameters.data.yAmp = 0;
    sys.parameters.data.yOmega = 2.5;
end

%% Slide
newBody('Id','S1', ...
        'Name','Slide 1', ...
        'RefSys','ISYS', ...
        'RelPos','[x; 0; 0]', ...
        'RelRot','[0; 0; 0]', ...
        'CgPos','[0; 0; 0]', ...
        'Mass','0', ...
        'Inertia',zeros(3,3));

if(nDimensions == 3)
    relPos = '[0; y; -ly]';
else
    relPos = '[0; 0; -ly]';
end
newBody('Id','S2', ...
        'Name','Slide 2', ...
        'RefSys','S1', ...
        'RelPos',relPos, ...
        'RelRot','[0; 0; 0]', ...
        'CgPos','[0; 0; 0]', ...
        'Mass','0', ...
        'Inertia',zeros(3,3));  
    
%% Chain link 1
newGenCoord('alpha1','beta1');
newBody('Id','P1', ...
        'Name','ChainLink1', ...
        'RefSys','S2', ...
        'RelPos','[0; 0; -0.01]', ...
        'RelRot','[alpha1; beta1; 0]', ...
        'CgPos','[0; 0; -l1/2]', ...
        'Mass','m1', ...
        'Inertia','[Ix1 0 0; 0 Iy1 0; 0 0 Iz1]'); 
    
%% p-1 chain links
for i=2:p
    al = 'alpha';
    be = 'beta';
    P = 'P';
    Name = 'ChainLink';
    num = num2str(i);
    numi_1 = num2str(i-1);
    alnum = strcat(al,num);
    benum = strcat(be,num);
    Pnum = strcat(P,num);
    Namenum = strcat(Name,num);
    Refsys = strcat(P,numi_1,'_cg');
    if(nDimensions == 3)
        relRot = strcat('[',alnum,'; ',benum,';0]');
        newGenCoord(alnum,benum);
    else
        relRot = strcat('[0; ',benum,';0]');
        newGenCoord(benum);
    end
    
    newBody('Id',Pnum, ...
        'Name',Namenum, ...
        'RefSys',Refsys, ...
        'RelPos','[0; 0; -l1/2]', ...
        'RelRot',relRot, ...
        'CgPos','[0; 0; -l1/2]', ...
        'Mass','m1', ...
        'Inertia','[Ix1 0 0; 0 Iy1 0; 0 0 Iz1]'); 
end

%% load

P = 'P';
num = num2str(p);
if(nDimensions == 3)
    relRot = '[alphaL;betaL;0]';
    newGenCoord('alphaL','betaL'); 
else
    relRot = '[0;betaL;0]';
    newGenCoord('betaL'); 
end
Refsys = strcat(P,num,'_cg');
 
newBody('Id','B', ...
    'Name','Load', ...
    'RefSys',Refsys, ...
    'RelPos','[0; 0; -l1/2-0.01]', ...
    'RelRot',relRot, ...
    'CgPos','[0; 0; -l2/2]', ...
    'Mass','m2', ...
    'Inertia','[Ix2 0 0; 0 Iy2 0; 0 0 Iz2]'); 

% END OF sysDef
