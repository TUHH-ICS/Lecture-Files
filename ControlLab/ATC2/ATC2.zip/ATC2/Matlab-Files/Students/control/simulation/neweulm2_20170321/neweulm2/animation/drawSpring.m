% drawSpring - Add a spring to the graphics data
% 
%  Description:
% The spring connects two coordinate systems dynamically. It will be drawn
% in updateGeo. This function only adds settings to sys.graphics.spring
%
%  Input arguments:
% frame1 ...... name of the first coordinate system
% frame2 ...... name of the second coordinate system
% ID .......... ID for this line object, which is used in the system
%               data structure
% 
%  Optional inputs, given pairwise: 
% Color........... Color of the spring {[0 0 0]}
% Diameter ....... Diameter of the spring {0.01}
% LineWidth ...... Linewidth {2}
% NumWinding ..... Number of windings of the spring {5}
% Radius ......... Instead of the diameter, the radius can be specified
%                  {0.005}
%
%  Examples:
% drawSpring('BODY_1','BODY_2');
% drawSpring('BODY_1','BODY_2','spring_1_2','NumWinding',10,'Diameter',0.1);
%
%  See also:
% drawArrow3d, drawCube, drawElasticBeam, drawLine, drawRotBody,
% drawSphere, drawSTL
%
% First appearance: 24.03.2011
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
