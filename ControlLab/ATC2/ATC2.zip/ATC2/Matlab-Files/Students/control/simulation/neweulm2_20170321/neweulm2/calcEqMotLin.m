% calcEqMotLin - Calculating the linearized equations of motion.
% 
%  Syntax:
%> calcEqMotLin('Property', value , ... )
% 
%  Description:
% This function derives the symbolical of the user-defined system. For this
% the nonlinear equations of motion have to exist. Should any state
% dependent parameters exist in the expressions of the equations of
% motion, then they will not be touched. In the files created by
% _writeMbsLin.m_ they are simply evaluated at the linearization set values.
% If the equations of motion are highly nonlinear and already rather long
% and complicated it may be a good choice to replace most of the constant
% parameters with their numerical values. This results in a partly
% symbolical formulation. For this the function symStruct2num.m may be used
% which allows to specify a list of parameters to be kept symbolically.
%
%  Preliminaries:
%> calcEqMotNonLin;
%
%  Input arguments (all optional, given pairwise):
% Formulation ............. Specify which part is to be done symbolically.
%         Possibilities are: 'Minimal' or 'newtonEuler'. For
%         _newtonEuler_ the premultiplication of the global Jacobian matrix
%         is done numerically instead of symbolically as in _Minimal_.
%         Recursive is not yet implemented {'newtonEuler'}
% NumericalSetValues ... Logical/Numerical: true/false
%         Set all set values (sys.dynamics.linear.reference) to numerical zeros {false}
% OutType .............. Type to use for the status updates, see
%           'n2StatusOutput' for more information {'CMD'}
% OutHandle ............ Handle to use for the status updates, see
%           'n2StatusOutput' for more information {1}
% Simplify ............. Controls the use of simplifications, extensive
%         description can be found in calcEqMotNonLin.m
% SymbolicSetValues .... Logical/Numerical: true/false
%         Set all set values (sys.dynamics.linear.reference) to their corresponding
%         paramters, e.g. for a generalized coordinate x to 'x_s', 'Dx_s'
%         and 'D2x_s' {false}
% CheckVarargin ........ An advanced feature to avoid errors if invalid
%         parameters are passed. This is only if you know exactly what you
%         are doing. {true}
%
%  Example:
%> calcEqMotLin('Formulation','Minimal');
%
%  See also:
% calcEqMotNonLin, writeMbsLin
%
% First appearance: 23.1.2007
% Major Update:     03.11.2010
%
% Neweul-M2
% Multibody systems based on symbolic Newton-Euler-Equations
% Copyright (c) ITM University of Stuttgart, www.itm.uni-stuttgart.de
