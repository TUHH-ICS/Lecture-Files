% plotResults

load sys

fig = figure;
set(fig,'Name',sprintf('Result - Crank angle'));
plot(sys.results.timeInt.x,sys.results.timeInt.y(1,:));
grid on
xlabel('Time [s]')
ylabel('Angle [rad]')

fig = figure;
set(fig,'Name',sprintf('Result - Slider position and speed'));
[AX,H1,H2] = plotyy(sys.results.timeInt.x,sys.results.timeInt.outControl(1,:),...
    sys.results.timeInt.x,sys.results.timeInt.outControl(2,:));
xlabel('Time [s]');
grid on
set(H1,'Color',[0 0 1]);
set(AX(1),'YColor',[0 0 1]);
set(get(AX(1),'YLabel'),'String','Slider position [m]');
set(H2,'Color',[1 0 0]);
set(AX(2),'YColor',[1 0 0]);
set(get(AX(2),'YLabel'),'String','Slider speed [m/s]');
LEGH = legend([H1;H2],'position','speed','location','SouthEast');
