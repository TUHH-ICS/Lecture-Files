% #########################################################################
% TUHH :: Institute for Control Systems :: Control Lab
% #########################################################################
% Experiment CSTD1: Identification and Control of a Torsional Plant
%
% Copyright Herbert Werner and Hamburg University of Technology, 2020
% #########################################################################
% This file is to be completed by the student.
% Submit this file at least one week prior to the scheduled date
% for the experiment
%
% !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
% !!!  The gaps in the code are denoted by TODO !!!
% !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
%
% HINT 1:
% if you want to find out more about a certain command, just type 
% 'help command' into the matlab window
% HINT 2:
% use section evaluations (Ctrl+Enter) to run the code within a single 
% section

%----------------------------
% v.1.2 - 30-10-2017
% by Antonio Mendez G
%----------------------------

%% 1 Filter the Signals
%
% Design a filter to filter measurement noise

Ts = 1e-3; % sampling time

[B,A] = butter(XXX, XXX); % TODO

% Filter the mesurements
Theta1_ff = XXX; % TODO
Theta2_ff = XXX; % TODO
Theta3_ff = XXX; % TODO
Plant_input_u_ff = XXX; % TODO

% Calculate angular velocity from input vector in deg/s
Theta1_dot = XXX; % TODO
Theta2_dot = XXX; % TODO
Theta3_dot = XXX; % TODO

% Calculate angular acceleration from input vector in deg/s/s
Theta1_ddot = XXX; % TODO
Theta2_ddot = XXX; % TODO
Theta3_ddot = XXX; % TODO

% Filter Calculated angular velocity:
Theta1_dot_ff = XXX; % TODO
Theta2_dot_ff = XXX; % TODO
Theta3_dot_ff = XXX; % TODO

% Filter Calculated angular acceleration:
Theta1_ddot_ff = XXX; % TODO
Theta2_ddot_ff = XXX; % TODO
Theta3_ddot_ff = XXX; % TODO

% Find the number of samples (ThetaX_ff/ThetaX_dot_ff/ThetaX_ddot_ff/)
Theta1_ff        = Theta1_ff(2:end-1);
Theta2_ff        = Theta2_ff(2:end-1);
Theta3_ff        = Theta3_ff(2:end-1);
Plant_input_u_ff = Plant_input_u_ff(2:end-1);

% Reduce number of samples to drop some at the end of all signals
% as the filtfilt-algorithm might introduce unwanted transients
% in its reverse filtering step
no_samples = length(Theta1_ff) - 200;

% Redefine the new signals
Theta1_ff = Theta1_ff(1:no_samples);
Theta2_ff = Theta2_ff(1:no_samples);
Theta3_ff = Theta3_ff(1:no_samples);

Theta1_dot_ff = Theta1_dot_ff(1:no_samples);
Theta2_dot_ff = Theta2_dot_ff(1:no_samples);
Theta3_dot_ff = Theta3_dot_ff(1:no_samples);

Theta1_ddot_ff = Theta1_ddot_ff(1:no_samples);
Theta2_ddot_ff = Theta2_ddot_ff(1:no_samples);
Theta3_ddot_ff = Theta3_ddot_ff(1:no_samples);

Plant_input_u_ff = Plant_input_u_ff(1:no_samples);

% -------------------------------------------------------------- 
%% 2 Build Measurement Matrix M
% 
% Assembling the Matrix M

M1 = [ Theta1_ddot_ff,      zeros(no_samples,1), zeros(no_samples,1) ;
       zeros(no_samples,1), Theta2_ddot_ff,      zeros(no_samples,1) ;
       zeros(no_samples,1), zeros(no_samples,1), Theta3_ddot_ff      ];

M2 = [ Theta1_dot_ff,       zeros(no_samples,1), zeros(no_samples,1) ;
       zeros(no_samples,1), Theta2_dot_ff,       zeros(no_samples,1) ;
       zeros(no_samples,1), zeros(no_samples,1), Theta3_dot_ff       ];

M3 = [ Theta1_ff - Theta2_ff, zeros(no_samples,1)   ;
       Theta2_ff - Theta1_ff, Theta2_ff - Theta3_ff ;
       zeros(no_samples,1),   Theta3_ff - Theta2_ff ];

M = [M1 M2 M3]*pi/180; % convert to radians

% -------------------------------------------------------------- 
%% 3 Build Matrix Torque:
%
% The torque signal is defined

Torque = zeros(3*no_samples,1);
Torque(1:no_samples,1) = Plant_input_u_ff;