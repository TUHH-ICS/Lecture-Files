% #########################################################################
% TUHH :: Institute for Control Systems :: Control Lab
% #########################################################################
% Experiment ATC1: Gain-Scheduled Control of a Gyroscope
%
% Copyright Herbert Werner and Hamburg University of Technology, 2014
% #########################################################################
% This File is used to run the nonlinear simulation and plot the results
% This version is to be published using 
%   publish('atc1_simulation.m','pdf') 
% and submitted as a pdf-file at least one week prior to the scheduled date
% for the experiment to prove that your design works

%----------------------------
% v.0.5 - 08-12-2014
% by Julian Theis 
%----------------------------
% Last modified on 05-06-2015
% by Sophia Voss
% ---------------------------
%%
% set initial conditions
q1dot_0 = 45;
q2_0 = 0;
q3_0 = 0;

controller_switch = 0;  % output feedback
% controller_switch = 1;  % state feedback


%% run simulation

addpath('./simulink')

open('atc1_GyroSimulation')
sim('atc1_GyroSimulation')


%% Plots Simulation Results

% downsampling
ds = 50;

% q3
figure(101);clf
subplot(211)
plot(downsample(simdata.time,ds),downsample(simdata.signals(1).values(:,2),ds),'k:')
hold on;
plot(downsample(simdata.time,ds),downsample(simdata.signals(1).values(:,1),ds),'b-')
xlim([20 70])
ylim([-50 50])
ylabel('q3')
title('Tracking')
% q4
subplot(212)
plot(downsample(simdata.time,ds),downsample(simdata.signals(2).values(:,2),ds),'k:')
hold on;
plot(downsample(simdata.time,ds),downsample(simdata.signals(2).values(:,1),ds),'b-')
xlim([20 70])
ylim([-100 100])
xlabel('time')
ylabel('q4')


% controls
figure(102)
subplot(211)
plot(downsample(simdata.time,ds),downsample(simdata.signals(5).values(:,1),ds),'b-')
xlim([20 70])
ylim([-0.666 0.666])
ylabel('T1 (Nm)')
title('Control Inputs')
subplot(212)
plot(downsample(simdata.time,ds),downsample(simdata.signals(5).values(:,2),ds),'b-')
xlim([20 70])
ylim([-2.44 2.44])
xlabel('time')
ylabel('T2 (Nm)')


% angular velocities
figure(103);clf
subplot(311)
plot(downsample(simdata.time,ds),downsample(simdata.signals(3).values(:,1),ds),'b-')
xlim([20 70])
ylim([-2 2])
ylabel('q2dot')
title('Angular Velocities')
subplot(312)
plot(downsample(simdata.time,ds),downsample(simdata.signals(3).values(:,2),ds),'b-')
xlim([20 70])
ylim([-2 2])
ylabel('q3dot')
subplot(313)
plot(downsample(simdata.time,ds),downsample(simdata.signals(3).values(:,3),ds),'b-')
xlim([20 70])
ylim([-2 2])
xlabel('time')
ylabel('q4dot')

% operating point
figure(104);clf
subplot(311)
plot(downsample(simdata.time,ds),repmat(q1dot_0,1,numel(downsample(simdata.time,ds))),'k:')
hold on;
plot(downsample(simdata.time,ds),downsample(simdata.signals(4).values(:,1),ds),'b-')
xlim([20 70])
ylim([30 60])
ylabel('q1dot')
title('Scheduling Signals')
subplot(312)
plot(downsample(simdata.time,ds),repmat(q2_0,1,numel(downsample(simdata.time,ds))),'k:')
hold on;
plot(downsample(simdata.time,ds),downsample(simdata.signals(4).values(:,2),ds),'b-')
xlim([20 70])
ylim([-25 25])
ylabel('q2')
subplot(313)
plot(downsample(simdata.time,ds),repmat(q3_0,1,numel(downsample(simdata.time,ds))),'k:')
hold on;
plot(downsample(simdata.time,ds),downsample(simdata.signals(1).values(:,1),ds),'b-')
xlabel('time')
ylabel('q3')
xlim([20 70])
ylim([-55 55])

ShowAllFig(101:104)