% #########################################################################
% TUHH :: Institute for Control Systems :: Control Lab
% #########################################################################
% Experiment ATC1: Gain-Scheduled Control of a Gyroscope
%
% Copyright Herbert Werner and Hamburg University of Technology, 2014
% #########################################################################
% This file is to be completed by the student.
% The completed version is to be published using 
%   publish('atc1_design.m','pdf') 
% and submitted as a pdf-file at least one week prior to the scheduled date
% for the experiment
%
% !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
% !!!  The gaps in the code are denoted by XXX !!!
% !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
%
% HINT 1:
% if you want to find out more about a certain command, just type 
% 'help command' into the matlab window
% HINT 2:
% use section evaluations (Ctrl+Enter) to run the code within a single 
% section

%----------------------------
% v.0.52 - 19-12-2014
% by Julian Theis 
%----------------------------
% Last modified on 05-06-2015
% by Sophia Voss
% ---------------------------


%%

clearvars; close all
addpath(genpath('.\Synthesis Tools P'))


%% 1.  PLANT AND SCALING

% We define the frequency range of interest for the design to be 0.01 rad/s
% to 1000 rad/s, mainly for convenience in plotting. Further some options
% for bodeplots are invoked.
w = {1e-1,1e3};
b = bodeoptions;
b.xlim = [1e-1 1e3];
b.ylim = [-1e2 1e2];
b.Grid = 'on';


%% Plant as grid-based LPV object 
 
% Let's first define the grid we want to use. It's spanned by the three
% parameters 'q1dot', 'q2' and 'q3', all of which are (of course) rate
% bounded. 
q1dot   = pgrid(XXX);
q2      = pgrid(XXX);
q3      = pgrid(XXX);
dom     = rgrid(XXX);

% Now we evaluate the Jacobian of the nonlinear system at all these 
% gridpoints, which gives an array of LTI state space models
G_      = linearize_gyro(q1dot.griddata,q2.griddata,q3.griddata);

% This array is now combined with the underlying grid to form a
% parameter-dependent state space model
Gp      = pss(G_,dom);

% This pss object can be treated almost identical to an ss object, and we
% can perform tasks such as, e.g., bode or sigmaplots
figure(1);clf
bodemag(Gp,b,w)
figure(2);clf
sigma(Gp,w)

% Furthermore we can manipulate the grid, with commands like 
% lpvsplit, lpvinterp, ...


%% Initial Scaling

% Let's define the largest allowed input signals (in Nm)
umax = [XXX];
% and the largest expected change in reference (in rad)
rmax = [XXX];
% No both input and output are scaled with this values
Du = diag(umax);
Dr = diag(rmax);
G = Dr\Gp*Du;
% G is now our synthesis model used to design a controller.
% When we apply this controller to the real plant, we need to remember to
% reverse the scalings, ie. 
% u_real = Du*u and y = Dr^-1*y_real and r = Dr^-1*r_real

% For comparison, we will also create a single LTI controller at the
% gridpoint (45,0,0)
GLTI = lpvsplit(G,'q1dot',45,'q2',0,'q3',0);
% Note that this design point does not cover any crosscouplings.


%% AUGMENTED STATE FEEDBACK DESIGN 
% S/KS closed-loop shaping filter design

% While we could use the parameterization from the ORC lecture 
% notes and build the filters manually as tf objects, a build-in command
% that we can use is makeweight(dcgain, bandwidth, feedthroughgain).
% For W1, the dcgain determines our error constant, the bandwidth the speed
% of response and the feedthroughgain limits the peak of S
W11 = XXX;
W12 = XXX;
WS  = mdiag(W11,W12);

% For W2, the dcgain determines available control effort, the bandwidth 
% corresponds to the actuator rates and the feedthroughgain limits 
% authority at high frequencies
W21 = XXX;
W22 = XXX;
WK  = mdiag(W21,W22);

figure(3)
subplot(211)
sigma(WS^-1)
subplot(212)
sigma(WK^-1)


%% Generalized Plant formulation

% For our synthesis tools to work, we need to first assemble a generalized 
% plant that includes our performance inputs/outputs.

% r-----------------+
%                   |
%          ------   v   ------
% u--+---->| G  |-->o-->| WS |--->e1
%    |     ------  -    ------
%    |                  ------
%    ------------------>| WK |--->e2
%                       ------
%
% A convinient way to do this is to use the sysic command
systemnames = 'XXX';
inputvar = '[XXX]';
outputvar = '[XXX]';
input_to_G = '[XXX]';
input_to_WS = '[XXX]';
input_to_WK = '[XXX]';
cleanupsysic = 'yes';
Psf = sysic;
      
% Verify that these leads to a state space representation
% |dx|   |A    B1   B2    |   |x|
% |e1| = |C11  DW1   0    | * |d|
% |e2|   |C12  0    DW2   |   |u|
%
Psf.Data(:,:,1)


%% Synthesis LPV
%
% You know from class that a parameter-dependent Lyapunov matrix is less
% conservative since it takes rate variations into account. In order to
% arrive at a tractable formulation, we need to choose basis functions.
% There are no useful guidelines on how to do this other than trial and
% error. (Have a look at linearize_gyro to get a guess on the scheduling 
% parameters). However, affine seems to be OK in most cases, so let's start 
% with that. (We can try other basis functions later on)

% We define the basis functions in terms of the pgrid variables and need to
% provide their partial derivites with respect to the scheduling variables
Pbasis = [];
Pbasis(1) = XXX;


% We can now run the synthesis code, which takes our generalized plant, the
% number of control signals and the basis function object and returns a
% state feedback gain F as well as the performance index gamma.
% The synthesis may take some time, since it's solving that large system of
% LMIs that you learned about in class. 
[F,gam,info] = lpvsfsynth(Psf,2,Pbasis);
gam
% The first thing that we should always check is whether everything worked
% fine. Even if we do not get an error message, could be mistakes made by
% us setting up the problem. So let's verify that the state feedback gain
% actually achieves stability and performance as it should.

% Let's first add the state outputs to our generalized plant and then form
% the closed-loop system by closing the loop with the gain F
P_aug = pss(Psf.a,Psf.b,[Psf.c;eye(9)], [Psf.d; zeros(9,4)]);
CL = lft(P_aug,F);

% Let's now verify that the closed loop is stable
LPVstab = double(lpvmin(isstable(CL)))
% and that the Hinfnorm at every gridpoint is less than our induced L2 norm
normOK = double(lpvmax(norm(CL,'inf')))<gam

% We first construct our unweighted closed loop, i.e., we reverse the 
% weighting filters at the outputs.
uCL = mdiag(WS,WK)\CL;
S = uCL(1:2,:);
KS = uCL(3:4,:);

% We can then plot these closed-loop shapes against the corresponding
% (scaled) weighting filters
figure(3);clf
splot = subplot(2,1,1); 
sigma(S,'b',WS\gam,{.001,1000});title('S')
ksplot = subplot(2,1,2); 
sigma(KS,'b',WK\gam,{.001,1000});title('KS')


%% Augmented state feedback - LPV

% Since we are using dynamic weights in our generalized plant, the state
% feedback gain that we just obtained needs access to the states of these
% filters as well. This means, that the filters are actually a part of the
% controller (with an interpretation as lag-compensator W1 and roll-off W2)
% and consequently we end up with a dynamic controller.

% It looks like this:
%                       x -----+
%                              |
%                  ------      +--->|\
%     r-y -------->| W1 |---------->|F>---+------------>u
%                  ------      +--->|/    |   ------
%                              |          +-->| W2 |
%                              |              ---+--
%                              +-----------------+
%
% In order to assemble this controller, we can use sysic again.

% First we need to modifiy the weighting filters such that we get the
% states instead of the outputs
    WSs = ss(WS.a,WS.b,eye(2),0);
    WKs = ss(WK.a,WK.b,eye(2),0);
% Second, we need to convert the gain into a pss object.
    Fs = pss(F);
% then we can connect all the components and get our controller    
    systemnames = 'XXX';
    inputvar = '[XXX]';
    outputvar = '[XXX]';
    input_to_Fs = '[XXX]';
    input_to_WSs = '[XXX]';
    input_to_WKs = '[XXX]';
    cleanupsysic = 'yes';
    Ksf = sysic;
% To keep track of the inputs, let's make a note that the first 2 channels 
% must be connected to the error signal r-y and the last 5 channels to the 
% state x
    Ksf.InputGroup.e = [1:2];
    Ksf.InputGroup.x = [3:7];
    
% Let's finally take a look at the controller that we just synthesized.    
    figure(4)    
    bodemag(Ksf) 
% We see, that we have (near) integral action in the first 2 channels (the
% error) and that we have a decrease in gain / roll-off in all of the
% channels. We further see, that the gain changes quite a bit over
% the different grid points.

fastestpole = max(double(lpvmax(abs(eig(Ksf.a)))))


%% OUTPUT FEEDBACK SYNTHESIS
%
% We will make use of the angular velocities w2, w3 and w4 for feedback, which in
% practice are obtained through differentiation filters. We ignore these 
% filters and the phase loss that they introduce in this design and
% hope that our controller is robust enough to still work satisfactory.
% While we could get a controller without this additional measurements,
% experiments have shown that it is advantageous to include them in the
% design 

% We add the 3rd, 4th and 5th state (w2, w3 and w4) to the outputs.
% The outputs are then q_3 \\ q_4 \\ w2 \\ w3 \\ w4.
Gv = pss(G.a,G.b,[G.c;zeros(3,2) eye(3)],[G.d;zeros(3,2)]);
Gv.StateName  = G.StateName;
Gv.OutputName = G.OutputName;
Gv.InputName  = G.InputName;

% W13, W14 and W14 are shaping filters for velocities. Remember that we are not
% tracking the velocities, but only q3 and q4.
W11 = makeweight(XXX);
W12 = makeweight(XXX);
W13 = XXX;  
W14 = XXX;
W15 = XXX;
W1  = mdiag(W11,W12,W13,W14,W15);

W21 = makeweight(XXX);
W22 = makeweight(XXX);
W2  = mdiag(W21,W22);

Wdi = XXX;
Wdo = XXX;


%% Generalized Plant formulation

% For our synthesis tools to work, we need to first assemble a generalized 
% plant that includes our performance inputs/outputs. We use a four block
% problem that looks like this:
%
%      di          d0     r
%      |           |      |
%      |           |      | 
%    -----       -----    | 
%   | Wdi |     | Wdo |   |
%    -----       -----    |
%      |           |      +---------------> (v2) 
%      |           |      |
%      v   ------  v      v   ------
% u--+-o-->| Gv |->o-+----o-->| W1 |------------------> (e1)
%    |     ------ -  |        ------
%    |               |
%    |               +--------------------> (v1) 
%    |
%    |                      ------
%    +--------------------->| W2 |------------------->(e2)
%                           ------
%
% A convinient way to do this is to use the sysic command

systemnames = 'XXX';
inputvar = '[XXX]';
outputvar = '[XXX]';
input_to_Gv = '[XXX]';
input_to_Wdi = '[XXX]';
input_to_Wdo = '[XXX]';
input_to_W1 = '[XXX]';
input_to_W2 = '[XXX]';
cleanupsysic = 'yes';
P = sysic;
      
% Verify that these leads to a state space representation
% |dx|   |A    B1    B2  |   |x|
% |e | = |C1   D11   D12 | * |d|
% |v |   |C2   D21   D22 |   |u|
P.Data(:,:,1)


%% Output feedback tuning
% Inevitably, we need to tune the controller to achieve adequate
% performance. While for LTI control, the synthesis itself does not take
% more than a second or two, an LPV synthesis can easily take up 20
% minutes. It is therefore not a good idea to tune the controller using the
% complete LPV synthesis. Two possible appraoches are
% 1) Tuning LPV controllers that use constant Lyapunov matrices and once a
% promising design has been found trying out a parameter-dependent
% synthesis.
% 2) Tuning LTI controllers on the individual grid points with common
% weights and once a promising design has been found switch to LPV
% synthesis
%
% A possible implementation for the second approach could look like this:
% tic
% TO = ss(zeros([5,5,size(P.Domain)]));
% for kk = 1:prod(size(P.Domain))
%     [ll, mm, nn] = ind2sub(size(P.Domain),kk);
%     PGrid = lpvsplit(P,'q1dot',ll,'q2',mm,'q3',nn,'indices');
%     PGrid = PGrid.Data;
%     GvGrid = lpvsplit(Gv,'q1dot',ll,'q2',mm,'q3',nn,'indices');
%     GvGrid = GvGrid.Data;
%  
%     [~,~,gam] = hinfsyn(PGrid,5,2);
%     [KGrid,~,gam] = hinfsyn(PGrid,5,2,'GMIN',1.2*gam);
%     
%     loops=loopsens(GvGrid,KGrid);
%     TO(:,:,ll,mm,nn) = loops.To;
% end
% test = pss(TO,P.Domain);
% toc 
% figure(5);step(test(1:2,1:2),10)

% The main conceptual difference is the following: The first approach gives
% as an upper bound during tuning, since the use of a common constant
% Lyapunov matrix is conservative. Our responses will usually look better
% on the actual parameter-dependent synthesis. The second approach on the
% other hand gives a lower bound. We cannot exceed the performance of an
% LTI controller at a single grid point, even if we used infinitely many
% basis functions for the Lyapunov matrices. Our results will thus look
% worse with the LPV controller.


%% Synthesis LPV
Xb = [];
Xb(1) = basis(XXX);

Yb = Xb;

% We can now run the synthesis code, which takes our generalized plant, the
% number of measurement and control signals and the basis function object and returns a
% dynamic controller K as well as the performance index gamma.
% The synthesis may take some time, since it's solving that large system of
% LMIs that you learned about in class. 
% You can try Sedumi instead of LMI lab as a solver by passing
% lpvsynOptions('solver','sedumi') as a sixth argument to lpvsyn. Note that
% you have to install Sedumi beforehand (just google it). It might be a little faster but
% usually is very prone to numerical problems and we don't really recommend
% to use it.
% Also it is not a necessity for Yb to be the same as Xb. 

tic
[K,gam,info] = lpvsyn(P,5+2,2,Xb,Yb);
toc
gam

CL = lft(P,K);

% Let's now verify that the closed loop is stable
LPVstab = double(lpvmin(isstable(CL)))
% and that the Hinfnorm at every gridpoint is less than our induced L2 norm
normOK = double(lpvmax(norm(CL,'inf')))<gam


%% Controller Post-Processing
% With parameter-dependent Lyapunov matrices, the controller also depends
% on scheduling rates. Usually this dependence can simply be ignored,
% although again, any theoretical guarantees are lost in doing so. 
% For the current case, we would require w1dotdot, w2dot and w3dot.
% It's your decision whether you want to implement the rate dependence with
% differentiation filters of ignore it. If we want to neglect it, we can
% simply interpolate the controller for zero rates:
K_rate = K;
K = lpvelimiv(lpvinterp(K_rate,'q1dotDot',0,'q2Dot',0,'q3Dot',0));

K.InputGroup.y = [1:5];
K.InputGroup.r = [6:7];
Ky = K(:,'y');
Kr = K(:,'r');

figure(6)
bodemag(K,b,w) 
fastestpole = max(double(lpvmax(abs(eig(K.a)))))


%% Linear Analysis: Frequency Response at Grid Points

%for state feedback
Gaug = pss(G.a,G.b,[G.c;eye(5)],0);

%this just builds the four transfer functions [SG S ; Ti KS]
systemnames = 'Gaug Ksf';
inputvar = '[di{2}; r{2}]';
outputvar = '[r-Gaug(1:2); Ksf]';
input_to_Gaug = '[di+Ksf]';
input_to_Ksf = '[r-Gaug(1:2);Gaug(3:7)]';
cleanupsysic = 'yes';
CL = sysic;

figure(7);clf 
subplot(2,2,1)
sigma(CL(1:2,3:4),pss(W1^-1),w)
title('S')
subplot(2,2,2)
sigma(CL(1:2,1:2),pss(W1^-1),w)
title('SG')
subplot(2,2,3)
sigma(CL(3:4,3:4),pss(W2^-1),w)
title('KS')
subplot(2,2,4)
sigma(CL(3:4,1:2),pss(W2^-2),w)
title('Ti')

% This looks nice, but we are really assuming PERFECT measurements of all
% states in the inner loop.

% For Output feedback
loops = loopsens(Gv,Ky);

figure(8);clf 
subplot(2,3,1)
sigma(lpvgetfield(loops,'So'),pss(W1^-1),w)
title('S')
subplot(2,3,2)
sigma(lpvgetfield(loops,'PSi'),pss(W1^-1),w)
title('SG')
subplot(2,3,4)
sigma(lpvgetfield(loops,'CSo'),pss(W2^-1),w)
title('KS')
subplot(2,3,5)
sigma(lpvgetfield(loops,'Ti'),pss(W2^-2),w)
title('Ti')

forwardS = lpvgetfield(loops,'PSi')*Kr;
subplot(2,3,3)
sigma(eye(2)-forwardS(1:2,:),pss(W1^-1),w)
title('I-SGKr')
subplot(2,3,6)
sigma(lpvgetfield(loops,'Si')*Kr,pss(W2^-1),w)
title('SiKr')

ShowAllFig([7 8])


%% Linear Analysis: Step Response at Grid Points

%Reference Following
figure(9);clf; 
SG = lpvgetfield(loops,'PSi');
step(SG(1:2,:)*K(:,6:7),10)             %this is SGKr

%Disturbance rejection
figure(10);clf; 
step(SG(1:2,:),10)                      %this is SG

%Reference Following
figure(11);clf; 
step(eye(2)-CL(1:2,3:4),10)             %this is I-S = T

%Disturbance rejection
figure(12);clf; 
step(-CL(1:2,1:2),10)                   %this is SG

ShowAllFig([9 10 ; 11 12])


%% Linear Analysis: Loop Margins at Grid Points

[~,~,~,~,~,~,MMIO]= loopmargin(Gv,Ky);

GM = lpvgetfield(MMIO,'GainMargin');
PM = lpvgetfield(MMIO,'PhaseMargin');
minGM = db(lpvmin(GM(2)))
minPM = min(lpvmin(PM(2)))


%% If you feel you need to add stuff, feel free to do so!


