% SOE_MKU_TRAPEZ  generates trapezoidal signal
%
%  u ^
% um |   ___________
%    |  /            \
%    | /              \
%    |/                \
%    +------------------------------+--------> t  
%    0   t1        t2   t3         t4
%
% [t,u] = soe_mku_trapez(t1,t2,t3,t4,um,dt)
% 
% The input parameters are:
% t1 - the time at which the top starts
% t2 - the time at which the top ends
% t3 - the time at which output 0 is achieved
% t4 - the end time of the vecotr
% um - the value at top
% dt - discretization time (should be sufficiently small, so that the sides
%      of the trapez seem continuous)
%
% The function returns:
% t - time vector of the trapezoidal signal
% u - the trapezoidal signal
%
% TUHH :: Institut f�r Regelungstechnik :: Regelungstechnik 1
% Last update: 27.11.2006


function [t,u] = soe_mku_trapez(t1,t2,t3,t4,um,dt)

% Sorry, no further help available
t = (0:dt:t4)';

u1 = um/t1 * t(1:t1/dt);
u2 = um*ones(round((t2-t1)/dt),1);
u3 = -um/(t3-t2) * t(1:round((t3-t2)/dt)+1) + um;

u = [u1; u2; u3];
u4 = zeros(length(t)-length(u),1);
u = [u; u4];
