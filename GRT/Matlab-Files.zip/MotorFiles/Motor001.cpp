/*
 * sfuntmpl_basic.c: Basic 'C' template for a level 2 S-function.
 *
 * Copyright 1990-2013 The MathWorks, Inc.
 */

//#include "stdafx.h"
#include <iostream>
#include <windows.h>
#include <stdio.h>

#define numberOfBytesToRead 3

class  Myusb {
    // Declare variables and structures
private:
    HANDLE hSerial;
    char word;
    unsigned char lastReadString[numberOfBytesToRead];
    int counter;
    COMSTAT status;
    DWORD errors;
public:
    Myusb(int portNumber, int baudrate) {
        char portname[20]={0};
        DCB dcbSerialParams = { 0 };
        COMMTIMEOUTS timeouts = { 0 };
        // Open the highest available serial port number       for larger than COM9 you should write in this format for com22: \\\\.\\COM22
        //fprintf(stderr, "Opening serial port...");
        
        counter = 0;
        if ( portNumber < 10)
            sprintf(portname,"COM%d",portNumber);
        else
            sprintf(portname,"\\\\.\\COM%d",portNumber);// portNumber<10  &&
       
        
        hSerial = CreateFileA(
		portname, GENERIC_READ | GENERIC_WRITE, 0, NULL,
		OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
        
//         if (hSerial == INVALID_HANDLE_VALUE)
//          {
//              static char msg[35];
//              sprintf(msg,"No Device is conected to port %d",portNumber);
//              ssSetErrorStatus(S,msg);
//              return 1;
//          }
        // Set device parameters (115200 baud, 1 start bit,
        // 1 stop bit, no parity)
        dcbSerialParams.DCBlength = sizeof(dcbSerialParams);
        GetCommState(hSerial, &dcbSerialParams);
//         if (GetCommState(hSerial, &dcbSerialParams) == 0)
//         {
//             fprintf(stderr, "Error getting device state\n");
//             CloseHandle(hSerial);
//             return 1;
//         }
        
        

        dcbSerialParams.BaudRate = baudrate;//https://msdn.microsoft.com/en-us/library/windows/desktop/aa363214(v=vs.85).aspx
        dcbSerialParams.ByteSize = 8;
        dcbSerialParams.StopBits = ONESTOPBIT;
        dcbSerialParams.Parity = NOPARITY;
        dcbSerialParams.fDtrControl = DTR_CONTROL_DISABLE; // disable DTR to avoid resetv
        SetCommState(hSerial, &dcbSerialParams);
//         if (SetCommState(hSerial, &dcbSerialParams) == 0)
//         {
//             fprintf(stderr, "Error setting device parameters\n");
//             CloseHandle(hSerial);
//             return 1;
//         }

        // Set COM port timeout settings
        timeouts.ReadIntervalTimeout = 50;
        timeouts.ReadTotalTimeoutConstant = 50;
        timeouts.ReadTotalTimeoutMultiplier = 10;
        timeouts.WriteTotalTimeoutConstant = 50;
        timeouts.WriteTotalTimeoutMultiplier = 10;
        SetCommTimeouts(hSerial, &timeouts);
//         if (SetCommTimeouts(hSerial, &timeouts) == 0)
//         {
//             fprintf(stderr, "Error setting timeouts\n");
//             CloseHandle(hSerial);
//             return 1;
//         }
        
        SetCommMask(hSerial, EV_RING);
        //if (!SetCommMask(hSerial, EV_RING)) // https://msdn.microsoft.com/en-us/library/ff802693.aspx#serial_topic4
        // Error setting communications mask
        //return FALSE;
        
        
        // clean the input buffer https://msdn.microsoft.com/en-us/library/aa363428.aspx
        //DWORD bytes_read, num_bytes_read = 0;
        //ReadFile(hSerial, &bytes_read, 100, &num_bytes_read, NULL);
        
        PurgeComm(hSerial, PURGE_RXCLEAR | PURGE_TXCLEAR);
    }
    void send(char thisword) {
        char Thisword[1];
        Thisword[0]=thisword;
        DWORD bytes_written, total_bytes_written = 0;
        WriteFile(hSerial, Thisword, 1, &bytes_written, NULL);
//         if (!WriteFile(hSerial, Thisword, 1, &bytes_written, NULL);)
//         {
//             fprintf(stderr, "Error\n");
//             CloseHandle(hSerial);
//             return 1;
//         } 
    }
    unsigned char * read(void) {
        DWORD num_bytes_read = 0;// bytes_read,
        //DWORD dwCommEvent;
        //char something[20];
        ReadFile(hSerial, lastReadString, 3 , &num_bytes_read, NULL);
        //if (WaitCommEvent(hSerial, &dwCommEvent, NULL)) {
        
        //Use the ClearCommError function to get status info on the Serial port
        //ClearCommError(hSerial, &errors, &status);
        //if(status.cbInQue<=numberOfBytesToRead){
        //    ReadFile(hSerial, lastReadString, numberOfBytesToRead , &num_bytes_read, NULL);
        //    return lastReadString;
        //} else {
        //    char *wasteData;
        //    wasteData = (char *)malloc(sizeof(char)*status.cbInQue - numberOfBytesToRead);
        //    ReadFile(hSerial, wasteData, status.cbInQue - numberOfBytesToRead , &num_bytes_read, NULL);
        //    ReadFile(hSerial, lastReadString, numberOfBytesToRead , &num_bytes_read, NULL);
        //    return lastReadString;
        //}
            //if (ReadFile(hSerial, lastReadString, numberOfBytesToRead , &num_bytes_read, NULL)){// A byte has been read; process it.
                //sprintf(&lastReadWord, "u", &bytes_read); // %d
                //lastReadString = (char)(bytes_read);
                
            //}
            //else {// An error occurred in the ReadFile call.
            //    for (int i = 0 ; i<numberOfBytesToRead; i++) lastReadString[0]=0;
            //    
            //    return lastReadString;
            //}
        //}
        //else{// Error in WaitCommEvent.
        //    for (int i = 0 ; i<numberOfBytesToRead; i++) lastReadString[0]=255;
            return lastReadString;
        //}
    }
    void terminate()
    {
        CloseHandle(hSerial);
    }
    void clearInputBuffer(){
        PurgeComm(hSerial, PURGE_RXCLEAR | PURGE_TXCLEAR);
    }
    void setCounter(int v){
        counter = v;
    }
    
    void increment(){
        counter = counter + 1;
    }
    
    int getCounter(){
        return counter;
    }
    char getX() const
    {
        return word;
    }
    void setX(char v)
    {
        word = v;
    }
    HANDLE gethSerial(){
        return hSerial;
    }
};

/*
 * You must specify the S_FUNCTION_NAME as the name of your S-function
 * (i.e. replace sfuntmpl_basic with the name of your S-function).
 */

#define S_FUNCTION_NAME  Motor001
#define S_FUNCTION_LEVEL 2

#define Speed_Control 1
#define Position_Control 0

/*
 * Need to include simstruc.h for the definition of the SimStruct and
 * its associated macro definitions.
 */
#include "simstruc.h"



/* Error handling
 * --------------
 *
 * You should use the following technique to report errors encountered within
 * an S-function:
 *
 *       ssSetErrorStatus(S,"Error encountered due to ...");
 *       return;
 *
 * Note that the 2nd argument to ssSetErrorStatus must be persistent memory.
 * It cannot be a local variable. For example the following will cause
 * unpredictable errors:
 *
 *      mdlOutputs()
 *      {
 *         char msg[256];         {ILLEGAL: to fix use "static char msg[256];"}
 *         sprintf(msg,"Error due to %s", string);
 *         ssSetErrorStatus(S,msg);
 *         return;
 *      }
 *
 */

/*====================*
 * S-function methods *
 *====================*/

/* Function: mdlInitializeSizes ===============================================
 * Abstract:
 *    The sizes information is used by Simulink to determine the S-function
 *    block's characteristics (number of inputs, outputs, states, etc.).
 */
static void mdlInitializeSizes(SimStruct *S)
{
    ssSetNumSFcnParams(S, 4);  /* Number of expected parameters */  // for the sampling time of sending, port number and baudrate
    if (ssGetNumSFcnParams(S) != ssGetSFcnParamsCount(S)) {
        /* Return if number of expected != number of actual parameters */
        return;
    }

    ssSetNumContStates(S, 0);
    ssSetNumDiscStates(S, 0);

    if (!ssSetNumInputPorts(S, 2)) return;
    ssSetInputPortWidth(S, 0, 1);
    ssSetInputPortWidth(S, 1, 1);
    ssSetInputPortRequiredContiguous(S, 0, true); /*direct input signal access*/
    ssSetInputPortRequiredContiguous(S, 1, true);
    /*
     * Set direct feedthrough flag (1=yes, 0=no).
     * A port has direct feedthrough if the input is used in either
     * the mdlOutputs or mdlGetTimeOfNextVarHit functions.
     */
    ssSetInputPortDirectFeedThrough(S, 0, 1);
    ssSetInputPortDirectFeedThrough(S, 1, 1);
    ssSetInputPortDataType(S,0,3); // set the input data type to 3=unit8, 0=double, http://de.mathworks.com/help/simulink/sfg/sssetinputportdatatype.html
    ssSetInputPortDataType(S,1,3);

    if (!ssSetNumOutputPorts(S, 3)) return;
    ssSetOutputPortWidth(S, 0, 1);
    ssSetOutputPortDataType(S,0,0);
    
    ssSetOutputPortWidth(S, 1, 1);
    ssSetOutputPortDataType(S,1,0);
    
    ssSetOutputPortWidth(S, 2, 1);
    ssSetOutputPortDataType(S,2,3);

    ssSetNumSampleTimes(S, 1);
    ssSetNumRWork(S, 0);
    ssSetNumIWork(S, 2); // to save  operation_mode and first step
    ssSetNumPWork(S, 1); // reserve element in the pointers vector to store a C++ object
    ssSetNumModes(S, 0);
    ssSetNumNonsampledZCs(S, 0);

    /* Specify the sim state compliance to be same as a built-in block */
    ssSetSimStateCompliance(S, USE_DEFAULT_SIM_STATE);

    ssSetOptions(S, 0);
}



/* Function: mdlInitializeSampleTimes =========================================
 * Abstract:
 *    This function is used to specify the sample time(s) for your
 *    S-function. You must register the same number of sample times as
 *    specified in ssSetNumSampleTimes.
 */
static void mdlInitializeSampleTimes(SimStruct *S)
{
    ssSetSampleTime(S, 0, mxGetScalar(ssGetSFcnParam(S, 0)));
    ssSetOffsetTime(S, 0, 0.0);
    ssSetModelReferenceSampleTimeDefaultInheritance(S);

}



#define MDL_INITIALIZE_CONDITIONS   /* Change to #undef to remove function */
#if defined(MDL_INITIALIZE_CONDITIONS)
  /* Function: mdlInitializeConditions ========================================
   * Abstract:
   *    In this function, you should initialize the continuous and discrete
   *    states for your S-function block.  The initial states are placed
   *    in the state vector, ssGetContStates(S) or ssGetRealDiscStates(S).
   *    You can also perform any other initialization activities that your
   *    S-function may require. Note, this routine will be called at the
   *    start of simulation and if it is present in an enabled subsystem
   *    configured to reset states, it will be call when the enabled subsystem
   *    restarts execution to reset the states.
   */
  static void mdlInitializeConditions(SimStruct *S)
  {
  }
#endif /* MDL_INITIALIZE_CONDITIONS */



#define MDL_START  /* Change to #undef to remove function */
#if defined(MDL_START) 
  /* Function: mdlStart =======================================================
   * Abstract:
   *    This function is called once at start of model execution. If you
   *    have states that should be initialized once, this is the place
   *    to do it.
   */
  static void mdlStart(SimStruct *S)
  {
      ssGetPWork(S)[0] = (void *) new Myusb((int)mxGetScalar(ssGetSFcnParam(S, 1)),(int)mxGetScalar(ssGetSFcnParam(S, 2))); // store new C++ object in the pointers vector
      Myusb *c = (Myusb *) ssGetPWork(S)[0];
      ssGetIWork(S)[1] = 0;
      
      if (c->gethSerial() == INVALID_HANDLE_VALUE)
        {
            static char msg[500];
            sprintf(msg,"No Device is conected to port %d. you might enter the port number of the arduino wrong. Go to PC's device manager to find Arduino's port number. Double click on USB block in Simulink file and change the port number.",(int)mxGetScalar(ssGetSFcnParam(S, 1)));
            ssSetErrorStatus(S,msg);
        }
      
      char_T buff[20];
      mxGetString(ssGetSFcnParam(S, 3),buff,20);
      if ( strcmp(buff,"Velocity")==0 ){
            ssGetIWork(S)[0] = Speed_Control;
            c->send(0x83); //0b1000 0011
            
      } else if ( strcmp(buff,"Angle")==0  ){
            ssGetIWork(S)[0] = Position_Control;
            c->send(0x81); //0b1000 0001
      }
      //c->send(0x00);
      //c->send(0x80);
  }
#endif /*  MDL_START */



/* Function: mdlOutputs =======================================================
 * Abstract:
 *    In this function, you compute the outputs of your S-function
 *    block.
 */
static void mdlOutputs(SimStruct *S, int_T tid)
{
    Myusb      *c = (Myusb *) ssGetPWork(S)[0];
    //unsigned char       *u1 = (unsigned char*) ssGetInputPortSignal(S,0);
    //unsigned char       *u2 = (unsigned char*) ssGetInputPortSignal(S,1);
    double       *y1 = (double*) ssGetOutputPortSignal(S,0);
    double       *y2 = (double*) ssGetOutputPortSignal(S,1);
    unsigned char       *y4 = (unsigned char*) ssGetOutputPortSignal(S,2);
    unsigned char       first, second, third,y40;
    int operation_mode = ssGetIWorkValue(S,0);
    
    if (ssGetIWorkValue(S,1) == 0){
        ssGetIWork(S)[1] = 1;
        if (ssGetIWorkValue(S,0) ==Speed_Control){
            c->send(0x83);//0b1000 0011
            c->send(0x83);
            c->send(0x83);
            c->send(0x83);
            c->send(0x83);
            
        } else {
            c->send(0x81); //0b1000 0001
            c->send(0x81);
            c->send(0x81);
            c->send(0x81);
            c->send(0x81);
        }
    }
    
    unsigned char       *u1 = (unsigned char*) ssGetInputPortSignal(S,0);
    unsigned char       *u2 = (unsigned char*) ssGetInputPortSignal(S,1);
    c->send(u1[0]);
    c->send(u2[0]);
    
    
    unsigned char  *y = c->read();
    
    if ((y[0] & (1<<7)) == 0){ // y[0] & 0b10000000 == 0b00000000
        first   = y[0];
        second  = y[1];
        third   = y[2];
        y40 = 1;
    } else if ( ((y[0] & (1<<7)) > 0) && ((y[1] & (1<<7)) > 0) ){ // y[0] & 0b10000000 == 0b10000000
        first   = y[2];
        second  = y[0];
        third   = y[1];
        y40 = 2;
    } else {
        first   = y[1];
        second  = y[2];
        third   = y[0];
        y40 = 3;
    }
    
    int firstByte = (int)first;
    int secondByte = (int)second;
    int thirdByte = (int)third;
    
    y1[0] = (double)((firstByte<<3) | ((secondByte & 0x70)>>4));
    int tempOut2 = ((secondByte & 0xF)<<6) | ((thirdByte & 0x7E)>>1);
    
    if (operation_mode == Speed_Control){
        if ( (tempOut2 & 0x200) == 0x200) {
            y2[0] = (-1) * (double)(tempOut2 & 0x1FF);
        } else {
            y2[0] = (double)(tempOut2);
        }
    } else if (operation_mode == Position_Control){
        y2[0] = (double)(tempOut2);
    }
    

    y4[0] = operation_mode ; //operation_mode;//y40
    /*
    y1[0] = y[0];
    y2[0] = y[1];
    y3[0] = y[2];
     */
    //UNUSED_ARG(tid); 
}



#undef MDL_UPDATE  /* Change to #undef to remove function */
#if defined(MDL_UPDATE)
  /* Function: mdlUpdate ======================================================
   * Abstract:
   *    This function is called once for every major integration time step.
   *    Discrete states are typically updated here, but this function is useful
   *    for performing any tasks that should only take place once per
   *    integration step.
   */
  static void mdlUpdate(SimStruct *S, int_T tid)
  {
      
  }
#endif /* MDL_UPDATE */



#undef MDL_DERIVATIVES  /* Change to #undef to remove function */
#if defined(MDL_DERIVATIVES)
  /* Function: mdlDerivatives =================================================
   * Abstract:
   *    In this function, you compute the S-function block's derivatives.
   *    The derivatives are placed in the derivative vector, ssGetdX(S).
   */
  static void mdlDerivatives(SimStruct *S)
  {
  }
#endif /* MDL_DERIVATIVES */



/* Function: mdlTerminate =====================================================
 * Abstract:
 *    In this function, you should perform any actions that are necessary
 *    at the termination of a simulation.  For example, if memory was
 *    allocated in mdlStart, this is the place to free it.
 */
static void mdlTerminate(SimStruct *S)
{
    Myusb *c = (Myusb *) ssGetPWork(S)[0]; // retrieve and destroy C++
    unsigned char te = 0x00;
    c->send(te);
    te = 0x80;
    c->send(te);
    
    c->terminate();
    delete c;  
}


/*=============================*
 * Required S-function trailer *
 *=============================*/

#ifdef  MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else
#include "cg_sfun.h"       /* Code generation registration function */
#endif
